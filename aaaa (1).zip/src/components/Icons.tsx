import { cn } from '../utils/cn';

interface IconProps {
  className?: string;
}

export function SpeakerIcon({ muted, className }: IconProps & { muted: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className={cn('h-6 w-6', className)} fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor" />
      {muted ? (
        <>
          <path d="M17 9l5 6" />
          <path d="M22 9l-5 6" />
        </>
      ) : (
        <>
          <path d="M16.5 8.5a5 5 0 0 1 0 7" />
          <path d="M19.5 5.5a9 9 0 0 1 0 13" />
        </>
      )}
    </svg>
  );
}

export function TrophyIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={cn('h-5 w-5', className)} fill="currentColor">
      <path d="M6 3h12v3h3v3a4 4 0 0 1-4 4h-.3A5 5 0 0 1 13 15.9V18h3v3H8v-3h3v-2.1A5 5 0 0 1 7.3 13H7a4 4 0 0 1-4-4V6h3zm0 5H5v1a2 2 0 0 0 1 1.7zm12 0v2.7A2 2 0 0 0 19 9V8z" />
    </svg>
  );
}

export function FlagIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={cn('h-5 w-5', className)} fill="currentColor">
      <path d="M5 2h2v20H5z" />
      <path d="M8 3h11l-3 4 3 4H8z" />
    </svg>
  );
}

export function ArrowIcon({ dir, className }: IconProps & { dir: 'left' | 'right' }) {
  return (
    <svg viewBox="0 0 24 24" className={cn('h-10 w-10', dir === 'left' && 'rotate-180', className)} fill="currentColor">
      <path d="M7 3l12 9-12 9z" />
    </svg>
  );
}

export function StarIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={cn('h-5 w-5', className)} fill="currentColor">
      <path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7L12 17.3 5.8 20.9l1.6-7L2 9.2l7.1-.6z" />
    </svg>
  );
}

export function PauseIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={cn('h-5 w-5', className)} fill="currentColor">
      <path d="M6 4h4v16H6zM14 4h4v16h-4z" />
    </svg>
  );
}
