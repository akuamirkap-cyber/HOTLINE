import { useMemo } from 'react';
import type { CSSProperties, ReactNode, Ref } from 'react';

/**
 * 2D parallax sky that sits BEHIND the transparent WebGL canvas.
 * Every silhouette is stair-stepped on a pixel grid so it reads as "far-away voxels",
 * fades into the same haze colour as the 3D fog, and scrolls with the game camera.
 */

function mul(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const TAU = Math.PI * 2;
/** sharp-peaked periodic wave (tileable for integer k) */
const peak = (u: number, k: number, ph: number) => 1 - Math.abs(Math.sin((u * k) / 2 + ph));
/** soft periodic wave (tileable for integer k) */
const wave = (u: number, k: number, ph: number) => 0.5 + 0.5 * Math.sin(u * k + ph);

const rect = (x: number, y: number, w: number, h: number, fill: string) =>
  '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + fill + '"/>';

function wrap(W: number, H: number, top: string, bottom: string, body: string) {
  const svg =
    '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H +
    '" preserveAspectRatio="none" shape-rendering="crispEdges">' +
    '<defs><linearGradient id="g" gradientUnits="userSpaceOnUse" x1="0" y1="' + Math.round(H * 0.15) + '" x2="0" y2="' + H + '">' +
    '<stop offset="0" stop-color="' + top + '"/><stop offset="1" stop-color="' + bottom + '"/></linearGradient></defs>' +
    body +
    '</svg>';
  return 'url("data:image/svg+xml,' + encodeURIComponent(svg) + '")';
}

type HeightFn = (u: number, x: number, ph: number[]) => number;

/** stair-stepped ridge line (mountains, hills, cloud banks) */
function ridge(
  seed: number,
  W: number,
  H: number,
  step: number,
  fn: HeightFn,
  top: string,
  bottom: string,
  cap?: { color: string; above: number; depth: number },
) {
  const r = mul(seed);
  const ph = [r() * TAU, r() * TAU, r() * TAU, r() * TAU];
  const n = Math.round(W / step);
  let d = 'M0 ' + H;
  let caps = '';
  for (let i = 0; i < n; i++) {
    const raw = fn((i / n) * TAU, i * step, ph);
    const h = Math.max(step, Math.min(H - step, Math.round(raw / step) * step));
    d += 'V' + (H - h) + 'H' + (i + 1) * step;
    if (cap && h > cap.above) {
      caps += rect(i * step, H - h, step, Math.min(cap.depth + (i % 3) * step, h - cap.above), cap.color);
    }
  }
  d += 'V' + H + 'Z';
  return wrap(W, H, top, bottom, '<path d="' + d + '" fill="url(#g)"/>' + caps);
}

/** blocky skyline with lit windows */
function skyline(
  seed: number,
  W: number,
  H: number,
  minH: number,
  maxH: number,
  top: string,
  bottom: string,
  wins: string[],
  lit: number,
) {
  const r = mul(seed);
  let x = 0;
  let body = '';
  let win = '';
  while (x < W) {
    let w = 40 + Math.floor(r() * 7) * 8;
    if (W - (x + w) < 40) w = W - x;
    const h = Math.round((minH + r() * r() * (maxH - minH)) / 8) * 8;
    const y = H - h;
    body += rect(x, y, w, h, 'url(#g)');
    const roof = r();
    if (roof < 0.3) body += rect(x + (w >> 1) - 2, y - 22, 4, 22, 'url(#g)');
    else if (roof < 0.55) body += rect(x + 8, y - 8, w - 16, 8, 'url(#g)');
    for (let wy = y + 10; wy < H - 10; wy += 14) {
      for (let wx = x + 7; wx < x + w - 11; wx += 12) {
        if (r() < lit) win += rect(wx, wy, 6, 7, wins[Math.floor(r() * wins.length)]);
      }
    }
    x += w;
  }
  return wrap(W, H, top, bottom, body + win);
}

function stars(seed: number, W: number, H: number, n: number) {
  const r = mul(seed);
  const cols = ['#ffffff', '#cfe3ff', '#ffe9c2', '#ffd6f2'];
  let body = '';
  for (let i = 0; i < n; i++) {
    const s = r() < 0.2 ? 3 : 2;
    body += rect(Math.floor(r() * (W - 4)), Math.floor(r() * (H - 4)), s, s, cols[Math.floor(r() * cols.length)]);
  }
  return wrap(W, H, '#fff', '#fff', body);
}

const abs: CSSProperties = { position: 'absolute' };

function Par({ url, ratio, top, h, k, opacity }: { url: string; ratio: number; top: number; h: number; k: number; opacity?: number }) {
  const tile = +(ratio * h).toFixed(2);
  return (
    <div
      data-k={k}
      data-ky={0.77}
      data-tile={tile}
      style={{
        ...abs,
        left: 0,
        top: top + 'vh',
        height: h + 'vh',
        width: 'calc(100% + ' + tile + 'vh)',
        backgroundImage: url,
        backgroundRepeat: 'repeat-x',
        backgroundSize: tile + 'vh 100%',
        opacity,
        willChange: 'transform',
      }}
    />
  );
}

function Haze({ rgb }: { rgb: string }) {
  return (
    <div
      data-ky={0.77}
      style={{
        ...abs,
        left: 0,
        right: 0,
        top: '31vh',
        height: '90vh',
        background:
          'linear-gradient(180deg, rgba(' + rgb + ',0) 0%, rgba(' + rgb + ',0.5) 11%, rgba(' + rgb + ',0.93) 21%, rgb(' + rgb + ') 30%)',
      }}
    />
  );
}

function buildScene(placeId: string): { sky: string; nodes: ReactNode } {
  if (placeId === 'tokyo') {
    const fuji = ridge(
      11,
      1800,
      400,
      10,
      (u, x, ph) => {
        const d = Math.max(0, Math.abs(x - 900) - 24);
        const cone = 335 * Math.exp(-d / 205);
        const hills = 46 + 70 * (0.6 * wave(u, 3, ph[0]) + 0.4 * peak(u, 8, ph[1]));
        return Math.max(cone, hills);
      },
      '#7a66a8',
      '#e6a79c',
      { color: '#ffe8e2', above: 240, depth: 20 },
    );
    const bank = ridge(12, 1200, 200, 10, (u, _x, ph) => 30 + 120 * (0.5 * wave(u, 2, ph[0]) + 0.3 * wave(u, 5, ph[1]) + 0.2 * wave(u, 9, ph[2])), '#ffd0b4', '#f3b08f');
    const city = skyline(13, 1280, 240, 50, 235, '#57467e', '#b57c8c', ['#ffd9a0', '#ffe9c4', '#ffb37a'], 0.24);
    return {
      sky: 'linear-gradient(180deg, #232f6b 0%, #4b3f86 14%, #8e5594 26%, #e06d7d 37%, #ff9a5a 46%, #f2b184 54%, #e8b48a 62%, #e8b48a 100%)',
      nodes: (
        <>
          <div data-ky={0.45} style={{ ...abs, left: '56vw', top: '11vh', width: '34vh', height: '34vh' }}>
            <div
              className="bd-pulse"
              style={{ ...abs, inset: '-40%', borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,190,120,0.55) 0%, rgba(255,140,110,0.22) 40%, rgba(255,120,120,0) 68%)' }}
            />
            <div
              style={{
                ...abs,
                inset: 0,
                borderRadius: '50%',
                background: 'linear-gradient(180deg, #fff6bd 0%, #ffd06a 34%, #ff8f62 66%, #f2577f 100%)',
                WebkitMaskImage:
                  'linear-gradient(180deg, #000 0 50%, transparent 50% 52.5%, #000 52.5% 60%, transparent 60% 63.5%, #000 63.5% 70%, transparent 70% 74.5%, #000 74.5% 80%, transparent 80% 85.5%, #000 85.5% 90%, transparent 90% 96%, #000 96%)',
                maskImage:
                  'linear-gradient(180deg, #000 0 50%, transparent 50% 52.5%, #000 52.5% 60%, transparent 60% 63.5%, #000 63.5% 70%, transparent 70% 74.5%, #000 74.5% 80%, transparent 80% 85.5%, #000 85.5% 90%, transparent 90% 96%, #000 96%)',
              }}
            />
          </div>
          <Par url={fuji} ratio={4.5} top={9} h={38} k={0.14} />
          <Par url={bank} ratio={6} top={27} h={20} k={0.2} opacity={0.75} />
          <Par url={city} ratio={5.333} top={27} h={21} k={0.4} />
          <Haze rgb="232,180,138" />
        </>
      ),
    };
  }

  if (placeId === 'shibuya') {
    const starsA = stars(21, 640, 320, 70);
    const starsB = stars(22, 640, 320, 55);
    const far = skyline(23, 1280, 260, 70, 250, '#2b2560', '#3b2d60', ['#ffe9a8', '#ff7ad9', '#7ae7ff', '#ffffff'], 0.3);
    const near = skyline(24, 1280, 240, 50, 215, '#15123a', '#2a2440', ['#ffe066', '#ff5ad2', '#5ad2ff', '#7dff6a'], 0.42);
    const starLayer = (url: string, cls: string): ReactNode => (
      <div className={cls} style={{ ...abs, left: 0, right: 0, top: 0, height: '46vh', backgroundImage: url, backgroundSize: '80vh 40vh' }} />
    );
    return {
      sky: 'linear-gradient(180deg, #05051a 0%, #0e0c30 16%, #1f1650 30%, #3c2468 42%, #55306f 50%, #3a2a58 57%, #2a2440 64%, #2a2440 100%)',
      nodes: (
        <>
          <div style={{ ...abs, inset: 0 }}>
            {starLayer(starsA, 'bd-twinkle-a')}
            {starLayer(starsB, 'bd-twinkle-b')}
            <div className="bd-shoot" style={{ ...abs, left: '78vw', top: '6vh', width: '16vh', height: '0.35vh', borderRadius: '1vh', background: 'linear-gradient(90deg, #ffffff, rgba(255,255,255,0))' }} />
          </div>
          <div data-ky={0.35} style={{ ...abs, left: '13vw', top: '7vh', width: '12vh', height: '12vh' }}>
            <div className="bd-pulse" style={{ ...abs, inset: '-90%', borderRadius: '50%', background: 'radial-gradient(circle, rgba(190,205,255,0.4) 0%, rgba(150,170,255,0.14) 40%, rgba(150,170,255,0) 68%)' }} />
            <div
              style={{
                ...abs,
                inset: 0,
                borderRadius: '50%',
                background:
                  'radial-gradient(circle at 68% 30%, rgba(190,180,140,0.55) 0 9%, transparent 10%), radial-gradient(circle at 36% 62%, rgba(190,180,140,0.5) 0 13%, transparent 14%), radial-gradient(circle at 62% 72%, rgba(190,180,140,0.4) 0 6%, transparent 7%), radial-gradient(circle at 36% 34%, #fffef2 0%, #f4edca 62%, #d8cfa6 100%)',
              }}
            />
          </div>
          <div
            data-ky={0.77}
            style={{ ...abs, left: 0, right: 0, top: '14vh', height: '36vh' }}
          >
            <div
              className="bd-pulse"
              style={{
                ...abs,
                inset: 0,
                background:
                  'radial-gradient(ellipse 42% 70% at 22% 100%, rgba(255,90,210,0.42), rgba(255,90,210,0) 70%), radial-gradient(ellipse 46% 70% at 76% 100%, rgba(90,210,255,0.36), rgba(90,210,255,0) 70%), radial-gradient(ellipse 30% 50% at 50% 100%, rgba(255,224,102,0.2), rgba(255,224,102,0) 70%)',
              }}
            />
          </div>
          <Par url={far} ratio={4.923} top={15} h={31} k={0.18} />
          <Par url={near} ratio={5.333} top={26} h={22} k={0.4} />
          <Haze rgb="42,36,64" />
        </>
      ),
    };
  }

  // Bukit Hijau — bright alpine morning
  const mountains = ridge(
    1,
    1600,
    400,
    10,
    (u, _x, ph) => 110 + 262 * (0.6 * peak(u, 3, ph[0]) + 0.28 * peak(u, 7, ph[1]) + 0.12 * peak(u, 13, ph[2])),
    '#93bfec',
    '#d2ecfd',
    { color: '#ffffff', above: 268, depth: 20 },
  );
  const bank = ridge(2, 1200, 200, 10, (u, _x, ph) => 36 + 130 * (0.5 * wave(u, 2, ph[0]) + 0.3 * wave(u, 5, ph[1]) + 0.2 * wave(u, 9, ph[2])), '#ffffff', '#e4f5ff');
  const hills = ridge(3, 1400, 240, 10, (u, _x, ph) => 60 + 150 * (0.6 * wave(u, 3, ph[0]) + 0.25 * wave(u, 7, ph[1]) + 0.15 * peak(u, 11, ph[2])), '#7fc79a', '#c9eedb');
  return {
    sky: 'linear-gradient(180deg, #1f86f2 0%, #46abff 16%, #7fcbff 30%, #b9e6ff 42%, #e3f6ff 50%, #cdefff 58%, #cdefff 100%)',
    nodes: (
      <>
        <div data-ky={0.35} style={{ ...abs, right: '13vw', top: '6vh', width: '15vh', height: '15vh' }}>
          <div
            className="bd-rays"
            style={{
              ...abs,
              inset: '-95%',
              borderRadius: '50%',
              background: 'repeating-conic-gradient(rgba(255,255,255,0.26) 0deg 8deg, rgba(255,255,255,0) 8deg 22.5deg)',
              WebkitMaskImage: 'radial-gradient(circle, #000 16%, transparent 66%)',
              maskImage: 'radial-gradient(circle, #000 16%, transparent 66%)',
            }}
          />
          <div className="bd-pulse" style={{ ...abs, inset: '-55%', borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,251,214,0.8) 0%, rgba(255,241,170,0.3) 38%, rgba(255,241,170,0) 68%)' }} />
          <div style={{ ...abs, inset: 0, borderRadius: '50%', background: 'radial-gradient(circle at 40% 38%, #ffffff 0%, #fff8c6 46%, #ffe27a 100%)', boxShadow: '0 0 6vh 1vh rgba(255,236,150,0.55)' }} />
        </div>
        <Par url={mountains} ratio={4} top={8} h={39} k={0.16} />
        <Par url={bank} ratio={6} top={26} h={21} k={0.22} opacity={0.9} />
        <Par url={hills} ratio={5.833} top={30} h={18} k={0.4} />
        <Haze rgb="205,239,255" />
      </>
    ),
  };
}

export function Backdrop({ placeId, ref }: { placeId: string; ref?: Ref<HTMLDivElement> }) {
  const scene = useMemo(() => buildScene(placeId), [placeId]);
  return (
    <div ref={ref} className="pointer-events-none absolute inset-0 overflow-hidden" style={{ background: scene.sky }}>
      {scene.nodes}
    </div>
  );
}

/** Called every frame with the game camera position (world metres). */
export function moveBackdrop(root: HTMLElement | null, x: number, y: number) {
  if (!root) return;
  const vh = window.innerHeight / 100;
  const kids = root.children;
  for (let i = 0; i < kids.length; i++) {
    const el = kids[i] as HTMLElement;
    const ds = el.dataset;
    if (!ds.ky) continue;
    let off = 0;
    if (ds.tile) {
      const tile = parseFloat(ds.tile) * vh;
      off = (((x * parseFloat(ds.k || '0') * vh) % tile) + tile) % tile;
    }
    el.style.transform = 'translate3d(' + (-off).toFixed(1) + 'px,' + (y * parseFloat(ds.ky) * vh).toFixed(1) + 'px,0)';
  }
}

/** Soft light-leak + vignette drawn OVER the 3D canvas so sky and voxels feel like one picture. */
export function SkyOverlay({ placeId }: { placeId: string }) {
  const glow =
    placeId === 'shibuya'
      ? 'radial-gradient(ellipse 60% 45% at 18% 0%, rgba(160,180,255,0.16), rgba(160,180,255,0) 70%)'
      : placeId === 'tokyo'
        ? 'radial-gradient(ellipse 70% 55% at 68% 22%, rgba(255,170,110,0.22), rgba(255,170,110,0) 70%)'
        : 'radial-gradient(ellipse 60% 55% at 84% 0%, rgba(255,246,200,0.3), rgba(255,246,200,0) 70%)';
  return (
    <div
      className="pointer-events-none absolute inset-0"
      style={{ background: glow + ', radial-gradient(ellipse at 50% 45%, rgba(12,14,40,0) 58%, rgba(12,14,40,0.3) 100%)' }}
    />
  );
}
