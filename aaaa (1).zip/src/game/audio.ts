type OscType = OscillatorType;

/**
 * Procedural skate SFX (WebAudio, no samples).
 * Ollie + landing are layered the way a real board sounds:
 * tail crack → hollow deck knock → griptape drag, and on touchdown
 * two truck slaps → body thump → hardware rattle → roll-away.
 */
export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private white: AudioBuffer | null = null;
  private rollGain: GainNode | null = null;
  private rollFilter: BiquadFilterNode | null = null;
  private hissGain: GainNode | null = null;
  private hissFilter: BiquadFilterNode | null = null;
  private windGain: GainNode | null = null;
  private windFilter: BiquadFilterNode | null = null;
  private lastT = 0;
  private crackAcc = 0;
  private crackGap = 3;
  muted = false;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    const AC: typeof AudioContext | undefined =
      window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    const master = ctx.createGain();
    master.gain.value = this.muted ? 0 : 0.6;
    // gentle bus compressor: layered hits stay punchy without clipping
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.knee.value = 12;
    comp.ratio.value = 5;
    comp.attack.value = 0.003;
    comp.release.value = 0.18;
    master.connect(comp).connect(ctx.destination);
    this.master = master;

    const len = ctx.sampleRate * 2;
    // soft (low-passed) noise: rumble, thumps, wind
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    // bright white noise: clicks, cracks, griptape
    const wbuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const wd = wbuf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      last = last * 0.6 + w * 0.4;
      d[i] = last * 1.6;
      wd[i] = w;
    }
    this.noise = buf;
    this.white = wbuf;

    // rolling rumble loop
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.loop = true;
    const rf = ctx.createBiquadFilter();
    rf.type = 'lowpass';
    rf.frequency.value = 400;
    rf.Q.value = 2;
    const rg = ctx.createGain();
    rg.gain.value = 0;
    src.connect(rf).connect(rg).connect(master);
    src.start();
    this.rollFilter = rf;
    this.rollGain = rg;

    // urethane-on-asphalt hiss loop
    const src3 = ctx.createBufferSource();
    src3.buffer = wbuf;
    src3.loop = true;
    src3.playbackRate.value = 0.9;
    const hf = ctx.createBiquadFilter();
    hf.type = 'bandpass';
    hf.frequency.value = 2800;
    hf.Q.value = 0.8;
    const hg = ctx.createGain();
    hg.gain.value = 0;
    src3.connect(hf).connect(hg).connect(master);
    src3.start();
    this.hissFilter = hf;
    this.hissGain = hg;

    // wind loop
    const src2 = ctx.createBufferSource();
    src2.buffer = buf;
    src2.loop = true;
    src2.playbackRate.value = 0.7;
    const wf = ctx.createBiquadFilter();
    wf.type = 'bandpass';
    wf.frequency.value = 900;
    wf.Q.value = 0.6;
    const wg = ctx.createGain();
    wg.gain.value = 0;
    src2.connect(wf).connect(wg).connect(master);
    src2.start();
    this.windFilter = wf;
    this.windGain = wg;
    this.lastT = ctx.currentTime;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.6, this.ctx.currentTime, 0.02);
  }

  update(speed: number, grounded: boolean, active: boolean) {
    const ctx = this.ctx;
    if (!ctx || !this.rollGain || !this.rollFilter || !this.windGain || !this.windFilter) return;
    const t = ctx.currentTime;
    const dt = Math.min(0.1, Math.max(0, t - this.lastT));
    this.lastT = t;
    const rolling = active && grounded;
    const roll = rolling ? Math.min(0.3, 0.05 + speed * 0.02) : 0;
    this.rollGain.gain.setTargetAtTime(roll, t, 0.04);
    this.rollFilter.frequency.setTargetAtTime(160 + speed * 55, t, 0.08);
    if (this.hissGain && this.hissFilter) {
      this.hissGain.gain.setTargetAtTime(rolling ? Math.min(0.06, speed * 0.0034) : 0, t, 0.05);
      this.hissFilter.frequency.setTargetAtTime(2400 + speed * 110, t, 0.1);
    }
    const wind = active ? Math.min(0.22, Math.max(0, speed - 5) * 0.014) * (grounded ? 0.45 : 1) : 0;
    this.windGain.gain.setTargetAtTime(wind, t, 0.15);
    this.windFilter.frequency.setTargetAtTime(500 + speed * 60, t, 0.2);

    // pavement cracks: front wheels tick, rear wheels follow a wheelbase later ("tk-tk … tk-tk")
    if (rolling && speed > 2.5) {
      this.crackAcc += speed * dt;
      if (this.crackAcc > this.crackGap) {
        this.crackAcc = 0;
        this.crackGap = 2.4 + Math.random() * 2.6;
        const v = Math.min(0.2, 0.05 + speed * 0.007);
        const wb = Math.min(0.14, 1.24 / speed);
        this.tick(t, v);
        this.tick(t + wb, v * 0.85);
      }
    }
  }

  private tick(t0: number, v: number) {
    this.burst(t0, 0.024, v, 'bandpass', 1150, 720, 2, false, 0.001);
    this.tone(190, t0, 0.03, 'sine', v * 0.6, 120, 0.001);
  }

  private tone(freq: number, t0: number, dur: number, type: OscType, vol: number, endFreq?: number, attack = 0.008) {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(this.master);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }

  private burst(
    t0: number,
    dur: number,
    vol: number,
    type: BiquadFilterType,
    f0: number,
    f1?: number,
    q = 1,
    bright = false,
    attack = 0.006,
  ) {
    const ctx = this.ctx;
    const buf = bright ? this.white : this.noise;
    if (!ctx || !this.master || !buf) return;
    const s = ctx.createBufferSource();
    s.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(f0, t0);
    if (f1) f.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    s.connect(f).connect(g).connect(this.master);
    s.start(t0, Math.random() * 1.5);
    s.stop(t0 + dur + 0.05);
  }

  /** compat helper for the older single-layer bursts */
  private noiseBurst(t0: number, dur: number, vol: number, type: BiquadFilterType, f0: number, f1?: number, q = 1) {
    this.burst(t0, dur, vol, type, f0, f1, q, false, 0.006);
  }

  /** OLLIE: tail cracks on the concrete, the deck rings, the front foot drags up the griptape */
  pop() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const p = 0.94 + Math.random() * 0.12;
    // tail crack
    this.burst(t, 0.036, 0.9, 'bandpass', 1900 * p, 1150 * p, 1.4, true, 0.001);
    this.burst(t, 0.012, 0.45, 'highpass', 5200, undefined, 0.7, true, 0.0006);
    // hollow 7-ply deck knock
    this.tone(430 * p, t, 0.07, 'triangle', 0.32, 205 * p, 0.002);
    this.tone(880 * p, t, 0.035, 'sine', 0.12, 520 * p, 0.001);
    // push-off thump
    this.tone(150, t, 0.11, 'sine', 0.38, 62, 0.003);
    // griptape drag
    this.burst(t + 0.034, 0.13, 0.17, 'bandpass', 3200, 6200, 0.9, true, 0.03);
    // wheels spinning free
    this.burst(t + 0.05, 0.24, 0.045, 'bandpass', 2500, 1500, 6, true, 0.05);
  }

  /** LANDING: back truck then front truck slap down, body weight, hardware rattle, roll-away */
  land(intensity: number, clean = false) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = Math.min(1, 0.32 + intensity * 0.055);
    const p = 0.94 + Math.random() * 0.12;
    const gap = clean ? 0.008 : 0.03 + Math.random() * 0.02;
    for (let i = 0; i < 2; i++) {
      const t0 = t + i * gap;
      const k = i === 0 ? 1 : 0.8;
      // urethane wheels slapping asphalt
      this.burst(t0, 0.05, 0.75 * v * k, 'bandpass', 950 * p, 520 * p, 1.1, false, 0.001);
      this.burst(t0, 0.016, 0.38 * v * k, 'highpass', 4200, undefined, 0.7, true, 0.0006);
      // deck + truck knock
      this.tone((330 - i * 40) * p, t0, 0.06, 'triangle', 0.26 * v * k, 170 * p, 0.002);
    }
    // body weight coming down
    this.tone(118, t, 0.2, 'sine', 0.6 * v, 44, 0.004);
    this.burst(t, 0.16, 0.4 * v, 'lowpass', 520, 140, 0.8, false, 0.004);
    // bearings / hardware rattle
    this.burst(t + gap + 0.02, 0.1, 0.12 * v, 'bandpass', 5200, 3600, 3, true, 0.01);
    // roll-away surge
    this.burst(t + gap + 0.03, 0.34, 0.2 * v, 'bandpass', 700, 380, 0.8, false, 0.06);
  }

  /** feet catch the board after a trick */
  catchBoard(chain = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    // every extra trick in the same air climbs a whole tone → combos sing upwards
    const p = Math.pow(2, (Math.min(Math.max(chain, 1), 7) - 1) / 6);
    this.burst(t, 0.03, 0.34, 'bandpass', 1500, 900, 1.6, true, 0.001);
    this.tone(300, t, 0.05, 'triangle', 0.2, 180, 0.002);
    this.tone(1175 * p, t + 0.01, 0.09, 'triangle', 0.11);
    this.tone(1568 * p, t + 0.07, 0.16, 'triangle', 0.11);
    this.burst(t + 0.05, 0.22, 0.045, 'highpass', 7000, undefined, 0.7, true, 0.02);
  }

  /** board whirring through a flip / spin: quick rising "fwip-fwip-fwip" */
  spin(dur = 0.5) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const n = Math.max(3, Math.round(dur / 0.13));
    for (let i = 0; i < n; i++) {
      const t0 = t + (i * dur * 0.8) / n;
      this.burst(t0, 0.085, 0.17, 'bandpass', 800 + i * 320, 2100 + i * 420, 2.6, true, 0.02);
    }
    this.burst(t, dur * 0.9, 0.12, 'bandpass', 500, 1700, 1.1, false, dur * 0.3);
  }

  /** hand reaching down and slapping onto the deck */
  grab() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.burst(t, 0.17, 0.18, 'bandpass', 650, 1500, 1.2, false, 0.05);
    this.burst(t + 0.12, 0.03, 0.36, 'bandpass', 1350, 900, 1.8, true, 0.001);
    this.tone(240, t + 0.12, 0.055, 'triangle', 0.2, 150, 0.002);
  }

  /** hollow plastic "bonk" of a traffic cone getting punted */
  coneHit() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(310, t, 0.17, 'sine', 0.55, 165, 0.002);
    this.tone(620, t, 0.08, 'triangle', 0.22, 400, 0.002);
    this.burst(t, 0.06, 0.5, 'bandpass', 820, 560, 3, false, 0.001);
    this.burst(t + 0.02, 0.12, 0.14, 'bandpass', 2600, 1400, 1.2, true, 0.02);
  }

  /** cone bouncing along the road */
  coneTok(intensity: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = Math.min(1, 0.25 + intensity * 0.5);
    this.tone(250 + Math.random() * 90, t, 0.09, 'sine', 0.3 * v, 150, 0.002);
    this.burst(t, 0.03, 0.24 * v, 'bandpass', 900, 600, 4, false, 0.001);
  }

  /** cleared a cone in the air: rising blip per cone */
  coneClear(n: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const f = 660 * Math.pow(2, (Math.min(n, 8) - 1) / 6);
    this.tone(f, t, 0.07, 'triangle', 0.13);
    this.tone(f * 1.5, t + 0.05, 0.12, 'triangle', 0.12);
  }

  /** sketchy save: wheels chirp + thud */
  save() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.burst(t, 0.2, 0.3, 'bandpass', 1900, 850, 5, true, 0.01);
    this.tone(140, t, 0.16, 'sine', 0.5, 58, 0.003);
    this.burst(t, 0.07, 0.4, 'bandpass', 900, 500, 1.2, false, 0.001);
  }

  coin(pitch = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(988 * pitch, t, 0.07, 'square', 0.09);
    this.tone(1319 * pitch, t + 0.065, 0.2, 'square', 0.09);
  }

  trick(level = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const notes = [523, 659, 784, 1047, 1319];
    const n = Math.min(notes.length, 3 + level);
    for (let i = 0; i < n; i++) this.tone(notes[i], t + i * 0.06, 0.16, 'triangle', 0.22);
  }

  perfect() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(1568, t, 0.12, 'sine', 0.2);
    this.tone(2093, t + 0.08, 0.25, 'sine', 0.18);
    this.burst(t + 0.02, 0.3, 0.06, 'highpass', 6500, undefined, 0.7, true, 0.02);
  }

  crash() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(110, t, 0.35, 'sine', 0.8, 35);
    this.noiseBurst(t, 0.35, 0.8, 'lowpass', 1400, 120);
    this.noiseBurst(t + 0.02, 0.15, 0.4, 'bandpass', 2400, 800, 2);
    // the board clattering away
    this.burst(t + 0.09, 0.04, 0.4, 'bandpass', 1700, 1100, 1.5, true, 0.001);
    this.burst(t + 0.2, 0.035, 0.26, 'bandpass', 1500, 1000, 1.5, true, 0.001);
  }

  thud(intensity: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = Math.min(1, 0.15 + intensity * 0.12);
    this.tone(105 + Math.random() * 50, t, 0.14, 'sine', 0.55 * v, 46, 0.003);
    this.noiseBurst(t, 0.09, 0.38 * v, 'lowpass', 650, 140);
    // soft, squishy body slap
    this.burst(t, 0.04, 0.16 * v, 'bandpass', 1200, 700, 1, false, 0.002);
  }

  squawk() {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const t = ctx.currentTime;
    for (let k = 0; k < 2; k++) {
      const t0 = t + 0.05 + k * 0.2;
      const f = 480 + Math.random() * 120;
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(f, t0);
      o.frequency.linearRampToValueAtTime(f * 1.9, t0 + 0.035);
      o.frequency.linearRampToValueAtTime(f * 1.35, t0 + 0.11);
      o.frequency.linearRampToValueAtTime(f * 0.75, t0 + 0.18);
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 42;
      const lg = ctx.createGain();
      lg.gain.value = 110;
      lfo.connect(lg).connect(o.frequency);
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = 1500;
      bp.Q.value = 2.2;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.55, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.19);
      o.connect(bp).connect(g).connect(this.master);
      o.start(t0);
      o.stop(t0 + 0.22);
      lfo.start(t0);
      lfo.stop(t0 + 0.22);
    }
  }

  splash() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.6, 0.7, 'lowpass', 4000, 250);
    this.noiseBurst(t + 0.05, 0.3, 0.3, 'bandpass', 1800, 600, 1.5);
    this.tone(300, t, 0.2, 'sine', 0.25, 90);
  }

  grindStart() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.burst(t, 0.25, 0.4, 'bandpass', 3200, 1400, 2, true, 0.004);
    this.tone(1800, t, 0.15, 'square', 0.06, 900);
  }

  whoosh() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.25, 0.25, 'bandpass', 600, 1800, 1.2);
  }

  dispose() {
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
  }
}
