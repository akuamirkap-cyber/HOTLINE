import * as THREE from 'three';

/**
 * Freestyle FX primitives.
 *  - Ribbon: a camera-facing light streak that follows one point (a board corner). Four of them
 *    turn every flip into a double helix and every shuv-it into looping curves.
 *  - Rings: expanding shock-rings for trick start / catch.
 *  - makeGlowTexture: soft radial sprite used as the aura behind the board.
 * Everything is additive + fog-free so it glows over both the voxels and the 2D sky.
 */

interface Pt {
  x: number;
  y: number;
  z: number;
  t: number;
  r: number;
  g: number;
  b: number;
  /** first point of a new stroke (don't connect to the previous one) */
  brk: boolean;
}

export class Ribbon {
  mesh: THREE.Mesh;
  private life: number;
  private width: number;
  private alpha: number;
  private max: number;
  private pts: Pt[] = [];
  private pos: Float32Array;
  private col: Float32Array;
  private geo: THREE.BufferGeometry;

  constructor(life = 0.45, width = 0.09, alpha = 0.9, max = 80) {
    this.life = life;
    this.width = width;
    this.alpha = alpha;
    this.max = max;
    this.pos = new Float32Array(max * 2 * 3);
    this.col = new Float32Array(max * 2 * 4);
    const idx = new Uint16Array((max - 1) * 6);
    for (let i = 0; i < max - 1; i++) {
      const a = i * 2;
      idx.set([a, a + 1, a + 2, a + 1, a + 3, a + 2], i * 6);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute('color', new THREE.BufferAttribute(this.col, 4).setUsage(THREE.DynamicDrawUsage));
    geo.setIndex(new THREE.BufferAttribute(idx, 1));
    geo.setDrawRange(0, 0);
    this.geo = geo;
    const mat = new THREE.MeshBasicMaterial({
      vertexColors: true,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
      fog: false,
      toneMapped: false,
    });
    this.mesh = new THREE.Mesh(geo, mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 5;
  }

  push(x: number, y: number, z: number, color: THREE.Color, time: number, brk = false) {
    if (this.pts.length >= this.max) this.pts.shift();
    this.pts.push({ x, y, z, t: time, r: color.r, g: color.g, b: color.b, brk });
  }

  update(now: number) {
    const pts = this.pts;
    while (pts.length && now - pts[0].t > this.life) pts.shift();
    const n = pts.length;
    const pos = this.pos;
    const col = this.col;
    let nx = 0;
    let ny = 1;
    for (let i = 0; i < n; i++) {
      const p = pts[i];
      const nextBrk = i + 1 < n && pts[i + 1].brk;
      const a = i > 0 && !p.brk ? pts[i - 1] : p;
      const b = i + 1 < n && !nextBrk ? pts[i + 1] : p;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const l = Math.hypot(dx, dy);
      if (l > 1e-4) {
        nx = -dy / l;
        ny = dx / l;
      }
      const k = Math.max(0, 1 - (now - p.t) / this.life); // 1 = fresh, 0 = gone
      // fat and white-hot at the head, thinning into a coloured thread at the tail
      const w = this.width * (0.18 + 0.82 * k * k);
      const al = p.brk || nextBrk ? 0 : k * (0.35 + 0.65 * k) * this.alpha;
      const hot = k * k * k * 0.7;
      const r = p.r + (1 - p.r) * hot;
      const g = p.g + (1 - p.g) * hot;
      const bl = p.b + (1 - p.b) * hot;
      const o = i * 6;
      pos[o] = p.x + nx * w;
      pos[o + 1] = p.y + ny * w;
      pos[o + 2] = p.z;
      pos[o + 3] = p.x - nx * w;
      pos[o + 4] = p.y - ny * w;
      pos[o + 5] = p.z;
      const c = i * 8;
      col[c] = col[c + 4] = r;
      col[c + 1] = col[c + 5] = g;
      col[c + 2] = col[c + 6] = bl;
      col[c + 3] = col[c + 7] = al;
    }
    this.geo.setDrawRange(0, Math.max(0, n - 1) * 6);
    this.geo.attributes.position.needsUpdate = true;
    this.geo.attributes.color.needsUpdate = true;
  }

  clear() {
    this.pts.length = 0;
    this.geo.setDrawRange(0, 0);
  }
}

interface RingItem {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  t: number;
  life: number;
  size: number;
}

export class Rings {
  group = new THREE.Group();
  private items: RingItem[] = [];
  private next = 0;

  constructor(n = 8) {
    const geo = new THREE.RingGeometry(0.87, 1, 48);
    for (let i = 0; i < n; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
        side: THREE.DoubleSide,
        fog: false,
        toneMapped: false,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      mesh.renderOrder = 6;
      this.group.add(mesh);
      this.items.push({ mesh, mat, t: 0, life: 0, size: 1 });
    }
  }

  spawn(x: number, y: number, z: number, color: THREE.ColorRepresentation, size: number, life: number) {
    const it = this.items[this.next];
    this.next = (this.next + 1) % this.items.length;
    it.t = 0;
    it.life = life;
    it.size = size;
    it.mat.color.set(color);
    it.mesh.position.set(x, y, z);
    it.mesh.rotation.z = Math.random() * Math.PI;
    it.mesh.visible = true;
  }

  update(dt: number) {
    for (const it of this.items) {
      if (!it.mesh.visible) continue;
      it.t += dt;
      const u = it.t / it.life;
      if (u >= 1) {
        it.mesh.visible = false;
        continue;
      }
      const e = 1 - Math.pow(1 - u, 3); // ease-out: snaps open, then drifts
      const s = it.size * (0.2 + 0.8 * e);
      it.mesh.scale.set(s, s, s);
      it.mat.opacity = (1 - u) * (1 - u) * 0.9;
    }
  }

  clear() {
    for (const it of this.items) it.mesh.visible = false;
  }
}

/** soft radial glow, built numerically (no canvas needed) */
export function makeGlowTexture(size = 64): THREE.DataTexture {
  const data = new Uint8Array(size * size * 4);
  const h = (size - 1) / 2;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const d = Math.min(1, Math.hypot(x - h, y - h) / h);
      const f = Math.pow(1 - d, 2.2);
      const o = (y * size + x) * 4;
      data[o] = data[o + 1] = data[o + 2] = 255;
      data[o + 3] = Math.round(f * 255);
    }
  }
  const tex = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearFilter;
  tex.needsUpdate = true;
  return tex;
}
