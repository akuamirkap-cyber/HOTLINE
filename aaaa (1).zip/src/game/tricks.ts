/**
 * Freestyle trick catalog — ported from the Pigeon SK8 game (akuamirkap-cyber/pigeon-baru-bgt).
 * Every trick keeps its original name, points, duration and SIGNATURE motion formula
 * (board flip / board yaw / board pitch, rider yaw / roll / pitch, grab), adapted to the side view.
 */
export type TrickKind =
  | 'kickflip'
  | 'salto'
  | 'heelflip'
  | 'spinL'
  | 'spinR'
  | 'shuvit'
  | 'impossible'
  | 'method'
  | 'indy'
  | 'wingflap'
  | 'coo540'
  | 'varial'
  | 'treflip'
  | 'hardflip'
  | 'laser'
  | 'inward'
  | 'dblflip'
  | 'pressure'
  | 'fingerflip'
  | 'hospital'
  | 'bigspin'
  | 'gazelle'
  | 'shifty'
  | 'air720'
  | 'melon'
  | 'nosegrab'
  | 'tailgrab'
  | 'stalefish'
  | 'benihana'
  | 'rocket'
  | 'christ'
  | 'airwalk'
  | 'heli'
  | 'tornado'
  | 'gyro';

export type TrickFamily = 'flip' | 'grab' | 'spin';

export interface TrickDef {
  kind: TrickKind;
  name: string;
  pts: number;
  color: string;
  dur: number;
  family: TrickFamily;
  bigAirOnly?: boolean;
  desc: string;
}

export const TRICKS: TrickDef[] = [
  // —— FLIP & SHUV family ——
  { kind: 'kickflip', name: 'KICKFLIP', pts: 50, color: '#ffd60a', dur: 0.42, family: 'flip', desc: 'Papan berputar 360° di sumbu panjang' },
  { kind: 'heelflip', name: 'HEELFLIP', pts: 50, color: '#ffd60a', dur: 0.42, family: 'flip', desc: 'Kebalikan kickflip, diputar tumit' },
  { kind: 'shuvit', name: 'POP SHUV-IT', pts: 70, color: '#f4a261', dur: 0.4, family: 'flip', desc: 'Papan berputar 180° horizontal' },
  { kind: 'varial', name: 'VARIAL FLIP', pts: 90, color: '#ffd60a', dur: 0.45, family: 'flip', desc: 'Kickflip + shuv-it combo' },
  { kind: 'inward', name: 'INWARD HEEL', pts: 110, color: '#ffd60a', dur: 0.48, family: 'flip', desc: 'Heelflip + shuv-it combo' },
  { kind: 'hardflip', name: 'HARDFLIP', pts: 120, color: '#ffb703', dur: 0.5, family: 'flip', desc: 'Hidung papan mencelat curam (wrap-around)' },
  { kind: 'fingerflip', name: 'FINGER FLIP', pts: 90, color: '#ffd60a', dur: 0.42, family: 'flip', desc: 'Papan disentil dengan tangan' },
  { kind: 'pressure', name: 'PRESSURE FLIP', pts: 130, color: '#ffb703', dur: 0.5, family: 'flip', desc: 'Papan berputar diagonal' },
  { kind: 'dblflip', name: 'DOUBLE FLIP', pts: 140, color: '#ffc93c', dur: 0.52, family: 'flip', desc: 'Kickflip berputar DUA kali' },
  { kind: 'hospital', name: 'HOSPITAL FLIP', pts: 150, color: '#80ed99', dur: 0.6, family: 'flip', desc: 'Papan berputar lalu BALIK sendiri' },
  { kind: 'impossible', name: 'IMPOSSIBLE', pts: 150, color: '#c77dff', dur: 0.6, family: 'flip', desc: 'Papan membungkus kaki belakang' },
  { kind: 'treflip', name: '360 FLIP', pts: 180, color: '#ff9f1c', dur: 0.55, family: 'flip', desc: 'Flip + shuv-it 360° legendaris' },
  { kind: 'laser', name: 'LASER FLIP', pts: 200, color: '#c77dff', dur: 0.6, family: 'flip', desc: 'Double heelflip + shuv-it 360°' },
  { kind: 'heli', name: 'HELIKOPTER 720', pts: 190, color: '#5ef2ff', dur: 0.62, family: 'flip', desc: 'Papan berputar 720° datar seperti baling-baling' },
  { kind: 'tornado', name: 'TORNADO FLIP', pts: 240, color: '#ff6ad5', dur: 0.68, family: 'flip', desc: 'Double flip + putar 720° + badan ikut 360°' },
  { kind: 'gyro', name: 'GYRO SPIN', pts: 210, color: '#b8ff5a', dur: 0.64, family: 'flip', desc: 'Papan jungkir balik ujung-ke-ujung sambil flip' },
  // —— GRAB & STYLE family ——
  { kind: 'indy', name: 'INDY GRAB', pts: 80, color: '#ff5c8a', dur: 0.45, family: 'grab', desc: 'Papan ditarik ke bawah badan' },
  { kind: 'method', name: 'METHOD GRAB', pts: 90, color: '#ff5c8a', dur: 0.5, family: 'grab', desc: 'Papan ditarik ke belakang' },
  { kind: 'melon', name: 'MELON GRAB', pts: 130, color: '#ff5c8a', dur: 0.5, family: 'grab', desc: 'Grab menyilang, papan ditweak ke depan' },
  { kind: 'nosegrab', name: 'NOSE GRAB', pts: 100, color: '#ff5c8a', dur: 0.45, family: 'grab', desc: 'Pegang hidung papan, badan merunduk' },
  { kind: 'tailgrab', name: 'TAIL GRAB', pts: 100, color: '#ff5c8a', dur: 0.45, family: 'grab', desc: 'Pegang ekor papan di udara' },
  { kind: 'stalefish', name: 'STALEFISH', pts: 120, color: '#ff85a1', dur: 0.48, family: 'grab', desc: 'Grab klasik miring ke belakang' },
  { kind: 'benihana', name: 'BENIHANA', pts: 140, color: '#ff85a1', dur: 0.52, family: 'grab', desc: 'Kaki menendang lepas, badan menukik' },
  { kind: 'wingflap', name: 'WING FLAP', pts: 60, color: '#80ed99', dur: 0.55, family: 'grab', bigAirOnly: true, desc: 'Kepak sayap/lengan heboh (big air)' },
  { kind: 'rocket', name: 'ROCKET AIR', pts: 160, color: '#ff6b6b', dur: 0.55, family: 'grab', bigAirOnly: true, desc: 'Papan menunjuk lurus ke bawah (big air)' },
  { kind: 'christ', name: 'CHRIST AIR', pts: 110, color: '#ffe066', dur: 0.6, family: 'grab', bigAirOnly: true, desc: 'Tangan terbentang huruf T (big air)' },
  { kind: 'airwalk', name: 'AIRWALK', pts: 120, color: '#a0e7ff', dur: 0.55, family: 'grab', desc: 'Kaki melayang di atas papan, badan tegak' },
  // —— SPIN family ——
  { kind: 'shifty', name: 'SHIFTY AIR', pts: 80, color: '#4cc9f0', dur: 0.45, family: 'spin', desc: 'Putar badan lalu kembali' },
  { kind: 'spinL', name: 'BS 360', pts: 100, color: '#4cc9f0', dur: 0.55, family: 'spin', desc: 'Badan + papan putar 360° backside' },
  { kind: 'spinR', name: 'FS 360', pts: 100, color: '#4cc9f0', dur: 0.55, family: 'spin', desc: 'Badan + papan putar 360° frontside' },
  { kind: 'salto', name: 'SALTO', pts: 220, color: '#ff6ad5', dur: 0.7, family: 'spin', desc: 'Salto badan penuh di atas papan' },
  { kind: 'gazelle', name: 'GAZELLE', pts: 170, color: '#38bdf8', dur: 0.6, family: 'spin', desc: 'Barrel roll badan, papan kontra-putar' },
  { kind: 'bigspin', name: 'BIG SPIN', pts: 150, color: '#4cc9f0', dur: 0.55, family: 'spin', bigAirOnly: true, desc: 'Badan 180° + papan 360° (big air)' },
  { kind: 'coo540', name: 'COO 540', pts: 200, color: '#ff9f1c', dur: 0.62, family: 'spin', bigAirOnly: true, desc: 'Putar 540° (big air)' },
  { kind: 'air720', name: 'COO 720', pts: 300, color: '#ff9f1c', dur: 0.7, family: 'spin', bigAirOnly: true, desc: 'Cork 720: dua putaran penuh (big air)' },
];

export const TRICK_MAP = Object.fromEntries(TRICKS.map((t) => [t.kind, t])) as Record<TrickKind, TrickDef>;

export const FAMILY_ORDER: Record<TrickFamily, TrickKind[]> = {
  flip: TRICKS.filter((t) => t.family === 'flip').map((t) => t.kind),
  grab: TRICKS.filter((t) => t.family === 'grab').map((t) => t.kind),
  spin: TRICKS.filter((t) => t.family === 'spin').map((t) => t.kind),
};

export const FAMILY_LABEL: Record<TrickFamily, string> = { flip: 'FLIP', grab: 'GRAB', spin: 'SPIN' };

/** Varied freestyle cycle for the left-mouse freestyle button: flip/grab/spin interleaved */
/** S key (hold): the classic grab poses */
export const GRAB_HOLD_CYCLE: TrickKind[] = ['indy', 'melon', 'airwalk'];

export const FREESTYLE_CYCLE: TrickKind[] = [
  'treflip', 'heli', 'spinL', 'varial', 'tornado', 'indy', 'gyro', 'kickflip', 'gazelle', 'impossible',
  'melon', 'laser', 'spinR', 'hardflip', 'airwalk', 'dblflip', 'salto', 'heelflip', 'method', 'shuvit',
  'shifty', 'inward', 'nosegrab', 'bigspin', 'fingerflip', 'tailgrab', 'coo540', 'pressure', 'stalefish',
  'air720', 'hospital', 'benihana', 'rocket', 'wingflap', 'christ',
];
export const FAMILY_KEY: Record<TrickFamily, string> = { flip: 'Z', grab: 'X', spin: 'C' };

export interface TrickPose {
  flip: number;
  yaw: number;
  grab: number;
  boardYaw: number;
  trickRoll: number;
  trickPitch: number;
  boardPitch: number;
  salto: number;
  hop: number;
  /** rider floats above the board (airwalk) */
  lift: number;
  /** board drops away below the feet (end-over-end spins) */
  boardDrop: number;
}

export const ZERO_POSE: TrickPose = { flip: 0, yaw: 0, grab: 0, boardYaw: 0, trickRoll: 0, trickPitch: 0, boardPitch: 0, salto: 0, hop: 0, lift: 0, boardDrop: 0 };

const FLIP_HOP = new Set<TrickKind>([
  'kickflip', 'heelflip', 'shuvit', 'impossible', 'varial', 'inward', 'hardflip', 'fingerflip', 'pressure', 'dblflip', 'hospital', 'treflip', 'laser', 'bigspin', 'heli', 'tornado', 'gyro',
]);

const easeInOut = (u: number) => (u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2);
const smooth = (u: number) => u * u * (3 - 2 * u);

/** Motion formulas ported 1:1 from the Pigeon SK8 engine. */
export function trickPose(kind: TrickKind, t: number, dur: number, dir: number): TrickPose {
  const u = Math.min(1, Math.max(0, t / dur));
  const e = easeInOut(u);
  const hump = Math.sin(Math.PI * u);
  const P: TrickPose = { ...ZERO_POSE };
  const PI = Math.PI;
  switch (kind) {
    case 'kickflip': P.flip = e * PI * 2; break;
    case 'heelflip': P.flip = -e * PI * 2; break;
    case 'salto': P.flip = dir * e * PI * 2; P.salto = -PI * 2 * dir * smooth(u); break;
    case 'spinL': P.yaw = e * PI * 2; break;
    case 'spinR': P.yaw = -e * PI * 2; break;
    case 'shuvit': P.boardYaw = e * PI; break;
    case 'impossible': P.flip = e * PI * 2; P.boardYaw = e * PI; break;
    case 'method': P.grab = hump; break;
    case 'indy': P.grab = -hump; break;
    case 'wingflap': P.grab = hump * 0.3; break;
    case 'coo540': P.yaw = dir * e * PI * 3; break;
    case 'varial': P.flip = e * PI * 2; P.boardYaw = e * PI; P.boardPitch = hump * 0.25; break;
    case 'inward': P.flip = -e * PI * 2; P.boardYaw = e * PI; P.boardPitch = -hump * 0.3; break;
    case 'hardflip': P.flip = e * PI * 2; P.boardYaw = -e * PI; P.boardPitch = hump * 0.75; break;
    case 'fingerflip': P.flip = e * PI * 2; P.grab = -hump * 0.55; P.boardPitch = hump * 0.15; P.trickPitch = hump * 0.2; break;
    case 'pressure': P.flip = -e * PI * 2; P.boardYaw = -e * PI; P.boardPitch = hump * 0.85; break;
    case 'dblflip': P.flip = e * PI * 4; P.boardPitch = hump * 0.12; break;
    case 'hospital': P.flip = hump * PI * 2; P.boardYaw = hump * PI; P.boardPitch = hump * 0.2; break;
    case 'treflip': P.flip = e * PI * 2; P.boardYaw = e * PI * 2; P.boardPitch = hump * 0.3; break;
    case 'laser': P.flip = -e * PI * 4; P.boardYaw = e * PI * 2; P.boardPitch = hump * 0.25; break;
    case 'shifty': P.yaw = hump * PI * 0.75; P.trickRoll = hump * 0.25; break;
    case 'bigspin': P.yaw = e * PI; P.boardYaw = e * PI * 2; P.trickPitch = hump * 0.2; break;
    case 'gazelle': P.trickRoll = e * PI * 2; P.yaw = e * PI; P.boardYaw = -e * PI * 2; break;
    case 'air720': P.yaw = dir * e * PI * 4; P.trickRoll = dir * hump * 0.85; break;
    case 'melon': P.yaw = hump * 0.6; P.grab = -hump; P.trickRoll = hump * 0.35; P.boardPitch = hump * 0.6; break;
    case 'nosegrab': P.grab = hump * 0.6; P.boardPitch = hump * 0.55; P.trickPitch = hump * 0.4; break;
    case 'tailgrab': P.grab = -hump * 0.75; P.boardPitch = -hump * 0.55; P.trickPitch = -hump * 0.4; break;
    case 'stalefish': P.grab = -hump; P.boardYaw = -hump * 0.2; P.yaw = hump * 0.3; P.trickRoll = -hump * 0.45; break;
    case 'benihana': P.grab = hump * 0.5; P.yaw = -hump * 0.4; P.trickPitch = hump * 0.55; break;
    case 'rocket': P.grab = -hump * 0.9; P.boardPitch = -hump * 0.8; P.trickPitch = -hump * 0.25; break;
    case 'christ': P.grab = hump * 0.25; P.boardPitch = hump * 0.25; P.trickRoll = hump * 0.08; break;
    case 'airwalk': P.lift = hump * 0.42; P.trickPitch = hump * 0.12; P.boardPitch = hump * 0.4; break;
    case 'heli': P.boardYaw = e * PI * 4; P.lift = hump * 0.2; P.trickPitch = hump * 0.08; break;
    case 'tornado': P.flip = e * PI * 4; P.boardYaw = e * PI * 4; P.boardPitch = hump * 0.35; P.yaw = e * PI * 2; break;
    case 'gyro': P.boardPitch = e * PI * 2; P.flip = e * PI * 2; P.lift = hump * 0.25; P.boardDrop = hump * 0.3; break;
  }
  if (FLIP_HOP.has(kind)) P.hop = hump * 0.3;
  return P;
}
