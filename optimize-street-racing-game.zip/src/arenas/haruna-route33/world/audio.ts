export function createAudio() {
  let ctx: AudioContext | null = null;
  let osc: OscillatorNode | null = null;
  let filter: BiquadFilterNode | null = null;
  let gain: GainNode | null = null;
  let screech: GainNode | null = null;
  let muted = false;

  function ensure() {
    if (ctx) return;
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.value = 60;
    filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 320;
    filter.Q.value = 0.7;
    gain = ctx.createGain();
    gain.gain.value = 0;
    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    osc.start();

    const buf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    const noise = ctx.createBufferSource();
    noise.buffer = buf;
    noise.loop = true;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 980;
    bp.Q.value = 0.8;
    screech = ctx.createGain();
    screech.gain.value = 0;
    noise.connect(bp);
    bp.connect(screech);
    screech.connect(ctx.destination);
    noise.start();
  }

  return {
    resume() {
      ensure();
      void ctx?.resume();
    },
    toggleMute() {
      muted = !muted;
      return muted;
    },
    get muted() {
      return muted;
    },
    update(rpm: number, throttle: number, drift: number, speed: number) {
      if (!ctx || !gain || !osc || !filter || !screech) return;
      const now = ctx.currentTime;
      if (muted) {
        gain.gain.setTargetAtTime(0, now, 0.04);
        screech.gain.setTargetAtTime(0, now, 0.04);
        return;
      }
      osc.frequency.setTargetAtTime(42 + rpm * 1.35, now, 0.05);
      filter.frequency.setTargetAtTime(240 + throttle * 780 + rpm * 3.1, now, 0.08);
      const vol = Math.min(0.07, 0.01 + throttle * 0.028 + Math.min(speed, 40) * 0.0007);
      gain.gain.setTargetAtTime(vol, now, 0.06);
      const sv = Math.min(0.055, Math.max(0, drift - 0.22) * 0.08);
      screech.gain.setTargetAtTime(sv, now, 0.07);
    },
    silence() {
      if (!ctx || !gain || !screech) return;
      const now = ctx.currentTime;
      gain.gain.setTargetAtTime(0, now, 0.02);
      screech.gain.setTargetAtTime(0, now, 0.02);
      void ctx.suspend().catch(() => {});
    },
  };
}
