import raw from "./centerline.json";

export type Sample = {
  x: number;
  y: number;
  z: number;
  dist: number;
  fromStart: number;
  tx: number;
  tz: number;
  rx: number;
  rz: number;
  heading: number;
  curv: number;
  grade: number;
  bank: number;
  halfW: number;
  railL: boolean;
  railR: boolean;
};

export type Corner = {
  index: number;
  dist: number;
  fromStart: number;
  x: number;
  y: number;
  z: number;
  dir: "L" | "R";
  angle: number;
  number: number;
  hairpin: boolean;
};

export type Projection = {
  dist: number;
  fromStart: number;
  cx: number;
  cz: number;
  y: number;
  lateral: number;
  heading: number;
  tx: number;
  tz: number;
  rx: number;
  rz: number;
  grade: number;
  bank: number;
  halfW: number;
  railL: boolean;
  railR: boolean;
  curv: number;
  idx: number;
};

type Hash = Map<string, number[]>;

const CELL = 36;

function wrap(a: number) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function catmull(
  pts: number[][],
  i: number,
  t: number,
): [number, number, number] {
  const p0 = pts[Math.max(0, i - 1)];
  const p1 = pts[i];
  const p2 = pts[Math.min(pts.length - 1, i + 1)];
  const p3 = pts[Math.min(pts.length - 1, i + 2)];
  const t2 = t * t;
  const t3 = t2 * t;
  const o: [number, number, number] = [0, 0, 0];
  for (let k = 0; k < 3; k++) {
    o[k] =
      0.5 *
      (2 * p1[k] +
        (-p0[k] + p2[k]) * t +
        (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 +
        (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3);
  }
  return o;
}

function buildHash(samples: Sample[]): Hash {
  const map: Hash = new Map();
  samples.forEach((s, i) => {
    const k = `${Math.floor(s.x / CELL)},${Math.floor(s.z / CELL)}`;
    const arr = map.get(k);
    if (arr) arr.push(i);
    else map.set(k, [i]);
  });
  return map;
}

export function buildTrack() {
  const pts = raw.points;
  const dense: [number, number, number][] = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const steps = 4;
    for (let s = 0; s < steps; s++) dense.push(catmull(pts, i, s / steps));
  }
  dense.push(catmull(pts, pts.length - 2, 1));

  const samples: Sample[] = [];
  let acc = 0;
  let prev = dense[0];
  samples.push(blank(prev, 0));
  for (let i = 1; i < dense.length; i++) {
    const p = dense[i];
    const seg = Math.hypot(p[0] - prev[0], p[2] - prev[2]);
    acc += seg;
    if (acc >= 4 || i === dense.length - 1) {
      samples.push(blank(p, samples.length ? samples[samples.length - 1].dist + Math.hypot(p[0] - samples[samples.length - 1].x, p[2] - samples[samples.length - 1].z) : 0));
      prev = p;
      acc = 0;
    }
  }

  // recompute true cumulative distance
  samples[0].dist = 0;
  for (let i = 1; i < samples.length; i++) {
    const a = samples[i - 1];
    const b = samples[i];
    b.dist = a.dist + Math.hypot(b.x - a.x, b.z - a.z);
  }

  for (let i = 0; i < samples.length; i++) {
    const a = samples[Math.max(0, i - 1)];
    const b = samples[Math.min(samples.length - 1, i + 1)];
    let dx = b.x - a.x;
    let dz = b.z - a.z;
    const len = Math.hypot(dx, dz) || 1;
    dx /= len;
    dz /= len;
    const s = samples[i];
    s.tx = dx;
    s.tz = dz;
    s.heading = Math.atan2(dx, dz);
    s.rx = dz;
    s.rz = -dx;
  }

  for (let pass = 0; pass < 2; pass++) {
    const ys = samples.map((s) => s.y);
    for (let i = 1; i < samples.length - 1; i++) {
      samples[i].y = ys[i] * 0.64 + ys[i - 1] * 0.18 + ys[i + 1] * 0.18;
    }
  }

  for (let i = 1; i < samples.length; i++) {
    const ds = Math.max(0.5, samples[i].dist - samples[i - 1].dist);
    const dh = wrap(samples[i].heading - samples[i - 1].heading);
    // positive curvature = left turn
    samples[i].curv = -dh / ds;
    samples[i].grade = (samples[i].y - samples[i - 1].y) / ds;
  }
  samples[0].curv = samples[1]?.curv ?? 0;
  samples[0].grade = samples[1]?.grade ?? 0;

  let startIdx = 0;
  let best = Infinity;
  for (let i = 0; i < samples.length; i++) {
    const d = samples[i].x ** 2 + samples[i].z ** 2 + samples[i].y ** 2;
    if (d < best) {
      best = d;
      startIdx = i;
    }
  }
  const startDist = samples[startIdx].dist;
  const length = samples[samples.length - 1].dist - startDist;

  for (const s of samples) {
    s.fromStart = s.dist - startDist;
    const radius = 1 / Math.max(0.0008, Math.abs(s.curv));
    let half = 4.05;
    const fs = s.fromStart;
    if (fs > -36 && fs < 48) {
      const t = 1 - Math.min(Math.abs(fs - 6) / 42, 1);
      half = 4.05 + t * 3.4;
    }
    if (length - fs < 55) {
      const t = 1 - Math.max(0, length - fs) / 55;
      half = Math.max(half, 4.05 + t * 2.6);
    }
    if (radius < 22) half = Math.min(half, Math.max(2.35, radius * 0.58));
    s.halfW = half;
    s.bank = Math.max(-0.028, Math.min(0.028, s.curv * 4));

    const valley = s.rx * 0.62 + s.rz * 0.78;
    const outside = s.curv >= 0 ? 1 : -1;
    s.railR = valley > 0.08 || outside > 0 || Math.abs(s.curv) > 0.045;
    s.railL = valley < -0.08 || outside < 0 || Math.abs(s.curv) > 0.045;
    if (Math.abs(s.curv) > 0.03) {
      if (outside > 0) s.railR = true;
      else s.railL = true;
    }
  }

  const corners = detectCorners(samples);
  const hash = buildHash(samples);

  return { samples, corners, startDist, length, hash, startIdx };
}

function blank(p: [number, number, number], dist: number): Sample {
  return {
    x: p[0],
    y: p[1],
    z: p[2],
    dist,
    fromStart: 0,
    tx: 0,
    tz: 1,
    rx: 1,
    rz: 0,
    heading: 0,
    curv: 0,
    grade: 0,
    bank: 0,
    halfW: 4.05,
    railL: false,
    railR: true,
  };
}

function detectCorners(samples: Sample[]): Corner[] {
  const score: number[] = new Array(samples.length).fill(0);
  for (let i = 0; i < samples.length; i++) {
    const target = samples[i].dist + 26;
    let j = i;
    while (j < samples.length - 1 && samples[j].dist < target) j++;
    score[i] = wrap(samples[j].heading - samples[i].heading);
  }

  const peaks: number[] = [];
  for (let i = 2; i < samples.length - 2; i++) {
    const a = Math.abs(score[i]);
    if (a < 0.34) continue;
    if (a >= Math.abs(score[i - 1]) && a >= Math.abs(score[i + 1])) peaks.push(i);
  }
  const kept: number[] = [];
  for (const i of peaks) {
    const last = kept[kept.length - 1];
    if (last === undefined || samples[i].dist - samples[last].dist > 48) kept.push(i);
    else if (Math.abs(score[i]) > Math.abs(score[last])) kept[kept.length - 1] = i;
  }

  let list = kept;
  if (list.length > 30) {
    const ranked = [...list].sort((a, b) => Math.abs(score[b]) - Math.abs(score[a]));
    const pick = new Set(ranked.slice(0, 30));
    list = list.filter((i) => pick.has(i));
  }

  return list.map((i, n) => {
    const s = samples[i];
    const angle = Math.abs(score[i]) * (180 / Math.PI);
    const dir: "L" | "R" = score[i] < 0 ? "L" : "R";
    const hairpin =
      angle > 52 && s.fromStart > 4700 && s.fromStart < 6400;
    return {
      index: i,
      dist: s.dist,
      fromStart: s.fromStart,
      x: s.x,
      y: s.y,
      z: s.z,
      dir,
      angle,
      number: list.length - n,
      hairpin,
    };
  });
}

export function projectPoint(
  x: number,
  z: number,
  samples: Sample[],
  hash: Hash,
): Projection {
  const cx = Math.floor(x / CELL);
  const cz = Math.floor(z / CELL);
  let bestI = 0;
  let bestD = Infinity;
  for (let ring = 0; ring <= 8; ring++) {
    for (let ix = cx - ring; ix <= cx + ring; ix++) {
      for (let iz = cz - ring; iz <= cz + ring; iz++) {
        if (ring > 0 && Math.abs(ix - cx) < ring && Math.abs(iz - cz) < ring) continue;
        const arr = hash.get(`${ix},${iz}`);
        if (!arr) continue;
        for (const i of arr) {
          const s = samples[i];
          const d = (s.x - x) ** 2 + (s.z - z) ** 2;
          if (d < bestD) {
            bestD = d;
            bestI = i;
          }
        }
      }
    }
    if (bestD < (ring * CELL) ** 2) break;
  }

  const i0 = Math.max(0, bestI - 1);
  const i1 = Math.min(samples.length - 1, bestI);
  const i2 = Math.min(samples.length - 1, bestI + 1);
  const a = projectSeg(x, z, samples[i0], samples[i1]);
  const b = projectSeg(x, z, samples[i1], samples[i2]);
  return a.d2 <= b.d2 ? a.proj : b.proj;
}

function projectSeg(px: number, pz: number, a: Sample, b: Sample) {
  const abx = b.x - a.x;
  const abz = b.z - a.z;
  const len2 = abx * abx + abz * abz || 1;
  let t = ((px - a.x) * abx + (pz - a.z) * abz) / len2;
  t = Math.max(0, Math.min(1, t));
  const cx = a.x + abx * t;
  const cz = a.z + abz * t;
  const dx = px - cx;
  const dz = pz - cz;
  const rx = a.rx + (b.rx - a.rx) * t;
  const rz = a.rz + (b.rz - a.rz) * t;
  const tx = a.tx + (b.tx - a.tx) * t;
  const tz = a.tz + (b.tz - a.tz) * t;
  const rlen = Math.hypot(rx, rz) || 1;
  const tlen = Math.hypot(tx, tz) || 1;
  const nrx = rx / rlen;
  const nrz = rz / rlen;
  const ntx = tx / tlen;
  const ntz = tz / tlen;
  const lateral = dx * nrx + dz * nrz;
  const y = a.y + (b.y - a.y) * t + lateral * Math.sin(a.bank + (b.bank - a.bank) * t);
  const proj: Projection = {
    dist: a.dist + (b.dist - a.dist) * t,
    fromStart: a.fromStart + (b.fromStart - a.fromStart) * t,
    cx,
    cz,
    y,
    lateral,
    heading: Math.atan2(ntx, ntz),
    tx: ntx,
    tz: ntz,
    rx: nrx,
    rz: nrz,
    grade: a.grade + (b.grade - a.grade) * t,
    bank: a.bank + (b.bank - a.bank) * t,
    halfW: a.halfW + (b.halfW - a.halfW) * t,
    railL: t < 0.5 ? a.railL : b.railL,
    railR: t < 0.5 ? a.railR : b.railR,
    curv: a.curv + (b.curv - a.curv) * t,
    idx: t < 0.5 ? samplesIndex(a) : samplesIndex(b),
  };
  return { d2: dx * dx + dz * dz, proj };
}

function samplesIndex(s: Sample) {
  return s.dist;
}

export function sampleAt(samples: Sample[], dist: number): Sample {
  if (dist <= samples[0].dist) return samples[0];
  const last = samples[samples.length - 1];
  if (dist >= last.dist) return last;
  let lo = 0;
  let hi = samples.length - 1;
  while (hi - lo > 1) {
    const m = (lo + hi) >> 1;
    if (samples[m].dist < dist) lo = m;
    else hi = m;
  }
  const a = samples[lo];
  const b = samples[hi];
  const t = (dist - a.dist) / Math.max(0.001, b.dist - a.dist);
  return {
    ...a,
    x: a.x + (b.x - a.x) * t,
    y: a.y + (b.y - a.y) * t,
    z: a.z + (b.z - a.z) * t,
    dist,
    fromStart: a.fromStart + (b.fromStart - a.fromStart) * t,
    tx: a.tx + (b.tx - a.tx) * t,
    tz: a.tz + (b.tz - a.tz) * t,
    rx: a.rx + (b.rx - a.rx) * t,
    rz: a.rz + (b.rz - a.rz) * t,
    heading: Math.atan2(a.tx + (b.tx - a.tx) * t, a.tz + (b.tz - a.tz) * t),
    curv: a.curv + (b.curv - a.curv) * t,
    grade: a.grade + (b.grade - a.grade) * t,
    bank: a.bank + (b.bank - a.bank) * t,
    halfW: a.halfW + (b.halfW - a.halfW) * t,
  };
}

export function sectionAt(fromStart: number) {
  const sections = [
    { d: 0, name: "Menara Air", jp: "給水塔" },
    { d: 420, name: "Hutan Atas", jp: "上の森" },
    { d: 980, name: "Hairpin Puncak", jp: "頂上" },
    { d: 1750, name: "Takane", jp: "高根展望台" },
    { d: 2650, name: "Lintasan Hutan", jp: "森の道" },
    { d: 4100, name: "Lurus Akina", jp: "秋名ストレート" },
    { d: 4920, name: "Lima Hairpin", jp: "五連ヘアピン" },
    { d: 6150, name: "Switchback Bawah", jp: "下のカーブ" },
    { d: 6750, name: "Parkir Gol", jp: "ゴール" },
  ];
  let cur = sections[0];
  for (const s of sections) if (fromStart >= s.d) cur = s;
  return cur;
}
