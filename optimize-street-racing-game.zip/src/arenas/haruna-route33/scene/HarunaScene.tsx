import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { createAudio } from "../world/audio";
import { spawnCar, stepCar, rivalSpeed, type CarState } from "../world/drive";
import { live, registerActions, emit, touch } from "../world/live";
import { sampleAt, sectionAt } from "../world/track";
import { createWorld, type World } from "../world/world";

const audio = createAudio();

export default function HarunaScene() {
  return (
    <Canvas
      shadows
      dpr={[1, 1.5]}
      gl={{
        antialias: true,
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.08,
      }}
      camera={{ fov: 48, near: 0.25, far: 9000, position: [400, 120, 1400] }}
      onCreated={({ gl }) => {
        gl.shadowMap.enabled = true;
        gl.shadowMap.type = THREE.PCFSoftShadowMap;
        gl.setClearColor("#e7d2b4");
      }}
    >
      <Experience />
    </Canvas>
  );
}

function Experience() {
  const [worldState, setWorldState] = useState<World | null>(null);
  const worldRef = useRef<World | null>(null);
  const sun = useRef<THREE.DirectionalLight>(null);
  const hemi = useRef<THREE.HemisphereLight>(null);
  const carRef = useRef<THREE.Group>(null);
  const rivalRef = useRef<THREE.Group>(null);
  const skyDay = useRef<THREE.Mesh>(null);
  const skyNight = useRef<THREE.Mesh>(null);
  const sunMesh = useRef<THREE.Mesh>(null);
  const moonMesh = useRef<THREE.Mesh>(null);
  const stars = useRef<THREE.Points>(null);
  const smoke = useRef<THREE.Points>(null);
  const { camera, gl, scene } = useThree();

  const keys = useRef({ f: false, b: false, l: false, r: false, h: false, shift: false, ctrl: false });
  const car = useRef<CarState | null>(null);
  const night = useRef(0);
  const camPos = useRef(new THREE.Vector3(200, 140, 400));
  const camLook = useRef(new THREE.Vector3(800, -300, 1800));
  const phase = useRef(live.phase);
  const camMode = useRef(0);
  const drone = useRef({ yaw: 0.4, pitch: -0.35, speed: 0 });
  const dragging = useRef<{ x: number; y: number } | null>(null);
  const timer = useRef({ armed: true, running: false, t: 0, done: false });
  const best = useRef(0);
  try {
    best.current = Number(localStorage.getItem("haruna-best") || "0") || 0;
  } catch {
    best.current = 0;
  }
  const rivalDist = useRef(0);
  const showcase = useRef(0);
  const puffs = useRef(
    Array.from({ length: 180 }, () => ({ life: 0, x: 0, y: 0, z: 0, vy: 0, s: 1 })),
  );
  const puffI = useRef(0);
  const cornerLatch = useRef("");

  const smokeGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const arr = new Float32Array(180 * 3);
    for (let i = 1; i < arr.length; i += 3) arr[i] = -999;
    g.setAttribute("position", new THREE.BufferAttribute(arr, 3));
    return g;
  }, []);

  useEffect(() => {
    const world = createWorld();
    worldRef.current = world;
    setWorldState(world);
    scene.fog = new THREE.FogExp2("#c9e4f8", 0.00022);
    const spawn = sampleAt(world.samples, world.startDist - 78);
    car.current = spawnCar(spawn);
    rivalDist.current = world.startDist + 5200;
    live.path = world.samples.filter((_, i) => i % 3 === 0).map((s) => ({ x: s.x, z: s.z }));
    live.hairpin = world.samples
      .filter((s) => s.fromStart > 5000 && s.fromStart < 6000 && Math.round(s.dist) % 12 < 5)
      .map((s) => ({ x: s.x, z: s.z }));
    live.best = best.current;
    live.phase = "intro";
    phase.current = "intro";
    emit();

    const onKey = (e: KeyboardEvent, down: boolean) => {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(e.key.toLowerCase()) || e.key === " ") {
        e.preventDefault();
      }
      if (k === "w" || e.key === "ArrowUp") keys.current.f = down;
      if (k === "s" || e.key === "ArrowDown") keys.current.b = down;
      if (k === "a" || e.key === "ArrowLeft") keys.current.l = down;
      if (k === "d" || e.key === "ArrowRight") keys.current.r = down;
      if (e.code === "Space") keys.current.h = down;
      if (e.key === "Shift") keys.current.shift = down;
      if (e.key === "Control") keys.current.ctrl = down;
      if (!down) return;
      audio.resume();
      if (k === "n") toggleNight();
      if (k === "c") cycleCam();
      if (k === "r") reset();
      if (k === "f") {
        if (phase.current === "drone") backToCar();
        else startDrone();
      }
      if (k === "m") {
        live.muted = audio.toggleMute();
        emit();
      }
      if (k === "enter" && phase.current === "intro") startDrive();
    };
    const down = (e: KeyboardEvent) => onKey(e, true);
    const up = (e: KeyboardEvent) => onKey(e, false);
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);

    const el = gl.domElement;
    const pd = (e: PointerEvent) => {
      if (phase.current !== "drone") return;
      dragging.current = { x: e.clientX, y: e.clientY };
    };
    const pm = (e: PointerEvent) => {
      if (!dragging.current || phase.current !== "drone") return;
      const dx = e.clientX - dragging.current.x;
      const dy = e.clientY - dragging.current.y;
      dragging.current = { x: e.clientX, y: e.clientY };
      drone.current.yaw += dx * 0.004;
      drone.current.pitch = Math.max(-1.2, Math.min(0.8, drone.current.pitch - dy * 0.003));
    };
    const pu = () => {
      dragging.current = null;
    };
    el.addEventListener("pointerdown", pd);
    window.addEventListener("pointermove", pm);
    window.addEventListener("pointerup", pu);

    registerActions({ startDrive, startDrone, reset, toggleNight, cycleCam, toggleMute: () => {
      audio.resume();
      live.muted = audio.toggleMute();
      emit();
    }, backToCar });

    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      el.removeEventListener("pointerdown", pd);
      window.removeEventListener("pointermove", pm);
      window.removeEventListener("pointerup", pu);
      audio.silence();
      live.phase = "loading";
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gl]);

  function startDrive() {
    audio.resume();
    const world = worldRef.current;
    if (!world) return;
    if (!car.current) {
      car.current = spawnCar(sampleAt(world.samples, world.startDist - 78));
    }
    rivalDist.current = world.startDist + 40;
    phase.current = "drive";
    live.phase = "drive";
    timer.current = { armed: true, running: false, t: 0, done: false };
    live.finished = null;
    emit();
  }

  function startDrone() {
    audio.resume();
    phase.current = "drone";
    live.phase = "drone";
    const cam = camera as THREE.PerspectiveCamera;
    drone.current.yaw = Math.atan2(
      camLook.current.x - cam.position.x,
      camLook.current.z - cam.position.z,
    );
    emit();
  }

  function backToCar() {
    phase.current = "drive";
    live.phase = "drive";
    emit();
  }

  function reset() {
    const world = worldRef.current;
    if (!world) return;
    car.current = spawnCar(sampleAt(world.samples, world.startDist - 78));
    rivalDist.current = world.startDist + 55;
    timer.current = { armed: true, running: false, t: 0, done: false };
    live.finished = null;
    live.time = 0;
    if (phase.current === "intro") return;
    phase.current = "drive";
    live.phase = "drive";
    emit();
  }

  function toggleNight() {
    live.night = !live.night;
    emit();
  }

  function cycleCam() {
    camMode.current = (camMode.current + 1) % 4;
    live.cam = ["Rally", "Kejar", "Kap", "TV"][camMode.current];
    emit();
  }

  useFrame((_, dt) => {
    const world = worldRef.current;
    const step = Math.min(0.033, dt);
    if (!world || !car.current) return;

    night.current += ((live.night ? 1 : 0) - night.current) * Math.min(1, step * 1.8);
    const n = night.current;

    if (skyDay.current) skyDay.current.visible = n < 0.98;
    if (skyNight.current) skyNight.current.visible = n > 0.02;
    if (skyDay.current) (skyDay.current.material as THREE.Material).opacity = 1 - n;
    if (skyNight.current) (skyNight.current.material as THREE.Material).opacity = n;
    if (sunMesh.current) sunMesh.current.visible = false;
    if (moonMesh.current) moonMesh.current.visible = n > 0.5;
    if (stars.current) stars.current.visible = n > 0.35;

    if (sun.current) {
      sun.current.intensity = THREE.MathUtils.lerp(0.95, 0.07, n);
      sun.current.color.set("#fff6e8").lerp(new THREE.Color("#9bb4d8"), n);
    }
    if (hemi.current) {
      hemi.current.intensity = THREE.MathUtils.lerp(0.95, 0.22, n);
      hemi.current.color.set("#e7f3ff").lerp(new THREE.Color("#223048"), n);
      hemi.current.groundColor.set("#9bb87a").lerp(new THREE.Color("#141810"), n);
    }
    gl.toneMappingExposure = THREE.MathUtils.lerp(1.16, 0.7, n);
    world.windowMat.emissiveIntensity = THREE.MathUtils.lerp(0.15, 1.5, n);
    world.lanternMat.emissiveIntensity = THREE.MathUtils.lerp(0.45, 1.8, n);
    const fog = scene.fog;
    if (fog instanceof THREE.FogExp2) {
      fog.color.set("#c9e4f8").lerp(new THREE.Color("#10182a"), n);
      fog.density = THREE.MathUtils.lerp(0.00022, 0.0003, n);
      gl.setClearColor(fog.color);
    }

    world.clouds.rotation.y += step * 0.012;
    world.clouds.traverse((o) => {
      if (o instanceof THREE.Mesh && o.parent === world.clouds) {
        o.position.x += Math.sin(performance.now() * 0.00005 + o.position.z) * step * 1.5;
      }
    });

    const driving = phase.current === "drive" || phase.current === "drone" || phase.current === "finish";
    if (driving && phase.current !== "intro") {
      const input = {
        throttle: Math.max(keys.current.f ? 1 : 0, touch.throttle),
        brake: Math.max(keys.current.b ? 1 : 0, touch.brake),
        steer: Math.max(-1, Math.min(1, (keys.current.r ? 1 : 0) - (keys.current.l ? 1 : 0) + touch.steer)),
        handbrake: keys.current.h || touch.handbrake,
      };
      if (phase.current === "drone") {
        input.throttle = 0;
        input.brake = 0;
        input.steer = 0;
        input.handbrake = false;
      }
      const res = stepCar(car.current, input, world.samples, step);
      audio.update(res.rpm, input.throttle, res.drift, Math.abs(car.current.speed));

      const fromStart = car.current.fromStart;
      if (timer.current.armed && fromStart > 2 && car.current.speed > 2) {
        timer.current.armed = false;
        timer.current.running = true;
        timer.current.t = 0;
      }
      if (fromStart < -8) {
        timer.current.armed = true;
        timer.current.running = false;
        timer.current.t = 0;
        timer.current.done = false;
      }
      if (timer.current.running) timer.current.t += step;
      if (timer.current.running && fromStart > world.length - 22 && !timer.current.done) {
        timer.current.done = true;
        timer.current.running = false;
        live.finished = timer.current.t;
        if (!best.current || timer.current.t < best.current) {
          best.current = timer.current.t;
          try {
            localStorage.setItem("haruna-best", String(best.current));
          } catch {
            /* ignore */
          }
          live.best = best.current;
        }
      }

      const sec = sectionAt(fromStart);
      live.section = sec.name;
      live.sectionJp = sec.jp;
      const upcoming = world.corners.find((c) => c.fromStart > fromStart && c.fromStart - fromStart < 90);
      if (upcoming && upcoming.fromStart - fromStart < 75) {
        const label = `C-${upcoming.number}`;
        if (cornerLatch.current !== label) cornerLatch.current = label;
        live.corner = label;
        live.cornerSub = upcoming.hairpin
          ? `HAIRPIN ${upcoming.dir === "L" ? "KIRI" : "KANAN"}`
          : upcoming.dir === "L"
            ? "TIKUNGAN KIRI"
            : "TIKUNGAN KANAN";
      } else if (!upcoming || upcoming.fromStart - fromStart > 80) {
        live.corner = "";
        live.cornerSub = "";
      }

      live.x = car.current.x;
      live.z = car.current.z;
      live.heading = car.current.heading;
      live.speed = Math.abs(car.current.speed) * 3.6;
      live.gear = car.current.speed < -0.4 ? 0 : car.current.gear;
      live.drift = res.drift;
      live.time = timer.current.running ? timer.current.t : live.finished ?? timer.current.t;
      live.progress = Math.max(0, Math.min(1, fromStart / world.length));

      if (res.drift > 0.32 || input.handbrake) spawnSmoke(car.current, res.drift);

      const g = carRef.current;
      if (g) {
        g.visible = true;
        g.position.set(car.current.x, car.current.y, car.current.z);
        g.rotation.order = "YXZ";
        g.rotation.y = car.current.heading;
        g.rotation.x = car.current.pitch;
        g.rotation.z = car.current.roll;
        const wheels = g.userData.wheels as THREE.Object3D[] | undefined;
        const spin = car.current.speed * step / 0.32;
        wheels?.forEach((w, i) => {
          w.rotation.x += spin;
          if (i < 2) w.rotation.y = -car.current!.slip * 0.7 + car.current!.steer * 0.12;
        });
        const pops = g.userData.pops as THREE.Object3D[] | undefined;
        pops?.forEach((p) => {
          p.position.y = THREE.MathUtils.lerp(p.position.y, n > 0.5 ? 0.18 : 0, 0.1);
        });
        const lamps = g.userData.lamps as THREE.SpotLight[] | undefined;
        lamps?.forEach((l) => {
          l.intensity = n * 18;
        });
      }
    }

    stepRival(world, step, n);
    stepSmoke(step);

    const persp = camera as THREE.PerspectiveCamera;
    const desired = new THREE.Vector3();
    const look = new THREE.Vector3();
    if (phase.current === "intro" || !car.current) {
      showcase.current += step * 16;
      const span = 520;
      const d = world.startDist + 5080 + (showcase.current % span);
      const s = sampleAt(world.samples, d);
      const ang = performance.now() * 0.00008;
      desired.set(
        world.hairpin.x + Math.cos(ang) * 112,
        world.hairpin.y + 68,
        world.hairpin.z + Math.sin(ang) * 88,
      );
      look.set(s.x, s.y + 2, s.z);
      persp.fov = 46;
    } else if (phase.current === "drone") {
      const fly = (keys.current.f ? 1 : 0) - (keys.current.b ? 1 : 0);
      const strafe = (keys.current.r ? 1 : 0) - (keys.current.l ? 1 : 0);
      const lift = (keys.current.h ? 1 : 0) - (keys.current.ctrl ? 1 : 0);
      const sp = (keys.current.shift ? 110 : 46) * step;
      const yaw = drone.current.yaw;
      camPos.current.x += Math.sin(yaw) * fly * sp + Math.cos(yaw) * strafe * sp;
      camPos.current.z += Math.cos(yaw) * fly * sp - Math.sin(yaw) * strafe * sp;
      camPos.current.y += lift * sp * 0.7;
      desired.copy(camPos.current);
      look.set(
        camPos.current.x + Math.sin(yaw) * Math.cos(drone.current.pitch),
        camPos.current.y + Math.sin(drone.current.pitch),
        camPos.current.z + Math.cos(yaw) * Math.cos(drone.current.pitch),
      );
      persp.fov = 52;
    } else if (car.current) {
      const c = car.current;
      const speed = Math.abs(c.speed);
      const mode = camMode.current;
      const back = mode === 0 ? 20 + speed * 0.08 : mode === 1 ? 7.5 : mode === 2 ? 0.2 : 5.5;
      const up = mode === 0 ? 13.5 + speed * 0.04 : mode === 1 ? 2.3 : mode === 2 ? 1.15 : 2.4;
      const ahead = mode === 0 ? 14 + speed * 0.12 : mode === 1 ? 6 : mode === 2 ? 8 : 4;
      const side = mode === 3 ? 4.2 : mode === 2 ? 0 : 0;
      const hx = Math.sin(c.heading);
      const hz = Math.cos(c.heading);
      const rx = Math.cos(c.heading);
      const rz = -Math.sin(c.heading);
      desired.set(c.x - hx * back + rx * side, c.y + up, c.z - hz * back + rz * side);
      look.set(c.x + hx * ahead, c.y + 1.3, c.z + hz * ahead);
      persp.fov = mode === 0 ? 47 + Math.min(7, speed * 0.1) : mode === 2 ? 68 : 58;
      
    }

    const damp = 1 - Math.exp(-step * (phase.current === "drone" ? 8 : 5.5));
    camPos.current.lerp(desired, phase.current === "drone" ? 1 : damp);
    camLook.current.lerp(look, phase.current === "drone" ? 1 : 1 - Math.exp(-step * 3.4));
    camera.position.copy(camPos.current);
    camera.lookAt(camLook.current);
    if (Math.abs(persp.fov - persp.userData.fov) > 0.05 || persp.userData.fov === undefined) {
      persp.userData.fov = persp.fov;
      persp.updateProjectionMatrix();
    }

    if (sun.current) {
      const dir = new THREE.Vector3(-0.32, 0.88, 0.22).normalize();
      const focus =
        phase.current === "drive" && car.current
          ? new THREE.Vector3(car.current.x, car.current.y, car.current.z)
          : camLook.current;
      sun.current.position.copy(focus).addScaledVector(dir, 180);
      sun.current.target.position.copy(focus);
      sun.current.target.updateMatrixWorld();
    }

    if (Math.floor(performance.now() / 120) !== live.tick) {
      live.gap = rivalFrom(world) - (car.current ? car.current.fromStart : 0);
      emit();
    }
  });

  function rivalFrom(world: World) {
    return rivalDist.current - world.startDist;
  }

  function stepRival(world: World, step: number, n: number) {
    const end = world.startDist + world.length - 30;
    if (phase.current === "intro") {
      const span = 480;
      rivalDist.current = world.startDist + 5050 + ((showcase.current * 1.05) % span);
    } else {
      const s = sampleAt(world.samples, rivalDist.current);
      const target = rivalSpeed(s.curv);
      rivalDist.current += target * step;
      if (rivalDist.current > end) rivalDist.current = world.startDist + 20;
    }
    const s = sampleAt(world.samples, rivalDist.current);
    const slip = Math.max(-0.55, Math.min(0.55, -s.curv * 9));
    const lat = Math.max(-1.6, Math.min(1.6, -s.curv * 28));
    const g = rivalRef.current;
    if (!g) return;
    g.visible = true;
    g.position.set(s.x + s.rx * lat, s.y + Math.sin(s.bank) * lat, s.z + s.rz * lat);
    g.rotation.order = "YXZ";
    g.rotation.y = s.heading + slip;
    g.rotation.z = -slip * 0.35;
    const wheels = g.userData.wheels as THREE.Object3D[] | undefined;
    wheels?.forEach((w) => {
      w.rotation.x += step * 12;
    });
    const lamps = g.userData.lamps as THREE.SpotLight[] | undefined;
    lamps?.forEach((l) => {
      l.intensity = n * 14;
    });
    live.rx = g.position.x;
    live.rz = g.position.z;
    if (Math.abs(slip) > 0.18) {
      spawnAt(g.position.x - s.tx * 1.6, g.position.y + 0.3, g.position.z - s.tz * 1.6, 0.8);
    }
  }

  function spawnSmoke(c: CarState, drift: number) {
    const hx = Math.sin(c.heading);
    const hz = Math.cos(c.heading);
    spawnAt(c.x - hx * 1.7 + Math.cos(c.heading) * 0.7, c.y + 0.25, c.z - hz * 1.7 - Math.sin(c.heading) * 0.7, drift);
    spawnAt(c.x - hx * 1.7 - Math.cos(c.heading) * 0.7, c.y + 0.25, c.z - hz * 1.7 + Math.sin(c.heading) * 0.7, drift);
  }

  function spawnAt(x: number, y: number, z: number, drift: number) {
    const p = puffs.current[puffI.current % puffs.current.length];
    puffI.current++;
    p.life = 1;
    p.x = x;
    p.y = y;
    p.z = z;
    p.vy = 0.8 + drift;
    p.s = 1.2 + drift * 2.2;
  }

  function stepSmoke(step: number) {
    const attr = smokeGeo.getAttribute("position") as THREE.BufferAttribute;
    const arr = attr.array as Float32Array;
    puffs.current.forEach((p, i) => {
      if (p.life <= 0) {
        arr[i * 3 + 1] = -9999;
        return;
      }
      p.life -= step * 0.55;
      p.y += p.vy * step;
      p.s += step * 1.4;
      arr[i * 3] = p.x;
      arr[i * 3 + 1] = p.y;
      arr[i * 3 + 2] = p.z;
    });
    attr.needsUpdate = true;
    if (smoke.current) {
      const m = smoke.current.material as THREE.PointsMaterial;
      m.size = 2.8;
    }
  }

  return (
    <>
      <hemisphereLight ref={hemi} args={["#e7f3ff", "#9bb87a", 0.95]} />
      <ambientLight intensity={0.32} color="#f4f8fc" />
      <directionalLight
        ref={sun}
        castShadow
        intensity={0.95}
        color="#fff6e8"
        position={[-80, 120, -40]}
        shadow-mapSize={[2048, 2048]}
        shadow-camera-near={8}
        shadow-camera-far={280}
        shadow-camera-left={-78}
        shadow-camera-right={78}
        shadow-camera-top={78}
        shadow-camera-bottom={-78}
        shadow-bias={-0.00035}
        shadow-normalBias={0.04}
      />
      <Sky refDay={skyDay} refNight={skyNight} />
      <mesh ref={sunMesh} position={[-900, 2800, 700]} visible={false}>
        <sphereGeometry args={[40, 10, 8]} />
        <meshBasicMaterial color="#fff8ee" fog={false} transparent opacity={0.35} />
      </mesh>
      <mesh ref={moonMesh} position={[1800, 1400, -1600]} visible={false}>
        <sphereGeometry args={[46, 10, 8]} />
        <meshBasicMaterial color="#e7eef8" fog={false} />
      </mesh>
      <Stars ref={stars} />
      {worldState && <primitive object={worldState.group} />}
      <group ref={carRef} visible={false}>
        <Car kind="ae86" />
      </group>
      <group ref={rivalRef}>
        <Car kind="fd" />
      </group>
      <points ref={smoke} geometry={smokeGeo}>
        <pointsMaterial
          color="#f4f1ea"
          size={2.8}
          transparent
          opacity={0.55}
          depthWrite={false}
          sizeAttenuation
          map={smokeTexture()}
        />
      </points>
    </>
  );
}

function Sky({
  refDay,
  refNight,
}: {
  refDay: RefObject<THREE.Mesh | null>;
  refNight: RefObject<THREE.Mesh | null>;
}) {
  const day = useMemo(() => skyGeo("#c5e6ff", "#3b92e6"), []);
  const night = useMemo(() => skyGeo("#1a2438", "#070b14"), []);
  return (
    <>
      <mesh ref={refDay} geometry={day}>
        <meshBasicMaterial vertexColors side={THREE.BackSide} fog={false} transparent />
      </mesh>
      <mesh ref={refNight} geometry={night} visible={false}>
        <meshBasicMaterial vertexColors side={THREE.BackSide} fog={false} transparent opacity={0} />
      </mesh>
    </>
  );
}

function skyGeo(horizon: string, zenith: string) {
  const geo = new THREE.SphereGeometry(6200, 20, 14);
  const pos = geo.attributes.position;
  const cols = new Float32Array(pos.count * 3);
  const a = new THREE.Color(horizon);
  const b = new THREE.Color(zenith);
  const c = new THREE.Color();
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i) / 6200;
    const t = Math.max(0, Math.min(1, (y + 0.15) / 0.85));
    c.copy(a).lerp(b, Math.pow(t, 0.75));
    cols[i * 3] = c.r;
    cols[i * 3 + 1] = c.g;
    cols[i * 3 + 2] = c.b;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(cols, 3));
  return geo;
}

function Stars({ ref }: { ref: RefObject<THREE.Points | null> }) {
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    const arr = new Float32Array(900 * 3);
    for (let i = 0; i < 900; i++) {
      const u = Math.random();
      const v = Math.random();
      const th = u * Math.PI * 2;
      const ph = Math.acos(2 * v - 1);
      const r = 5000;
      arr[i * 3] = r * Math.sin(ph) * Math.cos(th);
      arr[i * 3 + 1] = Math.abs(r * Math.cos(ph)) * 0.85 + 200;
      arr[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
    }
    g.setAttribute("position", new THREE.BufferAttribute(arr, 3));
    return g;
  }, []);
  return (
    <points ref={ref} geometry={geo} visible={false}>
      <pointsMaterial color="#f4f7ff" size={2.2} sizeAttenuation={false} fog={false} />
    </points>
  );
}

let smokeTex: THREE.Texture | null = null;
function smokeTexture() {
  if (smokeTex) return smokeTex;
  const c = document.createElement("canvas");
  c.width = 64;
  c.height = 64;
  const g = c.getContext("2d");
  if (g) {
    const grd = g.createRadialGradient(32, 32, 2, 32, 32, 30);
    grd.addColorStop(0, "rgba(255,255,255,0.7)");
    grd.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = grd;
    g.fillRect(0, 0, 64, 64);
  }
  smokeTex = new THREE.CanvasTexture(c);
  return smokeTex;
}

function Car({ kind }: { kind: "ae86" | "fd" }) {
  const wheels = useRef<THREE.Object3D[]>([]);
  const pops = useRef<THREE.Object3D[]>([]);
  const lamps = useRef<THREE.SpotLight[]>([]);
  const targetL = useRef<THREE.Object3D>(null);
  const targetR = useRef<THREE.Object3D>(null);
  const group = useRef<THREE.Group>(null);

  useEffect(() => {
    const g = group.current?.parent;
    if (!g) return;
    g.userData.wheels = wheels.current;
    g.userData.pops = pops.current;
    g.userData.lamps = lamps.current;
    lamps.current.forEach((l, i) => {
      l.target = i === 0 ? targetL.current! : targetR.current!;
    });
  }, []);

  const paint = kind === "ae86" ? "#f4f1ea" : "#f0c431";
  const hood = kind === "ae86" ? "#1a1c1f" : "#141414";
  return (
    <group ref={group}>
      <mesh position={[0, 0.62, 0.05]} castShadow>
        <boxGeometry args={kind === "ae86" ? [1.68, 0.5, 3.7] : [1.74, 0.42, 4.05]} />
        <meshStandardMaterial color={paint} roughness={0.42} metalness={0.08} flatShading />
      </mesh>
      <mesh position={[0, kind === "ae86" ? 0.9 : 0.82, kind === "ae86" ? 1.15 : 1.25]} castShadow>
        <boxGeometry args={[1.55, 0.08, 1.35]} />
        <meshStandardMaterial color={hood} roughness={0.5} flatShading />
      </mesh>
      <mesh position={[0, kind === "ae86" ? 1.12 : 0.98, -0.2]} castShadow>
        <boxGeometry args={[1.48, 0.46, 1.5]} />
        <meshStandardMaterial color="#1c2830" roughness={0.18} metalness={0.45} flatShading />
      </mesh>
      <mesh position={[0, kind === "ae86" ? 1.38 : 1.22, -0.2]}>
        <boxGeometry args={[1.4, 0.08, 1.35]} />
        <meshStandardMaterial color={kind === "ae86" ? "#f7f4ef" : "#141414"} flatShading />
      </mesh>
      <mesh position={[0, 0.4, kind === "ae86" ? 1.88 : 2.05]}>
        <boxGeometry args={[1.72, 0.22, 0.16]} />
        <meshStandardMaterial color="#1a1c1f" flatShading />
      </mesh>
      <mesh position={[0, 0.4, kind === "ae86" ? -1.82 : -1.95]}>
        <boxGeometry args={[1.72, 0.22, 0.16]} />
        <meshStandardMaterial color="#1a1c1f" flatShading />
      </mesh>
      <mesh position={[0.62, 0.7, kind === "ae86" ? -1.84 : -1.98]}>
        <boxGeometry args={[0.42, 0.12, 0.06]} />
        <meshStandardMaterial color="#d63a32" emissive="#8a1812" emissiveIntensity={0.6} flatShading />
      </mesh>
      <mesh position={[-0.62, 0.7, kind === "ae86" ? -1.84 : -1.98]}>
        <boxGeometry args={[0.42, 0.12, 0.06]} />
        <meshStandardMaterial color="#d63a32" emissive="#8a1812" emissiveIntensity={0.6} flatShading />
      </mesh>
      {kind === "ae86" && (
        <mesh position={[0.15, 1.02, -1.2]} castShadow>
          <boxGeometry args={[0.42, 0.26, 0.4]} />
          <meshStandardMaterial color="#f7f4ef" flatShading />
        </mesh>
      )}
      {kind === "fd" && (
        <mesh position={[0, 1.15, -1.55]} castShadow>
          <boxGeometry args={[1.55, 0.08, 0.38]} />
          <meshStandardMaterial color="#141414" flatShading />
        </mesh>
      )}
      {kind === "ae86" && (
        <>
          <group ref={(n) => { if (n) pops.current[0] = n; }} position={[0.52, 0.95, 1.35]}>
            <mesh>
              <boxGeometry args={[0.42, 0.08, 0.28]} />
              <meshStandardMaterial color="#f4f1ea" flatShading />
            </mesh>
          </group>
          <group ref={(n) => { if (n) pops.current[1] = n; }} position={[-0.52, 0.95, 1.35]}>
            <mesh>
              <boxGeometry args={[0.42, 0.08, 0.28]} />
              <meshStandardMaterial color="#f4f1ea" flatShading />
            </mesh>
          </group>
        </>
      )}
      <Wheel ref={(n) => { if (n) wheels.current[0] = n; }} x={0.78} z={1.25} />
      <Wheel ref={(n) => { if (n) wheels.current[1] = n; }} x={-0.78} z={1.25} />
      <Wheel ref={(n) => { if (n) wheels.current[2] = n; }} x={0.78} z={-1.25} />
      <Wheel ref={(n) => { if (n) wheels.current[3] = n; }} x={-0.78} z={-1.25} />
      <spotLight
        ref={(n) => { if (n) lamps.current[0] = n; }}
        position={[0.45, 0.7, 1.7]}
        angle={0.5}
        penumbra={0.55}
        distance={78}
        intensity={0}
        color="#fff1d2"
      />
      <spotLight
        ref={(n) => { if (n) lamps.current[1] = n; }}
        position={[-0.45, 0.7, 1.7]}
        angle={0.5}
        penumbra={0.55}
        distance={78}
        intensity={0}
        color="#fff1d2"
      />
      <object3D ref={targetL} position={[0.6, 0.2, 16]} />
      <object3D ref={targetR} position={[-0.6, 0.2, 16]} />
    </group>
  );
}

const Wheel = ({
  x,
  z,
  ref,
}: {
  x: number;
  z: number;
  ref: (n: THREE.Group | null) => void;
}) => (
  <group ref={ref} position={[x, 0.32, z]}>
    <mesh rotation={[0, 0, Math.PI / 2]}>
      <cylinderGeometry args={[0.32, 0.32, 0.22, 8]} />
      <meshStandardMaterial color="#1a1a1a" flatShading roughness={0.7} />
    </mesh>
    <mesh rotation={[0, 0, Math.PI / 2]}>
      <cylinderGeometry args={[0.16, 0.16, 0.24, 6]} />
      <meshStandardMaterial color="#c8c2b6" flatShading metalness={0.4} roughness={0.4} />
    </mesh>
  </group>
);
