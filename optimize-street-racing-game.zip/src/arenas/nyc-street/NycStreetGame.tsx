import { useCallback, useEffect, useRef, useState } from 'react';
import { Activity, ArrowLeft, Camera, Cpu, Flame, Gauge, Globe, Hand, Home, MoonStar, Mountain, Pause, Play, RotateCcw, SlidersHorizontal, Sun, Sunset, Trophy, Volume2, VolumeX, Wrench, X, Zap } from 'lucide-react';
import { createEngine, type CameraMode, type Engine, type GameEvent, type GamePhase, type HandPoseMode, type LightingSnapshot, type Telemetry } from './game/engine';
import type { TimeOfDay } from './game/lighting';
import { LIGHT_SLIDERS } from '../rc-drift/pigeon/drive-lighting';
import LiveSpeedo from './LiveSpeedo';
import type { SpeedoStyle } from './game/gtCockpit';
import { CURVE_WORLD_LABEL, CURVE_WORLD_ORDER, type CurveWorldMode } from './game/curveWorld';
import { QUALITY_LABEL, QUALITY_ORDER, readPerformance, savePerformance, type PerformanceSettings, type QualityTier } from './game/performance';
import './nyc.css';

const SETTINGS_KEY = 'nyc-street.settings.v2';
type Settings = {
  sound: boolean;
  volume: number;
  steering: number;
  speedoStyle: SpeedoStyle;
  curveWorld: CurveWorldMode;
  handPose: HandPoseMode;
  camera: CameraMode;
  mood: TimeOfDay;
};
const DEFAULT_VOLUME = 0.5;
const DEFAULT_STEERING = 1.15; // 115% — snappy NYC lane changes without twitch
const DEFAULT_SPEEDO: SpeedoStyle = 'classic'; // Default remains the classic speedometer
const DEFAULT_CURVE_WORLD: CurveWorldMode = 'normal'; // Subway Surfers–style Curved World active by default
const DEFAULT_HAND_POSE: HandPoseMode = 'window'; // Default: left arm relaxed on the left window sill (Gambar 1)
const STEERING_MIN = 0.7, STEERING_MAX = 1.6;
const STEERING_PRESETS = [
  { value: 0.85, label: 'SANTAI' },
  { value: 1.0, label: 'NORMAL' },
  { value: 1.15, label: 'SPORT' },
  { value: 1.3, label: 'CEPAT' },
  { value: 1.45, label: 'PRO' },
] as const;
const CAMERAS: CameraMode[] = ['chase', 'cockpit', 'hood', 'far'];
const CAMERA_LABEL: Record<CameraMode, string> = { chase: 'Belakang', cockpit: 'Kokpit', hood: 'Bemper', far: 'Jauh' };
function readSettings(): Settings {
  try {
    const v = JSON.parse(localStorage.getItem(SETTINGS_KEY) ?? '{}');
    const rawVolume = typeof v.volume === 'number' && Number.isFinite(v.volume) ? v.volume : DEFAULT_VOLUME;
    const rawSteering = typeof v.steering === 'number' && Number.isFinite(v.steering) ? v.steering : DEFAULT_STEERING;
    return {
      sound: v.sound !== false,
      volume: Math.max(0, Math.min(1, rawVolume)),
      steering: Math.max(STEERING_MIN, Math.min(STEERING_MAX, rawSteering)),
      speedoStyle: v.speedoStyle === 'gt' ? 'gt' : DEFAULT_SPEEDO,
      curveWorld: (CURVE_WORLD_ORDER.includes(v.curveWorld) ? v.curveWorld : DEFAULT_CURVE_WORLD) as CurveWorldMode,
      handPose: v.handPose === 'wheel' ? 'wheel' : DEFAULT_HAND_POSE,
      camera: (CAMERAS.includes(v.camera) ? v.camera : 'chase') as CameraMode,
      mood: (['day', 'dusk', 'night'].includes(v.mood) ? v.mood : 'day') as TimeOfDay,
    };
  } catch {
    return {
      sound: true,
      volume: DEFAULT_VOLUME,
      steering: DEFAULT_STEERING,
      speedoStyle: DEFAULT_SPEEDO,
      curveWorld: DEFAULT_CURVE_WORLD,
      handPose: DEFAULT_HAND_POSE,
      camera: 'chase',
      mood: 'day',
    };
  }
}
function saveSettings(s: Settings) { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)); } catch { /* optional */ } }

const emptyTelemetry: Telemetry = { phase: 'ready', kmh: 0, nitro: 55, nitroActive: false, health: 100, score: 0, distance: 0, time: 0, combo: 0, nearMisses: 0, overtakes: 0, crashes: 0, gear: '1', rpm: 0.15, camera: 'chase', mood: 'day', topSpeed: 0, best: 0, slipDeg: 0, drifting: false, driftPoints: 0, driftBanked: 0, handbrake: false,
  perf: { quality: 'high', lock60: true, adaptive: true, fps: 60, frameMs: 16.7, pixelRatio: 1, drawCalls: 0, traffic: 0, degraded: false } };

type Toast = { id: number; text: string; sub?: string; tone: 'gold' | 'red' | 'blue' | 'white' | 'violet' };

const fmt = (n: number) => Math.floor(n).toLocaleString('id-ID');
const fmtTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

const SUN_SLIDERS: { key: 'sunElevation' | 'sunAzimuth' | 'godRays' | 'fog' | 'exposure'; name: string; min: number; max: number; step: number; unit: string; desc: string }[] = [
  { key: 'sunElevation', name: 'Elevasi matahari', min: 6, max: 80, step: 1, unit: '°', desc: 'Tinggi matahari di atas cakrawala (bayangan gedung memanjang saat rendah)' },
  { key: 'sunAzimuth', name: 'Azimuth matahari', min: -180, max: 180, step: 1, unit: '°', desc: '0° = lurus di ujung avenue, ±90° = dari sisi gedung' },
  { key: 'godRays', name: 'God rays', min: 0, max: 2.5, step: 0.05, unit: '×', desc: 'Sinar volumetrik di antara pencakar langit' },
  { key: 'fog', name: 'Kabut kota', min: 0.2, max: 2.5, step: 0.05, unit: '×', desc: 'Kepekatan haze (sama dengan slider kabut Haruna V3)' },
  { key: 'exposure', name: 'Exposure', min: 0.4, max: 2, step: 0.05, unit: '×', desc: 'Kecerahan komposit volumetrik' },
];

export default function NycStreetGame({ onExit, onGarage, onHaruna }: { onExit?: () => void; onGarage?: () => void; onHaruna?: () => void }) {
  const host = useRef<HTMLDivElement>(null);
  const engine = useRef<Engine | undefined>(undefined);
  const [settings, setSettings] = useState<Settings>(readSettings);
  const [telemetry, setTelemetry] = useState<Telemetry>(emptyTelemetry);
  const [phase, setPhase] = useState<GamePhase>('ready');
  const [progress, setProgress] = useState({ label: 'Memuat…', pct: 0 });
  const [ready, setReady] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [flash, setFlash] = useState<'crash' | null>(null);
  const [final, setFinal] = useState<{ score: number; best: boolean } | null>(null);
  const [showHelp, setShowHelp] = useState(false);
  const [lightPanel, setLightPanel] = useState(false);
  const [light, setLight] = useState<LightingSnapshot | null>(null);
  const [perfOpen, setPerfOpen] = useState(false);
  const [volumeOpen, setVolumeOpen] = useState(false);
  const [steerOpen, setSteerOpen] = useState(false);
  const [perf, setPerf] = useState<PerformanceSettings>(readPerformance);
  const perfRef = useRef(perf);
  perfRef.current = perf;
  const toastId = useRef(0);
  const phaseRef = useRef<GamePhase>('ready');
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  const pushToast = useCallback((text: string, tone: Toast['tone'], sub?: string) => {
    const id = ++toastId.current;
    setToasts(t => [...t.slice(-3), { id, text, sub, tone }]);
    window.setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 1400);
  }, []);

  useEffect(() => {
    const abort = new AbortController();
    const el = host.current!;
    let disposed = false;
    createEngine(el, {
      onTelemetry: t => { setTelemetry(t); if (t.phase !== phaseRef.current) { phaseRef.current = t.phase; setPhase(t.phase); } },
      onEvent: (e: GameEvent) => {
        if (e.type === 'nearMiss') pushToast(`NEAR MISS +${fmt(e.points)}`, e.oncoming ? 'red' : 'gold', e.combo > 1 ? `COMBO x${e.combo}${e.oncoming ? ' · LAWAN ARAH 2X' : ''}` : e.oncoming ? 'LAWAN ARAH 2X' : undefined);
        else if (e.type === 'crash') { pushToast(e.headOn ? 'TABRAKAN FRONTAL!' : 'TABRAKAN', 'red', `-${Math.round(e.damage)} kondisi`); setFlash('crash'); window.setTimeout(() => setFlash(null), 260); }
        else if (e.type === 'nitro') { /* NOS uses pure optical FOV warp — no blue screen flash */ }
        else if (e.type === 'drift') pushToast(e.lost ? 'DRIFT HILANG' : `DRIFT +${fmt(e.points)}`, e.lost ? 'red' : 'violet', e.lost ? 'tabrakan membatalkan skor' : `${e.seconds.toFixed(1)} dtk · NOS terisi`);
        else if (e.type === 'milestone') pushToast(`${fmt(e.distance)} M`, 'blue', '+150 BONUS JARAK');
        else if (e.type === 'wrecked') { setFinal({ score: e.score, best: e.best }); phaseRef.current = 'wrecked'; setPhase('wrecked'); }
      },
      onProgress: (label, pct) => setProgress({ label, pct }),
    }, abort.signal, { sound: settingsRef.current.sound, volume: settingsRef.current.volume, steering: settingsRef.current.steering, speedoStyle: settingsRef.current.speedoStyle, curveWorld: settingsRef.current.curveWorld, handPose: settingsRef.current.handPose, headlights: settingsRef.current.mood !== 'day', camera: settingsRef.current.camera, mood: settingsRef.current.mood, performance: perfRef.current })
      .then(e => { if (disposed) { e?.dispose(); return; } engine.current = e; if (e) { e.steering(settingsRef.current.steering); e.speedoStyle(settingsRef.current.speedoStyle); e.curveWorld(settingsRef.current.curveWorld); e.handPose(settingsRef.current.handPose); setLight(e.lighting()); const p = e.performance(); setPerf({ quality: p.quality, lock60: p.lock60, adaptive: p.adaptive }); } setReady(Boolean(e)); })
      .catch(err => { console.error(err); setProgress({ label: 'Gagal memuat WebGL. Coba browser lain.', pct: 1 }); });
    return () => { disposed = true; abort.abort(); engine.current?.dispose(); engine.current = undefined; };
  }, [pushToast]);

  // Keyboard
  useEffect(() => {
    const steer = { left: false, right: false };
    const apply = () => engine.current?.setInput({ steer: (steer.left ? 1 : 0) - (steer.right ? 1 : 0) });
    const down = (e: KeyboardEvent) => {
      if (e.repeat && !['Space', 'ShiftLeft', 'ShiftRight', 'KeyN'].includes(e.code)) return;
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'BUTTON') && e.code !== 'Escape') return;
      switch (e.code) {
        case 'KeyA': case 'ArrowLeft': steer.left = true; apply(); e.preventDefault(); break;
        case 'KeyD': case 'ArrowRight': steer.right = true; apply(); e.preventDefault(); break;
        case 'KeyS': case 'ArrowDown': engine.current?.setInput({ brake: true }); e.preventDefault(); break;
        case 'KeyW': case 'ArrowUp': engine.current?.setInput({ power: true }); e.preventDefault(); break;
        case 'Space': if (phaseRef.current === 'ready') startRun(); else engine.current?.setInput({ handbrake: true }); e.preventDefault(); break;
        case 'ShiftLeft': case 'ShiftRight': case 'KeyN':
          if (phaseRef.current === 'ready') startRun(); else engine.current?.setInput({ nitro: true });
          e.preventDefault(); break;
        case 'Enter': if (phaseRef.current === 'ready') startRun(); else if (phaseRef.current === 'wrecked') restart(); break;
        case 'KeyR': if (phaseRef.current !== 'ready') restart(); break;
        case 'KeyC': if (engine.current) { const m = engine.current.cycleCamera(); setSettings(s => { const n = { ...s, camera: m }; saveSettings(n); return n; }); } break;
        case 'KeyT': if (engine.current) { const m = engine.current.cycleMood(); setSettings(s => { const n = { ...s, mood: m }; saveSettings(n); return n; }); } break;
        case 'KeyL': setLightPanel(v => !v); break;
        case 'KeyF': setPerfOpen(v => !v); break;
        case 'KeyK': setSteerOpen(v => !v); break;
        case 'KeyG': {
          const next: SpeedoStyle = settingsRef.current.speedoStyle === 'classic' ? 'gt' : 'classic';
          changeSpeedoStyle(next, true);
          break;
        }
        case 'KeyV': {
          const idx = CURVE_WORLD_ORDER.indexOf(settingsRef.current.curveWorld);
          const next = CURVE_WORLD_ORDER[(idx + 1) % CURVE_WORLD_ORDER.length];
          changeCurveWorld(next, true);
          break;
        }
        case 'KeyB': {
          changeHandPose(settingsRef.current.handPose === 'window' ? 'wheel' : 'window', true);
          break;
        }
        case 'BracketLeft': case 'BracketRight': {
          // Fine-tune steering feeling without pausing the run.
          const next = Math.round(Math.max(STEERING_MIN, Math.min(STEERING_MAX, settingsRef.current.steering + (e.code === 'BracketRight' ? 0.05 : -0.05))) * 100);
          changeSteering(next / 100);
          pushToast(`SETIR ${next}%`, 'white', next >= 130 ? 'SANGAT RESPONSIF' : next <= 95 ? 'LEMBUT' : 'SPORT');
          e.preventDefault();
          break;
        }
        case 'KeyM': toggleSound(); break;
        case 'KeyP': case 'Escape': togglePause(); break;
        case 'KeyH': setShowHelp(v => !v); break;
      }
    };
    const up = (e: KeyboardEvent) => {
      switch (e.code) {
        case 'KeyA': case 'ArrowLeft': steer.left = false; apply(); break;
        case 'KeyD': case 'ArrowRight': steer.right = false; apply(); break;
        case 'KeyS': case 'ArrowDown': engine.current?.setInput({ brake: false }); break;
        case 'KeyW': case 'ArrowUp': engine.current?.setInput({ power: false }); break;
        case 'Space': engine.current?.setInput({ handbrake: false }); break;
        case 'ShiftLeft': case 'ShiftRight': case 'KeyN': engine.current?.setInput({ nitro: false }); break;
      }
    };
    const blur = () => { steer.left = steer.right = false; apply(); engine.current?.setInput({ brake: false, nitro: false, power: false, handbrake: false }); };
    window.addEventListener('keydown', down); window.addEventListener('keyup', up); window.addEventListener('blur', blur);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); window.removeEventListener('blur', blur); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function startRun() { engine.current?.unlockAudio(); engine.current?.start(); setFinal(null); }
  function restart() { engine.current?.restart(); setFinal(null); setToasts([]); }
  function togglePause() {
    if (phaseRef.current === 'running') engine.current?.pause(true);
    else if (phaseRef.current === 'paused') engine.current?.pause(false);
  }
  function toggleSound() {
    setSettings(s => {
      const n = { ...s, sound: !s.sound, volume: s.volume > 0 ? s.volume : DEFAULT_VOLUME };
      saveSettings(n);
      engine.current?.sound(n.sound);
      engine.current?.volume(n.volume);
      return n;
    });
  }
  /** Steering gain: [ and ] nudge it, the HUD panel/presets set exact values. */
  function changeSteering(value: number) {
    const steering = Math.max(STEERING_MIN, Math.min(STEERING_MAX, Math.round(value * 100) / 100));
    setSettings(s => { const n = { ...s, steering }; saveSettings(n); return n; });
    engine.current?.steering(steering);
  }

  function changeHandPose(handPose: HandPoseMode, notify = false) {
    setSettings(s => { const n = { ...s, handPose }; saveSettings(n); return n; });
    engine.current?.handPose(handPose);
    if (notify) {
      pushToast(
        handPose === 'window' ? 'POSE: SANTAI DI JENDELA' : 'POSE: 2 TANGAN DI SETIR',
        'gold',
        handPose === 'window' ? 'Tangan kiri santai di jendela' : 'Kedua tangan memegang setir GT',
      );
    }
  }

  function changeCurveWorld(curveWorld: CurveWorldMode, notify = false) {
    setSettings(s => { const n = { ...s, curveWorld }; saveSettings(n); return n; });
    engine.current?.curveWorld(curveWorld);
    if (notify) {
      pushToast(
        `HORIZON: ${CURVE_WORLD_LABEL[curveWorld].toUpperCase()}`,
        curveWorld === 'off' ? 'white' : 'violet',
        curveWorld === 'cinematic' ? 'Efek lengkung Subway maksimal' : curveWorld === 'normal' ? 'Efek Curved World aktif' : 'Avenue lurus klasik',
      );
    }
  }

  function changeSpeedoStyle(speedoStyle: SpeedoStyle, notify = false) {
    setSettings(s => { const n = { ...s, speedoStyle }; saveSettings(n); return n; });
    engine.current?.speedoStyle(speedoStyle);
    if (notify) {
      pushToast(
        speedoStyle === 'gt' ? 'SPEEDOMETER: GT TWIN-DIAL' : 'SPEEDOMETER: KLASIK',
        speedoStyle === 'gt' ? 'blue' : 'gold',
        speedoStyle === 'gt' ? 'Analog bulat km/h + RPM' : 'Default bawaan',
      );
    }
  }

  /** Single source of truth for master volume: 50% by default, persisted. */
  function changeVolume(value: number) {
    const volume = Math.max(0, Math.min(1, value));
    setSettings(s => { const n = { ...s, volume, sound: volume > 0 ? true : s.sound }; saveSettings(n); engine.current?.volume(n.volume); engine.current?.sound(n.sound); return n; });
  }
  function setCamera(m: CameraMode) { engine.current?.camera(m); setSettings(s => { const n = { ...s, camera: m }; saveSettings(n); return n; }); }
  function changePerformance(patch: Partial<PerformanceSettings>) {
    const next = { ...perfRef.current, ...patch };
    perfRef.current = next;
    setPerf(next);
    savePerformance(next);
    const live = engine.current?.setPerformance(next);
    if (live) setTelemetry(t => ({ ...t, perf: live }));
  }
  function chooseQuality(q: QualityTier) { changePerformance({ quality: q }); }
  function setMood(m: TimeOfDay) { engine.current?.mood(m); setSettings(s => { const n = { ...s, mood: m }; saveSettings(n); return n; }); }

  const touch = (patch: Parameters<Engine['setInput']>[0]) => () => engine.current?.setInput(patch);

  const t = telemetry;
  const nitroLow = t.nitro < 8;
  const healthTone = t.health > 60 ? '#7ef0a0' : t.health > 30 ? '#ffb248' : '#ff4d4d';
  const nextCamera = CAMERAS[(CAMERAS.indexOf(settings.camera) + 1) % CAMERAS.length];

  return (
    <div className="nyc-root" data-phase={phase}>
      <div ref={host} className="nyc-canvas" onPointerDown={() => engine.current?.unlockAudio()} />

      <div className={`nyc-vignette ${t.health < 30 && phase === 'running' ? 'is-hurt' : ''}`} aria-hidden="true" />
      {flash && <div className={`nyc-flash nyc-flash-${flash}`} aria-hidden="true" />}

      {!ready && (
        <div className="nyc-overlay nyc-loading">
          <div className="nyc-brand"><span>NYC</span> STREET KINGS</div>
          <div className="nyc-progress"><div style={{ width: `${Math.round(progress.pct * 100)}%` }} /></div>
          <p>{progress.label}</p>
          <div className="nyc-load-badges">
            <span><Zap size={12} /> LALU LINTAS 2×</span>
            <span><Activity size={12} /> TARGET 60 FPS</span>
            <span><Cpu size={12} /> LOD RINGAN · HD</span>
          </div>
        </div>
      )}

      {ready && (
        <>
          <header className="nyc-top">
            <div className="nyc-top-left">
              {onExit && <button type="button" className="nyc-icon" onClick={onExit} title="Kembali ke menu (F2)" aria-label="Kembali ke menu"><Home size={18} /></button>}
              <div className={`nyc-volume-wrap ${volumeOpen ? 'is-open' : ''}`}>
                <button type="button" className={`nyc-icon nyc-icon-vol ${settings.sound && settings.volume > 0 ? '' : 'is-muted'}`} onClick={() => setVolumeOpen(v => !v)} title="Volume (M untuk mute)" aria-label={`Volume ${Math.round(settings.volume * 100)} persen`}>
                  {settings.sound && settings.volume > 0 ? <Volume2 size={18} /> : <VolumeX size={18} />}
                  <small>{Math.round(settings.volume * 100)}</small>
                </button>
                {volumeOpen && (
                  <div className="nyc-volume-pop" role="group" aria-label="Pengaturan volume">
                    <header><span>VOLUME MASTER</span><b>{Math.round(settings.volume * 100)}%</b></header>
                    <input type="range" min={0} max={100} step={1} value={Math.round(settings.volume * 100)} aria-label="Volume master" onChange={e => changeVolume(Number(e.target.value) / 100)} />
                    <div className="nyc-volume-presets">
                      {[0, 25, 50, 75, 100].map(v => <button key={v} type="button" aria-pressed={Math.round(settings.volume * 100) === v} onClick={() => changeVolume(v / 100)}>{v === 0 ? 'OFF' : `${v}%`}</button>)}
                    </div>
                    <button type="button" className="nyc-volume-mute" onClick={toggleSound}>{settings.sound ? <Volume2 size={13} /> : <VolumeX size={13} />}{settings.sound ? 'Mute' : 'Unmute'}<kbd>M</kbd></button>
                    <p>Mesin S63, ban, angin & SFX. Default 50%.</p>
                  </div>
                )}
              </div>
              <button type="button" className="nyc-icon nyc-icon-wide" onClick={() => setCamera(nextCamera)} title="Kamera (C)" aria-label="Kamera"><Camera size={18} /><span>{CAMERA_LABEL[settings.camera]}</span></button>
              <button type="button" className="nyc-icon nyc-icon-wide" onClick={() => changeHandPose(settings.handPose === 'window' ? 'wheel' : 'window', true)} title="Pose Tangan Kokpit: Santai di Jendela / 2 Tangan (B)" aria-label="Pose tangan kokpit">
                <Hand size={16} /><span>{settings.handPose === 'window' ? 'Santai' : '2 Tangan'}</span>
              </button>
              <button type="button" className={`nyc-icon nyc-icon-wide nyc-icon-speedo ${settings.speedoStyle === 'gt' ? 'is-gt' : ''}`} onClick={() => changeSpeedoStyle(settings.speedoStyle === 'classic' ? 'gt' : 'classic', true)} title="Gaya Speedometer: Klasik / GT Analog (G)" aria-label="Ganti gaya speedometer">
                <Gauge size={16} /><span>{settings.speedoStyle === 'gt' ? 'Speedo: GT' : 'Speedo: Klasik'}</span>
              </button>
              <button type="button" className={`nyc-icon nyc-icon-wide nyc-icon-curve ${settings.curveWorld !== 'off' ? 'is-active' : ''}`} onClick={() => {
                const idx = CURVE_WORLD_ORDER.indexOf(settings.curveWorld);
                changeCurveWorld(CURVE_WORLD_ORDER[(idx + 1) % CURVE_WORLD_ORDER.length], true);
              }} title="Efek Curve World ala Subway Surfers (V)" aria-label="Ganti efek Curve World">
                <Globe size={16} /><span>{CURVE_WORLD_LABEL[settings.curveWorld]}</span>
              </button>
              <button type="button" className={`nyc-icon nyc-icon-wide nyc-icon-steer ${steerOpen ? 'is-on' : ''}`} onClick={() => { setSteerOpen(v => !v); setPerfOpen(false); }} title="Sensitivitas setir (K)" aria-label={`Sensitivitas setir ${Math.round(settings.steering * 100)} persen`}>
                <Gauge size={17} /><span>{Math.round(settings.steering * 100)}%</span>
              </button>
              <button type="button" className="nyc-icon" onClick={() => setMood(settings.mood === 'day' ? 'dusk' : settings.mood === 'dusk' ? 'night' : 'day')} title="Waktu (T)" aria-label="Waktu">
                {settings.mood === 'day' ? <Sun size={18} /> : settings.mood === 'dusk' ? <Sunset size={18} /> : <MoonStar size={18} />}
              </button>
              <button type="button" className={`nyc-icon ${lightPanel ? 'is-on' : ''}`} onClick={() => setLightPanel(v => !v)} title="Pencahayaan & sudut matahari (L)" aria-label="Pencahayaan"><SlidersHorizontal size={18} /></button>
              {phase !== 'ready' && <button type="button" className="nyc-icon" onClick={togglePause} title="Pause (P)" aria-label="Pause">{phase === 'paused' ? <Play size={18} /> : <Pause size={18} />}</button>}
              <button type="button" className={`nyc-perf-chip ${perfOpen ? 'is-on' : ''} ${t.perf.fps >= 57 ? 'is-good' : t.perf.fps >= 45 ? 'is-warn' : 'is-bad'}`} onClick={() => { setPerfOpen(v => !v); setSteerOpen(false); }} title="Performa & optimasi (F)" aria-label="Panel performa">
                <Activity size={14} /><b>{Math.round(t.perf.fps)}</b><small>FPS</small>
                <i>{QUALITY_LABEL[t.perf.quality]}</i><em>{t.perf.traffic} MOBIL · {t.perf.pixelRatio.toFixed(2)}×</em>
              </button>
            </div>
            <div className="nyc-score">
              <small>SKOR</small>
              <b>{fmt(t.score)}</b>
              <span><Trophy size={11} /> {fmt(Math.max(t.best, t.score))}</span>
            </div>
            <div className="nyc-stats">
              <div><small>JARAK</small><b>{(t.distance / 1000).toFixed(2)}<i>km</i></b></div>
              <div><small>WAKTU</small><b>{fmtTime(t.time)}</b></div>
              <div><small>NEAR MISS</small><b>{t.nearMisses}</b></div>
              <div><small>DRIFT</small><b>{fmt(t.driftBanked)}</b></div>
            </div>
          </header>

          {t.combo > 1 && phase === 'running' && <div className="nyc-combo" key={t.combo}>COMBO <b>x{t.combo}</b></div>}

          {(t.drifting || t.driftPoints > 0) && phase === 'running' && (
            <div className={`nyc-drift ${t.drifting ? 'is-live' : ''}`}>
              <small>{t.handbrake ? 'E-BRAKE DRIFT' : 'DRIFT'} · {Math.abs(Math.round(t.slipDeg))}°</small>
              <b>+{fmt(t.driftPoints)}</b>
            </div>
          )}

          <div className="nyc-toasts" aria-live="polite">
            {toasts.map(x => <div key={x.id} className={`nyc-toast tone-${x.tone}`}><b>{x.text}</b>{x.sub && <small>{x.sub}</small>}</div>)}
          </div>

          <footer className="nyc-bottom">
            <div className="nyc-health">
              <small><Wrench size={11} /> KONDISI</small>
              <div className="nyc-bar"><div style={{ width: `${t.health}%`, background: healthTone }} /></div>
            </div>
            <div className={`nyc-speedo-slot ${settings.speedoStyle === 'gt' ? 'is-gt' : ''} ${t.nitroActive ? 'is-nitro' : ''}`}>
              <LiveSpeedo engineRef={engine} style={settings.speedoStyle} />
            </div>
            <div className={`nyc-nitro ${t.nitroActive ? 'is-active' : ''} ${nitroLow ? 'is-low' : ''}`}>
              <small><Flame size={11} /> NOS <em>2X</em></small>
              <div className="nyc-bar nyc-bar-nitro"><div style={{ width: `${t.nitro}%` }} /></div>
              <span>{t.nitroActive ? 'BOOST AKTIF' : nitroLow ? 'ISI: NEAR MISS / DRIFT' : 'TAHAN SHIFT / N'}</span>
            </div>
          </footer>

          <div className="nyc-touch" aria-hidden="true">
            <button type="button" className="nyc-tbtn nyc-tbtn-left" onPointerDown={touch({ steer: 1 })} onPointerUp={touch({ steer: 0 })} onPointerCancel={touch({ steer: 0 })} onPointerLeave={touch({ steer: 0 })}>◀</button>
            <button type="button" className="nyc-tbtn nyc-tbtn-right" onPointerDown={touch({ steer: -1 })} onPointerUp={touch({ steer: 0 })} onPointerCancel={touch({ steer: 0 })} onPointerLeave={touch({ steer: 0 })}>▶</button>
            <button type="button" className="nyc-tbtn nyc-tbtn-brake" onPointerDown={touch({ brake: true })} onPointerUp={touch({ brake: false })} onPointerCancel={touch({ brake: false })} onPointerLeave={touch({ brake: false })}>REM</button>
            <button type="button" className="nyc-tbtn nyc-tbtn-drift" onPointerDown={touch({ handbrake: true })} onPointerUp={touch({ handbrake: false })} onPointerCancel={touch({ handbrake: false })} onPointerLeave={touch({ handbrake: false })}>DRIFT</button>
            <button type="button" className="nyc-tbtn nyc-tbtn-nos" onPointerDown={() => { if (phaseRef.current === 'ready') startRun(); else engine.current?.setInput({ nitro: true }); }} onPointerUp={touch({ nitro: false })} onPointerCancel={touch({ nitro: false })} onPointerLeave={touch({ nitro: false })}>NOS</button>
          </div>

          {steerOpen && (
            <aside className="nyc-perf nyc-steer" aria-label="Sensitivitas setir">
              <header>
                <div><p className="nyc-kicker">STEERING TUNE · BERLAKU LANGSUNG</p><h3>Sensivitas Setir</h3></div>
                <button type="button" className="nyc-icon" onClick={() => setSteerOpen(false)} aria-label="Tutup"><X size={16} /></button>
              </header>
              <div className="nyc-steer-value">
                <div><small>GAIN SETIR</small><b>{Math.round(settings.steering * 100)}<i>%</i></b></div>
                <p>Normal 100% · Sport 115% · Pro 145%</p>
              </div>
              <input className="nyc-steer-slider" type="range" min={STEERING_MIN * 100} max={STEERING_MAX * 100} step={5}
                value={Math.round(settings.steering * 100)} aria-label="Sensitivitas setir"
                onChange={e => changeSteering(Number(e.target.value) / 100)} />
              <div className="nyc-steer-presets" role="group" aria-label="Preset sensitivitas setir">
                {STEERING_PRESETS.map(preset => (
                  <button key={preset.value} type="button" aria-pressed={Math.abs(settings.steering - preset.value) < 0.001} onClick={() => changeSteering(preset.value)}>
                    <b>{preset.label}</b><small>{Math.round(preset.value * 100)}%</small>
                  </button>
                ))}
              </div>
              <div className="nyc-steer-facts">
                <span><b>250</b> km/h top normal</span>
                <span><b>500</b> km/h dengan NOS</span>
                <span><b>[]</b> atur cepat saat balapan</span>
                <span><b>K</b> buka/tutup panel ini</span>
              </div>
              <p className="nyc-perf-note">Gain mengalikan input belok. Belok rendah tetap ringan, sedangkan di kecepatan tinggi lock otomatis dibatasi supaya NOS 500 km/h tidak membalik mobil. Coba <b>130–145%</b> kalau masih terasa lambat.</p>
            </aside>
          )}

          {perfOpen && (
            <aside className="nyc-perf" aria-label="Performa dan optimasi">
              <header>
                <div><p className="nyc-kicker">RENDER BUDGET · TARGET 60 FPS</p><h3>Performa</h3></div>
                <button type="button" className="nyc-icon" onClick={() => setPerfOpen(false)} aria-label="Tutup"><X size={16} /></button>
              </header>
              <div className="nyc-perf-live">
                <div><small>FPS</small><b data-good={t.perf.fps >= 57}>{Math.round(t.perf.fps)}</b></div>
                <div><small>FRAME</small><b>{t.perf.frameMs.toFixed(1)}<i>ms</i></b></div>
                <div><small>DRAW CALL</small><b>{t.perf.drawCalls}</b></div>
                <div><small>RESOLUSI</small><b>{t.perf.pixelRatio.toFixed(2)}<i>×</i></b></div>
              </div>
              <p className="nyc-perf-row-title">Kualitas render</p>
              <div className="nyc-perf-presets" role="group" aria-label="Kualitas render">
                {QUALITY_ORDER.map(q => (
                  <button key={q} type="button" aria-pressed={perf.quality === q} onClick={() => chooseQuality(q)}>
                    <b>{QUALITY_LABEL[q]}</b>
                    <small>{q === 'ultra' ? 'God rays + volumetrik' : q === 'high' ? 'Bloom + sharpen' : 'Paling aman untuk iGPU'}</small>
                  </button>
                ))}
              </div>
              <div className="nyc-perf-toggles">
                <button type="button" role="switch" aria-checked={perf.lock60} onClick={() => changePerformance({ lock60: !perf.lock60 })}>
                  <span><Zap size={14} /> Kunci 60 FPS</span><i data-on={perf.lock60} />
                </button>
                <button type="button" role="switch" aria-checked={perf.adaptive} onClick={() => changePerformance({ adaptive: !perf.adaptive })}>
                  <span><Activity size={14} /> Resolusi adaptif</span><i data-on={perf.adaptive} />
                </button>
              </div>
              <div className="nyc-perf-facts">
                <span><b>2×</b> kepadatan lalu lintas</span>
                <span><b>3</b> mesh / mobil AI</span>
                <span><b>1024</b> px facade HD</span>
                <span><b>{t.perf.traffic}</b> mobil aktif</span>
              </div>
              <p className="nyc-perf-note">Tekstur, atap kota, dan paint mobil tetap HD. Yang dikurangi hanya pass layar penuh, bayangan jauh, dan poligon interior mobil AI — pemain tetap memakai model Group B penuh.</p>
            </aside>
          )}

          {lightPanel && light && (
            <aside className="nyc-light" aria-label="Pengaturan pencahayaan">
              <header>
                <div><p className="nyc-kicker">RIG MT. HARUNA V3 · TERSINKRON</p><h3>Matahari & Cahaya</h3></div>
                <button type="button" className="nyc-icon" onClick={() => setLightPanel(false)} aria-label="Tutup"><X size={16} /></button>
              </header>
              <div className="nyc-light-moods">
                {(['day', 'dusk', 'night'] as TimeOfDay[]).map(m => <button key={m} type="button" aria-pressed={settings.mood === m} onClick={() => setMood(m)}>{m === 'day' ? 'Siang' : m === 'dusk' ? 'Senja' : 'Malam'}</button>)}
              </div>
              {SUN_SLIDERS.map(sl => (
                <label key={sl.key} className="nyc-slider">
                  <span>{sl.name}<em>{sl.unit === '°' ? `${Math.round(light.v2[sl.key])}°` : `${light.v2[sl.key].toFixed(2)}×`}</em></span>
                  <input type="range" min={sl.min} max={sl.max} step={sl.step} value={light.v2[sl.key]}
                    onChange={e => { const next = engine.current?.setSun({ [sl.key]: Number(e.target.value) }); if (next) setLight(next); }} />
                  <small>{sl.desc}</small>
                </label>
              ))}
              {LIGHT_SLIDERS.map(sl => (
                <label key={sl.key} className="nyc-slider">
                  <span>{sl.name}<em>{light.state[sl.key]}%</em></span>
                  <input type="range" min={0} max={100} step={1} value={light.state[sl.key]}
                    onChange={e => { const next = engine.current?.setLightLevels({ [sl.key]: Number(e.target.value) }); if (next) setLight(next); }} />
                  <small>{sl.desc}</small>
                </label>
              ))}
              <div className="nyc-light-actions">
                <button type="button" className="nyc-secondary" onClick={() => { const next = engine.current?.resetLighting(); if (next) setLight(next); }}><RotateCcw size={14} /> Reset ke preset V3 (42° / 28°)</button>
              </div>
            </aside>
          )}
        </>
      )}

      {ready && phase === 'ready' && !lightPanel && (
        <div className="nyc-overlay nyc-start">
          <div className="nyc-start-card">
            <p className="nyc-kicker">PRODRIFT · MANHATTAN AVENUE · FISIKA DRIFT & PENCAHAYAAN MT. HARUNA V3</p>
            <h1 className="nyc-brand"><span>NYC</span> STREET KINGS</h1>
            <div className="nyc-tech-strip">
              <span><Zap size={12} /> LALU LINTAS <b>2×</b></span>
              <span><Activity size={12} /> <b>60</b> FPS ADAPTIF</span>
              <span><Cpu size={12} /> MOBIL & GEDUNG RINGAN · HD</span>
              <span><Gauge size={12} /> NYATA <b>250</b> / NOS <b>500</b> KM/H</span>
              <span><Volume2 size={12} /> VOLUME <b>50%</b></span>
              <span><Gauge size={12} /> SETIR <b>SPORT 115%</b></span>
              <span><Globe size={12} /> EFEK <b>CURVED WORLD</b></span>
            </div>
            <div className="nyc-audio-row">
              <button type="button" className="nyc-audio-icon" onClick={toggleSound} aria-label={settings.sound ? 'Mute' : 'Unmute'}>{settings.sound && settings.volume > 0 ? <Volume2 size={16} /> : <VolumeX size={16} />}</button>
              <label htmlFor="nyc-volume-start">VOLUME <b>{Math.round(settings.volume * 100)}%</b></label>
              <input id="nyc-volume-start" type="range" min={0} max={100} value={Math.round(settings.volume * 100)} onChange={e => changeVolume(Number(e.target.value) / 100)} />
              <span>default 50%</span>
            </div>
            <div className="nyc-steer-row">
              <div className="nyc-steer-row-title"><span><Gauge size={13} /> SENSITIVITAS SETIR</span><b>{Math.round(settings.steering * 100)}%</b></div>
              <input type="range" min={STEERING_MIN * 100} max={STEERING_MAX * 100} step={5} value={Math.round(settings.steering * 100)} aria-label="Sensitivitas setir" onChange={e => changeSteering(Number(e.target.value) / 100)} />
              <div className="nyc-steer-quick">
                {STEERING_PRESETS.map(preset => <button key={preset.value} type="button" aria-pressed={Math.abs(settings.steering - preset.value) < 0.001} onClick={() => changeSteering(preset.value)}>{preset.label}</button>)}
                <span>Default Sport 115%</span>
              </div>
            </div>
            <div className="nyc-speedo-choice" role="group" aria-label="Gaya speedometer">
              <span><Gauge size={13} /> SPEEDOMETER</span>
              <div className="nyc-speedo-choice-btns">
                <button type="button" aria-pressed={settings.speedoStyle === 'classic'} onClick={() => changeSpeedoStyle('classic')}>KLASIK <em>DEFAULT</em></button>
                <button type="button" aria-pressed={settings.speedoStyle === 'gt'} onClick={() => changeSpeedoStyle('gt')}>GT TWIN-DIAL</button>
              </div>
            </div>
            <div className="nyc-speedo-choice" role="group" aria-label="Efek Curve World">
              <span><Globe size={13} /> CURVED WORLD</span>
              <div className="nyc-speedo-choice-btns">
                <button type="button" aria-pressed={settings.curveWorld === 'normal'} onClick={() => changeCurveWorld('normal')}>SUBWAY CURVE <em>DEFAULT</em></button>
                <button type="button" aria-pressed={settings.curveWorld === 'cinematic'} onClick={() => changeCurveWorld('cinematic')}>CURVE MAX</button>
                <button type="button" aria-pressed={settings.curveWorld === 'off'} onClick={() => changeCurveWorld('off')}>DATAR</button>
              </div>
            </div>
            <div className="nyc-speedo-choice" role="group" aria-label="Pose tangan kokpit">
              <span><Hand size={13} /> POSE TANGAN</span>
              <div className="nyc-speedo-choice-btns">
                <button type="button" aria-pressed={settings.handPose === 'window'} onClick={() => changeHandPose('window')}>SANTAI JENDELA <em>DEFAULT</em></button>
                <button type="button" aria-pressed={settings.handPose === 'wheel'} onClick={() => changeHandPose('wheel')}>2 TANGAN SETIR</button>
              </div>
            </div>
            <p className="nyc-lede">Pacu Group B di avenue 6 lajur Manhattan dengan fisika drift Mt. Haruna: bebas belok, <b>E-brake drift</b>, power-over, manji antar lajur. Salip serapat mungkin untuk <b>NEAR MISS</b>, isi tabung <b>NOS</b>, lalu boost ke <b>2× top speed: 500 km/h</b> (normal 250 km/h). Lajur kiri lawan arah = poin ganda, risiko ganda. <b>Awas perempatan — mobil melintas!</b></p>
            <div className="nyc-keys">
              <div><kbd>A</kbd><kbd>D</kbd> / <kbd>◀</kbd><kbd>▶</kbd><span>Belok</span></div>
              <div><kbd>SPASI</kbd><span>Handbrake / E-brake drift</span></div>
              <div><kbd>SHIFT</kbd> / <kbd>N</kbd><span>NOS 2X</span></div>
              <div><kbd>W</kbd> / <kbd>▲</kbd><span>Gas penuh (power-over)</span></div>
              <div><kbd>S</kbd> / <kbd>▼</kbd><span>Rem / mundur</span></div>
              <div><kbd>C</kbd><span>Kamera: belakang · kokpit · bemper · jauh</span></div>
              <div><kbd>L</kbd><span>Sudut matahari & cahaya</span></div>
              <div><kbd>T</kbd><span>Siang / Senja / Malam</span></div>
              <div><kbd>R</kbd><span>Ulang</span></div>
              <div><kbd>F</kbd><span>Performa & optimasi</span></div>
              <div><kbd>M</kbd><span>Mute volume (default 50%)</span></div>
              <div><kbd>K</kbd> / <kbd>[</kbd><kbd>]</kbd><span>Sensitivitas setir</span></div>
              <div><kbd>G</kbd><span>Speedometer: Klasik / GT</span></div>
              <div><kbd>V</kbd><span>Curved World: Subway / Max / Datar</span></div>
              <div><kbd>B</kbd><span>Tangan: Santai Jendela / 2 Tangan</span></div>
            </div>
            <div className="nyc-actions">
              <button type="button" className="nyc-primary" onClick={startRun}><Play size={20} /> MULAI BALAPAN</button>
              {onHaruna && <button type="button" className="nyc-secondary nyc-secondary-haruna" onClick={onHaruna}><Mountain size={16} /> MT. HARUNA V3</button>}
              {onGarage && <button type="button" className="nyc-secondary" onClick={onGarage}><Wrench size={16} /> Garasi & Arena Klasik</button>}
              <button type="button" className="nyc-secondary" onClick={() => setLightPanel(true)}><SlidersHorizontal size={16} /> Atur matahari</button>
              <button type="button" className="nyc-secondary" onClick={() => { setPerfOpen(true); setSteerOpen(false); }}><Activity size={16} /> Performa</button>
            </div>
            {t.best > 0 && <p className="nyc-best"><Trophy size={13} /> Rekor terbaik: <b>{fmt(t.best)}</b></p>}
          </div>
        </div>
      )}

      {phase === 'paused' && (
        <div className="nyc-overlay nyc-pause">
          <div className="nyc-start-card nyc-compact">
            <h2>JEDA</h2>
            <div className="nyc-audio-row nyc-audio-row-compact">
              <button type="button" className="nyc-audio-icon" onClick={toggleSound} aria-label={settings.sound ? 'Mute' : 'Unmute'}>{settings.sound && settings.volume > 0 ? <Volume2 size={16} /> : <VolumeX size={16} />}</button>
              <label htmlFor="nyc-volume-pause">VOLUME <b>{Math.round(settings.volume * 100)}%</b></label>
              <input id="nyc-volume-pause" type="range" min={0} max={100} value={Math.round(settings.volume * 100)} onChange={e => changeVolume(Number(e.target.value) / 100)} />
            </div>
            <div className="nyc-steer-row nyc-steer-row-compact">
              <div className="nyc-steer-row-title"><span><Gauge size={13} /> SENSITIVITAS SETIR</span><b>{Math.round(settings.steering * 100)}%</b></div>
              <input type="range" min={STEERING_MIN * 100} max={STEERING_MAX * 100} step={5} value={Math.round(settings.steering * 100)} aria-label="Sensitivitas setir" onChange={e => changeSteering(Number(e.target.value) / 100)} />
              <div className="nyc-steer-quick">
                {STEERING_PRESETS.map(preset => <button key={preset.value} type="button" aria-pressed={Math.abs(settings.steering - preset.value) < 0.001} onClick={() => changeSteering(preset.value)}>{preset.label}</button>)}
              </div>
            </div>
            <div className="nyc-speedo-choice nyc-speedo-choice-compact" role="group" aria-label="Gaya speedometer">
              <span><Gauge size={13} /> SPEEDOMETER</span>
              <div className="nyc-speedo-choice-btns">
                <button type="button" aria-pressed={settings.speedoStyle === 'classic'} onClick={() => changeSpeedoStyle('classic')}>KLASIK</button>
                <button type="button" aria-pressed={settings.speedoStyle === 'gt'} onClick={() => changeSpeedoStyle('gt')}>GT TWIN-DIAL</button>
              </div>
            </div>
            <div className="nyc-speedo-choice nyc-speedo-choice-compact" role="group" aria-label="Efek Curve World">
              <span><Globe size={13} /> CURVED WORLD</span>
              <div className="nyc-speedo-choice-btns">
                <button type="button" aria-pressed={settings.curveWorld === 'normal'} onClick={() => changeCurveWorld('normal')}>CURVE</button>
                <button type="button" aria-pressed={settings.curveWorld === 'cinematic'} onClick={() => changeCurveWorld('cinematic')}>MAX</button>
                <button type="button" aria-pressed={settings.curveWorld === 'off'} onClick={() => changeCurveWorld('off')}>DATAR</button>
              </div>
            </div>
            <div className="nyc-speedo-choice nyc-speedo-choice-compact" role="group" aria-label="Pose tangan kokpit">
              <span><Hand size={13} /> TANGAN</span>
              <div className="nyc-speedo-choice-btns">
                <button type="button" aria-pressed={settings.handPose === 'window'} onClick={() => changeHandPose('window')}>SANTAI JENDELA</button>
                <button type="button" aria-pressed={settings.handPose === 'wheel'} onClick={() => changeHandPose('wheel')}>2 TANGAN</button>
              </div>
            </div>
            <div className="nyc-actions">
              <button type="button" className="nyc-primary" onClick={() => engine.current?.pause(false)}><Play size={18} /> Lanjut</button>
              <button type="button" className="nyc-secondary" onClick={restart}><RotateCcw size={16} /> Ulang</button>
              {onHaruna && <button type="button" className="nyc-secondary nyc-secondary-haruna" onClick={onHaruna}><Mountain size={16} /> Mt. Haruna V3</button>}
              {onExit && <button type="button" className="nyc-secondary" onClick={onExit}><ArrowLeft size={16} /> Menu</button>}
            </div>
          </div>
        </div>
      )}

      {phase === 'wrecked' && final && (
        <div className="nyc-overlay nyc-over">
          <div className="nyc-start-card">
            <p className="nyc-kicker">MOBIL RUSAK TOTAL</p>
            <h2>{final.best ? 'REKOR BARU!' : 'RUN SELESAI'}</h2>
            <div className="nyc-final"><small>SKOR</small><b>{fmt(final.score)}</b></div>
            <div className="nyc-grid">
              <div><small>Jarak</small><b>{(t.distance / 1000).toFixed(2)} km</b></div>
              <div><small>Top speed</small><b>{Math.round(t.topSpeed)} km/h</b></div>
              <div><small>Near miss</small><b>{t.nearMisses}</b></div>
              <div><small>Skor drift</small><b>{fmt(t.driftBanked)}</b></div>
              <div><small>Tabrakan</small><b>{t.crashes}</b></div>
              <div><small>Waktu</small><b>{fmtTime(t.time)}</b></div>
            </div>
            <div className="nyc-actions">
              <button type="button" className="nyc-primary" onClick={restart}><RotateCcw size={18} /> BALAP LAGI</button>
              {onHaruna && <button type="button" className="nyc-secondary nyc-secondary-haruna" onClick={onHaruna}><Mountain size={16} /> Mt. Haruna V3</button>}
              {onExit && <button type="button" className="nyc-secondary" onClick={onExit}><ArrowLeft size={16} /> Menu</button>}
            </div>
          </div>
        </div>
      )}

      {showHelp && (
        <div className="nyc-help">
          <b><Gauge size={12} /> Tips</b> Near miss &lt; 1,15 m mengisi NOS · drift dibank saat slide berakhir (juga mengisi NOS) · lawan arah 2x poin · tabrakan membatalkan drift & combo · kondisi pulih jika 6 detik tanpa benturan.
        </div>
      )}
    </div>
  );
}
