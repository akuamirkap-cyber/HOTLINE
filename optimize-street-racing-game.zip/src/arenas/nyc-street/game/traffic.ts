import * as THREE from 'three';
import type { RallyModel } from '../../rc-drift/pigeon/rally-model.js';
import { laneX, ONCOMING_LANES, PLAYER_LANES, ROAD_HALF } from './city';
import { createTrafficProxy } from './trafficModel';

/** Half extents of the civilian car body used for OBB collision (metres). */
export const CAR_HALF_W = 1.9 / 2;
export const CAR_HALF_L = 1.77;

export type Body = { x: number; z: number; yaw: number };

/** Passenger-car liveries for the lightweight NYC traffic proxy. */
const PALETTES: Record<'black' | 'blue' | 'green', { ink: number; dim: number }> = {
  black: { ink: 0x282931, dim: 0x4d4f55 },
  blue: { ink: 0x1c56b2, dim: 0x4574bc },
  green: { ink: 0x176d46, dim: 0x4c9670 },
};
type Livery = { name: string; theme: keyof typeof PALETTES; ink?: number; dim?: number; weight: number };
const LIVERIES: Livery[] = [
  { name: 'NYC Taxi', theme: 'green', ink: 0xf4b41a, dim: 0xf9c94a, weight: 3.2 },
  { name: 'Silver', theme: 'black', ink: 0xb8bcc4, dim: 0xd3d6dc, weight: 1.4 },
  { name: 'White', theme: 'black', ink: 0xe9eaec, dim: 0xf4f4f6, weight: 1.4 },
  { name: 'Black', theme: 'black', weight: 1.3 },
  { name: 'Navy', theme: 'blue', ink: 0x1b2f5a, dim: 0x2d4677, weight: 1 },
  { name: 'Burgundy', theme: 'blue', ink: 0x6e1a28, dim: 0x8c2a3a, weight: 0.8 },
  { name: 'Graphite', theme: 'green', ink: 0x3a3d42, dim: 0x5a5e66, weight: 1 },
  { name: 'Forest', theme: 'green', weight: 0.5 },
  { name: 'Ocean', theme: 'blue', weight: 0.6 },
];

function pickLivery(rng: () => number) {
  const total = LIVERIES.reduce((s, l) => s + l.weight, 0);
  let r = rng() * total;
  for (const l of LIVERIES) { r -= l.weight; if (r <= 0) return l; }
  return LIVERIES[0];
}

/** Creates one lightweight, cached civilian car for a livery. */
function civilCar(livery: Livery) {
  const pal = PALETTES[livery.theme];
  return createTrafficProxy(
    livery.ink ?? pal.ink,
    livery.dim ?? livery.ink ?? pal.dim,
    { contactShadow: true },
  );
}

// ---------- 2D OBB (SAT) ----------
const axes: THREE.Vector2[] = [new THREE.Vector2(), new THREE.Vector2(), new THREE.Vector2(), new THREE.Vector2()];
function project(b: Body, hw: number, hl: number, axis: THREE.Vector2) {
  const c = b.x * axis.x + b.z * axis.y;
  const fx = Math.sin(b.yaw), fz = Math.cos(b.yaw); // forward
  const rx = fz, rz = -fx;                            // right
  const r = Math.abs((rx * axis.x + rz * axis.y) * hw) + Math.abs((fx * axis.x + fz * axis.y) * hl);
  return [c - r, c + r];
}
export type Contact = { nx: number; nz: number; depth: number } | null;
/** Returns the minimum translation vector pushing `a` out of `b` (normal points from b to a). */
export function obbContact(a: Body, b: Body, hw = CAR_HALF_W, hl = CAR_HALF_L): Contact {
  axes[0].set(Math.cos(a.yaw), -Math.sin(a.yaw));
  axes[1].set(Math.sin(a.yaw), Math.cos(a.yaw));
  axes[2].set(Math.cos(b.yaw), -Math.sin(b.yaw));
  axes[3].set(Math.sin(b.yaw), Math.cos(b.yaw));
  let best = Infinity, bx = 0, bz = 0;
  for (const ax of axes) {
    const [a0, a1] = project(a, hw, hl, ax);
    const [b0, b1] = project(b, hw, hl, ax);
    const overlap = Math.min(a1, b1) - Math.max(a0, b0);
    if (overlap <= 0) return null;
    if (overlap < best) {
      best = overlap;
      const sign = (a.x * ax.x + a.z * ax.y) - (b.x * ax.x + b.z * ax.y) >= 0 ? 1 : -1;
      bx = ax.x * sign; bz = ax.y * sign;
    }
  }
  return { nx: bx, nz: bz, depth: best };
}

export type TrafficCar = {
  car: RallyModel;
  livery: string;
  lane: number;
  targetLane: number;
  dir: 1 | -1;
  x: number; z: number; yaw: number;
  v: number;           // speed magnitude (m/s)
  cruise: number;
  laneTimer: number;
  braking: boolean;
  passed: boolean;
  hitCooldown: number;
  spin: number;        // yaw kick after a hit
};

export type TrafficEvent =
  | { type: 'nearMiss'; closeness: number; oncoming: boolean; x: number; z: number }
  | { type: 'overtake' }
  | { type: 'crash'; impact: number; nx: number; nz: number; oncoming: boolean; headOn: boolean; /** contact offset along the player's heading (+ = ahead of centre) */ ahead: number; /** tangential (side-swipe) closing speed in m/s */ tangent: number };

export type PlayerBody = Body & { vx: number; vz: number; speed: number };

export type Traffic = {
  group: THREE.Group;
  cars: TrafficCar[];
  update(dt: number, player: PlayerBody, playerYawRate: number, active: boolean): TrafficEvent[];
  density(level: number): void;
  reset(playerZ: number): void;
  setHeadlights(on: boolean): void;
  dispose(): void;
};

const SPAWN_MIN = 190, SPAWN_MAX = 460;

export async function createTraffic(scene: THREE.Scene, count: number, onProgress?: (done: number, total: number) => void): Promise<Traffic> {
  const group = new THREE.Group();
  group.name = 'NYC traffic';
  scene.add(group);
  let seed = 4242;
  const rng = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const cars: TrafficCar[] = [];
  for (let i = 0; i < count; i++) {
    const livery = pickLivery(rng);
    const car = civilCar(livery);
    car.rotation.order = 'YXZ';
    car.name = `Traffic ${livery.name} ${i + 1}`;
    group.add(car);
    cars.push({ car, livery: livery.name, lane: 0, targetLane: 0, dir: 1, x: 0, z: 0, yaw: 0, v: 0, cruise: 0, laneTimer: 0, braking: false, passed: false, hitCooldown: 0, spin: 0 });
    onProgress?.(i + 1, count);
    // Yield briefly so the loading screen can paint between procedural builds.
    if (i % 6 === 5) await new Promise(r => setTimeout(r, 0));
  }

  let densityLevel = 1;
  let activeCount = count;
  let playerSpeed = 0; // m/s, lets spawn distance & lane-change etiquette scale with NOS speeds

  function laneFree(lane: number, z: number, gap: number, except?: TrafficCar) {
    for (const c of cars) {
      if (c === except) continue;
      if ((c.lane === lane || c.targetLane === lane) && Math.abs(c.z - z) < gap) return false;
    }
    return true;
  }
  function occupiedLanes(lanes: readonly number[], z: number, window: number, except?: TrafficCar) {
    const set = new Set<number>();
    for (const c of cars) if (c !== except && Math.abs(c.z - z) < window) { set.add(c.lane); set.add(c.targetLane); }
    return lanes.filter(l => set.has(l)).length;
  }
  function spawn(c: TrafficCar, playerZ: number, far = false) {
    const oncoming = rng() < 0.34;
    const lanes = oncoming ? ONCOMING_LANES : PLAYER_LANES;
    const lead = Math.min(260, playerSpeed * 1.6); // at 2x NOS (124 m/s) cars appear ~200 m further out
    let z = playerZ + SPAWN_MIN + lead + rng() * (SPAWN_MAX - SPAWN_MIN) + (far ? 120 : 0);
    let lane = lanes[Math.floor(rng() * lanes.length)];
    for (let tries = 0; tries < 12; tries++) {
      lane = lanes[Math.floor(rng() * lanes.length)];
      // Never close every lane in one spot: keep at least one escape lane within a 34 m window.
      if (laneFree(lane, z, 28, c) && occupiedLanes(lanes, z, 34, c) < lanes.length - 1) break;
      z += 26 + rng() * 30;
    }
    c.dir = oncoming ? -1 : 1;
    c.lane = c.targetLane = lane;
    c.z = z;
    c.x = laneX(lane);
    c.cruise = oncoming ? 22.5 + rng() * 10.5 : 17.5 + rng() * 10; // 63–104 km/h our side, 81–118 km/h oncoming
    c.v = c.cruise;
    c.yaw = oncoming ? Math.PI : 0;
    c.laneTimer = 4 + rng() * 10;
    c.passed = false;
    c.braking = false;
    c.hitCooldown = 0;
    c.spin = 0;
    c.car.visible = true;
  }

  function reset(playerZ: number) {
    cars.forEach((c, i) => {
      spawn(c, playerZ + i * 18, false);
      c.z = Math.max(c.z, playerZ + 60 + i * 24);
      c.car.visible = i < activeCount;
    });
  }
  reset(0);

  const events: TrafficEvent[] = [];
  const tmpPlayer: Body = { x: 0, z: 0, yaw: 0 };

  function update(dt: number, player: PlayerBody, _playerYawRate: number, active: boolean) {
    events.length = 0;
    playerSpeed = player.vz;
    tmpPlayer.x = player.x; tmpPlayer.z = player.z; tmpPlayer.yaw = player.yaw;

    for (let i = 0; i < cars.length; i++) {
      const c = cars[i];
      if (i >= activeCount) { c.car.visible = false; continue; }
      c.car.visible = true;

      // ---- recycle ----
      const rel = c.z - player.z;
      if ((c.dir === 1 && rel < -70) || (c.dir === -1 && rel < -30) || rel > SPAWN_MAX + 260) spawn(c, player.z);

      if (active) {
        // ---- AI: follow leader in lane, occasional lane changes ----
        let desired = c.cruise;
        c.braking = false;
        for (const o of cars) {
          if (o === c || o.dir !== c.dir || !o.car.visible) continue;
          const sameLane = o.lane === c.lane || o.targetLane === c.lane || o.targetLane === c.targetLane;
          const ahead = (o.z - c.z) * c.dir;
          if (sameLane && ahead > 0 && ahead < 22) {
            const gapSpeed = Math.max(0, o.v - (22 - ahead) * 0.6);
            if (gapSpeed < desired) { desired = gapSpeed; c.braking = o.v < c.v - 1.5; }
          }
        }
        // React to the player sitting in front (brake lights, no ghosting)
        const relP = (player.z - c.z) * c.dir;
        if (relP > 0 && relP < 16 && Math.abs(player.x - c.x) < 2.1) {
          const pSpeed = player.vz * c.dir;
          if (pSpeed < desired) { desired = Math.max(0, pSpeed - 1); c.braking = true; }
        }
        c.v += THREE.MathUtils.clamp(desired - c.v, -9 * dt, 3.2 * dt);
        if (c.v < 0) c.v = 0;

        c.laneTimer -= dt;
        if (c.laneTimer <= 0 && c.lane === c.targetLane) {
          c.laneTimer = 5 + rng() * 11;
          const lanes = c.dir === 1 ? PLAYER_LANES : ONCOMING_LANES;
          const idx = lanes.indexOf(c.lane);
          const options = [lanes[idx - 1], lanes[idx + 1]].filter(l => l !== undefined) as number[];
          const next = options[Math.floor(rng() * options.length)];
          // Never cut across the player's nose: the no-lane-change bubble grows with closing speed.
          const bubble = 18 + (c.dir === 1 ? Math.max(0, player.vz - c.v) : player.vz + c.v) * 0.95;
          if (next !== undefined && laneFree(next, c.z, 30, c) && Math.abs(c.z - player.z) > bubble) c.targetLane = next;
        }
        const tx = laneX(c.targetLane);
        const dx = tx - c.x;
        const lateral = THREE.MathUtils.clamp(dx * 1.6, -2.6, 2.6) * (c.v > 1 ? 1 : 0);
        c.x += lateral * dt;
        if (Math.abs(dx) < 0.08) { c.lane = c.targetLane; c.x = tx; }
        c.z += c.v * c.dir * dt;
        const heading = c.dir === 1 ? 0 : Math.PI;
        const steerYaw = Math.atan2(lateral * c.dir, Math.max(c.v, 3));
        c.spin *= Math.exp(-dt * 2.2);
        c.yaw = heading + steerYaw * 0.9 + c.spin;
        c.hitCooldown = Math.max(0, c.hitCooldown - dt);

        // ---- near miss / overtake bookkeeping ----
        const relNow = c.z - player.z;
        if (!c.passed && relNow < 0 && rel >= 0) {
          c.passed = true;
          const gap = Math.abs(c.x - player.x) - CAR_HALF_W * 2;
          if (c.hitCooldown <= 0 && gap < 1.15 && player.speed > 18) {
            events.push({ type: 'nearMiss', closeness: THREE.MathUtils.clamp(1 - gap / 1.15, 0, 1), oncoming: c.dir === -1, x: c.x, z: c.z });
          } else if (c.dir === 1 && c.hitCooldown <= 0) {
            events.push({ type: 'overtake' });
          }
        }
      }

      // ---- collision with the player: equal masses, normal impulse + Coulomb-like friction tangent ----
      const contact = obbContact(tmpPlayer, c);
      if (contact) {
        // Split the de-penetration (player is pushed a bit further than the NPC so the world feels solid)
        player.x += contact.nx * contact.depth * 0.62;
        player.z += contact.nz * contact.depth * 0.62;
        c.x -= contact.nx * contact.depth * 0.38;
        c.x = THREE.MathUtils.clamp(c.x, -ROAD_HALF + 1.0, ROAD_HALF - 1.0);
        tmpPlayer.x = player.x; tmpPlayer.z = player.z;
        const nx = contact.nx, nz = contact.nz;
        const tx = -nz, tz = nx; // contact tangent
        const relVx = player.vx, relVz = player.vz - c.v * c.dir;
        const vn = relVx * nx + relVz * nz;
        const vt = relVx * tx + relVz * tz;
        if (vn < 0) {
          const headOn = c.dir === -1 && Math.abs(nz) > 0.7;
          const e = headOn ? 0.28 : 0.16; // frontal hits rebound harder, sideswipes smear along the body
          const j = -(1 + e) * vn * 0.5;                   // normal impulse (equal masses → split)
          const jt = THREE.MathUtils.clamp(-vt * 0.38, -(Math.abs(j) * 0.9 + 0.9), Math.abs(j) * 0.9 + 0.9); // friction along the flank
          player.vx += nx * j + tx * jt;
          player.vz += nz * j + tz * jt;
          // NPC reacts on its axis of travel plus a lateral kick, so the car gets shoved across the lane
          c.v = THREE.MathUtils.clamp(c.v + (nz * j + tz * jt) * c.dir * 0.9, 0, 46);
          c.x -= THREE.MathUtils.clamp(nx * (Math.abs(j) * 0.05 + Math.abs(jt) * 0.04), 0, 1.1);
          c.spin += THREE.MathUtils.clamp(-nx * j * 0.016 * c.dir - tz * jt * 0.008, -0.62, 0.62);
          c.v *= 1 - Math.min(0.18, Math.abs(jt) * 0.008); // scrubbing sideways bleeds speed
          c.hitCooldown = 1.2;
          c.passed = true;
          const ahead = (c.x - player.x) * Math.sin(player.yaw) + (c.z - player.z) * Math.cos(player.yaw);
          events.push({ type: 'crash', impact: -vn, nx, nz, oncoming: c.dir === -1, headOn, ahead, tangent: Math.abs(vt) });
        }
      }

      // ---- present ----
      c.car.position.set(c.x, 0, c.z);
      c.car.rotation.y = c.yaw;
      c.car.userData.tick(dt, { speed: c.v, steer: THREE.MathUtils.clamp((laneX(c.targetLane) - c.x) * 0.6, -1, 1), serviceBrake: c.braking });
    }
    return events;
  }

  return {
    group,
    cars,
    update,
    density(level) {
      densityLevel = level;
      activeCount = Math.round(THREE.MathUtils.clamp(count * (0.62 + densityLevel * 0.13), 6, count));
    },
    reset,
    setHeadlights(on) { for (const c of cars) c.car.userData.setHeadlights(on); },
    dispose() {
      scene.remove(group);
      // All civilian geometry/materials/contact shadows are cached and shared
      // between the 50 AI cars, so they are intentionally kept alive here.
      group.traverse(o => {
        const m = o as THREE.Mesh;
        if (m.isMesh && !m.userData.shared) { m.geometry?.dispose(); const mats = Array.isArray(m.material) ? m.material : [m.material]; mats.forEach(mm => mm?.dispose?.()); }
      });
      for (const c of cars) for (const m of (c.car.userData.repaintMats as THREE.Material[] | undefined) ?? []) m.dispose();
    },
  };
}

/* ================= Intersection (cross-street) traffic =================
 * Cars crossing the avenue at each cross street, using the same Group B body.
 * They wait at the far curb while the player barrels through (they yield), then
 * stream across — so the intersections finally live.
 */
export const CROSS_SPACING = 240;
export const CROSS_OFFSET = 210;
/** World z of the k-th intersection (every 4th 60 m chunk is a cross street). */
export function crossingZ(k: number) { return CROSS_OFFSET + CROSS_SPACING * k; }

export type CrossCar = {
  car: RallyModel;
  k: number;
  dir: 1 | -1;
  x: number; z: number; yaw: number;
  v: number; cruise: number;
  hold: boolean; // true while yielding to the player
};
export type CrossTraffic = {
  group: THREE.Group;
  cars: CrossCar[];
  update(dt: number, player: PlayerBody, active: boolean): TrafficEvent[];
  reset(playerZ: number): void;
  setHeadlights(on: boolean): void;
  dispose(): void;
};

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

export async function createCrossTraffic(scene: THREE.Scene, count: number, onProgress?: (done: number, total: number) => void): Promise<CrossTraffic> {
  const group = new THREE.Group();
  group.name = 'NYC intersection traffic';
  scene.add(group);
  let seed = 99173;
  const rng = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  const cars: CrossCar[] = [];
  for (let i = 0; i < count; i++) {
    const livery = pickLivery(rng);
    const car = civilCar(livery);
    car.rotation.order = 'YXZ';
    car.name = `Cross traffic ${livery.name} ${i + 1}`;
    group.add(car);
    cars.push({ car, k: i, dir: 1, x: 0, z: 0, yaw: 0, v: 0, cruise: 11 + rng() * 4, hold: true });
    onProgress?.(i + 1, count);
    if (i % 6 === 5) await new Promise(r => setTimeout(r, 0));
  }

  let farK = count;
  function respawn(c: CrossCar) {
    const side = rng() < 0.5 ? -1 : 1;
    c.dir = side > 0 ? -1 : 1;
    c.x = side * (ROAD_HALF + 42 + rng() * 48);
    c.z = crossingZ(c.k);
    c.yaw = c.dir > 0 ? Math.PI / 2 : -Math.PI / 2;
    c.v = 0;
    c.cruise = 12 + rng() * 4;
    c.hold = true;
  }

  function reset(playerZ: number) {
    const startK = Math.ceil((playerZ - 120) / CROSS_SPACING);
    cars.forEach((c, i) => { c.k = startK + i; respawn(c); });
    farK = startK + count + 1;
  }
  reset(0);

  const events: TrafficEvent[] = [];
  const body: Body = { x: 0, z: 0, yaw: 0 };

  function update(dt: number, player: PlayerBody, active: boolean): TrafficEvent[] {
    events.length = 0;
    body.x = player.x; body.z = player.z; body.yaw = player.yaw;
    for (const c of cars) {
      let z = crossingZ(c.k);
      // Fell behind the player: beam it onto a fresh intersection ahead
      if (z < player.z - 90) { c.k = farK++; respawn(c); z = c.z; }
      c.z = z;
      c.yaw = c.dir > 0 ? Math.PI / 2 : -Math.PI / 2;

      const outside = Math.abs(c.x) > ROAD_HALF + 2.1;
      // Time-based yield: only hold back if the player will reach the junction before this car can clear its half.
      const tPlayer = (z - player.z) / Math.max(player.vz, 1);
      const need = Math.max(0, (Math.abs(c.x) - (ROAD_HALF + 2.1)) / Math.max(c.cruise, 6));
      const threat = outside && player.vz > 6 && tPlayer > -0.4 && tPlayer < need + 0.5;
      if (active && threat) {
        c.v = Math.max(0, c.v - 26 * dt);
        c.hold = true;               // yield at the curb: brake lights on
      } else {
        c.v = Math.min(c.cruise, c.v + 8.5 * dt);
        c.hold = false;
      }
      if (active) c.x += c.dir * c.v * dt;
      // Crossed the whole block: move to the next crossing ahead
      if (Math.abs(c.x) > ROAD_HALF + 88) { c.k = farK++; respawn(c); }

      // Collision with the player (same two-body impulse model)
      const contact = obbContact(body, c);
      if (contact) {
        player.x += contact.nx * contact.depth * 0.62;
        player.z += contact.nz * contact.depth * 0.62;
        body.x = player.x; body.z = player.z;
        c.x = clamp(c.x - contact.nx * contact.depth * 0.38, -ROAD_HALF - 86, ROAD_HALF + 86);
        const nx = contact.nx, nz = contact.nz;
        const tx = -nz, tz = nx;
        const relVx = player.vx - c.dir * c.v, relVz = player.vz;
        const vn = relVx * nx + relVz * nz;
        const vt = relVx * tx + relVz * tz;
        if (vn < 0) {
          const e = 0.2;
          const j = -(1 + e) * vn * 0.5;
          const jt = clamp(-vt * 0.38, -(Math.abs(j) * 0.9 + 0.9), Math.abs(j) * 0.9 + 0.9);
          player.vx += nx * j + tx * jt;
          player.vz += nz * j + tz * jt;
          // Cross car loses/gains crossing-axis speed and gets shoved & spun
          c.v = clamp(Math.abs(c.v + (nx * j + tx * jt) * c.dir * 0.5), 0, 18);
          c.x = clamp(c.x + nx * Math.min(0.8, Math.abs(j) * 0.06), -ROAD_HALF - 86, ROAD_HALF + 86);
          const ahead = (c.x - player.x) * Math.sin(player.yaw) + (c.z - player.z) * Math.cos(player.yaw);
          events.push({ type: 'crash', impact: -vn, nx, nz, oncoming: false, headOn: false, ahead, tangent: Math.abs(vt) });
        }
      }

      c.car.position.set(c.x, 0, c.z);
      c.car.rotation.y = c.yaw;
      c.car.userData.tick(dt, { speed: c.v, steer: clamp(-c.dir * 0.0, -1, 1), serviceBrake: c.hold });
    }
    return events;
  }

  return {
    group,
    cars,
    update,
    reset,
    setHeadlights(on: boolean) { for (const c of cars) c.car.userData.setHeadlights(on); },
    dispose() {
      scene.remove(group);
      // All civilian geometry/materials/contact shadows are cached and shared
      // between the 50 AI cars, so they are intentionally kept alive here.
      group.traverse(o => {
        const m = o as THREE.Mesh;
        if (m.isMesh && !m.userData.shared) { m.geometry?.dispose(); const mats = Array.isArray(m.material) ? m.material : [m.material]; mats.forEach(mm => mm?.dispose?.()); }
      });
      for (const c of cars) for (const m of (c.car.userData.repaintMats as THREE.Material[] | undefined) ?? []) m.dispose();
    },
  };
}
