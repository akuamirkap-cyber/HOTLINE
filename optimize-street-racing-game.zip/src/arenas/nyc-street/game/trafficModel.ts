import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { RallyModel } from '../../rc-drift/pigeon/rally-model.js';
import { applyCurvedWorld } from './curveWorld';
import { makeContactShadow } from './trafficShadow';

/**
 * Lightweight "HD-looking" NYC traffic body.
 *
 * The old traffic spawned a complete, articulated Group B rally model for every
 * car: cockpit, driver, suspension, decals, dozens of materials and draw calls.
 * At 2× density that is the single biggest GPU/CPU cost in NYC.
 *
 * Here every civilian car is three draw calls:
 *   1. paint + trim + wheels  (one vertex-coloured PBR material)
 *   2. cabin glass            (one shared glossy material)
 *   3. lamps                  (one shared unlit vertex-coloured material)
 * plus a baked contact shadow. Geometry is cached per livery and shared between
 * cars, so 38 cars cost about as much as two of the old models.
 * The silhouette uses beveled extrusions + chamfered wheel arches/rear wing lip,
 * so it still reads as premium low-poly HD rather than a plain box.
 */

const GEOMETRY_CACHE = new Map<string, THREE.BufferGeometry>();
const LIGHT_GEOMETRY = (() => {
  let cached: THREE.BufferGeometry | null = null;
  return () => (cached ??= buildLightGeometry());
})();
const GLASS_GEOMETRY = (() => {
  let cached: THREE.BufferGeometry | null = null;
  return () => (cached ??= cabinGeometry());
})();

const PAINT_MATERIAL = applyCurvedWorld(new THREE.MeshStandardMaterial({
  vertexColors: true,
  color: 0xffffff,
  roughness: 0.39,
  metalness: 0.42,
  envMapIntensity: 1.28,
}))!;

const GLASS_MATERIAL = applyCurvedWorld(new THREE.MeshStandardMaterial({
  color: 0x101b26,
  roughness: 0.07,
  metalness: 0.45,
  envMapIntensity: 1.8,
}))!;

const LAMP_MATERIAL = applyCurvedWorld(new THREE.MeshBasicMaterial({
  vertexColors: true,
  toneMapped: false,
  transparent: false,
}))!;

const COLOR = new THREE.Color();
const M = new THREE.Matrix4();
const Q = new THREE.Quaternion();
const E = new THREE.Euler();
const V = new THREE.Vector3();
const S = new THREE.Vector3(1, 1, 1);

function tint(geometry: THREE.BufferGeometry, hex: number, position: [number, number, number] = [0, 0, 0], rotation: [number, number, number] = [0, 0, 0]) {
  const g = geometry.index ? geometry.toNonIndexed() : geometry.clone();
  if (g !== geometry) geometry.dispose();
  if (rotation[0] || rotation[1] || rotation[2]) {
    Q.setFromEuler(E.set(rotation[0], rotation[1], rotation[2]));
    M.compose(V.set(0, 0, 0), Q, S);
    g.applyMatrix4(M);
  }
  g.translate(position[0], position[1], position[2]);
  COLOR.setHex(hex);
  const count = g.attributes.position.count;
  const colors = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    colors[i * 3] = COLOR.r;
    colors[i * 3 + 1] = COLOR.g;
    colors[i * 3 + 2] = COLOR.b;
  }
  g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  if (g.attributes.uv2) g.deleteAttribute('uv2');
  return g;
}

function box(w: number, h: number, d: number, hex: number, position: [number, number, number], rotation: [number, number, number] = [0, 0, 0]) {
  return tint(new THREE.BoxGeometry(w, h, d), hex, position, rotation);
}

/** Side silhouette extruded across the car's width. Length is local +Z after rotation. */
function hullGeometry() {
  const profile = new THREE.Shape();
  profile.moveTo(-1.82, 0.31);
  profile.lineTo(-1.88, 0.53);
  profile.lineTo(-1.86, 0.72);
  profile.lineTo(-1.68, 0.84);
  profile.lineTo(-1.16, 0.9);
  profile.lineTo(-0.34, 0.93);
  profile.lineTo(0.9, 0.92);
  profile.lineTo(1.5, 0.83);
  profile.lineTo(1.8, 0.75);
  profile.lineTo(1.86, 0.57);
  profile.lineTo(1.84, 0.33);
  profile.lineTo(1.68, 0.24);
  profile.lineTo(-1.62, 0.24);
  profile.closePath();
  const geo = new THREE.ExtrudeGeometry(profile, {
    depth: 1.74, steps: 1, curveSegments: 5, bevelEnabled: true,
    bevelThickness: 0.055, bevelSize: 0.055, bevelSegments: 2,
  });
  geo.translate(0, 0, -0.87);
  geo.rotateY(-Math.PI / 2);
  return geo;
}

function cabinGeometry() {
  const shape = new THREE.Shape();
  shape.moveTo(0.88, 0.92);
  shape.lineTo(0.25, 1.36);
  shape.lineTo(-0.88, 1.38);
  shape.lineTo(-1.38, 0.92);
  shape.closePath();
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth: 1.54, steps: 1, curveSegments: 4, bevelEnabled: true,
    bevelThickness: 0.04, bevelSize: 0.04, bevelSegments: 2,
  });
  geo.translate(0, 0, -0.77);
  geo.rotateY(-Math.PI / 2);
  return geo;
}

function wheelGeometry() {
  const tire = new THREE.CylinderGeometry(0.32, 0.32, 0.24, 12, 1);
  tire.rotateZ(Math.PI / 2);
  const rim = new THREE.CylinderGeometry(0.177, 0.177, 0.255, 10, 1);
  rim.rotateZ(Math.PI / 2);
  const hub = new THREE.CylinderGeometry(0.045, 0.045, 0.27, 6, 1);
  hub.rotateZ(Math.PI / 2);
  return { tire, rim, hub };
}

function buildPaintGeometry(ink: number, dim: number) {
  const parts: THREE.BufferGeometry[] = [];
  const hull = hullGeometry();
  parts.push(tint(hull, ink));
  hull.dispose();

  // Greenhouse glass is a separate draw call; the paint below adds the A/C pillars,
  // roof and a subtle rear spoiler lip so the silhouette is never a plain box.
  parts.push(box(0.07, 0.5, 0.055, 0x181c20, [-0.79, 1.12, 0.6], [0, 0, -0.28]));
  parts.push(box(0.07, 0.5, 0.055, 0x181c20, [0.79, 1.12, 0.6], [0, 0, -0.28]));
  parts.push(box(0.07, 0.5, 0.07, 0x181c20, [-0.79, 1.12, -1.16], [0, 0, 0.28]));
  parts.push(box(0.07, 0.5, 0.07, 0x181c20, [0.79, 1.12, -1.16], [0, 0, 0.28]));
  parts.push(box(1.6, 0.07, 1.1, ink, [0, 1.4, -0.32]));
  parts.push(box(1.66, 0.09, 0.18, dim, [0, 0.98, -1.48]));
  parts.push(box(1.7, 0.08, 0.16, 0x121316, [0, 0.8, -1.83]));
  parts.push(box(1.72, 0.06, 0.32, dim, [0, 0.94, -1.72]));
  // Side rubbing strips + wheel-arch shoulders, all in one material.
  parts.push(box(0.035, 0.075, 2.55, 0x15171b, [-0.925, 0.62, 0]));
  parts.push(box(0.035, 0.075, 2.55, 0x15171b, [0.925, 0.62, 0]));
  parts.push(box(1.78, 0.07, 0.1, 0x0d0e10, [0, 0.33, 1.83]));
  parts.push(box(1.88, 0.11, 0.2, 0x0d0e10, [0, 0.38, 1.88]));

  const wheels = wheelGeometry();
  for (const side of [-1, 1]) {
    for (const z of [-1.18, 1.18]) {
      parts.push(tint(wheels.tire.clone(), 0x0a0b0d, [side * 0.85, 0.325, z]));
      parts.push(tint(wheels.rim.clone(), 0xa9afb8, [side * 0.86, 0.325, z]));
      parts.push(tint(wheels.hub.clone(), 0x23272d, [side * 0.865, 0.325, z]));
    }
  }
  wheels.tire.dispose(); wheels.rim.dispose(); wheels.hub.dispose();

  // Grille, mirrors and the NYC taxi roof plate.
  parts.push(box(0.75, 0.16, 0.06, 0x0c0d0f, [0, 0.55, 1.88]));
  parts.push(box(0.17, 0.1, 0.22, dim, [-1.0, 1.02, 0.45]));
  parts.push(box(0.17, 0.1, 0.22, dim, [1.0, 1.02, 0.45]));
  parts.push(box(0.5, 0.13, 0.22, 0xf2c230, [0, 1.51, -0.25]));

  const merged = mergeGeometries(parts, false);
  parts.forEach(p => p.dispose());
  return merged ?? new THREE.BufferGeometry();
}

function buildLightGeometry() {
  const parts: THREE.BufferGeometry[] = [];
  for (const side of [-0.63, 0.63]) {
    parts.push(box(0.36, 0.14, 0.05, 0xfff3d2, [side, 0.7, 1.925]));
    parts.push(box(0.44, 0.13, 0.05, 0xcd1b24, [side, 0.69, -1.92]));
    parts.push(box(0.17, 0.08, 0.04, 0xffb020, [side * 1.18, 0.66, -1.74]));
  }
  const merged = mergeGeometries(parts, false);
  parts.forEach(p => p.dispose());
  return merged ?? new THREE.BufferGeometry();
}

function paintGeometry(ink: number, dim: number) {
  const key = `${ink}-${dim}`;
  let geo = GEOMETRY_CACHE.get(key);
  if (!geo) { geo = buildPaintGeometry(ink, dim); GEOMETRY_CACHE.set(key, geo); }
  return geo;
}

/**
 * RallyModel-compatible stand-in. Only the traffic-facing surface is provided;
 * the player still uses the full studio model.
 */
export function createTrafficProxy(ink: number, dim: number, opts: { contactShadow?: boolean } = {}): RallyModel {
  const group = new THREE.Group();
  group.name = 'NYC traffic proxy';

  const paint = new THREE.Mesh(paintGeometry(ink, dim), PAINT_MATERIAL);
  paint.userData.shared = true;
  paint.castShadow = false;
  paint.receiveShadow = false;
  paint.frustumCulled = false;
  group.add(paint);

  const glass = new THREE.Mesh(GLASS_GEOMETRY(), GLASS_MATERIAL);
  glass.userData.shared = true;
  glass.scale.set(1, 1, 1);
  glass.castShadow = false;
  glass.frustumCulled = false;
  group.add(glass);

  const lamps = new THREE.Mesh(LIGHT_GEOMETRY(), LAMP_MATERIAL);
  lamps.userData.shared = true;
  lamps.visible = false;
  lamps.frustumCulled = false;
  group.add(lamps);
  if (opts.contactShadow !== false) group.add(makeContactShadow(2.2, 3.9, 0.64));

  group.userData = {
    tick: () => {},
    setHeadlights: (on: boolean) => { lamps.visible = on; },
    updateGlow: () => {},
    setCockpitView: () => {},
    setMirrorTexture: () => {},
    resetDriver: () => {},
    driverAction: { mode: 'wheel', reach: 0, contact: false },
    sockets: { driverEye: new THREE.Object3D() },
    repaintMats: [] as THREE.Material[],
  };
  return group as unknown as RallyModel;
}

export function disposeTrafficGeometry() {
  GEOMETRY_CACHE.forEach(g => g.dispose());
  GEOMETRY_CACHE.clear();
  PAINT_MATERIAL.dispose();
  GLASS_MATERIAL.dispose();
  LAMP_MATERIAL.dispose();
  LIGHT_GEOMETRY().dispose();
}
