import type { DriftState, DriftWheel, WheelId } from '../../rc-drift/pigeon/drift-physics.js';
import { CAR_SCALE } from '../../rc-drift/pigeon/rmx-drift-adapter';
import { ROAD_HALF } from './city';

/**
 * NYC street-drift vehicle model.
 *
 * Same family of dynamics as the PRODRIFT / Mt. Haruna drift car: the body heading and the velocity
 * vector are integrated separately, lateral tyre force is a soft-saturating (tanh) function of lateral
 * slip with three grip tiers (grip / slide / handbrake), a hidden stability term flattens gentle
 * cornering, power-over lets the rear step out under throttle + lock, a counter-steer assist pulls the
 * nose toward the velocity vector so slides stay catchable, and the handbrake kills rear grip for
 * E-brake entries, donuts and 360s.  On top of that the street version adds a high-speed engine map
 * (250 km/h), NOS (2× top speed, 500 km/h), speed-scaled downforce and steering lock so the top end
 * stays drivable, and curb barriers that reflect only the into-wall velocity component.
 */
export const BASE_MAX = 250 / 3.6;     // m/s = exactly 250 km/h on the speedometer
export const NITRO_MULT = 2;
export const NITRO_MAX = BASE_MAX * NITRO_MULT; // exactly 500 km/h

const T = {
  ENGINE: 18.5, NITRO_ENGINE: 45, BRAKE: 27, REVERSE: 14, REVERSE_MAX: 7, HANDBRAKE_DRAG: 7.5,
  AERO: 0.00018, ROLL: 0.017, OVERCAP_DECAY: 2.4,
  // Responsive street steering: a shorter input ramp + less high-speed lock
  // taper gives the immediate "point and go" feel of an arcade racer, while
  // the yaw dampers below still keep 500 km/h NOS runs stable.
  STEER_ON: 22, STEER_OFF: 24,
  GRIP_STRAIGHT: 6.8, GRIP_SLIDE: 5.2, GRIP_HANDBRAKE: 1.6, SLIP_SOFTEN: 0.40, STABILITY: 2.4, POWER_OVER: 0.78,
  TANH_GAIN: 0.28, LAT_SCALE: 4.6, LAT_DAMP: 0.95, LAT_DAMP_HB: 0.35,
  STEER_FACTOR_SPEED: 4.4, YAW: 6.4, YAW_HB: 9.4, COUNTER: 2.9, COUNTER_MIN_SPEED: 5, COUNTER_MIN_SLIP: 0.14, HARD_SPIN: 0.85,
  ANG_DAMP: 4.0, ANG_DAMP_HB: 2.2, VISUAL_STEER: 0.52,
  WALL_SCRAPE_E: 0.12, WALL_CRASH_E: 0.30, WALL_CRASH_SPEED: 6,
} as const;

const HALF_TRACK = 1.038 * CAR_SCALE, FRONT_Z = 1.665 * CAR_SCALE, REAR_Z = -1.433 * CAR_SCALE;
const WHEEL_R = 0.479 * CAR_SCALE;
const PROBE_HALF_W = 0.98, PROBE_HALF_L = 1.9;
const PROBES: ReadonlyArray<readonly [number, number]> = [
  [PROBE_HALF_W, PROBE_HALF_L], [PROBE_HALF_W, 0], [PROBE_HALF_W, -PROBE_HALF_L], [0, PROBE_HALF_L],
  [0, -PROBE_HALF_L], [-PROBE_HALF_W, PROBE_HALF_L], [-PROBE_HALF_W, 0], [-PROBE_HALF_W, -PROBE_HALF_L],
];
const clamp = (x: number, a: number, b: number) => (x < a ? a : x > b ? b : x);
const TAU = Math.PI * 2;

export type StreetInput = {
  /** +1 = left (A), -1 = right (D) */
  steer: number;
  /** 0..1 brake / reverse */
  brake: number;
  /** Space: E-brake drift */
  handbrake: boolean;
  /** Shift / N: NOS */
  nitro: boolean;
  /** W held: full power (enables power-over). Otherwise the car cruises on auto-throttle. */
  power: boolean;
  /** auto-throttle cruise */
  auto: boolean;
  /** Steering response gain (0.7–1.6). Scales ramp, turn-in and a slice of
   *  high-speed lock, so even a full key press responds differently. */
  response?: number;
};

export type StreetTelemetry = {
  slipDeg: number;
  drifting: boolean;
  driftTime: number;
  wallHit: number;       // approach speed of the last curb impact this step (m/s)
  nitroActive: boolean;
  /** Exact wheel-coupled engine speed in RPM (680 idle .. 7120 redline). */
  rpm: number;
  /** Numeric gear for audio & MFD: 0 = neutral/stopped, 1..7 = forward, -1 = reverse. */
  gearNum: number;
  /** Acoustic engine load 0.04..1.0, gated at crawl speeds so 1 km/h sounds gentle. */
  load: number;
};

export function createStreetCar() {
  const ids: WheelId[] = ['FL', 'FR', 'RL', 'RR'];
  const wheels = Object.fromEntries(ids.map(id => [id, {
    front: id[0] === 'F', side: id[1] === 'L' ? 1 : -1,
    x: 0, z: 0, angle: 0, omega: 0, spin: 0, along: 0, across: 0, slip: 0, load: 1220 * 9.81 / 4, roughness: 0, height: 0, worldY: 0,
  } as DriftWheel])) as Record<WheelId, DriftWheel>;
  const list = ids.map(id => wheels[id]);

  const state: DriftState = {
    x: 0, z: 0, yaw: 0, vx: 0, vz: 0, yawRate: 0, speed: 0, forwardSpeed: 0, lateralSpeed: 0, beta: 0,
    steer: 0, steerAngle: 0, accelLong: 0, accelLat: 0, throttle: 0, brake: 0, rearLock: 0, rev: 0.16, gear: '1', shifting: false,
    handbrake: false, serviceBrake: false, rearSlip: 0, tireNoise: 0, roughness: 0, wheels,
    driftBlend: 0, driftPhase: 'grip', driftDirection: 0, coasting: false,
    cueSpeed: 0, cueScale: 1, bodyRoll: 0, bodyPitch: 0, wheelTurn: 0,
  };
  const IDLE_RPM = 680;
  const REDLINE_RPM = 7200;
  const GEAR_BANDS = [0, 35, 75, 120, 170, 225, 300, NITRO_MAX * 3.6];
  // Entry and shift-point RPM per forward gear (close-ratio 7-speed M-DCT).
  const GEAR_RPM_LO = [IDLE_RPM, IDLE_RPM, 3450, 3820, 4080, 4320, 4520, 4950];
  const GEAR_RPM_HI = [IDLE_RPM, 6550, 6660, 6750, 6820, 6880, 6960, 7080];

  const tele: StreetTelemetry = {
    slipDeg: 0, drifting: false, driftTime: 0, wallHit: 0, nitroActive: false,
    rpm: IDLE_RPM, gearNum: 0, load: 0.05,
  };

  let steerAngle = 0, angularVel = 0, roll = 0, pitch = 0, rearSpin = 0, frontSpin = 0;
  let nitroActive = false;
  let engineRpm = IDLE_RPM;

  function syncGearFromSpeed(vLong: number) {
    const absKmh = Math.abs(vLong) * 3.6;
    if (vLong < -0.35) {
      state.gear = 'R';
      tele.gearNum = -1;
      return { gear: -1, ratio: clamp(absKmh / (T.REVERSE_MAX * 3.6), 0, 1) };
    }
    const kmh = Math.max(0, vLong) * 3.6;
    let gear = 1;
    while (gear < 7 && kmh >= GEAR_BANDS[gear]) gear++;
    state.gear = String(gear);
    tele.gearNum = kmh < 0.12 && state.throttle < 0.05 ? 0 : gear;
    const lo = GEAR_BANDS[gear - 1], hi = GEAR_BANDS[gear];
    return { gear, ratio: clamp((kmh - lo) / Math.max(1, hi - lo), 0, 1) };
  }

  function refresh() {
    const fx = Math.sin(state.yaw), fz = Math.cos(state.yaw), rx = Math.cos(state.yaw), rz = -Math.sin(state.yaw);
    state.speed = Math.hypot(state.vx, state.vz);
    state.forwardSpeed = state.vx * fx + state.vz * fz;
    state.lateralSpeed = state.vx * rx + state.vz * rz;
    state.beta = state.speed > 1.8 ? Math.atan2(state.lateralSpeed, Math.max(0.5, Math.abs(state.forwardSpeed))) : 0;
    state.cueSpeed = state.speed;
    state.yawRate = angularVel;
    // Keep gear & RPM truthful right after an impact slows the car down (e.g. to 1 km/h).
    const g = syncGearFromSpeed(state.forwardSpeed);
    if (g.gear > 0) {
      const coupled = GEAR_RPM_LO[g.gear] + (GEAR_RPM_HI[g.gear] - GEAR_RPM_LO[g.gear]) * g.ratio;
      if (engineRpm > coupled + 350 && !state.handbrake) engineRpm = coupled;
    }
    tele.rpm = engineRpm;
    state.rev = clamp(engineRpm / REDLINE_RPM, 0.08, 1);
    for (const w of list) {
      const lx = w.side * HALF_TRACK, lz = w.front ? FRONT_Z : REAR_Z;
      w.x = state.x + lx * rx + lz * fx;
      w.z = state.z + lx * rz + lz * fz;
    }
  }

  function reset(x = 0, z = 0, yaw = 0) {
    engineRpm = IDLE_RPM;
    Object.assign(state, { x, z, yaw, vx: 0, vz: 0, yawRate: 0, steer: 0, steerAngle: 0, accelLong: 0, accelLat: 0, throttle: 0, brake: 0, rearLock: 0, rev: IDLE_RPM / REDLINE_RPM, gear: '1', handbrake: false, serviceBrake: false, rearSlip: 0, tireNoise: 0, driftBlend: 0, driftPhase: 'grip', driftDirection: 0, bodyRoll: 0, bodyPitch: 0, wheelTurn: 0 });
    for (const w of list) Object.assign(w, { angle: 0, omega: 0, spin: 0, along: 0, across: 0, slip: 0, height: 0, worldY: 0 });
    steerAngle = angularVel = roll = pitch = rearSpin = frontSpin = 0;
    nitroActive = false;
    Object.assign(tele, { slipDeg: 0, drifting: false, driftTime: 0, wallHit: 0, nitroActive: false, rpm: IDLE_RPM, gearNum: 0, load: 0.05 });
    refresh();
  }

  /** Curb barriers along the avenue: push out by the worst probe penetration, reflect only the into-wall component. */
  function curbs(): number {
    const fwX = Math.sin(state.yaw), sdX = Math.cos(state.yaw);
    const limit = ROAD_HALF - 0.12;
    let maxPen = 0, nx = 0;
    for (const [a, b] of PROBES) {
      const px = state.x + sdX * a + fwX * b;
      const pen = Math.abs(px) - limit;
      if (pen > maxPen) { maxPen = pen; nx = px > 0 ? -1 : 1; }
    }
    if (maxPen <= 0) return 0;
    state.x += nx * maxPen;
    const vn = state.vx * nx;
    if (vn < 0) {
      const approach = -vn;
      const e = approach > T.WALL_CRASH_SPEED ? T.WALL_CRASH_E : T.WALL_SCRAPE_E;
      state.vx -= (1 + e) * vn * nx;
      if (approach > T.WALL_CRASH_SPEED) { state.vx *= 0.9; state.vz *= 0.9; }
      angularVel *= 0.85;
      return approach;
    }
    // grinding along the curb: tangential scrub
    state.vz *= 1 - Math.min(0.02, 0.004 * Math.abs(state.vz) / 10);
    return 0;
  }

  function step(dt: number, input: StreetInput) {
    const steerCmd = clamp(input.steer, -1, 1);
    const response = clamp(input.response ?? 1, 0.7, 1.6);
    const brake = clamp(input.brake, 0, 1);
    const handbrake = input.handbrake;
    // Throttle semantics: cruise = 0.5 (stability on), W held = 1.0 (power-over available), brake = 0.
    const throttle = brake > 0.05 ? 0 : input.power ? 1 : input.auto ? 0.5 : 0;
    const driveForce = brake > 0.05 ? 0 : (input.power || input.auto) ? 1 : 0;
    nitroActive = input.nitro && driveForce > 0;
    tele.nitroActive = nitroActive;

    const fx = Math.sin(state.yaw), fz = Math.cos(state.yaw), rx = Math.cos(state.yaw), rz = -Math.sin(state.yaw);
    const vLong = state.vx * fx + state.vz * fz;
    const vLat = state.vx * rx + state.vz * rz;
    const speed = Math.hypot(state.vx, state.vz);

    // ---- steering (speed-sensitive lock, tuned for quick NYC lane changes) ----
    // The taper now starts later and bottoms out higher, so 250 km/h still has
    // a usable ~55% lock (previously 40%). Sensitivity from the HUD scales the
    // input itself, keeping the same physical lock limit for every player.
    const lock = clamp(1 - Math.max(0, speed - 24) * 0.0085, 0.34, 1) * (0.86 + 0.14 * response);
    const steerGoal = steerCmd * lock;
    const ramp = (steerCmd !== 0 ? T.STEER_ON * (1 - 0.32 * Math.min(1, speed / 90)) : T.STEER_OFF) * response;
    steerAngle += (steerGoal - steerAngle) * Math.min(1, ramp * dt);

    const slip = speed > 1.8 ? Math.atan2(vLat, Math.max(0.5, Math.abs(vLong))) : 0;
    const absSlip = Math.abs(slip);
    tele.slipDeg = slip * 180 / Math.PI;

    // ---- longitudinal ----
    const maxSpeed = nitroActive ? NITRO_MAX : BASE_MAX;
    let longAccel = 0;
    if (driveForce > 0) {
      const ratio = Math.min(1, Math.max(0, vLong) / maxSpeed);
      // Engine map never drops below 28%: the cap itself is enforced by the over-cap decay term.
      longAccel += (nitroActive ? T.NITRO_ENGINE : T.ENGINE) * (1 - 0.72 * ratio * ratio) * driveForce;
    }
    if (brake > 0) longAccel -= (vLong > 1.5 ? T.BRAKE : vLong < -T.REVERSE_MAX ? 0 : T.REVERSE) * brake;
    if (handbrake && speed > 1) longAccel -= Math.sign(vLong) * T.HANDBRAKE_DRAG;
    const drag = T.AERO * speed * speed + T.ROLL * Math.abs(vLong) + (vLong > maxSpeed ? (vLong - maxSpeed) * T.OVERCAP_DECAY : 0);
    longAccel -= Math.sign(vLong) * drag;

    // ---- lateral grip / oversteer ----
    let grip: number = handbrake ? T.GRIP_HANDBRAKE : absSlip > T.SLIP_SOFTEN ? T.GRIP_SLIDE : T.GRIP_STRAIGHT;
    // Demand is measured against the available lock, so a full tap at 200 km/h behaves like a full tap at 60 km/h.
    const relSteer = Math.abs(steerAngle) / Math.max(lock, 0.5);
    const demand = Math.min(1, Math.max(0, (relSteer - 0.45) / 0.4) + Math.max(0, (throttle - 0.55) / 0.45));
    const stability = handbrake ? 0 : Math.max(0, 1 - absSlip / 0.30) * (1 - demand);
    grip += T.STABILITY * stability;
    const slideFactor = clamp((absSlip - 0.15) / 0.45, 0, 1);
    if (throttle > 0.55 && Math.abs(steerAngle) > 0.3 && speed > 9 && slideFactor > 0) grip *= 1 - (1 - T.POWER_OVER) * slideFactor;
    // High-speed downforce plants the car for lane changes, but fades once the rear is out so a slide keeps its speed.
    const downforce = 1 + Math.min(1.2, speed / 70) * (1 - slideFactor * 0.7);
    // Turn-in bite: a little extra front-end response when the wheel is applied
    // and the car is still gripping, so a keyboard tap changes lane instantly.
    const turnIn = 1 + Math.abs(steerAngle) * (1 - slideFactor) * 0.22 * response;
    const lateralForce = -Math.tanh(vLat * T.TANH_GAIN) * grip * T.LAT_SCALE * downforce * turnIn - vLat * (handbrake ? T.LAT_DAMP_HB : T.LAT_DAMP);

    const ax = fx * longAccel + rx * lateralForce, az = fz * longAccel + rz * lateralForce;
    state.vx += ax * dt; state.vz += az * dt;
    // Hard longitudinal cap: the speedometer, NOS and physics share exactly the
    // same ceiling (250 km/h / 500 km/h) instead of settling a few km/h above it.
    const cappedLong = state.vx * fx + state.vz * fz;
    if (cappedLong > maxSpeed) {
      const excess = cappedLong - maxSpeed;
      state.vx -= fx * excess; state.vz -= fz * excess;
    }
    if (driveForce <= 0 && brake <= 0 && Math.hypot(state.vx, state.vz) < 0.25) { state.vx = 0; state.vz = 0; }

    // ---- yaw: steer torque + counter-steer assist + damping ----
    const steerFactor = Math.min(1, speed / T.STEER_FACTOR_SPEED);
    const dirSign = vLong >= -0.5 ? 1 : -1;
    const yawStrength = handbrake ? T.YAW_HB * (1 - 0.35 * Math.min(1, speed / 50)) : T.YAW * (1 + 0.3 * Math.min(1, speed / 80));
    let yawTorque = steerAngle * yawStrength * steerFactor * dirSign * (0.82 + 0.18 * response);
    const hardSpin = handbrake && Math.abs(steerAngle) > T.HARD_SPIN;
    if (speed > T.COUNTER_MIN_SPEED && absSlip > T.COUNTER_MIN_SLIP && !hardSpin) yawTorque += Math.sin(slip) * T.COUNTER;
    // Extra yaw damping at autobahn speeds keeps the nose calm when weaving at 200–450 km/h.
    const angDamp = handbrake ? T.ANG_DAMP_HB : T.ANG_DAMP + 1.7 * stability + 1.5 * Math.min(1, speed / 80);
    angularVel += (yawTorque - angularVel * angDamp) * dt;
    state.yaw += angularVel * dt;
    if (state.yaw > Math.PI) state.yaw -= TAU; else if (state.yaw < -Math.PI) state.yaw += TAU;

    state.x += state.vx * dt;
    state.z += state.vz * dt;
    tele.wallHit = curbs();

    // ---- body + wheels for the Group B model ----
    const targetRoll = clamp(-vLat * 0.012 + angularVel * 0.035, -0.11, 0.11);
    const targetPitch = clamp(throttle * -0.025 + brake * 0.035 - (nitroActive ? 0.02 : 0), -0.06, 0.05);
    roll += (targetRoll - roll) * Math.min(1, 10 * dt);
    pitch += (targetPitch - pitch) * Math.min(1, 10 * dt);
    const visualSteer = steerAngle * T.VISUAL_STEER;
    const frontOmega = vLong / WHEEL_R;
    // Rear wheels over-spin under power-over / handbrake lock for the smoke + blur cues
    const spinUp = throttle > 0.55 && slideFactor > 0 ? 1 + slideFactor * 0.6 : 1;
    const rearOmega = handbrake && speed > 2 ? frontOmega * 0.15 : frontOmega * spinUp;
    frontSpin = (frontSpin + frontOmega * dt) % TAU;
    rearSpin = (rearSpin + rearOmega * dt) % TAU;
    const latIntensity = clamp((Math.abs(vLat) - 2.2) / 14 + (handbrake && speed > 4 ? 0.55 : 0), 0, 1);
    for (const w of list) {
      w.angle = w.front ? visualSteer : 0;
      w.omega = w.front ? frontOmega : rearOmega;
      w.spin = w.front ? frontSpin : rearSpin;
      w.along = vLong; w.across = vLat;
      w.slip = w.front ? clamp(Math.abs(vLat) / 16, 0, 1) : clamp(latIntensity + (spinUp - 1) * 0.5, 0, 1);
      w.height = 0; w.worldY = 0;
    }

    // ---- drift bookkeeping ----
    const drifting = speed > 6.5 && Math.abs(tele.slipDeg) > 14;
    tele.drifting = drifting;
    tele.driftTime = drifting ? tele.driftTime + dt : 0;
    const blendGoal = drifting ? Math.min(1, (Math.abs(tele.slipDeg) - 10) / 30) : 0;
    state.driftBlend += (blendGoal - state.driftBlend) * Math.min(1, dt * (blendGoal > state.driftBlend ? 6.6 : 4.8));
    state.driftDirection = drifting ? (slip >= 0 ? 1 : -1) : 0;
    state.driftPhase = !drifting ? 'grip' : handbrake ? 'entry' : Math.abs(tele.slipDeg) > 24 ? 'slide' : 'exit';

    // ---- state mirror ----
    state.steerAngle = visualSteer;
    state.steer = steerAngle;
    state.wheelTurn = steerAngle;
    state.bodyRoll = roll; state.bodyPitch = pitch;
    const absKmh = speed * 3.6;
    // Gate effective throttle & load at crawl speeds (e.g. 0–3 km/h) so 1 km/h
    // sounds like a gentle 1st-gear clutch creep instead of a full-throttle bark.
    const crawlGate = clamp(0.18 + 0.82 * Math.min(1, absKmh / 14), 0.18, 1);
    const rawThrottle = driveForce > 0 ? (nitroActive ? 1 : input.power ? 1 : 0.58) : 0;
    state.throttle = rawThrottle * crawlGate;
    state.brake = brake;
    state.serviceBrake = brake > 0.05 && vLong > 0.5;
    state.handbrake = handbrake;
    state.rearLock += ((handbrake ? 1 : 0) - state.rearLock) * Math.min(1, dt * 20);
    state.rearSlip = wheels.RL.slip;
    state.tireNoise = clamp(latIntensity * 1.2 + (brake > 0.3 && vLong > 10 ? 0.35 : 0), 0, 1);
    state.accelLong = longAccel;
    state.accelLat = lateralForce;

    // ---- Wheel-coupled 7-speed M-DCT RPM & load ----
    const g = syncGearFromSpeed(vLong);
    let rpmGoal = IDLE_RPM;
    if (g.gear === -1) {
      rpmGoal = 740 + g.ratio * 3560;
    } else if (handbrake && absKmh > 3) {
      // Clutch disengaged during E-brake: rev if W held, drop toward fast-idle otherwise.
      rpmGoal = input.power ? 5650 : 1250;
    } else if (absKmh < 0.12 && driveForce <= 0) {
      rpmGoal = IDLE_RPM;
    } else {
      const coupled = GEAR_RPM_LO[g.gear] + (GEAR_RPM_HI[g.gear] - GEAR_RPM_LO[g.gear]) * g.ratio;
      // Tiny realistic clutch-bite slip (max ~95 RPM) only between 0.2 and 8 km/h under gas.
      const bite = g.gear === 1 && driveForce > 0
        ? 95 * Math.min(1, absKmh / 1.2) * (1 - clamp((absKmh - 2.5) / 7, 0, 1))
        : 0;
      rpmGoal = coupled + bite;
    }
    const rpmRate = rpmGoal < engineRpm ? 24 : 30;
    engineRpm += (rpmGoal - engineRpm) * Math.min(1, dt * rpmRate);

    // Acoustic load: reflects real acceleration effort + aero drag, calm when coasting or creeping.
    const accelEffort = clamp(Math.max(0, longAccel) / (nitroActive ? T.NITRO_ENGINE : T.ENGINE), 0, 1);
    const aeroEffort = clamp((absKmh / 250) * 0.44, 0, 0.58);
    const loadGoal = driveForce <= 0
      ? 0.05
      : nitroActive
        ? 1.0
        : clamp((0.16 + 0.62 * accelEffort + aeroEffort + (input.power ? 0.22 : 0)) * crawlGate, 0.06, 0.98);
    tele.load += (loadGoal - tele.load) * Math.min(1, dt * 18);
    tele.rpm = engineRpm;
    state.rev = clamp(engineRpm / REDLINE_RPM, 0.08, 1);

    refresh();
  }

  return {
    state, tele, step, reset, refresh,
    /** External contacts (traffic) write x/z/vx/vz; call this afterwards to resync derived values. */
    kick(yawImpulse: number) { angularVel += yawImpulse; },
    get nitroActive() { return nitroActive; },
  };
}
export type StreetCar = ReturnType<typeof createStreetCar>;
