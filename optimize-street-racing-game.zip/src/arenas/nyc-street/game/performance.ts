/**
 * NYC STREET KINGS — performance budget.
 *
 * The goal is a locked 60 fps without throwing away the Haruna V3 look.
 * Instead of cutting textures, we cut *redundant work*:
 *  - far less geometry per AI car (the player keeps the full Group B model),
 *  - merged / atlased buildings (already one batch per material),
 *  - resolution scaling before any texture downgrade,
 *  - a render-rate governor so 120/144 Hz screens do not double our workload,
 *  - effect tiers (god rays / volumetric / sharpen) only on the top tier.
 */

export type QualityTier = 'ultra' | 'high' | 'balanced';

export type PerformanceSettings = {
  /** Render target tier. Does not change HD texture resolution. */
  quality: QualityTier;
  /** Hard cap: never render more than ~60 frames per second. */
  lock60: boolean;
  /** Dynamically lower internal resolution when frames are late. */
  adaptive: boolean;
};

export type PerfSnapshot = PerformanceSettings & {
  fps: number;
  frameMs: number;
  pixelRatio: number;
  drawCalls: number;
  traffic: number;
  degraded: boolean;
};

export const QUALITY_ORDER: QualityTier[] = ['ultra', 'high', 'balanced'];

export const QUALITY_LABEL: Record<QualityTier, string> = {
  ultra: 'ULTRA HD',
  high: 'HIGH HD',
  balanced: 'BALANCED HD',
};

export type QualityProfile = {
  label: string;
  /** CSS-pixel multiplier cap (multiplied by devicePixelRatio). */
  pixelCap: number;
  /** Lowest adaptive multiplier, relative to pixelCap. */
  minScale: number;
  shadowMap: number;
  /** Refresh the sun shadow map every N frames. */
  shadowEvery: number;
  godRays: boolean;
  volumetric: boolean;
  sharpen: boolean;
  bloom: number;
  /** Max texture anisotropy — 8 is visually identical to 16 on our facades. */
  anisotropy: number;
  /** AI cars streamed around the player (2× the original 18). */
  traffic: number;
  crossTraffic: number;
};

/**
 * Desktop "high" is the default. It keeps the HD facades, PBR car paint and
 * bloom, while god rays/volumetric scattering are reserved for ULTRA because
 * those are full-screen passes with the worst pixel-cost/benefit ratio.
 */
export const QUALITY_PROFILES: Record<QualityTier, QualityProfile> = {
  ultra: {
    label: 'ULTRA HD', pixelCap: 1.5, minScale: 0.78, shadowMap: 2048, shadowEvery: 2,
    godRays: true, volumetric: true, sharpen: true, bloom: 0.34, anisotropy: 8,
    traffic: 44, crossTraffic: 14,
  },
  high: {
    label: 'HIGH HD', pixelCap: 1.25, minScale: 0.72, shadowMap: 2048, shadowEvery: 3,
    godRays: true, volumetric: false, sharpen: true, bloom: 0.3, anisotropy: 8,
    traffic: 38, crossTraffic: 12,
  },
  balanced: {
    label: 'BALANCED HD', pixelCap: 1.0, minScale: 0.7, shadowMap: 1024, shadowEvery: 4,
    godRays: false, volumetric: false, sharpen: false, bloom: 0.22, anisotropy: 4,
    traffic: 28, crossTraffic: 8,
  },
};

export const DEFAULT_PERFORMANCE: PerformanceSettings = {
  quality: 'high',
  lock60: true,
  adaptive: true,
};

export const PERFORMANCE_KEY = 'nyc-street.performance.v2';

export function readPerformance(): PerformanceSettings {
  try {
    const raw = JSON.parse(localStorage.getItem(PERFORMANCE_KEY) ?? '{}') as Partial<PerformanceSettings>;
    return {
      quality: raw.quality === 'ultra' || raw.quality === 'balanced' || raw.quality === 'high' ? raw.quality : 'high',
      lock60: raw.lock60 !== false,
      adaptive: raw.adaptive !== false,
    };
  } catch {
    return { ...DEFAULT_PERFORMANCE };
  }
}

export function savePerformance(settings: PerformanceSettings) {
  try { localStorage.setItem(PERFORMANCE_KEY, JSON.stringify(settings)); } catch { /* storage is optional */ }
}

/** Very light software/phone GPU detection. Never inspect strings per frame. */
export function detectQuality(): QualityTier {
  if (typeof window === 'undefined') return 'high';
  if (window.matchMedia('(pointer: coarse)').matches) return 'balanced';
  return 'high';
}

/**
 * Tiny adaptive-resolution controller. It samples wall-clock frame intervals,
 * ignores one-off loading hitches and uses hysteresis so quality never flaps.
 */
export class FrameGovernor {
  fps = 60;
  frameMs = 16.7;
  degraded = false;
  private frames = 0;
  private total = 0;
  private warmup = 40;
  private stableFor = 0;
  private cooldown = 0;

  constructor(private isAdaptive: () => boolean, private reduce: (step: number) => boolean) {}

  /** Returns the measured FPS; caller decides when to act on `degraded`. */
  sample(renderIntervalMs: number, dt: number) {
    if (renderIntervalMs > 0 && renderIntervalMs < 250) {
      this.frames++;
      this.total += renderIntervalMs;
    }
    this.cooldown = Math.max(0, this.cooldown - dt);
    if (this.frames < 30) return this.fps;
    this.frameMs = this.total / this.frames;
    this.fps = 1000 / Math.max(0.001, this.frameMs);
    this.frames = 0;
    this.total = 0;

    if (this.warmup > 0) { this.warmup--; return this.fps; }
    if (!this.isAdaptive() || this.cooldown > 0) return this.fps;

    // A locked 60 fps loop renders every ~16.7 ms. Sustained > 21 ms means
    // the GPU or compositor is behind: give it fewer pixels immediately.
    if (this.frameMs > 21 && this.reduce(1)) {
      this.cooldown = 1.2;
      this.stableFor = 0;
      this.degraded = true;
    } else if (this.frameMs < 17.2) {
      this.stableFor++;
      if (this.stableFor > 8 && this.reduce(-1)) {
        this.cooldown = 3.5;
        this.stableFor = 0;
        this.degraded = false;
      }
    }
    return this.fps;
  }
}
