import * as THREE from 'three';
import type { CameraMode } from './engine';

/**
 * Subway Surfers–style "Curved World" (World-Space Horizon Bending Shader).
 *
 * Physics, lanes, OBB collisions and crosswalks stay 100% straight and fast on
 * the CPU, while the GPU vertex shader smoothly bends world-space coordinates
 * beyond a flat comfort zone around the camera (`uCurveFlatZ = 16 m`):
 *   - Vertical planetary curve (`uCurveY`): the avenue rolls gracefully over a
 *     curved globe horizon so skyscrapers, lamps and cars crest into view.
 *   - Sweeping boulevard arc (`uCurveX`): the straight avenue curves smoothly
 *     left and right in the distance as you drive down Manhattan.
 *
 * Because shadow passes & `<worldpos_vertex>` remain in unbent space while
 * `<project_vertex>` bends every world mesh identically, sun shadows, lane
 * markings, contact shadows and traffic cars stay locked together with 0 gap.
 */

export type CurveWorldMode = 'off' | 'normal' | 'cinematic';

export const CURVE_WORLD_ORDER: CurveWorldMode[] = ['normal', 'cinematic', 'off'];

export const CURVE_WORLD_LABEL: Record<CurveWorldMode, string> = {
  normal: 'Curve World',
  cinematic: 'Curve Max',
  off: 'Jalan Datar',
};

export const curveWorldUniforms = {
  uCurveOriginZ: { value: 0 },
  uCurveFlatZ: { value: 16 },
  uCurveX: { value: 0.00034 },
  uCurveY: { value: 0.000145 },
};

const CURVE_UNIFORM_DECL = /* glsl */ `
uniform float uCurveOriginZ;
uniform float uCurveFlatZ;
uniform float uCurveX;
uniform float uCurveY;
`;

const CURVE_PROJECT_VERTEX = /* glsl */ `
vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
  mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
  mvPosition = instanceMatrix * mvPosition;
#endif
vec4 cwWorld = modelMatrix * mvPosition;
float cwDz = cwWorld.z - uCurveOriginZ;
float cwDist = max( 0.0, abs( cwDz ) - uCurveFlatZ );
float cwDist2 = cwDist * cwDist;
cwWorld.x += uCurveX * cwDist2;
cwWorld.y -= uCurveY * cwDist2;
mvPosition = viewMatrix * cwWorld;
gl_Position = projectionMatrix * mvPosition;
`;

const PATCHED = Symbol('nycCurvedWorldPatched');

/**
 * Attaches the Curved World vertex bend to any Three.js material (preserving
 * existing `onBeforeCompile` hooks such as Haruna V3 wind foliage shaders).
 */
export function applyCurvedWorld<T extends THREE.Material>(mat: T | undefined | null): T | undefined | null {
  if (!mat || (mat as unknown as Record<symbol, boolean>)[PATCHED]) return mat;
  (mat as unknown as Record<symbol, boolean>)[PATCHED] = true;

  // Custom ShaderMaterial support (e.g. drift tyre skidmarks in world space)
  if ((mat as unknown as THREE.ShaderMaterial).isShaderMaterial) {
    const sm = mat as unknown as THREE.ShaderMaterial;
    if (sm.vertexShader.includes('modelViewMatrix*vec4(position,1.)')) {
      Object.assign(sm.uniforms, curveWorldUniforms);
      sm.vertexShader = CURVE_UNIFORM_DECL + sm.vertexShader.replace(
        'gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);',
        `vec4 cwWorld = modelMatrix * vec4(position, 1.0);
         float cwDz = cwWorld.z - uCurveOriginZ;
         float cwDist = max(0.0, abs(cwDz) - uCurveFlatZ);
         float cwDist2 = cwDist * cwDist;
         cwWorld.x += uCurveX * cwDist2;
         cwWorld.y -= uCurveY * cwDist2;
         gl_Position = projectionMatrix * viewMatrix * cwWorld;`,
      );
      sm.needsUpdate = true;
    }
    return mat;
  }

  const hasOwnCompile = Object.prototype.hasOwnProperty.call(mat, 'onBeforeCompile');
  const prevCompile = hasOwnCompile ? mat.onBeforeCompile.bind(mat) : null;
  const hasOwnCacheKey = Object.prototype.hasOwnProperty.call(mat, 'customProgramCacheKey');
  const prevCacheKey = hasOwnCacheKey ? mat.customProgramCacheKey.bind(mat) : null;

  mat.onBeforeCompile = (shader, renderer) => {
    prevCompile?.(shader, renderer);
    Object.assign(shader.uniforms, curveWorldUniforms);
    if (!shader.vertexShader.includes('uniform float uCurveOriginZ;')) {
      shader.vertexShader = CURVE_UNIFORM_DECL + shader.vertexShader;
    }
    shader.vertexShader = shader.vertexShader.replace('#include <project_vertex>', CURVE_PROJECT_VERTEX);
  };

  const staticKey = `${prevCacheKey ? prevCacheKey() : mat.type}-nyc-cw-v1`;
  mat.customProgramCacheKey = () => staticKey;
  mat.needsUpdate = true;
  return mat;
}

export function patchObjectCurvedWorld(root: THREE.Object3D) {
  root.traverse(obj => {
    const mesh = obj as THREE.Mesh;
    if (!mesh.isMesh) return;
    if (Array.isArray(mesh.material)) mesh.material.forEach(m => applyCurvedWorld(m));
    else applyCurvedWorld(mesh.material);
  });
}

export function createCurveWorldController(initialMode: CurveWorldMode = 'normal') {
  let mode: CurveWorldMode = initialMode;
  let curX = 0;
  let curY = 0;
  let initialized = false;

  function computeTargets(playerZ: number, cameraMode: CameraMode) {
    if (mode === 'off') return { tx: 0, ty: 0 };
    const boost = mode === 'cinematic' ? 1.42 : 1.0;

    // Camera-aware horizon drop so oncoming traffic cars remain visible 260+ m ahead
    // even from low cockpit/bumper cameras while keeping a rich planetary horizon arc.
    const baseY = cameraMode === 'far'
      ? 0.000180
      : cameraMode === 'chase'
        ? 0.000148
        : 0.000092;
    const waveY = 0.92 + 0.08 * Math.sin(playerZ * 0.0018);
    const ty = baseY * waveY * boost;

    // Smooth Subway Surfers–style sweeping boulevard curve (already photogenic at z = 0)
    const sweep = 0.00040 * Math.sin(playerZ * 0.00135 + 0.84) + 0.00015 * Math.sin(playerZ * 0.0029 - 0.35);
    const tx = sweep * (mode === 'cinematic' ? 1.48 : 1.0);
    return { tx, ty };
  }

  return {
    getMode: () => mode,
    setMode(next: CurveWorldMode) {
      mode = next;
      return mode;
    },
    sync(dt: number, playerZ: number, originZ: number, cameraMode: CameraMode, instant = false) {
      curveWorldUniforms.uCurveOriginZ.value = originZ;
      const { tx, ty } = computeTargets(playerZ, cameraMode);
      if (!initialized || instant) {
        curX = tx;
        curY = ty;
        initialized = true;
      } else {
        const k = 1 - Math.exp(-Math.max(0.001, dt) * 4.5);
        curX += (tx - curX) * k;
        curY += (ty - curY) * k;
      }
      curveWorldUniforms.uCurveX.value = curX;
      curveWorldUniforms.uCurveY.value = curY;
    },
  };
}
