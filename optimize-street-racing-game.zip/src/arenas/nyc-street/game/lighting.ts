import * as THREE from 'three';
import { normalizeV2Lighting, readV2Lighting, saveV2Lighting, type HarunaV2Lighting, type V2LightingSettings } from '../../rc-drift/pigeon/haruna-v2/lighting';
import { DEFAULT_LIGHTING, normalizeLighting, readLighting, saveLighting, type LightingState } from '../../rc-drift/pigeon/drive-lighting';
import { smoothstep } from '../../rc-drift/pigeon/haruna-v2/noise';

/**
 * NYC Street lighting rig.
 *
 * This is a 1:1 port of the Mt. Haruna V3 daylight rig (`haruna-v2/lighting.ts`, which V3 uses verbatim):
 *   - identical analytic sky dome shader (zenith / horizon / sun disc terms),
 *   - identical sun (0xfff1dc, 4.4 * elevation curve, 42° elevation, 28° azimuth),
 *   - identical hemisphere fill (0xc3d6e2 / 0x4a3b28), FogExp2 base density 0.0029,
 *   - identical PMREM sky environment at 0.42 intensity,
 *   - identical 4096 px snapped shadow cascade (±70 m ortho, bias -0.0004, normalBias 0.05).
 * Only the atmosphere tint is nudged towards a warm urban haze so the skyline blends in.
 * It exposes the exact surface `createHarunaV2Post` expects, so the V3 composer
 * (volumetric light + god rays + bloom + ACES + micro sharpen) runs unchanged.
 */
/** Same adjustable sun model as Mt. Haruna V3 (shared localStorage key, so both maps stay in sync). */
export type CityLightingSettings = V2LightingSettings;
export const CITY_LIGHTING: CityLightingSettings = { sunElevation: 42, sunAzimuth: 28, godRays: 1, fog: 1, wind: 1, exposure: 1, smoke: false };

function skyMaterial() {
  return new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    fog: false,
    uniforms: {
      uSunDir: { value: new THREE.Vector3(0, 1, 0) },
      uZenith: { value: new THREE.Color('#5d8fc4') },
      uHorizon: { value: new THREE.Color('#c9dbdc') },
      uSunColor: { value: new THREE.Color(1, 0.93, 0.8) },
    },
    vertexShader: `varying vec3 vDir; void main(){ vDir = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }`,
    fragmentShader: `
      uniform vec3 uSunDir; uniform vec3 uZenith; uniform vec3 uHorizon; uniform vec3 uSunColor;
      varying vec3 vDir;
      void main(){
        vec3 d = normalize(vDir);
        float h = max(d.y, 0.0);
        vec3 col = mix(uHorizon, uZenith, pow(h, 0.5));
        float s = max(dot(d, uSunDir), 0.0);
        col += uSunColor * (pow(s, 1800.0) * 60.0 + pow(s, 60.0) * 1.2 + pow(s, 8.0) * 0.35);
        if (d.y < 0.0) col = mix(uHorizon, uHorizon * 0.6, min(-d.y * 3.0, 1.0));
        gl_FragColor = vec4(col, 1.0);
      }`,
  });
}

export type TimeOfDay = 'day' | 'dusk' | 'night';

export function createCityLighting(scene: THREE.Scene, renderer: THREE.WebGLRenderer, shadowSize = 4096) {
  let settings: CityLightingSettings = readV2Lighting();
  let state: LightingState = readLighting();
  let mood: TimeOfDay = 'day';

  const skyMat = skyMaterial();
  const sky = new THREE.Mesh(new THREE.SphereGeometry(1000, 48, 24), skyMat);
  sky.name = 'NYC sky dome';
  sky.frustumCulled = false;
  sky.renderOrder = -1;
  scene.add(sky);

  const baseFog = 0.0029;
  const fog = new THREE.FogExp2('#a6bab2', baseFog);
  scene.fog = fog;
  const background = new THREE.Color('#a6bab2');
  scene.background = background;

  const sun = new THREE.DirectionalLight(0xfff1dc, 3.4);
  sun.castShadow = true;
  const clampedShadow = Math.min(renderer.capabilities.maxTextureSize, shadowSize);
  sun.shadow.mapSize.set(clampedShadow, clampedShadow);
  const c = sun.shadow.camera;
  c.left = c.bottom = -70;
  c.right = c.top = 70;
  c.near = 1;
  c.far = 520;
  c.updateProjectionMatrix();
  sun.shadow.bias = -0.0004;
  sun.shadow.normalBias = 0.05;
  sun.shadow.radius = 2;
  scene.add(sun, sun.target);

  const hemi = new THREE.HemisphereLight(0xc3d6e2, 0x4a3b28, 0.75);
  scene.add(hemi);

  const sunMesh = new THREE.Mesh(
    new THREE.SphereGeometry(18, 24, 12),
    new THREE.MeshBasicMaterial({ color: new THREE.Color(1, 0.94, 0.82), transparent: true, depthWrite: false, fog: false }),
  );
  sunMesh.frustumCulled = false;
  sunMesh.layers.enable(2);

  const sunDir = new THREE.Vector3(0, 1, 0);
  const sunCol = new THREE.Color(1, 0.93, 0.8);
  // Avenue runs along +Z; azimuth 0 = straight down the avenue so god rays pour between the towers ahead.
  const startFwd = new THREE.Vector3(0, 0, 1);
  const startRight = new THREE.Vector3(-startFwd.z, 0, startFwd.x).normalize();

  let effectiveGodRays = settings.godRays;
  let effectiveVolDensity = 0.0065;
  let effectiveExposure = settings.exposure;

  function sync() {
    const fillScale = state.hemiOn ? state.hemi / 100 : 0;
    const directScale = state.dirOn ? state.dir / 100 : 0;
    const elDeg = mood === 'night' ? 24 : mood === 'dusk' ? Math.min(14, settings.sunElevation) : settings.sunElevation;
    const el = THREE.MathUtils.degToRad(elDeg);
    const az = THREE.MathUtils.degToRad(settings.sunAzimuth);

    sunDir
      .copy(startFwd).multiplyScalar(Math.cos(az) * Math.cos(el))
      .addScaledVector(startRight, Math.sin(az) * Math.cos(el))
      .add(new THREE.Vector3(0, Math.sin(el), 0))
      .normalize();

    const warm = smoothstep(4, 40, elDeg);
    const zen = new THREE.Color('#3f6fae').lerp(new THREE.Color('#5d8fc4'), warm);
    const hor = new THREE.Color('#e9c9a2').lerp(new THREE.Color('#c9dbdc'), warm);
    sunCol.setRGB(1, 0.62 + 0.33 * warm, 0.38 + 0.47 * warm);

    let sunIntensity = 4.4 * (0.35 + 0.65 * smoothstep(-2, 25, elDeg)) * directScale;
    let hemiIntensity = (0.42 + 0.18 * warm) * fillScale;
    // V3 fog colour nudged 12% toward a warm concrete haze: Manhattan at midday.
    const fogCol = new THREE.Color('#8aa59d').lerp(hor, 0.15).lerp(new THREE.Color('#c7bfae'), 0.12);
    let fogScale = settings.fog;
    let raysScale = settings.godRays * directScale;

    if (mood === 'dusk') {
      zen.set('#2d4d86');
      hor.set('#f0b27a');
      sunCol.setRGB(1, 0.66, 0.42);
      fogCol.set('#c8a083');
      sunIntensity *= 0.82;
      hemiIntensity = 0.48 * fillScale;
      fogScale *= 1.25;
      raysScale *= 1.3;
    } else if (mood === 'night') {
      sunCol.set('#b6cdf7');
      zen.set('#0e1a2e');
      hor.set('#222e3d');
      fogCol.set('#1b2634');
      sunIntensity = 0.9 * directScale;
      hemiIntensity = 0.35 * fillScale;
      fogScale *= 1.1;
      raysScale *= 0.22;
    }

    sun.color.copy(sunCol);
    sun.intensity = sunIntensity;
    if ('intensity' in sun.shadow) (sun.shadow as unknown as { intensity: number }).intensity = state.shadow / 100;
    hemi.intensity = hemiIntensity;

    skyMat.uniforms.uSunDir.value.copy(sunDir);
    skyMat.uniforms.uSunColor.value.copy(sunCol);
    skyMat.uniforms.uZenith.value.copy(zen);
    skyMat.uniforms.uHorizon.value.copy(hor);

    fog.density = baseFog * fogScale;
    fog.color.copy(fogCol);
    background.copy(fogCol);

    effectiveGodRays = raysScale;
    effectiveVolDensity = 0.0065 * (0.3 + 0.7 * fogScale);
    effectiveExposure = settings.exposure;
    (sunMesh.material as THREE.MeshBasicMaterial).color.copy(sunCol);
  }

  // PMREM sky environment, exactly like Haruna V3: glass towers & car paint pick up the real sky.
  const pm = new THREE.PMREMGenerator(renderer);
  const envScene = new THREE.Scene();
  const envSky = new THREE.Mesh(new THREE.SphereGeometry(10, 32, 16), skyMat);
  envScene.add(envSky);
  sync();
  let envRT = pm.fromScene(envScene, 0.04);
  scene.environment = envRT.texture;
  scene.environmentIntensity = 0.42;
  envSky.geometry.dispose();
  pm.dispose();

  function rebuildEnvironment() {
    const gen = new THREE.PMREMGenerator(renderer);
    const es = new THREE.Scene();
    const m = new THREE.Mesh(new THREE.SphereGeometry(10, 32, 16), skyMat);
    es.add(m);
    const next = gen.fromScene(es, 0.04);
    envRT.dispose();
    envRT = next;
    scene.environment = envRT.texture;
    m.geometry.dispose();
    gen.dispose();
  }

  const fwdVec = new THREE.Vector3();
  const centreVec = new THREE.Vector3();
  const lzVec = new THREE.Vector3();
  const lxVec = new THREE.Vector3();
  const lyVec = new THREE.Vector3();
  const snappedVec = new THREE.Vector3();
  const worldUp = new THREE.Vector3(0, 1, 0);

  function update(carPos: THREE.Vector3, viewPos: THREE.Vector3, yaw: number, viewDir?: THREE.Vector3) {
    sky.position.copy(viewPos);
    sunMesh.position.copy(viewPos).addScaledVector(sunDir, 800);
    sunMesh.updateMatrixWorld(true);

    if (viewDir) fwdVec.copy(viewDir);
    else {
      fwdVec.subVectors(carPos, viewPos);
      if (fwdVec.lengthSq() < 0.25) fwdVec.set(Math.sin(yaw), 0, Math.cos(yaw));
    }
    fwdVec.y = 0;
    if (fwdVec.lengthSq() < 1e-4) fwdVec.set(Math.sin(yaw), 0, Math.cos(yaw));
    fwdVec.normalize();

    // Texel-snapped shadow frustum centred 38 m ahead of the eye (V3 behaviour).
    centreVec.copy(viewPos).addScaledVector(fwdVec, 38);
    const cam = sun.shadow.camera;
    const span = cam.right - cam.left;
    const texel = span / sun.shadow.mapSize.x;
    lzVec.copy(sunDir);
    lxVec.crossVectors(worldUp, lzVec).normalize();
    lyVec.crossVectors(lzVec, lxVec).normalize();
    const px = Math.round(centreVec.dot(lxVec) / texel) * texel;
    const py = Math.round(centreVec.dot(lyVec) / texel) * texel;
    const pz = centreVec.dot(lzVec);
    snappedVec.copy(lxVec).multiplyScalar(px).addScaledVector(lyVec, py).addScaledVector(lzVec, pz);
    sun.target.position.copy(snappedVec);
    sun.position.copy(snappedVec).addScaledVector(sunDir, 250);
    sun.target.updateMatrixWorld();
    // NOTE: shadow map refresh is driven by the engine (every 2nd frame) to keep frame time low.
  }

  const api = {
    scene,
    hemi,
    dir: sun,
    dome: sky,
    background,
    fog,
    sunMesh,
    sunDirection: sunDir,
    hasDaylightAtmosphere: true,
    get sunGain() { return mood === 'day' ? 1 : 0.2; },
    get mood() { return mood; },
    get godRaysStrength() { return effectiveGodRays; },
    get volDensity() { return effectiveVolDensity; },
    get exposure() { return effectiveExposure; },
    get sunColor() { return sunCol; },
    get settings() { return settings; },
    get state() { return state; },
    setMood(next: TimeOfDay) { mood = next; sync(); rebuildEnvironment(); },
    /** Sun angle / god rays / fog / exposure — persisted to the shared Haruna V3 key. */
    applyV2(next: Partial<CityLightingSettings>) {
      settings = normalizeV2Lighting({ ...settings, ...next });
      saveV2Lighting(settings);
      sync();
      return settings;
    },
    /** Hemisphere / sun / shadow percentages (the launcher's "Pencahayaan" sliders). */
    apply(next: Partial<LightingState>) {
      state = normalizeLighting({ ...state, ...next });
      saveLighting(state);
      sync();
      return state;
    },
    resetAll() {
      settings = { ...CITY_LIGHTING };
      state = { ...DEFAULT_LIGHTING };
      saveV2Lighting(settings); saveLighting(state);
      sync(); rebuildEnvironment();
    },
    rebuildEnvironment,
    update,
    dispose() {
      scene.environment = null;
      envRT.dispose();
      (sunMesh.material as THREE.Material).dispose();
      sunMesh.geometry.dispose();
      sky.geometry.dispose();
      skyMat.dispose();
    },
  };
  return api;
}

export type CityLighting = ReturnType<typeof createCityLighting>;
/** The V3 composer only touches the members shared with Haruna V2 lighting, so this cast is safe. */
export const asHarunaLighting = (l: CityLighting) => l as unknown as HarunaV2Lighting;
