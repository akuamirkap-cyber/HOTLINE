import * as THREE from 'three';
import { createRallyCarModel, type RallyModel } from '../../rc-drift/pigeon/rally-model.js';
import { readBuild } from '../../rc-drift/pigeon/rally-config';
import { CAR_SCALE } from '../../rc-drift/pigeon/rmx-drift-adapter';
import { createV3SurfaceTextures } from '../../rc-drift/pigeon/haruna-v3/textures';
import { createV2Textures } from '../../rc-drift/pigeon/haruna-v2/textures';
import { createLibrary } from '../../rc-drift/pigeon/haruna-v2/library';
import { createHarunaV2Post } from '../../rc-drift/pigeon/haruna-v2/post';
import { GroundKind, type GroundAt } from '../../rc-drift/pigeon/pigeon-world/suspension';
import { createBmwDriveAudio } from '../../rc-drift/pigeon/bmw/sound';
import { createDriftEffects } from '../../rc-drift/pigeon/drift-effects';
import { batchRigidParts } from '../../rc-drift/pigeon/render-batching';
import type { LightingState } from '../../rc-drift/pigeon/drive-lighting';
import { asHarunaLighting, createCityLighting, type CityLightingSettings, type TimeOfDay } from './lighting';
import { createCity, createCityMaterials, type City, type StreetTreeAsset } from './city';
import { createCrossTraffic, createTraffic, type CrossTraffic, type Traffic, type TrafficEvent } from './traffic';
import { makeContactShadow } from './trafficShadow';
import { FrameGovernor, QUALITY_PROFILES, detectQuality, type PerfSnapshot, type PerformanceSettings, type QualityTier } from './performance';
import { createSfx } from './sfx';
import { BASE_MAX, createStreetCar, NITRO_MAX } from './driftCar';
import { createNycCockpitUpgrades, type SpeedoStyle } from './gtCockpit';
import { createCurveWorldController, patchObjectCurvedWorld, type CurveWorldMode } from './curveWorld';

export type CameraMode = 'chase' | 'cockpit' | 'hood' | 'far';
export type HandPoseMode = 'window' | 'wheel';
export type GamePhase = 'ready' | 'running' | 'paused' | 'wrecked';

export type Telemetry = {
  phase: GamePhase;
  kmh: number;
  nitro: number;        // 0..100
  nitroActive: boolean;
  health: number;       // 0..100
  score: number;
  distance: number;     // metres
  time: number;         // seconds
  combo: number;
  nearMisses: number;
  overtakes: number;
  crashes: number;
  gear: string;
  rpm: number;          // 0..1
  camera: CameraMode;
  mood: TimeOfDay;
  topSpeed: number;     // km/h reached this run
  best: number;
  slipDeg: number;
  drifting: boolean;
  driftPoints: number;  // pending (un-banked) drift score
  driftBanked: number;  // total banked drift score this run
  handbrake: boolean;
  /** Live renderer budget — shown in the HUD and the performance panel. */
  perf: PerfSnapshot;
};

export type GameEvent =
  | { type: 'nearMiss'; points: number; combo: number; oncoming: boolean }
  | { type: 'crash'; damage: number; headOn: boolean }
  | { type: 'scrape' }
  | { type: 'nitro'; on: boolean }
  | { type: 'drift'; points: number; lost: boolean; seconds: number }
  | { type: 'wrecked'; score: number; best: boolean }
  | { type: 'milestone'; distance: number };

export type Input = { steer: number; brake: boolean; nitro: boolean; power: boolean; handbrake: boolean };

export type LightingSnapshot = { v2: CityLightingSettings; state: LightingState };

export type Engine = {
  start(): void;
  restart(): void;
  pause(p: boolean): void;
  setInput(patch: Partial<Input>): void;
  camera(mode: CameraMode): void;
  cycleCamera(): CameraMode;
  mood(next: TimeOfDay): void;
  cycleMood(): TimeOfDay;
  sound(on: boolean): void;
  /** Master volume 0..1 shared by the engine model + SFX (mute is independent). */
  volume(v: number): void;
  /** Steering sensitivity 0.7..1.6 (1 = default physical lock). */
  steering(v: number): number;
  /** Switch speedometer style ('classic' default | 'gt' twin-dial option). */
  speedoStyle(style: SpeedoStyle): SpeedoStyle;
  /** Subway Surfers–style Curved World horizon bending ('normal' default | 'cinematic' | 'off'). */
  curveWorld(mode?: CurveWorldMode): CurveWorldMode;
  /** Cockpit left-arm pose ('window' casual left-window rest DEFAULT | 'wheel' 2-hands grip). */
  handPose(mode?: HandPoseMode): HandPoseMode;
  /** Exact live speed & engine RPM for the 60 fps speedometer, read straight from physics. */
  speed(): {
    kmh: number;
    forwardKmh: number;
    baseKmh: number;
    maxKmh: number;
    ratio: number;
    gear: string;
    rpm: number;
    rpmActual: number;
    nitro: number;
    nitroActive: boolean;
    distanceKm: number;
  };
  unlockAudio(): void;
  lighting(): LightingSnapshot;
  setSun(next: Partial<CityLightingSettings>): LightingSnapshot;
  setLightLevels(next: Partial<LightingState>): LightingSnapshot;
  resetLighting(): LightingSnapshot;
  /** Runtime quality controls (safe to call while driving). */
  performance(): PerfSnapshot;
  setPerformance(next: Partial<PerformanceSettings>): PerfSnapshot;
  resize(): void;
  dispose(): void;
};

const NITRO_DRAIN = 18;       // units/s (full tank ≈ 5.6 s)
const NITRO_PASSIVE = 1.4;    // units/s
const BEST_KEY = 'nyc-street.best.v1';
const PHYS_STEP = 1 / 120;
const COCKPIT_LAYER = 2;

function readBest() { try { return Math.max(0, Number(localStorage.getItem(BEST_KEY)) || 0); } catch { return 0; } }
function writeBest(v: number) { try { localStorage.setItem(BEST_KEY, String(Math.floor(v))); } catch { /* optional */ } }

const groundAt: GroundAt = (_x, _z, out) => {
  const g = out ?? { y: 0, kind: GroundKind.Asphalt };
  g.y = 0; g.kind = GroundKind.Asphalt;
  return g;
};

export async function createEngine(
  host: HTMLDivElement,
  callbacks: { onTelemetry: (t: Telemetry) => void; onEvent: (e: GameEvent) => void; onProgress: (label: string, pct: number) => void },
  signal: AbortSignal,
  opts: { sound: boolean; headlights: boolean; camera?: CameraMode; mood?: TimeOfDay; performance?: PerformanceSettings; volume?: number; steering?: number; speedoStyle?: SpeedoStyle; curveWorld?: CurveWorldMode; handPose?: HandPoseMode },
): Promise<Engine | undefined> {
  await Promise.resolve();
  if (signal.aborted) return;

  // ---- Renderer / performance budget ----
  // The composer resolves the final image, so MSAA on the default framebuffer
  // would allocate an extra full-resolution buffer for nothing.
  const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance', stencil: false });
  const gl = renderer.getContext();
  const info = gl.getExtension('WEBGL_debug_renderer_info');
  const gpuName = info ? String(gl.getParameter(info.UNMASKED_RENDERER_WEBGL)) : '';
  const softwareGpu = /swiftshader|llvmpipe|softpipe|software rasterizer/i.test(gpuName);
  const compactGpu = window.matchMedia('(pointer: coarse)').matches;
  const requestedQuality = opts.performance?.quality ?? detectQuality();
  let perfSettings: PerformanceSettings = {
    quality: softwareGpu ? 'balanced' : requestedQuality,
    lock60: opts.performance?.lock60 ?? true,
    adaptive: opts.performance?.adaptive ?? true,
  };
  let renderScale = 1;
  let drawCalls = 0;

  const qualityProfile = () => QUALITY_PROFILES[perfSettings.quality];
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1; // V3 composer owns ACES + exposure
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.shadowMap.autoUpdate = false;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, qualityProfile().pixelCap));
  // Keep counters for the whole composited frame instead of the last pass.
  renderer.info.autoReset = false;
  renderer.domElement.setAttribute('aria-label', 'NYC street racing 3D');
  renderer.domElement.style.display = 'block';
  host.append(renderer.domElement);

  const scene = new THREE.Scene();
  callbacks.onProgress('Menyalakan matahari Manhattan (rig Haruna V3)…', 0.05);
  const shadowSize = softwareGpu || compactGpu ? 1024 : qualityProfile().shadowMap;
  const lighting = createCityLighting(scene, renderer, shadowSize);

  // Adaptive resolution: fewer pixels before lower-quality textures.
  const governor = new FrameGovernor(
    () => perfSettings.adaptive,
    step => {
      const profile = QUALITY_PROFILES[perfSettings.quality];
      if (step > 0) {
        if (renderScale > profile.minScale + 0.02) {
          renderScale = Math.max(profile.minScale, renderScale - 0.08);
          resize();
          return true;
        }
        if (perfSettings.quality !== 'balanced') {
          perfSettings = { ...perfSettings, quality: perfSettings.quality === 'ultra' ? 'high' : 'balanced' };
          applyQuality();
          return true;
        }
        return false;
      }
      if (renderScale < 1) {
        renderScale = Math.min(1, renderScale + 0.04);
        resize();
        return true;
      }
      return false;
    },
  );

  const camera = new THREE.PerspectiveCamera(58, 1, 0.1, 12000);
  const cockpitCamera = new THREE.PerspectiveCamera(60, 1, 0.032, 12000);
  cockpitCamera.layers.set(COCKPIT_LAYER);
  const mirrorCamera = new THREE.PerspectiveCamera(34, 3.09, 0.25, 12000);
  mirrorCamera.layers.set(COCKPIT_LAYER);
  const mirrorTarget = new THREE.WebGLRenderTarget(512, 168, { depthBuffer: true });
  mirrorTarget.texture.colorSpace = THREE.SRGBColorSpace;
  mirrorTarget.texture.generateMipmaps = false;
  mirrorTarget.texture.wrapS = THREE.RepeatWrapping;
  mirrorTarget.texture.repeat.x = -1; mirrorTarget.texture.offset.x = 1;
  scene.add(camera);

  callbacks.onProgress('Mengaspal avenue (tekstur HD V3)…', 0.15);
  await new Promise(r => setTimeout(r, 0));
  // Textures stay 2048 px HD. Capping anisotropy at 8 cuts texture sampling
  // cost at grazing angles while being indistinguishable in the chase camera.
  const aniso = Math.min(renderer.capabilities.getMaxAnisotropy(), qualityProfile().anisotropy);
  const v3 = createV3SurfaceTextures(aniso);
  callbacks.onProgress('Membangun pencakar langit…', 0.3);
  await new Promise(r => setTimeout(r, 0));
  const cityMats = createCityMaterials(v3, aniso);
  callbacks.onProgress('Menanam pohon Haruna V3…', 0.26);
  await new Promise(r => setTimeout(r, 0));
  const v2Tex = createV2Textures(aniso);
  const library = createLibrary(v2Tex);
  const mapleDef = library.find(d => d.id === 'maple')!;
  const treeAsset: StreetTreeAsset = {
    templates: [mapleDef.make(701), mapleDef.make(1313), mapleDef.make(2027)].map(t => ({ leaves: t.leaves, bark: t.bark })),
    leafMat: mapleDef.leaf.mat,
    leafDepth: mapleDef.leaf.depth,
    barkMat: mapleDef.bark?.mat,
    barkDepth: mapleDef.bark?.depth,
  };
  const city: City = createCity(scene, cityMats, treeAsset);
  if (signal.aborted) { cleanup(); return; }

  // 2× the original avenue density (18 → 38 cars) and 2× intersection traffic.
  // Each civilian car is now 3 shared-draw-call meshes instead of a full
  // articulated rally model, so the extra density costs less than the old one.
  const trafficCount = softwareGpu ? 12 : compactGpu ? Math.min(30, qualityProfile().traffic) : qualityProfile().traffic;
  const traffic: Traffic = await createTraffic(scene, trafficCount, (done, total) => callbacks.onProgress(`Mengisi lalu lintas ${done}/${total} mobil…`, 0.34 + 0.38 * done / total));
  if (signal.aborted) { cleanup(); return; }
  const crossCount = softwareGpu ? 4 : compactGpu ? Math.min(9, qualityProfile().crossTraffic) : qualityProfile().crossTraffic;
  const crossTraffic: CrossTraffic = await createCrossTraffic(scene, crossCount, (done, total) => callbacks.onProgress(`Mobil perempatan ${done}/${total}…`, 0.72 + 0.16 * done / total));
  if (signal.aborted) { cleanup(); return; }

  // Drift smoke + rubber marks straight from PRODRIFT, bent cleanly with the Curved World road
  const effects = createDriftEffects(THREE);
  patchObjectCurvedWorld(effects.root);
  scene.add(effects.root);
  const curveCtrl = createCurveWorldController(opts.curveWorld ?? 'normal');

  // ---- Speed streaks (wind) ----
  const STREAKS = 90;
  const streakGeo = new THREE.PlaneGeometry(0.04, 1);
  const streakMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.0, depthWrite: false, blending: THREE.AdditiveBlending, fog: false });
  const streaks = new THREE.InstancedMesh(streakGeo, streakMat, STREAKS);
  streaks.frustumCulled = false;
  const streakPos = Array.from({ length: STREAKS }, () => new THREE.Vector3((Math.random() - 0.5) * 16, Math.random() * 6 + 0.3, Math.random() * 40));
  scene.add(streaks);

  // Everything built so far is visible from inside the cabin (cockpit layer), exactly like the studio does for its courses.
  scene.traverse(o => o.layers.enable(COCKPIT_LAYER));

  callbacks.onProgress('Memanggil mobil pemain dari garasi…', 0.9);
  await new Promise(r => setTimeout(r, 0));
  let currentHandPose: HandPoseMode = opts.handPose ?? 'window';
  const car: RallyModel = createRallyCarModel({
    THREE,
    build: readBuild(),
    headlights: opts.headlights,
    leftArmWindow: currentHandPose === 'window',
  });
  car.scale.setScalar(CAR_SCALE);
  car.rotation.order = 'YXZ';
  car.traverse(node => { const m = node as THREE.Mesh; if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });

  function cockpitLights(model: RallyModel) {
    // The first-person camera renders only the cockpit layer, so that layer gets its own bright daylight rig.
    const skyFill = new THREE.HemisphereLight(0xeaf4ff, 0x7a6248, 1.62);
    skyFill.layers.set(COCKPIT_LAYER); model.add(skyFill);
    const sun = new THREE.DirectionalLight(0xfff0d6, 2.35);
    sun.position.set(.22, 2.26, 1.14); sun.target.position.set(.47, 1.168, -.193);
    sun.layers.set(COCKPIT_LAYER); model.add(sun, sun.target);
    const bounce = new THREE.PointLight(0xf3f7ff, .56, 2.55, 1.55);
    bounce.layers.set(COCKPIT_LAYER); bounce.position.set(.248, 1.729, -.412); model.add(bounce);
    const windshieldFill = new THREE.PointLight(0xffe4bc, .44, 2.7, 1.65);
    windshieldFill.layers.set(COCKPIT_LAYER); windshieldFill.position.set(.48, 1.46, .49); model.add(windshieldFill);
  }
  function enableCabin(model: RallyModel) {
    // Remove the old boxy interior rear-view mirror & stem BEFORE rigid batching so zero polygons remain.
    for (const oldPart of ['cabinMirror', 'interiorMirrorStem']) {
      const node = model.getObjectByName(oldPart);
      node?.parent?.remove(node);
    }
    for (const part of ['cabin', 'hood', 'mirrors', 'evoHeritageDecals', 'classicHeritageDecals', 'evoRallyDecals', 'classicRallyDecals']) {
      model.getObjectByName(part)?.traverse(object => object.layers.enable(COCKPIT_LAYER));
    }
    model.getObjectByName('lights')?.traverse(object => { if ((object as THREE.PointLight).isPointLight) object.layers.enable(COCKPIT_LAYER); });
    cockpitLights(model);
    // Interior blackout shell (cockpit layer only): an unlit matte floor + dash backer so the road
    // and asphalt can never show through the gaps between the steering column, pedals and floor.
    const shellMat = new THREE.MeshBasicMaterial({ color: 0x0a0b0e, fog: false, side: THREE.DoubleSide });
    const shell = new THREE.Group();
    shell.name = 'cockpit blackout shell';
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(2.3, 3.7), shellMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, 0.52, -0.12);
    const dashBacker = new THREE.Mesh(new THREE.PlaneGeometry(2.15, 1.35), shellMat);
    dashBacker.position.set(0, 0.82, 0.86);
    dashBacker.rotation.set(-0.22, Math.PI, 0);
    const tunnel = new THREE.Mesh(new THREE.PlaneGeometry(0.72, 1.9), shellMat);
    tunnel.rotation.x = -Math.PI / 2;
    tunnel.position.set(0, 0.62, -0.35);
    const kickLeft = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 1.1), shellMat);
    kickLeft.rotation.set(0, Math.PI / 2, 0); kickLeft.position.set(-0.78, 0.78, 0.55);
    const kickRight = kickLeft.clone();
    kickRight.position.x = 0.78;
    const doorLeft = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.75), shellMat);
    doorLeft.rotation.set(0, Math.PI / 2, 0); doorLeft.position.set(-1.02, 0.72, -0.25);
    const doorRight = doorLeft.clone();
    doorRight.position.x = 1.02;
    shell.add(floor, dashBacker, tunnel, kickLeft, kickRight, doorLeft, doorRight);
    shell.traverse(object => object.layers.set(COCKPIT_LAYER));
    model.add(shell);
    batchRigidParts(model);
  }
  enableCabin(car);

  // Attach the new rounded-stadium rear-view mirror + optional GT speedometer inside the classic cockpit.
  const cockpitUpgrades = createNycCockpitUpgrades(car, COCKPIT_LAYER, CAR_SCALE, opts.speedoStyle ?? 'classic');

  car.add(makeContactShadow(2.4, 4.2, 0.8));
  scene.add(car);
  let lampsActive = opts.headlights;
  car.userData.setHeadlights(lampsActive);

  const post = createHarunaV2Post(
    renderer, scene, camera, asHarunaLighting(lighting), groundAt,
    softwareGpu || compactGpu, true, perfSettings.quality,
  );

  /**
   * Applies a render tier without touching any HD texture/geometry:
   * - balanced: bloom + SMAA only, no volumetric/god rays/sharpen
   * - high: bloom + sharper image, 2× MSAA
   * - ultra: full V3 atmosphere, 4× MSAA
   * Sun shadows, resolution cap and effect passes follow automatically.
   */
  function applyQuality(tier?: QualityTier) {
    if (tier) perfSettings = { ...perfSettings, quality: tier };
    post.setQuality(perfSettings.quality);
    renderScale = 1;
    renderer.shadowMap.needsUpdate = true;
    resize();
  }
  const audio = createBmwDriveAudio();
  audio.setEnabled(opts.sound);
  audio.setVolume(opts.volume ?? 0.5);
  audio.setDrivetrain({ engine: 's63', trans: 'dct' });
  const sfx = createSfx();
  sfx.setEnabled(opts.sound);
  sfx.setVolume(opts.volume ?? 0.5);

  // ---- State ----
  const sim = createStreetCar();
  const S = sim.state;
  let phase: GamePhase = 'ready';
  let cameraMode: CameraMode = opts.camera ?? 'chase';
  let mood: TimeOfDay = opts.mood ?? 'day';
  const input: Input = { steer: 0, brake: false, nitro: false, power: false, handbrake: false };
  // Player-tuned input gain. It scales the keyboard/steer command, not the car's
  // physical lock, so max grip and NOS stability stay identical for everyone.
  let steeringSensitivity = THREE.MathUtils.clamp(opts.steering ?? 1.15, 0.7, 1.6);
  const p = {
    nitro: 55, nitroActive: false, health: 100, score: 0, distance: 0, time: 0,
    combo: 0, comboTimer: 0, nearMisses: 0, overtakes: 0, crashes: 0, topSpeed: 0,
    regenDelay: 0, scrapeTimer: 0, milestone: 500, shake: 0, lastImpactAt: 0,
    driftPoints: 0, driftBanked: 0, driftSeconds: 0, driftCooldown: 0, lastZ: 0, curbCooldown: 0,
  };
  let best = readBest();
  let elapsed = 0, reportAt = 0, mirrorFrame = 0, envRebuildAt = 0;

  const camPos = new THREE.Vector3(0, 2.6, -7.5), camLook = new THREE.Vector3(), camTarget = new THREE.Vector3(), camDesired = new THREE.Vector3();
  const viewDir = new THREE.Vector3(), carPos = new THREE.Vector3(), heading = new THREE.Vector3(), velDir = new THREE.Vector3(), blendDir = new THREE.Vector3();
  const eyeRotation = new THREE.Quaternion(), driverLocal = new THREE.Vector3(), aim = new THREE.Vector3(), mirrorPos = new THREE.Vector3(), mirrorAim = new THREE.Vector3();
  let bumpCycle = 0, headingOffset = 0, nitroFov = 0;
  const tmpM = new THREE.Matrix4(), tmpQ = new THREE.Quaternion().setFromEuler(new THREE.Euler(Math.PI / 2, 0, 0)), tmpS = new THREE.Vector3(), tmpP = new THREE.Vector3();

  function placeAtStart() {
    sim.reset(-5.25, 0, 0);
    Object.assign(p, { nitro: 55, nitroActive: false, health: 100, score: 0, distance: 0, time: 0, combo: 0, comboTimer: 0, nearMisses: 0, overtakes: 0, crashes: 0, topSpeed: 0, regenDelay: 0, scrapeTimer: 0, milestone: 500, shake: 0, lastImpactAt: 0, driftPoints: 0, driftBanked: 0, driftSeconds: 0, driftCooldown: 0, lastZ: 0, curbCooldown: 0 });
    car.position.set(S.x, 0, S.z); car.rotation.y = 0;
    car.userData.resetDriver?.('1');
    traffic.reset(0);
    traffic.density(1);
    crossTraffic.reset(0);
    city.update(0);
    effects.reset();
    camPos.set(S.x + 0.4, 2.6, S.z - 7.5);
    camLook.set(S.x, 1.2, S.z + 4);
    curveCtrl.sync(1 / 60, S.z, S.z, cameraMode, true);
    audio.grid();
  }
  placeAtStart();
  applyMood(mood);
  applyCameraMode();

  function applyMood(next: TimeOfDay) {
    mood = next;
    lighting.setMood(next);
    city.setMood(next);
    const lamps = next !== 'day' || opts.headlights;
    lampsActive = lamps;
    car.userData.setHeadlights(lamps);
    traffic.setHeadlights(next !== 'day');
    crossTraffic.setHeadlights(next !== 'day');
    streakMat.color.set(next === 'night' ? 0xcfe3ff : 0xffffff);
  }
  function applyCameraMode() {
    const interior = cameraMode === 'cockpit';
    car.userData.setCockpitView(interior, true);
    cockpitUpgrades.setMirrorTexture(interior ? mirrorTarget.texture : null);
    if (interior) {
      mirrorFrame = 0;
      cockpitUpgrades.update({
        kmh: Math.max(0, S.speed * 3.6),
        rpm: phase === 'running' ? sim.tele.rpm : 680,
        gear: S.gear,
        nitro: p.nitro,
        nitroActive: p.nitroActive,
        distanceKm: p.distance / 1000,
        headlights: lampsActive,
        drifting: sim.tele.drifting,
      });
    }
  }

  // ---- Physics ----
  function stepPhysics(dt: number) {
    const wantNitro = input.nitro && phase === 'running';
    if (wantNitro && !p.nitroActive && p.nitro >= 8) { p.nitroActive = true; callbacks.onEvent({ type: 'nitro', on: true }); sfx.nitro(true); }
    if (p.nitroActive && (!wantNitro || p.nitro <= 0)) { p.nitroActive = false; callbacks.onEvent({ type: 'nitro', on: false }); sfx.nitro(false); }
    if (p.nitroActive) p.nitro = Math.max(0, p.nitro - NITRO_DRAIN * dt);
    else p.nitro = Math.min(100, p.nitro + NITRO_PASSIVE * dt);

    sim.step(dt, { steer: input.steer, response: steeringSensitivity, brake: input.brake ? 1 : 0, handbrake: input.handbrake, nitro: p.nitroActive, power: input.power, auto: true });
    effects.step(dt, S);

    // curb impacts: real hits (approach > 1.5 m/s) damage once per 0.3 s, grinding only scrubs speed + sparks sfx
    p.curbCooldown -= dt; p.scrapeTimer -= dt;
    if (sim.tele.wallHit > 0) {
      const hit = sim.tele.wallHit;
      if (hit > 1.5 && p.curbCooldown <= 0) {
        p.curbCooldown = 0.3;
        damage(Math.min(16, hit * 0.9 + S.speed * 0.01), false, false);
        p.shake = Math.max(p.shake, Math.min(1, hit / 8));
        bankDrift(true);
      }
      if (p.scrapeTimer <= 0) { callbacks.onEvent({ type: 'scrape' }); sfx.scrape(Math.min(1, hit / 8)); p.scrapeTimer = 0.4; }
    }

    // progress & score
    const dz = S.z - p.lastZ; p.lastZ = S.z;
    if (dz > 0) p.distance += dz;
    p.time += dt;
    p.topSpeed = Math.max(p.topSpeed, S.speed * 3.6);
    p.score += Math.max(0, S.forwardSpeed) * dt * (0.5 + (p.nitroActive ? 0.5 : 0));
    p.comboTimer -= dt;
    if (p.comboTimer <= 0 && p.combo > 0) p.combo = 0;
    p.regenDelay -= dt;
    if (p.regenDelay <= 0 && p.health > 0) p.health = Math.min(100, p.health + 1.2 * dt);
    if (p.distance >= p.milestone) { callbacks.onEvent({ type: 'milestone', distance: p.milestone }); p.score += 150; p.milestone += 500; }

    // drift scoring (PRODRIFT style: bank when the slide ends)
    if (sim.tele.drifting) {
      p.driftSeconds += dt;
      p.driftPoints += dt * (Math.abs(sim.tele.slipDeg) * 0.9 + S.speed * 0.6) * (1 + p.combo * 0.1);
      p.driftCooldown = 0.55;
    } else if (p.driftPoints > 0) {
      p.driftCooldown -= dt;
      if (p.driftCooldown <= 0) bankDrift(false);
    }
  }

  function bankDrift(lost: boolean) {
    if (p.driftPoints <= 0) return;
    const pts = Math.round(p.driftPoints);
    if (!lost && p.driftSeconds > 0.6) {
      p.score += pts; p.driftBanked += pts;
      p.nitro = Math.min(100, p.nitro + Math.min(22, pts / 35));
      callbacks.onEvent({ type: 'drift', points: pts, lost: false, seconds: p.driftSeconds });
      audio.feedback('bank');
    } else if (lost && pts > 40) {
      callbacks.onEvent({ type: 'drift', points: pts, lost: true, seconds: p.driftSeconds });
      audio.feedback('lost');
    }
    p.driftPoints = 0; p.driftSeconds = 0; p.driftCooldown = 0;
  }

  function damage(amount: number, headOn: boolean, notify: boolean) {
    if (phase !== 'running') return;
    p.health -= amount;
    p.regenDelay = 6;
    if (notify) callbacks.onEvent({ type: 'crash', damage: amount, headOn });
    if (p.health <= 0) {
      p.health = 0;
      phase = 'wrecked';
      p.nitroActive = false;
      const isBest = p.score > best;
      if (isBest) { best = p.score; writeBest(best); }
      callbacks.onEvent({ type: 'wrecked', score: p.score, best: isBest });
      sfx.wreck();
      audio.silence();
    }
  }

  function handleTrafficEvents(events: TrafficEvent[]) {
    for (const e of events) {
      if (e.type === 'nearMiss') {
        if (phase !== 'running') continue;
        p.combo = Math.min(20, p.combo + 1);
        p.comboTimer = 3.2;
        p.nearMisses++;
        const points = Math.round(100 * (0.6 + e.closeness) * (1 + p.combo * 0.35) * (e.oncoming ? 2 : 1) * (sim.tele.drifting ? 1.5 : 1));
        p.score += points;
        p.nitro = Math.min(100, p.nitro + (e.oncoming ? 16 : 10) * (0.6 + e.closeness));
        callbacks.onEvent({ type: 'nearMiss', points, combo: p.combo, oncoming: e.oncoming });
        sfx.whoosh(e.closeness, e.oncoming);
      } else if (e.type === 'overtake') {
        if (phase !== 'running') continue;
        p.overtakes++;
        p.score += 15;
        p.nitro = Math.min(100, p.nitro + 2.5);
      } else if (e.type === 'crash') {
        // yaw kick from an off-centre impact: lateral push ahead of the axle centre rotates the nose
        const rx = Math.cos(S.yaw), rz = -Math.sin(S.yaw);
        const nLat = e.nx * rx + e.nz * rz;
        sim.kick(THREE.MathUtils.clamp(nLat * Math.sign(e.ahead || 1) * Math.min(1.1, e.impact * 0.045), -1.1, 1.1));
        if (elapsed - p.lastImpactAt < 0.25) continue;
        p.lastImpactAt = elapsed;
        p.crashes++;
        p.combo = 0;
        bankDrift(true);
        const swipe = Math.min(10, e.tangent * 0.35); // glancing blow along the flank still hurts
        const dmg = Math.min(85, Math.max(0, (e.impact - 2.0) * 2.1) * (e.headOn ? 1.35 : 1) + (e.impact > 1.5 ? swipe : 0));
        p.shake = Math.max(p.shake, Math.min(1.4, e.impact / 12));
        p.nitroActive = false;
        sfx.crash(Math.min(1, e.impact / 25));
        damage(dmg, e.headOn, true);
      }
    }
  }

  // ---- Cameras (pure optical NOS FOV warp — zero blue screen tint) ----
  function updateCamera(dt: number) {
    const speed = S.speed;
    const rush = THREE.MathUtils.smoothstep(speed, 0, NITRO_MAX);
    // Punchy acceleration onset when NOS triggers, smooth optical settle when released
    nitroFov = THREE.MathUtils.damp(nitroFov, p.nitroActive ? 1 : 0, p.nitroActive ? 9.5 : 4.2, dt);
    carPos.set(S.x, 0, S.z);
    heading.set(Math.sin(S.yaw), 0, Math.cos(S.yaw));
    if (speed > 1.5) velDir.set(S.vx, 0, S.vz).normalize(); else velDir.copy(heading);
    // Drift-sim chase: follow a blend of heading and velocity so slides show the car's angle
    blendDir.copy(heading).lerp(velDir, 0.38).normalize();

    if (cameraMode === 'cockpit') {
      cockpitPose(dt, rush, nitroFov);
      cockpitCamera.getWorldDirection(viewDir);
      return;
    }
    let fov = 58;
    if (cameraMode === 'chase') {
      const back = 7.4 + rush * 3.2 + nitroFov * 2.15, height = 2.7 + rush * 0.6 + nitroFov * 0.12;
      camDesired.copy(carPos).addScaledVector(blendDir, -back); camDesired.y = height;
      camTarget.copy(carPos).addScaledVector(heading, 3.5 + rush * 7 + nitroFov * 4.5); camTarget.y = 1.25;
      fov = 60 + Math.min(13, speed * 0.28) + rush * 10 + nitroFov * 14.5;
    } else if (cameraMode === 'far') {
      const back = 12 + rush * 4 + nitroFov * 2.6, height = 4.6 + rush * 1.2 + nitroFov * 0.2;
      camDesired.copy(carPos).addScaledVector(blendDir, -back); camDesired.y = height;
      camTarget.copy(carPos).addScaledVector(heading, 10 + nitroFov * 5); camTarget.y = 1.2;
      fov = 50 + rush * 18 + nitroFov * 13.5;
    } else {
      camDesired.copy(carPos).addScaledVector(heading, 1.25); camDesired.y = 1.0;
      camTarget.copy(carPos).addScaledVector(heading, 30 + nitroFov * 8); camTarget.y = 0.9 - rush * 0.2;
      fov = 66 + rush * 22 + nitroFov * 15.0;
    }
    const posLag = cameraMode === 'hood' ? 1 : 1 - Math.exp(-dt * (7.5 + rush * 4));
    const lookLag = cameraMode === 'hood' ? 1 : 1 - Math.exp(-dt * 11);
    camPos.lerp(camDesired, posLag);
    camLook.lerp(camTarget, lookLag);
    p.shake = Math.max(0, p.shake - dt * 2.2);
    const jitter = p.shake * 0.22 + nitroFov * 0.020 * rush + rush * rush * 0.012;
    camera.position.copy(camPos);
    camera.position.x += (Math.random() - 0.5) * jitter;
    camera.position.y += (Math.random() - 0.5) * jitter;
    camera.lookAt(camLook);
    camera.rotation.z += (Math.random() - 0.5) * jitter * 0.08 + S.yawRate * 0.012;
    const nextFov = THREE.MathUtils.damp(camera.fov, fov, 9.5, dt);
    if (Math.abs(camera.fov - nextFov) > 0.02) { camera.fov = nextFov; camera.updateProjectionMatrix(); }
    camera.getWorldDirection(viewDir);
  }

  function cockpitPose(dt: number, rush: number, nosWarp: number) {
    const eye = car.userData.sockets.driverEye;
    eye.getWorldPosition(cockpitCamera.position); eye.getWorldQuaternion(eyeRotation);
    const motion = THREE.MathUtils.clamp(S.speed / 25, 0, 1);
    bumpCycle += S.speed * dt * motion * 0.65;
    headingOffset = THREE.MathUtils.damp(headingOffset, S.steer * 0.04 + THREE.MathUtils.clamp(S.beta * 0.48, -0.42, 0.42), 2.8, dt);
    const narrow = 1 - THREE.MathUtils.smoothstep(cockpitCamera.aspect, 0.85, 1.65);
    const targetFov = THREE.MathUtils.lerp(56, 74, narrow) + rush * THREE.MathUtils.lerp(7.2, 4.8, narrow) + nosWarp * 11.5;
    const nextFov = THREE.MathUtils.damp(cockpitCamera.fov, targetFov, 10.5, dt);
    if (Math.abs(cockpitCamera.fov - nextFov) > 0.02) { cockpitCamera.fov = nextFov; cockpitCamera.updateProjectionMatrix(); }
    p.shake = Math.max(0, p.shake - dt * 2.2);
    const jitter = p.shake * 0.03 + nosWarp * 0.005 * rush;
    // G-force pushes head subtly back into headrest (-Z) under NOS boost for pure speed-FOV sensation
    driverLocal.set(
      S.steer * 0.008 + (Math.random() - 0.5) * jitter,
      Math.sin(bumpCycle * 2.4) * motion * 0.0018 + (Math.random() - 0.5) * jitter,
      -0.014 - narrow * 0.022 + 0.022 * rush - 0.038 * nosWarp,
    ).multiplyScalar(CAR_SCALE).applyQuaternion(eyeRotation);
    cockpitCamera.position.add(driverLocal);
    cockpitCamera.up.set(0, 1, 0).applyQuaternion(eyeRotation);
    aim.set(-0.055 + headingOffset, -0.288 - 0.055 * narrow + 0.036 * rush + 0.016 * nosWarp, 1).applyQuaternion(eyeRotation).add(cockpitCamera.position);
    cockpitCamera.lookAt(aim);
  }

  function renderMirror() {
    mirrorPos.set(0, 1.24 / CAR_SCALE, -2.05 / CAR_SCALE);
    car.localToWorld(mirrorPos);
    mirrorAim.set(0, 1.12 / CAR_SCALE, -45 / CAR_SCALE);
    car.localToWorld(mirrorAim);
    mirrorCamera.position.copy(mirrorPos);
    mirrorCamera.up.set(0, 1, 0);
    mirrorCamera.lookAt(mirrorAim);
    const prevVis = car.visible;
    car.visible = false;
    const prev = renderer.getRenderTarget();
    renderer.setRenderTarget(mirrorTarget);
    renderer.render(scene, mirrorCamera);
    renderer.setRenderTarget(prev);
    car.visible = prevVis;
  }

  function updateStreaks(dt: number) {
    const v = S.speed;
    const strength = THREE.MathUtils.smoothstep(v, 20, NITRO_MAX) * (p.nitroActive ? 1 : 0.6);
    streakMat.opacity = strength * 0.66;
    if (strength <= 0.001) { streaks.visible = false; return; }
    streaks.visible = true;
    const len = 2 + v * 0.09;
    const origin = cameraMode === 'cockpit' ? cockpitCamera.position : camPos;
    for (let i = 0; i < STREAKS; i++) {
      const s = streakPos[i];
      s.z -= v * dt * 1.1;
      if (s.z < -6) { s.z = 40 + Math.random() * 30; s.x = (Math.random() - 0.5) * 18; s.y = Math.random() * 7 + 0.2; }
      tmpP.set(origin.x + s.x, s.y, origin.z + s.z);
      tmpS.set(1, len, 1);
      tmpM.compose(tmpP, tmpQ, tmpS);
      streaks.setMatrixAt(i, tmpM);
    }
    streaks.instanceMatrix.needsUpdate = true;
  }

  // ---- Main loop ----
  let frame = 0, last = performance.now(), accumulator = 0, shadowFrame = 0, lastReport = 0;
  const renderInterval = 1000 / 60;
  let nextRenderDue = performance.now();
  function loop(now: number) {
    frame = requestAnimationFrame(loop);
    if (perfSettings.lock60) {
      // Frame pacing based on a due-time (not a simple interval test). This
      // renders a true ~60 fps on 60/75/120/144/165 Hz panels and lets the
      // display skip/take frames without speeding physics up.
      if (now + 2 < nextRenderDue) return;
      nextRenderDue = Math.max(now, nextRenderDue) + renderInterval;
      if (nextRenderDue < now - 40) nextRenderDue = now + renderInterval;
    }
    const sinceRender = now - last;
    const frameDt = Math.min(0.05, sinceRender / 1000);
    last = now;
    if (phase === 'paused') {
      if (now - lastReport > 200) { lastReport = now; reportTelemetry(now); }
      return;
    }
    governor.sample(sinceRender, frameDt);
    renderer.info.reset();
    elapsed += frameDt;
    if (envRebuildAt && elapsed >= envRebuildAt) { envRebuildAt = 0; lighting.rebuildEnvironment(); }

    const running = phase === 'running';
    const wrecked = phase === 'wrecked';
    const simDt = wrecked ? frameDt * 0.35 : frameDt;
    if (running || wrecked) {
      accumulator += simDt;
      let steps = 0;
      while (accumulator >= PHYS_STEP && steps < 12) {
        if (running) stepPhysics(PHYS_STEP);
        else { sim.step(PHYS_STEP, { steer: 0, brake: 1, handbrake: false, nitro: false, power: false, auto: false }); effects.step(PHYS_STEP, S); }
        accumulator -= PHYS_STEP; steps++;
      }
    }
    const body = { x: S.x, z: S.z, yaw: S.yaw, vx: S.vx, vz: S.vz, speed: S.speed };
    const events = traffic.update(simDt, body, S.yawRate, running || wrecked || phase === 'ready');
    const crossEvents = crossTraffic.update(simDt, body, running || wrecked || phase === 'ready');
    if (body.x !== S.x || body.z !== S.z || body.vx !== S.vx || body.vz !== S.vz) {
      S.x = body.x; S.z = body.z; S.vx = body.vx; S.vz = body.vz; sim.refresh();
    }
    handleTrafficEvents([...events, ...crossEvents]);
    traffic.density(Math.min(3, 1 + p.distance / 2500));

    city.update(S.z);
    car.position.set(S.x, 0, S.z);
    car.rotation.y = S.yaw;
    const interior = cameraMode === 'cockpit';
    const liveRpm = running ? sim.tele.rpm : 680;
    // Map actual RPM (680..7200) cleanly onto the classic cockpit's (1.1 + rev * 7.9) × 1000 display formula
    const classicRev = THREE.MathUtils.clamp(((liveRpm / 1000) - 1.1) / 7.9, 0, 1);
    car.userData.tick(frameDt, {
      ...S,
      rev: classicRev,
      speed: S.forwardSpeed,
      displayKmh: S.speed * 3.6,
      animateCabin: interior,
      roughness: 0.2 + (p.nitroActive ? 0.45 : 0),
    });
    if (interior) {
      cockpitUpgrades.update({
        kmh: Math.max(0, S.speed * 3.6),
        rpm: liveRpm,
        gear: S.gear,
        nitro: p.nitro,
        nitroActive: p.nitroActive,
        distanceKm: p.distance / 1000,
        headlights: lampsActive,
        drifting: sim.tele.drifting,
      });
    }
    car.userData.updateGlow(interior ? cockpitCamera.position : camera.position);

    updateCamera(frameDt);
    updateStreaks(frameDt);
    const view = interior ? cockpitCamera : camera;
    curveCtrl.sync(frameDt, S.z, view.position.z, cameraMode);
    lighting.update(carPos, view.position, S.yaw, viewDir);
    if ((shadowFrame = (shadowFrame + 1) % qualityProfile().shadowEvery) === 0) renderer.shadowMap.needsUpdate = true;
    effects.update(1, view.position);

    // Engine audio locked 1:1 to actual vehicle speed, gear, RPM & load (from 0 and 1 km/h up to 500 km/h NOS)
    audio.sample(S, 0, interior, {
      v: running || wrecked ? S.speed : 0,
      rpm: running ? sim.tele.rpm : 680,
      gear: running ? sim.tele.gearNum : 0,
      load: running ? sim.tele.load : 0.05,
    });
    sfx.update(frameDt, S.speed / NITRO_MAX, p.nitroActive);

    if (interior && (mirrorFrame++ % 3) === 0) renderMirror();
    post.render(scene, view, frameDt, elapsed);
    drawCalls = renderer.info.render.calls;

    if (now >= reportAt) {
      reportAt = now + 66;
      reportTelemetry(now);
    }
  }

  function reportTelemetry(now: number) {
    lastReport = now;
    callbacks.onTelemetry({
      phase, kmh: S.speed * 3.6, nitro: p.nitro, nitroActive: p.nitroActive, health: p.health,
      score: p.score, distance: p.distance, time: p.time, combo: p.combo, nearMisses: p.nearMisses, overtakes: p.overtakes, crashes: p.crashes,
      gear: S.gear, rpm: S.rev, camera: cameraMode, mood, topSpeed: p.topSpeed, best,
      slipDeg: sim.tele.slipDeg, drifting: sim.tele.drifting, driftPoints: p.driftPoints, driftBanked: p.driftBanked, handbrake: S.handbrake,
      perf: {
        ...perfSettings,
        fps: Math.round(governor.fps),
        frameMs: Math.round(governor.frameMs * 10) / 10,
        pixelRatio: Math.round(renderer.getPixelRatio() * 100) / 100,
        drawCalls,
        traffic: trafficCount + crossCount,
        degraded: governor.degraded,
      },
    });
  }

  function resize() {
    // This is the only place resolution changes: CSS layout always stays 1:1,
    // only the internal pixel grid scales. HUD typography remains razor sharp.
    const profile = QUALITY_PROFILES[perfSettings.quality];
    const base = Math.min(window.devicePixelRatio || 1, profile.pixelCap);
    renderer.setPixelRatio(Math.max(0.65, base * renderScale));
    const w = host.clientWidth || window.innerWidth, h = host.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    renderer.domElement.style.width = '100%'; renderer.domElement.style.height = '100%';
    camera.aspect = w / h; camera.updateProjectionMatrix();
    cockpitCamera.aspect = w / h; cockpitCamera.updateProjectionMatrix();
  }
  resize();
  const ro = new ResizeObserver(() => resize());
  ro.observe(host);
  const onVisibility = () => { if (document.hidden && phase === 'running') { phase = 'paused'; audio.silence(); } };
  document.addEventListener('visibilitychange', onVisibility);
  try {
    scene.updateMatrixWorld(true);
    renderer.compile(scene, camera);
    renderer.compile(scene, cockpitCamera);
    renderer.shadowMap.needsUpdate = true;
  } catch { /* prewarm is best-effort */ }
  frame = requestAnimationFrame(loop);
  callbacks.onProgress('Siap balapan', 1);

  function cleanup() {
    cancelAnimationFrame(frame);
    document.removeEventListener('visibilitychange', onVisibility);
    ro.disconnect();
    try { post.dispose(); } catch { /* composer may be half-built */ }
    traffic.dispose();
    crossTraffic.dispose();
    city.dispose();
    for (const t of treeAsset.templates) t.leaves.dispose();
    treeAsset.templates.forEach(t => t.bark?.dispose());
    v2Tex.dispose();
    lighting.dispose();
    v3.dispose();
    cockpitUpgrades.dispose();
    mirrorTarget.dispose();
    streakGeo.dispose(); streakMat.dispose();
    car.traverse(o => { const m = o as THREE.Mesh; if (m.isMesh) { m.geometry?.dispose(); } });
    audio.dispose();
    sfx.dispose();
    renderer.dispose();
    renderer.domElement.remove();
  }

  const snapshot = (): LightingSnapshot => ({ v2: { ...lighting.settings }, state: { ...lighting.state } });
  const cameraOrder: CameraMode[] = ['chase', 'cockpit', 'hood', 'far'];
  const moodOrder: TimeOfDay[] = ['day', 'dusk', 'night'];
  return {
    start() { if (phase === 'ready') { phase = 'running'; audio.unlock(); sfx.unlock(); audio.wake(); } },
    restart() { placeAtStart(); phase = 'running'; accumulator = 0; audio.unlock(); sfx.unlock(); audio.wake(); },
    pause(pz) {
      if (pz && phase === 'running') { phase = 'paused'; audio.silence(); }
      else if (!pz && phase === 'paused') { phase = 'running'; last = performance.now(); audio.wake(); }
    },
    setInput(patch) { Object.assign(input, patch); },
    camera(m) { cameraMode = m; applyCameraMode(); },
    cycleCamera() { cameraMode = cameraOrder[(cameraOrder.indexOf(cameraMode) + 1) % cameraOrder.length]; applyCameraMode(); return cameraMode; },
    mood(next) { applyMood(next); },
    cycleMood() { applyMood(moodOrder[(moodOrder.indexOf(mood) + 1) % moodOrder.length]); return mood; },
    sound(on) { audio.setEnabled(on); sfx.setEnabled(on); },
    volume(v) { const level = Math.max(0, Math.min(1, v)); audio.setVolume(level); sfx.setVolume(level); },
    steering(v) { steeringSensitivity = THREE.MathUtils.clamp(v, 0.7, 1.6); return steeringSensitivity; },
    speedoStyle(style) {
      cockpitUpgrades.setSpeedoStyle(style);
      if (cameraMode === 'cockpit') {
        cockpitUpgrades.update({
          kmh: Math.max(0, S.speed * 3.6),
          rpm: phase === 'running' ? sim.tele.rpm : 680,
          gear: S.gear,
          nitro: p.nitro,
          nitroActive: p.nitroActive,
          distanceKm: p.distance / 1000,
          headlights: lampsActive,
          drifting: sim.tele.drifting,
        });
      }
      return cockpitUpgrades.getSpeedoStyle();
    },
    curveWorld(next) {
      if (next) {
        curveCtrl.setMode(next);
        const view = cameraMode === 'cockpit' ? cockpitCamera : camera;
        curveCtrl.sync(1 / 60, S.z, view.position.z, cameraMode, true);
      }
      return curveCtrl.getMode();
    },
    handPose(next) {
      if (next) {
        currentHandPose = next;
        car.userData.setLeftArmWindow(next === 'window');
      }
      return currentHandPose;
    },
    speed() {
      const kmh = Math.max(0, S.speed * 3.6);
      return {
        kmh,
        forwardKmh: Math.max(0, S.forwardSpeed * 3.6),
        baseKmh: BASE_MAX * 3.6,
        maxKmh: NITRO_MAX * 3.6,
        ratio: Math.min(1, kmh / (NITRO_MAX * 3.6)),
        gear: S.gear,
        rpm: S.rev,
        rpmActual: phase === 'running' ? sim.tele.rpm : 680,
        nitro: p.nitro,
        nitroActive: p.nitroActive,
        distanceKm: p.distance / 1000,
      };
    },
    unlockAudio() { audio.unlock(); sfx.unlock(); },
    lighting: snapshot,
    setSun(next) { lighting.applyV2(next); envRebuildAt = elapsed + 0.35; return snapshot(); },
    setLightLevels(next) { lighting.apply(next); return snapshot(); },
    resetLighting() { lighting.resetAll(); return snapshot(); },
    performance() {
      return {
        ...perfSettings,
        fps: Math.round(governor.fps), frameMs: Math.round(governor.frameMs * 10) / 10,
        pixelRatio: Math.round(renderer.getPixelRatio() * 100) / 100,
        drawCalls, traffic: trafficCount + crossCount, degraded: governor.degraded,
      };
    },
    setPerformance(next) {
      const quality = next.quality && next.quality !== perfSettings.quality ? next.quality : perfSettings.quality;
      perfSettings = {
        ...perfSettings,
        ...next,
        quality,
      };
      if (next.quality && next.quality !== post.quality) applyQuality(next.quality);
      else resize();
      return {
        ...perfSettings,
        fps: Math.round(governor.fps), frameMs: Math.round(governor.frameMs * 10) / 10,
        pixelRatio: Math.round(renderer.getPixelRatio() * 100) / 100,
        drawCalls, traffic: trafficCount + crossCount, degraded: governor.degraded,
      };
    },
    resize,
    dispose: cleanup,
  };
}
export { BASE_MAX, NITRO_MAX };
