import * as THREE from 'three';
import { applyCurvedWorld } from './curveWorld';

let stamp: THREE.CanvasTexture | null = null;
const GEO_CACHE = new Map<string, THREE.PlaneGeometry>();
const MAT_CACHE = new Map<number, THREE.MeshBasicMaterial>();

function contactShadowTexture() {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128;
  const c = canvas.getContext('2d')!;
  const g = c.createRadialGradient(64, 64, 4, 64, 64, 64);
  g.addColorStop(0, 'rgba(0,0,0,.80)'); g.addColorStop(.5, 'rgba(0,0,0,.52)');
  g.addColorStop(.8, 'rgba(0,0,0,.18)'); g.addColorStop(1, 'rgba(0,0,0,0)');
  c.fillStyle = g; c.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(canvas);
}

/** Shared blob shadow: one texture, one material shape per footprint. */
export function makeContactShadow(w = 2.5, l = 4.3, opacity = 0.78) {
  stamp ??= contactShadowTexture();
  const key = `${w}:${l}`;
  let geometry = GEO_CACHE.get(key);
  if (!geometry) { geometry = new THREE.PlaneGeometry(w, l); GEO_CACHE.set(key, geometry); }
  let material = MAT_CACHE.get(opacity);
  if (!material) {
    material = applyCurvedWorld(new THREE.MeshBasicMaterial({ map: stamp, transparent: true, opacity, depthWrite: false }))!;
    MAT_CACHE.set(opacity, material);
  }
  const mesh = new THREE.Mesh(geometry, material);
  mesh.userData.shared = true;
  mesh.frustumCulled = false;
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.02;
  mesh.renderOrder = 1;
  return mesh;
}
