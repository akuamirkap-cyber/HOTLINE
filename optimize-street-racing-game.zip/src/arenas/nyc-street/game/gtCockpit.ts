import * as THREE from 'three';

/**
 * NYC Street Kings — Cockpit Mirror Upgrade & Optional GT Twin-Dial Speedometer.
 *
 * Keeps the classic Group B cockpit, steering wheel and animated hands 100% intact, while:
 *  1. Replacing the old boxy cabin rear-view mirror with the sleek rounded-stadium
 *     live rear-view mirror on an angled ceiling stalk, and
 *  2. Providing an optional GT Twin-Dial analog-sport instrument cluster inside the
 *     existing dashboard binnacle (default remains the classic digital cluster).
 */

export type SpeedoStyle = 'classic' | 'gt';

export type CockpitGaugeTelemetry = {
  kmh: number;
  rpm: number;        // actual engine RPM (680..7200)
  gear: string;       // '1'..'7' | 'R'
  nitro: number;      // 0..100
  nitroActive: boolean;
  distanceKm: number;
  headlights: boolean;
  drifting: boolean;
};

export type NycCockpitUpgrades = {
  mirrorHost: THREE.Group;
  setMirrorTexture(tex: THREE.Texture | null): void;
  setSpeedoStyle(style: SpeedoStyle): void;
  getSpeedoStyle(): SpeedoStyle;
  update(tele: CockpitGaugeTelemetry): void;
  dispose(): void;
};

function stadiumShape(w: number, h: number, r: number) {
  const hw = w / 2, hh = h / 2, rr = Math.min(r, hw * 0.95, hh * 0.95);
  const s = new THREE.Shape();
  s.moveTo(-hw + rr, -hh);
  s.lineTo(hw - rr, -hh);
  s.absarc(hw - rr, -hh + rr, rr, -Math.PI / 2, 0, false);
  s.lineTo(hw, hh - rr);
  s.absarc(hw - rr, hh - rr, rr, 0, Math.PI / 2, false);
  s.lineTo(-hw + rr, hh);
  s.absarc(-hw + rr, hh - rr, rr, Math.PI / 2, Math.PI, false);
  s.lineTo(-hw, -hh + rr);
  s.absarc(-hw + rr, -hh + rr, rr, Math.PI, Math.PI * 1.5, false);
  s.closePath();
  return s;
}

function normalizePlanarUV(geo: THREE.BufferGeometry, w: number, h: number) {
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const uvs = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    uvs[i * 2] = pos.getX(i) / w + 0.5;
    uvs[i * 2 + 1] = pos.getY(i) / h + 0.5;
  }
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  return geo;
}

/** Sport non-linear speedometer sweep: 0–250 km/h uses 65%, 250–500 uses 35% NOS zone. */
export function gtSpeedFraction(kmh: number) {
  const v = Math.max(0, Math.min(500, kmh));
  if (v <= 250) return (v / 250) * 0.65;
  return 0.65 + ((v - 250) / 250) * 0.35;
}

/**
 * Builds the optional GT Twin-Dial canvas cluster sized cleanly for the classic
 * Group B binnacle (`0.601 × 0.189` model units -> 1024 × 322 aspect-matched canvas)
 * so circles render perfectly round through the 3-spoke steering wheel opening.
 */
function buildBinnacleGtCluster() {
  const W = 1024, H = 322;
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const g = c.getContext('2d')!;

  const bgCanvas = document.createElement('canvas');
  bgCanvas.width = W; bgCanvas.height = H;
  const bg = bgCanvas.getContext('2d')!;

  // Clip to the exact arched hood silhouette of the classic binnacle so corners never poke out
  function traceHoodPath(ctx: CanvasRenderingContext2D) {
    ctx.beginPath();
    ctx.moveTo(20, 310);
    ctx.lineTo(20, 174);
    ctx.quadraticCurveTo(74, 18, 206, 12);
    ctx.lineTo(852, 12);
    ctx.quadraticCurveTo(960, 22, 1004, 156);
    ctx.lineTo(1004, 310);
    ctx.closePath();
  }

  bg.clearRect(0, 0, W, H);
  bg.save();
  traceHoodPath(bg);
  bg.clip();

  const backGrad = bg.createLinearGradient(0, 0, 0, H);
  backGrad.addColorStop(0, '#0a0e18');
  backGrad.addColorStop(1, '#05070d');
  bg.fillStyle = backGrad;
  bg.fillRect(0, 0, W, H);

  const LX = 300, RX = 724, CY = 172, R = 118;
  const START_A = (135 * Math.PI) / 180;
  const SWEEP_A = (270 * Math.PI) / 180;

  // Indigo-blue GT ambient halo around both dials
  for (const cx of [LX, RX]) {
    const halo = bg.createRadialGradient(cx, CY, R * 0.68, cx, CY, R * 1.28);
    halo.addColorStop(0, 'rgba(72, 104, 235, 0)');
    halo.addColorStop(0.72, 'rgba(92, 126, 255, 0.36)');
    halo.addColorStop(0.90, 'rgba(118, 152, 255, 0.48)');
    halo.addColorStop(1, 'rgba(8, 12, 24, 0)');
    bg.fillStyle = halo;
    bg.beginPath(); bg.arc(cx, CY, R * 1.28, 0, Math.PI * 2); bg.fill();

    const face = bg.createRadialGradient(cx, CY - 16, 8, cx, CY, R);
    face.addColorStop(0, '#181e2c');
    face.addColorStop(0.8, '#0b0e16');
    face.addColorStop(1, '#06080d');
    bg.fillStyle = face;
    bg.beginPath(); bg.arc(cx, CY, R, 0, Math.PI * 2); bg.fill();

    bg.strokeStyle = 'rgba(205, 218, 244, 0.42)';
    bg.lineWidth = 2.4;
    bg.beginPath(); bg.arc(cx, CY, R - 3, 0, Math.PI * 2); bg.stroke();
  }

  // Left Dial: Speedometer 0–500 km/h
  bg.strokeStyle = '#e5252c';
  bg.lineWidth = 6.5;
  bg.beginPath();
  bg.arc(LX, CY, R - 9, START_A + SWEEP_A * 0.58, START_A + SWEEP_A, false);
  bg.stroke();

  for (let i = 0; i <= 50; i++) {
    const frac = i / 50;
    const a = START_A + frac * SWEEP_A;
    const major = i % 5 === 0;
    const rOut = R - 12;
    const rIn = major ? R - 26 : R - 19;
    bg.strokeStyle = frac > 0.65 ? '#ff474d' : major ? '#f4f7ff' : 'rgba(215,225,245,0.55)';
    bg.lineWidth = major ? 2.6 : 1.3;
    bg.beginPath();
    bg.moveTo(LX + Math.cos(a) * rIn, CY + Math.sin(a) * rIn);
    bg.lineTo(LX + Math.cos(a) * rOut, CY + Math.sin(a) * rOut);
    bg.stroke();
  }
  bg.font = '700 14px sans-serif';
  bg.textAlign = 'center';
  bg.textBaseline = 'middle';
  for (const spd of [0, 30, 60, 100, 140, 180, 220, 250, 320, 400, 500]) {
    const a = START_A + gtSpeedFraction(spd) * SWEEP_A;
    const rn = R - 40;
    bg.fillStyle = spd > 250 ? '#ff6a70' : '#eef3ff';
    bg.fillText(String(spd), LX + Math.cos(a) * rn, CY + Math.sin(a) * rn);
  }
  bg.fillStyle = '#96a8cc';
  bg.font = '700 11px sans-serif';
  bg.fillText('km/h', LX, CY + 46);

  // Right Dial: Tachometer 0..8 × 1000 RPM
  bg.strokeStyle = '#e5252c';
  bg.lineWidth = 6.5;
  bg.beginPath();
  bg.arc(RX, CY, R - 9, START_A + SWEEP_A * (6.8 / 8), START_A + SWEEP_A, false);
  bg.stroke();

  for (let i = 0; i <= 40; i++) {
    const frac = i / 40;
    const a = START_A + frac * SWEEP_A;
    const major = i % 5 === 0;
    const rOut = R - 12;
    const rIn = major ? R - 26 : R - 19;
    const red = frac >= 6.8 / 8;
    bg.strokeStyle = red ? '#ff3b42' : major ? '#f4f7ff' : 'rgba(215,225,245,0.55)';
    bg.lineWidth = major ? 2.6 : 1.3;
    bg.beginPath();
    bg.moveTo(RX + Math.cos(a) * rIn, CY + Math.sin(a) * rIn);
    bg.lineTo(RX + Math.cos(a) * rOut, CY + Math.sin(a) * rOut);
    bg.stroke();
  }
  bg.font = '700 16px sans-serif';
  for (let r = 0; r <= 8; r++) {
    const a = START_A + (r / 8) * SWEEP_A;
    const rn = R - 40;
    bg.fillStyle = r >= 7 ? '#ff555b' : '#eef3ff';
    bg.fillText(String(r), RX + Math.cos(a) * rn, CY + Math.sin(a) * rn);
  }
  bg.fillStyle = '#96a8cc';
  bg.font = '700 10px sans-serif';
  bg.fillText('RPM × 1000', RX, CY + 46);

  // 3 circular indicator pods at top center
  for (let i = 0; i < 3; i++) {
    const px = 476 + i * 36, py = 54;
    bg.strokeStyle = 'rgba(180, 196, 226, 0.55)';
    bg.lineWidth = 2.2;
    bg.fillStyle = '#0d111b';
    bg.beginPath(); bg.arc(px, py, 11, 0, Math.PI * 2); bg.fill(); bg.stroke();
  }

  // Center digital MFD frame
  bg.fillStyle = '#0c111d';
  bg.strokeStyle = 'rgba(165, 185, 225, 0.38)';
  bg.lineWidth = 2;
  bg.beginPath();
  bg.roundRect(450, 86, 124, 182, 9);
  bg.fill(); bg.stroke();

  traceHoodPath(bg);
  bg.strokeStyle = '#252d3d';
  bg.lineWidth = 4;
  bg.stroke();
  bg.restore();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;

  function drawNeedle(cx: number, cy: number, angle: number, length: number) {
    g.save();
    g.translate(cx, cy);
    g.rotate(angle);
    g.shadowColor = 'rgba(255, 62, 36, 0.85)';
    g.shadowBlur = 9;
    g.fillStyle = '#ff3b28';
    g.beginPath();
    g.moveTo(-16, -3.5);
    g.lineTo(length, -1.3);
    g.lineTo(length, 1.3);
    g.lineTo(-16, 3.5);
    g.closePath();
    g.fill();
    g.restore();

    const cap = g.createRadialGradient(cx - 4, cy - 4, 2, cx, cy, 15);
    cap.addColorStop(0, '#dce4f2');
    cap.addColorStop(0.55, '#596273');
    cap.addColorStop(1, '#181c24');
    g.fillStyle = cap;
    g.beginPath(); g.arc(cx, CY, 14, 0, Math.PI * 2); g.fill();
  }

  let lastKey = '';
  function update(tele: CockpitGaugeTelemetry) {
    const key = `${Math.round(tele.kmh * 2)}:${Math.round(tele.rpm / 20)}:${tele.gear}:${Math.round(tele.nitro)}:${tele.nitroActive ? 1 : 0}:${tele.headlights ? 1 : 0}:${tele.drifting ? 1 : 0}`;
    if (key === lastKey) return;
    lastKey = key;

    g.clearRect(0, 0, W, H);
    g.drawImage(bgCanvas, 0, 0);

    if (tele.headlights) {
      g.fillStyle = '#36d399';
      g.beginPath(); g.arc(476, 54, 5.5, 0, Math.PI * 2); g.fill();
    }
    if (tele.drifting) {
      g.fillStyle = '#fbbf24';
      g.beginPath(); g.arc(512, 54, 5.5, 0, Math.PI * 2); g.fill();
    }
    if (tele.rpm > 6500 || tele.nitroActive) {
      g.fillStyle = tele.nitroActive ? '#38bdf8' : '#ef4444';
      g.beginPath(); g.arc(548, 54, 5.5, 0, Math.PI * 2); g.fill();
    }

    g.textAlign = 'center';
    g.fillStyle = tele.nitroActive ? '#5eead4' : '#9bb4de';
    g.font = '700 12px sans-serif';
    g.fillText(tele.nitroActive ? 'NOS 2X' : 'SPORT+', 512, 108);

    g.fillStyle = '#ffffff';
    g.font = '800 34px sans-serif';
    g.fillText(String(Math.round(tele.kmh)), 512, 146);
    g.fillStyle = '#8fa4c8';
    g.font = '600 11px sans-serif';
    g.fillText('km/h', 512, 166);

    g.fillStyle = 'rgba(255,255,255,0.09)';
    g.beginPath(); g.roundRect(478, 178, 68, 36, 7); g.fill();
    g.fillStyle = tele.gear === 'R' ? '#f87171' : '#ffd166';
    g.font = '800 23px sans-serif';
    const gLabel = tele.gear === 'R' ? 'R' : tele.kmh < 0.2 ? 'D1' : `D${tele.gear}`;
    g.fillText(gLabel, 512, 203);

    g.fillStyle = '#9fb2d4';
    g.font = '600 12px monospace';
    g.fillText(`${tele.distanceKm.toFixed(1)} km`, 512, 236);
    g.fillStyle = 'rgba(255,255,255,0.14)';
    g.fillRect(464, 248, 96, 5);
    g.fillStyle = tele.nitroActive ? '#38bdf8' : '#60a5fa';
    g.fillRect(464, 248, 96 * Math.max(0, Math.min(1, tele.nitro / 100)), 5);

    const spdAngle = START_A + gtSpeedFraction(tele.kmh) * SWEEP_A;
    const rpmAngle = START_A + Math.max(0, Math.min(1, tele.rpm / 8000)) * SWEEP_A;
    drawNeedle(LX, CY, spdAngle, R - 18);
    drawNeedle(RX, CY, rpmAngle, R - 18);

    tex.needsUpdate = true;
  }

  return { tex, update, LX, RX, CY, R, W, H };
}

export function createNycCockpitUpgrades(
  model: THREE.Object3D,
  cockpitLayer: number,
  carScale: number,
  initialStyle: SpeedoStyle = 'classic',
): NycCockpitUpgrades {
  const ownedGeos: THREE.BufferGeometry[] = [];
  const ownedMats: THREE.Material[] = [];
  const ownedTex: THREE.Texture[] = [];
  const trackGeo = <T extends THREE.BufferGeometry>(g: T) => { ownedGeos.push(g); return g; };
  const trackMat = <T extends THREE.Material>(m: T) => { ownedMats.push(m); return m; };

  const cockpit = model.getObjectByName('cockpit') ?? model;

  // 1. Remove the legacy boxy rear-view mirror & stem from the old cockpit cleanly
  for (const legacyName of ['cabinMirror', 'interiorMirrorStem']) {
    const node = cockpit.getObjectByName(legacyName);
    node?.parent?.remove(node);
  }

  // 2. Attach the new rounded-stadium live rear-view mirror (1:1 real-metre scale)
  const mirrorHost = new THREE.Group();
  mirrorHost.name = 'nycRoundedRearMirror';
  mirrorHost.scale.setScalar(1 / carScale);
  cockpit.add(mirrorHost);

  const mirrorTrimMat = trackMat(new THREE.MeshStandardMaterial({
    color: 0x13161b, roughness: 0.72, metalness: 0.06, envMapIntensity: 0.3, side: THREE.DoubleSide,
  }));
  const mirrorGlassMat = trackMat(new THREE.MeshBasicMaterial({
    color: 0xe6edf7, toneMapped: false,
  }));

  const mirrorGroup = new THREE.Group();
  // Positioned in real metres inside the classic cabin: upper right-center of windshield,
  // tucked neatly below the top cross-bar and angled toward the driver's eye.
  mirrorGroup.position.set(0.055, 1.132, 0.215);
  mirrorGroup.rotation.order = 'YXZ';
  mirrorGroup.rotation.y = Math.PI - 0.11;
  mirrorGroup.rotation.x = 0.13;
  mirrorHost.add(mirrorGroup);

  // Angled ceiling stalk reaching up into the top cross-bar / headliner
  const stalkCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.012, 0.012, -0.016),
    new THREE.Vector3(0.022, 0.068, -0.022),
    new THREE.Vector3(0.056, 0.138, -0.028),
  ]);
  const stalk = new THREE.Mesh(trackGeo(new THREE.TubeGeometry(stalkCurve, 10, 0.011, 10, false)), mirrorTrimMat);
  mirrorGroup.add(stalk);

  const mw = 0.198, mh = 0.064, mr = 0.029;
  const housingGeo = trackGeo(new THREE.ExtrudeGeometry(stadiumShape(mw + 0.012, mh + 0.012, mr + 0.005), {
    depth: 0.016, curveSegments: 24, bevelEnabled: true, bevelThickness: 0.004, bevelSize: 0.004, bevelSegments: 3,
  }));
  const mirrorHousing = new THREE.Mesh(housingGeo, mirrorTrimMat);
  mirrorHousing.position.z = -0.018;
  mirrorGroup.add(mirrorHousing);

  // Bottom anti-glare tab
  const tabShape = new THREE.Shape();
  tabShape.moveTo(-0.026, 0);
  tabShape.lineTo(0.026, 0);
  tabShape.lineTo(0.019, -0.012);
  tabShape.lineTo(-0.019, -0.012);
  tabShape.closePath();
  const mirrorTab = new THREE.Mesh(
    trackGeo(new THREE.ExtrudeGeometry(tabShape, { depth: 0.012, bevelEnabled: false })),
    mirrorTrimMat,
  );
  mirrorTab.position.set(0, -(mh * 0.5 + 0.004), -0.012);
  mirrorGroup.add(mirrorTab);

  const mirrorGlassGeo = trackGeo(normalizePlanarUV(new THREE.ShapeGeometry(stadiumShape(mw, mh, mr), 24), mw, mh));
  const mirrorGlass = new THREE.Mesh(mirrorGlassGeo, mirrorGlassMat);
  mirrorGlass.position.z = 0.003;
  mirrorGroup.add(mirrorGlass);

  mirrorHost.traverse(o => o.layers.set(cockpitLayer));

  // 3. Optional GT Twin-Dial Cluster mounted inside the classic `digitalInstruments` binnacle
  const dashDisplay = cockpit.getObjectByName('digitalInstruments');
  const classicScreen = cockpit.getObjectByName('instrumentScreen');

  const clusterSys = buildBinnacleGtCluster();
  ownedTex.push(clusterSys.tex);

  const gtClusterGroup = new THREE.Group();
  gtClusterGroup.name = 'nycGtInstrumentOption';
  // Matches `rearFacingScreen(dashDisplay, 'instrumentScreen', 0.601, 0.189, ...)`
  const cw = 0.601, ch = 0.189;
  gtClusterGroup.rotation.y = Math.PI;
  gtClusterGroup.position.z = -0.001;

  const gtMat = trackMat(new THREE.MeshBasicMaterial({
    map: clusterSys.tex, toneMapped: false, transparent: true, alphaTest: 0.15,
  }));
  const gtPlane = new THREE.Mesh(trackGeo(new THREE.PlaneGeometry(cw, ch)), gtMat);
  gtClusterGroup.add(gtPlane);

  const chromeMat = trackMat(new THREE.MeshStandardMaterial({
    color: 0xcdd5e2, roughness: 0.24, metalness: 0.85, envMapIntensity: 0.95,
  }));
  for (const uPx of [clusterSys.LX, clusterSys.RX]) {
    const lx = (uPx / clusterSys.W - 0.5) * cw;
    const ly = (0.5 - clusterSys.CY / clusterSys.H) * ch;
    const dialR = (clusterSys.R / clusterSys.W) * cw;
    const ring = new THREE.Mesh(trackGeo(new THREE.TorusGeometry(dialR, 0.0052, 14, 48)), chromeMat);
    ring.position.set(lx, ly, 0.003);
    gtClusterGroup.add(ring);
  }

  gtClusterGroup.traverse(o => o.layers.set(cockpitLayer));
  if (dashDisplay) dashDisplay.add(gtClusterGroup);

  let currentStyle: SpeedoStyle = initialStyle;
  function setSpeedoStyle(style: SpeedoStyle) {
    currentStyle = style;
    const useGt = style === 'gt';
    if (classicScreen) classicScreen.visible = !useGt;
    gtClusterGroup.visible = useGt;
  }
  setSpeedoStyle(initialStyle);

  return {
    mirrorHost,
    setMirrorTexture(tex) {
      mirrorGlassMat.map = tex;
      mirrorGlassMat.color.setHex(tex ? 0xf2f6fc : 0x1a2230);
      mirrorGlassMat.needsUpdate = true;
    },
    setSpeedoStyle,
    getSpeedoStyle: () => currentStyle,
    update(tele) {
      if (currentStyle === 'gt') clusterSys.update(tele);
    },
    dispose() {
      for (const g of ownedGeos) g.dispose();
      for (const m of ownedMats) m.dispose();
      for (const t of ownedTex) t.dispose();
    },
  };
}
