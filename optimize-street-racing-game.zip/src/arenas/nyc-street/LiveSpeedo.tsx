import { memo, useEffect, useRef, type RefObject } from 'react';
import type { Engine } from './game/engine';
import { gtSpeedFraction, type SpeedoStyle } from './game/gtCockpit';

/**
 * 60 fps speedometer with selectable style:
 *  - 'classic' (DEFAULT): original semicircle orange/blue arc speedometer.
 *  - 'gt' (OPTION): twin circular chrome-ringed analog-sport dials (km/h + RPM)
 *    with indigo-blue ambient halo, glowing red needles and center digital MFD.
 */
const ARC_LENGTH = Math.PI * 80; // r = 80, semicircle

function polar(cx: number, cy: number, r: number, degFromRight: number) {
  const rad = (degFromRight * Math.PI) / 180;
  return { x: cx + Math.cos(rad) * r, y: cy + Math.sin(rad) * r };
}

function describeArc(cx: number, cy: number, r: number, startDeg: number, endDeg: number) {
  const s = polar(cx, cy, r, startDeg);
  const e = polar(cx, cy, r, endDeg);
  const large = endDeg - startDeg > 180 ? 1 : 0;
  return `M ${s.x.toFixed(2)} ${s.y.toFixed(2)} A ${r} ${r} 0 ${large} 1 ${e.x.toFixed(2)} ${e.y.toFixed(2)}`;
}

function LiveSpeedo({
  engineRef,
  style = 'classic',
}: {
  engineRef: RefObject<Engine | undefined>;
  style?: SpeedoStyle;
}) {
  // Classic refs
  const fill = useRef<SVGPathElement>(null);
  const needle = useRef<SVGPathElement>(null);
  const digits = useRef<HTMLElement>(null);
  const gear = useRef<HTMLElement>(null);
  const rpm = useRef<HTMLElement>(null);
  const baseMark = useRef<SVGLineElement>(null);

  // GT Twin-Dial refs
  const gtSpeedNeedle = useRef<SVGGElement>(null);
  const gtRpmNeedle = useRef<SVGGElement>(null);
  const gtDigits = useRef<SVGTextElement>(null);
  const gtGear = useRef<SVGTextElement>(null);
  const gtMode = useRef<SVGTextElement>(null);
  const gtNosBar = useRef<SVGRectElement>(null);

  useEffect(() => {
    let raf = 0;
    const paint = () => {
      const s = engineRef.current?.speed();
      if (s) {
        if (style === 'gt') {
          const spdDeg = 135 + gtSpeedFraction(s.kmh) * 270;
          const rpmDeg = 135 + Math.max(0, Math.min(1, s.rpmActual / 8000)) * 270;
          gtSpeedNeedle.current?.setAttribute('transform', `translate(76 78) rotate(${spdDeg})`);
          gtRpmNeedle.current?.setAttribute('transform', `translate(264 78) rotate(${rpmDeg})`);
          if (gtDigits.current) gtDigits.current.textContent = String(Math.round(s.kmh));
          if (gtGear.current) {
            gtGear.current.textContent = s.gear === 'R' ? 'R' : s.kmh < 0.2 ? 'D1' : `D${s.gear}`;
          }
          if (gtMode.current) {
            gtMode.current.textContent = s.nitroActive ? 'NOS 2X' : 'SPORT+';
            gtMode.current.setAttribute('fill', s.nitroActive ? '#5eead4' : '#9bb4de');
          }
          if (gtNosBar.current) {
            gtNosBar.current.setAttribute('width', `${40 * Math.max(0, Math.min(1, s.nitro / 100))}`);
            gtNosBar.current.setAttribute('fill', s.nitroActive ? '#38bdf8' : '#60a5fa');
          }
        } else {
          const ratio = Math.max(0, Math.min(1, s.ratio));
          const baseRatio = Math.max(0, Math.min(1, s.baseKmh / s.maxKmh));
          fill.current?.setAttribute('stroke-dasharray', `${ratio * ARC_LENGTH} ${ARC_LENGTH}`);
          fill.current?.setAttribute('stroke', s.nitroActive ? '#58d8ff' : ratio > baseRatio ? '#ffd166' : '#ffb248');
          needle.current?.setAttribute('transform', `rotate(${-90 + ratio * 180} 100 110)`);
          baseMark.current?.setAttribute('opacity', '1');
          if (digits.current) digits.current.textContent = String(Math.round(s.kmh));
          if (gear.current) gear.current.textContent = s.gear === 'R' ? 'R' : `G${s.gear}`;
          if (rpm.current) rpm.current.style.width = `${Math.round(Math.max(0, Math.min(1, s.rpm)) * 100)}%`;
        }
      }
      raf = requestAnimationFrame(paint);
    };
    raf = requestAnimationFrame(paint);
    return () => cancelAnimationFrame(raf);
  }, [engineRef, style]);

  if (style === 'gt') {
    const LX = 76, RX = 264, CY = 78, R = 58;
    const speedLabels = [0, 60, 140, 250, 400, 500];
    return (
      <div className="nyc-speedo nyc-speedo-gt">
        <svg viewBox="0 0 340 148" aria-hidden="true">
          <defs>
            <radialGradient id="gtHalo" cx="50%" cy="50%" r="50%">
              <stop offset="62%" stopColor="rgba(76,110,245,0)" />
              <stop offset="86%" stopColor="rgba(104,138,255,0.42)" />
              <stop offset="100%" stopColor="rgba(10,14,28,0)" />
            </radialGradient>
            <radialGradient id="gtFace" cx="50%" cy="38%" r="62%">
              <stop offset="0%" stopColor="#1b2131" />
              <stop offset="80%" stopColor="#0b0f18" />
              <stop offset="100%" stopColor="#06080e" />
            </radialGradient>
            <linearGradient id="gtChrome" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#eef3fb" />
              <stop offset="48%" stopColor="#8d99ae" />
              <stop offset="100%" stopColor="#3b4352" />
            </linearGradient>
          </defs>

          {/* Indigo-blue ambient halos */}
          <circle cx={LX} cy={CY} r={R + 15} fill="url(#gtHalo)" />
          <circle cx={RX} cy={CY} r={R + 15} fill="url(#gtHalo)" />

          {/* Center MFD pod */}
          <rect x="142" y="34" width="56" height="84" rx="7" fill="rgba(10,15,26,0.92)" stroke="rgba(175,195,235,0.38)" strokeWidth="1.3" />
          <text ref={gtMode} x="170" y="47" textAnchor="middle" fill="#9bb4de" fontSize="6.8" fontWeight="700" fontFamily="IBM Plex Mono, monospace">SPORT+</text>
          <text ref={gtDigits} x="170" y="70" textAnchor="middle" fill="#ffffff" fontSize="20" fontWeight="800" fontFamily="Barlow Condensed, sans-serif">0</text>
          <text x="170" y="80" textAnchor="middle" fill="#8fa4c8" fontSize="6.5" fontWeight="600" fontFamily="IBM Plex Mono, monospace">km/h</text>
          <rect x="153" y="85" width="34" height="17" rx="4" fill="rgba(255,255,255,0.08)" />
          <text ref={gtGear} x="170" y="97" textAnchor="middle" fill="#ffd166" fontSize="11.5" fontWeight="800" fontFamily="IBM Plex Mono, monospace">D1</text>
          <rect x="150" y="108" width="40" height="3.5" rx="1.75" fill="rgba(255,255,255,0.14)" />
          <rect ref={gtNosBar} x="150" y="108" width="22" height="3.5" rx="1.75" fill="#60a5fa" />

          {/* Left Dial: Speedometer */}
          <circle cx={LX} cy={CY} r={R + 2.5} fill="none" stroke="url(#gtChrome)" strokeWidth="3.5" />
          <circle cx={LX} cy={CY} r={R} fill="url(#gtFace)" stroke="rgba(210,222,245,0.28)" strokeWidth="1" />
          <path d={describeArc(LX, CY, R - 4, 135 + 270 * 0.58, 405)} fill="none" stroke="#e5252c" strokeWidth="3.2" strokeLinecap="round" />
          {Array.from({ length: 26 }, (_, i) => {
            const frac = i / 25;
            const deg = 135 + frac * 270;
            const major = i % 5 === 0;
            const p1 = polar(LX, CY, major ? R - 11 : R - 8, deg);
            const p2 = polar(LX, CY, R - 4.5, deg);
            return <line key={i} x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
              stroke={frac > 0.65 ? '#ff4d52' : major ? '#f4f7ff' : 'rgba(215,225,245,0.5)'}
              strokeWidth={major ? 1.5 : 0.8} />;
          })}
          {speedLabels.map(spd => {
            const pt = polar(LX, CY, R - 19, 135 + gtSpeedFraction(spd) * 270);
            return <text key={spd} x={pt.x} y={pt.y + 2.5} textAnchor="middle"
              fill={spd > 250 ? '#ff6a70' : '#e6eefc'} fontSize="7.2" fontWeight="700" fontFamily="Barlow, sans-serif">{spd}</text>;
          })}
          <text x={LX} y={CY + 24} textAnchor="middle" fill="#90a2c4" fontSize="6.5" fontWeight="700" fontFamily="IBM Plex Mono, monospace">km/h</text>
          <g ref={gtSpeedNeedle} transform={`translate(${LX} ${CY}) rotate(135)`}>
            <polygon points="-9,-1.8 48,-0.7 48,0.7 -9,1.8" fill="#ff3b28" style={{ filter: 'drop-shadow(0 0 4px rgba(255,59,40,0.85))' }} />
          </g>
          <circle cx={LX} cy={CY} r="6.2" fill="url(#gtChrome)" stroke="#141821" strokeWidth="1.2" />

          {/* Right Dial: Tachometer */}
          <circle cx={RX} cy={CY} r={R + 2.5} fill="none" stroke="url(#gtChrome)" strokeWidth="3.5" />
          <circle cx={RX} cy={CY} r={R} fill="url(#gtFace)" stroke="rgba(210,222,245,0.28)" strokeWidth="1" />
          <path d={describeArc(RX, CY, R - 4, 135 + 270 * (6.8 / 8), 405)} fill="none" stroke="#e5252c" strokeWidth="3.2" strokeLinecap="round" />
          {Array.from({ length: 33 }, (_, i) => {
            const frac = i / 32;
            const deg = 135 + frac * 270;
            const major = i % 4 === 0;
            const p1 = polar(RX, CY, major ? R - 11 : R - 8, deg);
            const p2 = polar(RX, CY, R - 4.5, deg);
            return <line key={i} x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
              stroke={frac >= 6.8 / 8 ? '#ff4248' : major ? '#f4f7ff' : 'rgba(215,225,245,0.5)'}
              strokeWidth={major ? 1.5 : 0.8} />;
          })}
          {Array.from({ length: 9 }, (_, r) => {
            const pt = polar(RX, CY, R - 18.5, 135 + (r / 8) * 270);
            return <text key={r} x={pt.x} y={pt.y + 2.6} textAnchor="middle"
              fill={r >= 7 ? '#ff585e' : '#e6eefc'} fontSize="8" fontWeight="700" fontFamily="Barlow, sans-serif">{r}</text>;
          })}
          <text x={RX} y={CY + 24} textAnchor="middle" fill="#90a2c4" fontSize="6" fontWeight="700" fontFamily="IBM Plex Mono, monospace">RPM×1k</text>
          <g ref={gtRpmNeedle} transform={`translate(${RX} ${CY}) rotate(135)`}>
            <polygon points="-9,-1.8 48,-0.7 48,0.7 -9,1.8" fill="#ff3b28" style={{ filter: 'drop-shadow(0 0 4px rgba(255,59,40,0.85))' }} />
          </g>
          <circle cx={RX} cy={CY} r="6.2" fill="url(#gtChrome)" stroke="#141821" strokeWidth="1.2" />
        </svg>
      </div>
    );
  }

  return (
    <div className="nyc-speedo">
      <svg viewBox="0 0 200 120" aria-hidden="true">
        <path d="M20 110 A80 80 0 0 1 180 110" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="10" strokeLinecap="round" />
        {/* Blue NOS extension: 250 → 500 km/h */}
        <path d="M20 110 A80 80 0 0 1 180 110" fill="none" stroke="rgba(88,216,255,0.34)" strokeWidth="10" strokeLinecap="round"
          strokeDasharray={`${ARC_LENGTH / 2} ${ARC_LENGTH}`} strokeDashoffset={-ARC_LENGTH / 2} />
        <path ref={fill} d="M20 110 A80 80 0 0 1 180 110" fill="none" stroke="#ffb248" strokeWidth="10" strokeLinecap="round"
          strokeDasharray={`0 ${ARC_LENGTH}`} />
        {Array.from({ length: 11 }, (_, i) => {
          const a = (-90 + i * 18) * Math.PI / 180;
          const cos = Math.cos(a), sin = Math.sin(a);
          const major = i % 5 === 0;
          return <line key={i} x1={100 + cos * (major ? 64 : 68)} y1={110 + sin * (major ? 64 : 68)}
            x2={100 + cos * 75} y2={110 + sin * 75} stroke={major ? 'rgba(255,255,255,.8)' : 'rgba(255,255,255,.3)'}
            strokeWidth={major ? 2 : 1} />;
        })}
        {/* Natural top-speed marker (exact 250 km/h on a 500 scale = top dead centre) */}
        <line ref={baseMark} x1="100" y1="27" x2="100" y2="43" stroke="#7bf0c4" strokeWidth="2.5" strokeLinecap="round" />
        <path ref={needle} d="M100 110 L100 34" fill="none" stroke="rgba(255,255,255,0.92)" strokeWidth="2" strokeLinecap="round"
          transform="rotate(-90 100 110)" />
        <circle cx="100" cy="110" r="4" fill="#ffb248" stroke="#151821" strokeWidth="1.5" />
        <text x="32" y="104" fill="rgba(255,255,255,.5)" fontSize="7" fontFamily="IBM Plex Mono, monospace">0</text>
        <text x="159" y="104" fill="rgba(255,255,255,.55)" fontSize="7" fontFamily="IBM Plex Mono, monospace">500</text>
      </svg>
      <div className="nyc-kmh"><b ref={digits}>0</b><small>km/h</small></div>
      <div className="nyc-gear"><span ref={gear}>G1</span><i ref={rpm} style={{ width: '16%' }} /></div>
      <p className="nyc-gauge-legend"><span>BASE 250</span><i>NOS 500</i></p>
    </div>
  );
}

export default memo(LiveSpeedo);
