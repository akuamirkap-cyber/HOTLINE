import * as THREE from 'three';
import type { Track } from './trackLayout';
import { BED, RoadField } from './terrain';
import { clamp, fbm, mulberry32 } from './noise';

/* ---------- tiny helpers ---------- */
export function canvasTex(w: number, h: number, draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  draw(ctx, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

class TriBuf {
  pos: number[] = [];
  col: number[] = [];
  tri(a: number[], b: number[], c: number[], color: THREE.Color) {
    this.pos.push(a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]);
    for (let k = 0; k < 3; k++) this.col.push(color.r, color.g, color.b);
  }
  quad(a: number[], b: number[], c: number[], d: number[], color: THREE.Color) {
    this.tri(a, b, c, color);
    this.tri(a, c, d, color);
  }
  geometry() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(this.col, 3));
    g.computeVertexNormals();
    g.computeBoundingSphere();
    return g;
  }
}

export interface RoadBuild {
  group: THREE.Group;
  cutL: Uint8Array;
  cutR: Uint8Array;
  baseAsphalt: THREE.Mesh<THREE.BufferGeometry, THREE.MeshLambertMaterial>;
  shoulders: THREE.Mesh<THREE.BufferGeometry, THREE.MeshLambertMaterial>;
  markings: THREE.Mesh<THREE.BufferGeometry, THREE.MeshLambertMaterial>;
  shoulderConcrete: Uint8Array;
  guardrails: THREE.Group;
}

const col = (h: number) => new THREE.Color(h);

export function roadFrame(track: Track, i: number, lat = 0) {
  const ps = track.psi[i];
  const cs = Math.cos(ps);
  const sn = Math.sin(ps);
  return {
    x: track.x[i] + lat * cs,
    y: track.y[i],
    z: track.z[i] - lat * sn,
    f: new THREE.Vector3(sn, 0, cs),
    r: new THREE.Vector3(-cs, 0, sn),
    l: new THREE.Vector3(cs, 0, -sn),
  };
}

export function buildRoad(track: Track, field: RoadField, opts?: { skipEdgeWhiteLines?: boolean; skipLaneLines?: boolean }): RoadBuild {
  const group = new THREE.Group();
  const n = track.n;
  const STEP = 2;

  const P = (i: number, lat: number, dy: number) => {
    const ps = track.psi[i];
    return [track.x[i] + lat * Math.cos(ps), track.y[i] + dy, track.z[i] - lat * Math.sin(ps)];
  };

  /* --- which side is cut (gutter) vs drop-off (guardrail) --- */
  const cutL = new Uint8Array(n);
  const cutR = new Uint8Array(n);
  for (let i = 0; i < n; i += 4) {
    const ps = track.psi[i];
    const lx = Math.cos(ps);
    const lz = -Math.sin(ps);
    const hl = field.height(track.x[i] + lx * 13, track.z[i] + lz * 13);
    const hr = field.height(track.x[i] - lx * 13, track.z[i] - lz * 13);
    const l = hl > track.y[i] - 0.2 ? 1 : 0;
    const r = hr > track.y[i] - 0.2 ? 1 : 0;
    for (let k = 0; k < 4 && i + k < n; k++) {
      cutL[i + k] = l;
      cutR[i + k] = r;
    }
  }
  // majority filter so rails do not flicker
  const filt = (a: Uint8Array) => {
    const o = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      let s = 0;
      let c = 0;
      for (let j = -24; j <= 24; j += 4) {
        const q = clamp(i + j, 0, n - 1);
        s += a[q];
        c++;
      }
      o[i] = s * 2 >= c ? 1 : 0;
    }
    return o;
  };
  const cL = filt(cutL);
  const cR = filt(cutR);

  /* --- asphalt --- */
  const asphalt = new TriBuf();
  const aLat = [-4.6, -4.25, -1.95, -0.85, 0, 0.85, 1.95, 4.25, 4.6];
  const aDy = [0, 0.01, 0.04, 0.05, 0.05, 0.05, 0.04, 0.01, 0];
  const cBase = col(0x6a6e78);
  const cWheel = col(0x535760);
  const cEdge = col(0x7d8087);
  const cPatch = col(0x5b5f68);
  const tmp = new THREE.Color();
  const rnd = mulberry32(77);
  for (let i = 0; i + STEP < n; i += STEP) {
    const patch = fbm(i / 24, 3.3, 2);
    for (let j = 0; j < aLat.length - 1; j++) {
      const mid = Math.abs((aLat[j] + aLat[j + 1]) / 2);
      tmp.copy(cBase);
      if (mid > 4.0) tmp.copy(cEdge);
      else if (mid > 0.8 && mid < 2.1) tmp.lerp(cWheel, 0.55);
      if (patch > 0.28) tmp.lerp(cPatch, 0.7);
      const jit = 1 + (rnd() - 0.5) * 0.07;
      tmp.multiplyScalar(jit);
      asphalt.quad(P(i, aLat[j], aDy[j]), P(i + STEP, aLat[j], aDy[j]), P(i + STEP, aLat[j + 1], aDy[j + 1]), P(i, aLat[j + 1], aDy[j + 1]), tmp);
    }
  }
  const roadMat = new THREE.MeshLambertMaterial({
    vertexColors: true,
    flatShading: true,
    side: THREE.DoubleSide,
    polygonOffset: true,
    polygonOffsetFactor: -2,
    polygonOffsetUnits: -2,
  });
  const asphaltMesh = new THREE.Mesh(asphalt.geometry(), roadMat);
  asphaltMesh.receiveShadow = true;
  group.add(asphaltMesh);

  /* --- roadside: shoulders, gutter --- */
  const side = new TriBuf();
  const shoulderConcrete: number[] = [];
  const fillProf: [number, number][] = [
    [4.6, 0],
    [4.95, -0.08],
    [6.2, -0.28],
    [8.1, -BED + 0.04],
  ];
  const cutProf: [number, number][] = [
    [4.6, 0],
    [4.68, -0.04],
    [4.8, -0.32],
    [5.5, -0.32],
    [5.62, 0.0],
    [6.4, -0.12],
    [8.1, -BED + 0.04],
  ];
  const cGutIn = col(0x9ba1a4);
  const cGutBot = col(0x7a8184);
  const cLip = col(0xc2c6c6);
  const cCurb = col(0xa5a9aa);
  const cGrass = col(0x7fa14f);
  const cGrass2 = col(0x6d9345);
  const cGravel = col(0xa49a7b);
  for (let i = 0; i + STEP < n; i += STEP) {
    for (const sgn of [1, -1]) {
      const isCut = (sgn === 1 ? cL[i] : cR[i]) === 1;
      const prof = isCut ? cutProf : fillProf;
      for (let j = 0; j < prof.length - 1; j++) {
        const a = prof[j];
        const b = prof[j + 1];
        if (isCut) {
          if (j === 0) tmp.copy(cCurb);
          else if (j === 1) tmp.copy(cGutIn);
          else if (j === 2) tmp.copy(cGutBot);
          else if (j === 3) tmp.copy(cGutIn);
          else if (j === 4) tmp.copy(cLip);
          else tmp.copy(cGrass).lerp(cGravel, 0.35);
        } else {
          if (j === 0) tmp.copy(cCurb);
          else if (j === 1) tmp.copy(cGravel);
          else tmp.copy(cGrass).lerp(cGrass2, fbm(i / 15, j, 2) * 0.5 + 0.5);
        }
        tmp.multiplyScalar(1 + (rnd() - 0.5) * 0.08);
        side.quad(
          P(i, a[0] * sgn, a[1]),
          P(i + STEP, a[0] * sgn, a[1]),
          P(i + STEP, b[0] * sgn, b[1]),
          P(i, b[0] * sgn, b[1]),
          tmp
        );
        const paved = Number(isCut ? j < 5 : j === 0);
        shoulderConcrete.push(paved, paved);
      }
    }
  }
  const sideMesh = new THREE.Mesh(side.geometry(), roadMat);
  sideMesh.receiveShadow = true;
  group.add(sideMesh);

  /* --- markings --- */
  const mk = new TriBuf();
  const white = col(0xf3f0e6);
  const orange = col(0xf0a11b);
  const lift = 0.035;
  const crown = (lat: number) => 0.05 * (1 - Math.min(1, Math.abs(lat) / 4.6) ** 1.5) + 0.0;
  const lineStrip = (i: number, l0: number, l1: number, color: THREE.Color) => {
    mk.quad(
      P(i, l0, crown(l0) + lift),
      P(i + STEP, l0, crown(l0) + lift),
      P(i + STEP, l1, crown(l1) + lift),
      P(i, l1, crown(l1) + lift),
      color
    );
  };
  if (!opts?.skipLaneLines) {
    for (let i = 0; i + STEP < n; i += STEP) {
      if (!opts?.skipEdgeWhiteLines) {
        lineStrip(i, 4.02, 4.24, white);
        lineStrip(i, -4.24, -4.02, white);
      }
      // centre: solid orange (no passing) — Japanese mountain road style
      lineStrip(i, -0.09, 0.09, orange);
    }
  }
  // start line and finish line (chequered)
  const chequer = (sIdx: number) => {
    const cw = 0.6;
    for (let k = 0; k < 8; k++) {
      for (let r = 0; r < 2; r++) {
        const c = (k + r) % 2 === 0 ? white : col(0x181a1f);
        const l0 = -4.2 + k * cw * 1.75;
        const l1 = l0 + cw * 1.75;
        const i0 = sIdx + r * 1;
        mk.quad(
          P(i0, l0, crown(l0) + lift + 0.004),
          P(i0 + 1, l0, crown(l0) + lift + 0.004),
          P(i0 + 1, l1, crown(l1) + lift + 0.004),
          P(i0, l1, crown(l1) + lift + 0.004),
          c
        );
      }
    }
  };
  chequer(Math.floor(track.startS));
  chequer(Math.floor(track.finishS));
  const mkMesh = new THREE.Mesh(
    mk.geometry(),
    new THREE.MeshLambertMaterial({
      vertexColors: true,
      flatShading: true,
      side: THREE.DoubleSide,
      polygonOffset: true,
      polygonOffsetFactor: -4,
      polygonOffsetUnits: -4,
    })
  );
  mkMesh.receiveShadow = true;
  mkMesh.name = 'Haruna original start, finish and lane markings';
  group.add(mkMesh);

  /* --- guard-rails (drop-off sides) --- */
  const guardrails = new THREE.Group();
  guardrails.name = 'Haruna original guardrails';
  const rail = new TriBuf();
  const cRailTop = col(0xeef1f3);
  const cRailFace = col(0xd3d8dc);
  const cRailBack = col(0xa7adb3);
  const cRailLow = col(0xe2e5e8);
  const postXf: THREE.Matrix4[] = [];
  const reflXf: THREE.Matrix4[] = [];
  const RL = 5.38;
  for (let i = 0; i + STEP < n; i += STEP) {
    for (const sgn of [1, -1]) {
      const isCut = (sgn === 1 ? cL[i] : cR[i]) === 1;
      const nextCut = (sgn === 1 ? cL[i + STEP] : cR[i + STEP]) === 1;
      if (isCut || nextCut) continue;
      const lat = RL * sgn;
      const w = 0.16 * sgn;
      const y0 = -0.12;
      const q = (la: number, ya: number, lb: number, yb: number, c: THREE.Color) =>
        rail.quad(P(i, la, ya + y0), P(i + STEP, la, ya + y0), P(i + STEP, lb, yb + y0), P(i, lb, yb + y0), c);
      // W-beam: face, ridge, lower band, top, back
      q(lat, 0.86, lat - w * 0.5, 0.8, cRailTop);
      q(lat - w * 0.5, 0.8, lat, 0.7, cRailFace);
      q(lat, 0.7, lat - w * 0.5, 0.6, cRailLow);
      q(lat - w * 0.5, 0.6, lat, 0.5, cRailFace);
      q(lat, 0.86, lat + w * 0.3, 0.86, cRailTop);
      q(lat + w * 0.3, 0.86, lat + w * 0.3, 0.5, cRailBack);
      if (i % 4 === 0) {
        const fr = roadFrame(track, i, lat + w * 0.3);
        const m = new THREE.Matrix4().makeBasis(fr.r, new THREE.Vector3(0, 1, 0), fr.f.clone().negate());
        m.setPosition(fr.x, fr.y - 0.12 + 0.4, fr.z);
        postXf.push(m);
        if (i % 24 === 0) {
          const m2 = m.clone();
          m2.setPosition(fr.x - fr.r.x * 0.0, fr.y - 0.12 + 0.9, fr.z);
          reflXf.push(m2);
        }
      }
    }
  }
  const railMesh = new THREE.Mesh(
    rail.geometry(),
    new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true, side: THREE.DoubleSide })
  );
  railMesh.castShadow = true;
  railMesh.receiveShadow = true;
  guardrails.add(railMesh);

  const postGeo = new THREE.BoxGeometry(0.14, 1.1, 0.14);
  const posts = new THREE.InstancedMesh(postGeo, new THREE.MeshLambertMaterial({ color: 0x9aa0a6, flatShading: true }), postXf.length);
  postXf.forEach((m, k) => posts.setMatrixAt(k, m));
  posts.castShadow = true;
  guardrails.add(posts);
  const reflGeo = new THREE.BoxGeometry(0.2, 0.12, 0.05);
  const refl = new THREE.InstancedMesh(reflGeo, new THREE.MeshBasicMaterial({ color: 0xff8a1c }), reflXf.length);
  reflXf.forEach((m, k) => refl.setMatrixAt(k, m));
  guardrails.add(refl);
  group.add(guardrails);

  /* --- corner chevron signs (outer side of bends) --- */
  const mkSign = (dir: number) =>
    canvasTex(128, 128, (ctx, w, h) => {
      ctx.clearRect(0, 0, w, h);
      ctx.beginPath();
      ctx.moveTo(w / 2, 4);
      ctx.lineTo(w - 4, h / 2);
      ctx.lineTo(w / 2, h - 4);
      ctx.lineTo(4, h / 2);
      ctx.closePath();
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(w / 2, 14);
      ctx.lineTo(w - 14, h / 2);
      ctx.lineTo(w / 2, h - 14);
      ctx.lineTo(14, h / 2);
      ctx.closePath();
      ctx.fillStyle = '#f59a12';
      ctx.fill();
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.scale(dir, 1);
      ctx.lineWidth = 15;
      ctx.lineJoin = 'miter';
      ctx.lineCap = 'butt';
      ctx.strokeStyle = '#15151a';
      ctx.beginPath();
      ctx.moveTo(-14, -30);
      ctx.lineTo(14, 0);
      ctx.lineTo(-14, 30);
      ctx.stroke();
      ctx.restore();
    });
  const signGeo = new THREE.PlaneGeometry(1.45, 1.45);
  const signXfL: THREE.Matrix4[] = [];
  const signXfR: THREE.Matrix4[] = [];
  const signPost: THREE.Matrix4[] = [];
  let lastSign = -999;
  for (let i = 6; i < n - 6; i += 2) {
    const k = track.kappa[i];
    if (Math.abs(k) < 1 / 95) continue;
    if (i - lastSign < 13) continue;
    lastSign = i;
    // sign sits on the outside of the bend, facing the oncoming driver
    const outer = k > 0 ? -1 : 1; // left bend (k>0) -> outer = right side (negative lat)
    const fr = roadFrame(track, i, outer * 6.7);
    const up = new THREE.Vector3(0, 1, 0);
    const back = fr.f.clone().negate();
    const m = new THREE.Matrix4().makeBasis(fr.r, up, back);
    m.setPosition(fr.x, fr.y + 1.75, fr.z);
    (k > 0 ? signXfL : signXfR).push(m);
    const pm = new THREE.Matrix4().makeBasis(fr.r, up, back);
    pm.setPosition(fr.x, fr.y + 0.55, fr.z);
    signPost.push(pm);
  }
  const addSigns = (arr: THREE.Matrix4[], dir: number) => {
    const im = new THREE.InstancedMesh(
      signGeo,
      new THREE.MeshBasicMaterial({ map: mkSign(dir), transparent: false, alphaTest: 0.5, side: THREE.DoubleSide }),
      arr.length
    );
    arr.forEach((m, q) => im.setMatrixAt(q, m));
    im.castShadow = true;
    group.add(im);
  };
  addSigns(signXfL, -1);
  addSigns(signXfR, 1);
  const spm = new THREE.InstancedMesh(
    new THREE.BoxGeometry(0.09, 2.4, 0.09),
    new THREE.MeshLambertMaterial({ color: 0x8a8f95, flatShading: true }),
    signPost.length
  );
  signPost.forEach((m, q) => spm.setMatrixAt(q, m));
  spm.castShadow = true;
  group.add(spm);

  /* --- painted text on the asphalt --- */
  const decal = (i: number, lines: string[], arrow: boolean, size = 5.6) => {
    const tex = canvasTex(512, 768, (ctx, w, h) => {
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = 'rgba(245,243,235,0.93)';
      ctx.textAlign = 'center';
      if (arrow) {
        ctx.beginPath();
        ctx.moveTo(w / 2, 20);
        ctx.lineTo(w / 2 + 90, 170);
        ctx.lineTo(w / 2 + 34, 170);
        ctx.lineTo(w / 2 + 34, 300);
        ctx.lineTo(w / 2 - 34, 300);
        ctx.lineTo(w / 2 - 34, 170);
        ctx.lineTo(w / 2 - 90, 170);
        ctx.closePath();
        ctx.fill();
      }
      ctx.font = '900 150px "Arial Black", Impact, sans-serif';
      lines.forEach((t, k) => ctx.fillText(t, w / 2, 470 + k * 165));
    });
    const geo = new THREE.PlaneGeometry(size, size * 1.5);
    const mesh = new THREE.Mesh(
      geo,
      new THREE.MeshBasicMaterial({
        map: tex,
        transparent: true,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -6,
        polygonOffsetUnits: -6,
      })
    );
    const fr = roadFrame(track, i, -0.0);
    const m = new THREE.Matrix4().makeBasis(fr.r, fr.f, new THREE.Vector3(0, 1, 0));
    m.setPosition(fr.x, fr.y + 0.09, fr.z);
    mesh.matrixAutoUpdate = false;
    mesh.matrix.copy(m);
    mesh.renderOrder = 3;
    group.add(mesh);
    // keep the text just inside the lane (two lanes: place on driver's lane)
    return mesh;
  };
  const dMesh = decal(Math.floor(track.startS) + 44, ['AKINA', 'TOUGE'], true, 5.2);
  dMesh.position.set(0, 0, 0);
  decal(Math.floor(track.startS) + 150, ['HARUNA', '榛名山'], false, 5.2);
  const fiveIdx = Math.max(10, Math.floor(track.sections.find((s) => s.name.startsWith('FIVE'))!.s0) - 36);
  decal(fiveIdx, ['5×', 'HAIRPIN'], true, 5.0);

  /* --- gates --- */
  const mkBanner = (title: string, sub: string, checker: boolean) =>
    canvasTex(1024, 160, (ctx, w, h) => {
      ctx.fillStyle = '#16181f';
      ctx.fillRect(0, 0, w, h);
      if (checker) {
        for (let x = 0; x < w; x += 32) {
          for (let y = 0; y < 2; y++) {
            ctx.fillStyle = (x / 32 + y) % 2 ? '#ffffff' : '#16181f';
            ctx.fillRect(x, y * 16, 32, 16);
            ctx.fillRect(x, h - 32 + y * 16, 32, 16);
          }
        }
      }
      ctx.fillStyle = '#f59a12';
      ctx.fillRect(0, 36, w, 6);
      ctx.fillRect(0, h - 44, w, 6);
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffffff';
      ctx.font = '900 62px "Arial Black", Impact, sans-serif';
      ctx.fillText(title, w / 2, 100);
      ctx.fillStyle = '#f59a12';
      ctx.font = '700 26px Arial, sans-serif';
      ctx.fillText(sub, w / 2, 134);
    });
  const buildGate = (i: number, title: string, sub: string, checker: boolean) => {
    const g = new THREE.Group();
    g.name = checker ? 'Haruna original finish gate' : 'Haruna original start gate';
    const steel = new THREE.MeshLambertMaterial({ color: 0xc8ccd2, flatShading: true });
    const dark = new THREE.MeshLambertMaterial({ color: 0x2b2e36, flatShading: true });
    const span = 7.4;
    for (const s of [-1, 1]) {
      const p = new THREE.Mesh(new THREE.BoxGeometry(0.4, 6.6, 0.4), steel);
      p.position.set(s * span, 3.1, 0);
      p.castShadow = true;
      g.add(p);
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.5, 0.9), dark);
      b.position.set(s * span, -0.1, 0);
      g.add(b);
    }
    const beam = new THREE.Mesh(new THREE.BoxGeometry(span * 2 + 0.6, 0.45, 0.45), steel);
    beam.position.set(0, 6.3, 0);
    beam.castShadow = true;
    g.add(beam);
    const banner = new THREE.Mesh(
      new THREE.PlaneGeometry(span * 2 - 0.4, 1.9),
      new THREE.MeshBasicMaterial({ map: mkBanner(title, sub, checker), side: THREE.DoubleSide })
    );
    banner.position.set(0, 5.1, 0.05);
    g.add(banner);
    const fr = roadFrame(track, i, 0);
    const m = new THREE.Matrix4().makeBasis(fr.r, new THREE.Vector3(0, 1, 0), fr.f.clone().negate());
    m.setPosition(fr.x, fr.y, fr.z);
    g.applyMatrix4(m);
    group.add(g);
  };
  buildGate(Math.floor(track.startS), '榛名山 HARUNA TOUGE', 'DOWNHILL TIME ATTACK · START', false);
  buildGate(Math.floor(track.finishS), 'FINISH', 'AKINA FOOT · 麓', true);

  return { group, cutL: cL, cutR: cR, baseAsphalt: asphaltMesh, shoulders: sideMesh, markings: mkMesh,
    shoulderConcrete: Uint8Array.from(shoulderConcrete), guardrails };
}
