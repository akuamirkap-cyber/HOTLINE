import * as THREE from 'three';
import type { V2TextureSet } from './textures';
import { barkMaterial, foliageMaterial } from './materials';
import {
  makeConifer, makeMaple, makeBeech, makeSapling, makeSasa, makeShrub, makeFern, type TreeAsset,
} from './trees';

export interface MatPair {
  mat: THREE.Material;
  depth: THREE.Material;
}

export interface AssetDef {
  id: string;
  name: string;
  latin: string;
  category: 'Pohon Konifer' | 'Pohon Daun Lebar' | 'Semak & Tanaman Bawah';
  make: (seed: number) => TreeAsset;
  bark?: MatPair;
  leaf: MatPair;
  variants: number;
}

export function createLibrary(tex: V2TextureSet) {
  const cedarBark = barkMaterial(tex.barkCedar.map, tex.barkCedar.normal, 0.00028);
  (cedarBark.mat as THREE.MeshStandardMaterial).color.set('#86766c');
  const cypressBark = barkMaterial(tex.barkCedar.map, tex.barkCedar.normal, 0.0003);
  (cypressBark.mat as THREE.MeshStandardMaterial).color.set('#a08c7e');
  const poleBark = barkMaterial(tex.barkCedar.map, tex.barkCedar.normal, 0.00026);
  (poleBark.mat as THREE.MeshStandardMaterial).color.set('#665a52');
  const broadBark = barkMaterial(tex.barkBroad.map, tex.barkBroad.normal, 0.0012);
  const mapleBark = barkMaterial(tex.barkBroad.map, tex.barkBroad.normal, 0.002);
  (mapleBark.mat as THREE.MeshStandardMaterial).color.set('#8c8478');
  const saplingBark = barkMaterial(tex.barkBroad.map, tex.barkBroad.normal, 0.006);
  (saplingBark.mat as THREE.MeshStandardMaterial).color.set('#9a8d76');

  const cedarLeaf = foliageMaterial(tex.cedar, { bend: 0.00028, flutter: 0.012, transl: 0.55, color: '#e6eedc' });
  const poleLeaf = foliageMaterial(tex.cedar, { bend: 0.00026, flutter: 0.012, transl: 0.5, color: '#d2dec8' });
  const cypressLeaf = foliageMaterial(tex.cypress, { bend: 0.0003, flutter: 0.014, transl: 0.65 });
  const mapleLeaf = foliageMaterial(tex.maple, { bend: 0.002, flutter: 0.03, transl: 1.9, color: '#f4ffd6' });
  const beechLeaf = foliageMaterial(tex.beech, { bend: 0.0012, flutter: 0.03, transl: 1.6, color: '#eefcd2' });
  const saplingLeaf = foliageMaterial(tex.maple, { bend: 0.006, flutter: 0.035, transl: 1.9, color: '#f6ffd0' });
  const sasaLeaf = foliageMaterial(tex.sasa, { bend: 0.03, flutter: 0.02, transl: 0.85 });
  const shrubLeaf = foliageMaterial(tex.shrub, { bend: 0.02, flutter: 0.02, transl: 0.8 });
  const fernLeaf = foliageMaterial(tex.fern, { bend: 0.05, flutter: 0.02, transl: 1.0 });

  const defs: AssetDef[] = [
    {
      id: 'cedar', name: 'Sugi — Japanese Cedar', latin: 'Cryptomeria japonica', category: 'Pohon Konifer',
      make: (s) => makeConifer(s, 'cedar'), bark: cedarBark, leaf: cedarLeaf, variants: 3,
    },
    {
      id: 'pole', name: 'Sugi Plantation Pole', latin: 'Cryptomeria japonica', category: 'Pohon Konifer',
      make: (s) => makeConifer(s, 'pole'), bark: poleBark, leaf: poleLeaf, variants: 2,
    },
    {
      id: 'cypress', name: 'Hinoki Cypress', latin: 'Chamaecyparis obtusa', category: 'Pohon Konifer',
      make: (s) => makeConifer(s, 'cypress'), bark: cypressBark, leaf: cypressLeaf, variants: 2,
    },
    {
      id: 'maple', name: 'Momiji — Japanese Maple', latin: 'Acer palmatum', category: 'Pohon Daun Lebar',
      make: makeMaple, bark: mapleBark, leaf: mapleLeaf, variants: 2,
    },
    {
      id: 'beech', name: 'Buna / Konara', latin: 'Fagus crenata / Quercus serrata', category: 'Pohon Daun Lebar',
      make: makeBeech, bark: broadBark, leaf: beechLeaf, variants: 2,
    },
    {
      id: 'sapling', name: 'Young Broadleaf', latin: 'Acer sp.', category: 'Pohon Daun Lebar',
      make: makeSapling, bark: saplingBark, leaf: saplingLeaf, variants: 2,
    },
    {
      id: 'sasa', name: 'Kumazasa Bamboo Grass', latin: 'Sasa veitchii', category: 'Semak & Tanaman Bawah',
      make: makeSasa, leaf: sasaLeaf, variants: 2,
    },
    {
      id: 'shrub', name: 'Broadleaf Shrub', latin: 'Aucuba / Pieris sp.', category: 'Semak & Tanaman Bawah',
      make: makeShrub, leaf: shrubLeaf, variants: 2,
    },
    {
      id: 'fern', name: 'Forest Fern', latin: 'Dryopteris sp.', category: 'Semak & Tanaman Bawah',
      make: makeFern, leaf: fernLeaf, variants: 2,
    },
  ];
  return defs;
}
