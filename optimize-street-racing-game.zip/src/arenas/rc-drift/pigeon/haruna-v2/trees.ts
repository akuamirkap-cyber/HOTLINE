import * as THREE from 'three';
import { mulberry32, rand, type RNG, clamp, smoothstep } from './noise';

const V = THREE.Vector3;
type V3 = THREE.Vector3;

class GeoBuilder {
  pos: number[] = [];
  nor: number[] = [];
  uv: number[] = [];
  ao: number[] = [];
  idx: number[] = [];
  get count() {
    return this.pos.length / 3;
  }
  v(p: V3, n: V3, u: number, w: number, ao = 1) {
    this.pos.push(p.x, p.y, p.z);
    this.nor.push(n.x, n.y, n.z);
    this.uv.push(u, w);
    this.ao.push(ao);
    return this.count - 1;
  }
  build() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.pos, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.nor, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    g.setAttribute('aAO', new THREE.Float32BufferAttribute(this.ao, 1));
    g.setIndex(this.idx);
    g.computeBoundingSphere();
    g.computeBoundingBox();
    return g;
  }
}

interface TubeOpts {
  radial: number;
  texH: number;
  uRep: number;
  flare?: number;
  ao?: (p: V3, t: number) => number;
}
function tube(b: GeoBuilder, pts: V3[], radii: number[], o: TubeOpts) {
  const n = pts.length;
  const T: V3[] = [], N: V3[] = [], B: V3[] = [];
  for (let i = 0; i < n; i++) {
    const a = pts[Math.max(0, i - 1)], c = pts[Math.min(n - 1, i + 1)];
    T.push(new V().subVectors(c, a).normalize());
  }
  let n0 = Math.abs(T[0].y) < 0.9 ? new V(0, 1, 0) : new V(1, 0, 0);
  n0 = new V().crossVectors(T[0], n0).normalize();
  for (let i = 0; i < n; i++) {
    if (i > 0) n0 = n0.clone().sub(T[i].clone().multiplyScalar(n0.dot(T[i]))).normalize();
    N.push(n0.clone());
    B.push(new V().crossVectors(T[i], n0).normalize());
  }
  let dist = 0;
  const start = b.count;
  const phase = pts[0].x * 13.1;
  for (let i = 0; i < n; i++) {
    if (i > 0) dist += pts[i].distanceTo(pts[i - 1]);
    const t = i / (n - 1);
    for (let j = 0; j <= o.radial; j++) {
      const a = (j / o.radial) * Math.PI * 2;
      const dir = new V().addScaledVector(N[i], Math.cos(a)).addScaledVector(B[i], Math.sin(a));
      let r = radii[i];
      if (o.flare) {
        const f = Math.exp(-dist / 0.9) * o.flare;
        r *= 1 + f * (0.5 + 0.5 * Math.max(0, Math.cos(a * 4 + phase)));
      }
      r *= 1 + 0.035 * Math.sin(a * 5 + dist * 2.3);
      const p = pts[i].clone().addScaledVector(dir, r);
      const ao = o.ao ? o.ao(p, t) : 1;
      b.v(p, dir, (j / o.radial) * o.uRep, dist / o.texH, ao);
    }
  }
  const row = o.radial + 1;
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < o.radial; j++) {
      const a = start + i * row + j, c = a + row;
      b.idx.push(a, c, a + 1, a + 1, c, c + 1);
    }
  }
}

function bentPath(r: RNG, start: V3, dir: V3, len: number, segs: number, gravity: number, wiggle: number) {
  const pts = [start.clone()];
  const d = dir.clone().normalize();
  const p = start.clone();
  for (let i = 1; i <= segs; i++) {
    d.y += gravity / segs;
    d.x += rand(r, -wiggle, wiggle);
    d.z += rand(r, -wiggle, wiggle);
    d.normalize();
    p.addScaledVector(d, len / segs);
    pts.push(p.clone());
  }
  return pts;
}

function card(b: GeoBuilder, base: V3, dir: V3, side: V3, h: number, w: number, droop: number) {
  const s = b.count;
  const rows = 3;
  for (let i = 0; i < rows; i++) {
    const t = i / (rows - 1);
    const c = base.clone().addScaledVector(dir, h * t);
    c.y -= droop * t * t * h;
    for (let k = 0; k < 2; k++) {
      const p = c.clone().addScaledVector(side, (k - 0.5) * w * (0.75 + 0.25 * t));
      b.v(p, new V(0, 1, 0), k, t, 1);
    }
  }
  for (let i = 0; i < rows - 1; i++) {
    const a = s + i * 2;
    b.idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
  }
}

function randomPerp(r: RNG, d: V3) {
  const a = new V(rand(r, -1, 1), rand(r, -1, 1), rand(r, -1, 1));
  return a.cross(d).normalize();
}

function finalizeLeaves(b: GeoBuilder, center: (p: V3) => V3, scale: V3, radius: number, up = 0.45, aoMin = 0.35) {
  const p = new V(), n = new V();
  let minY = Infinity, maxY = -Infinity;
  for (let i = 1; i < b.pos.length; i += 3) {
    minY = Math.min(minY, b.pos[i]);
    maxY = Math.max(maxY, b.pos[i]);
  }
  for (let i = 0; i < b.count; i++) {
    p.set(b.pos[i * 3], b.pos[i * 3 + 1], b.pos[i * 3 + 2]);
    const c = center(p);
    n.subVectors(p, c).divide(scale);
    const d = n.length() / radius;
    n.normalize();
    n.y += up;
    n.normalize();
    b.nor[i * 3] = n.x;
    b.nor[i * 3 + 1] = n.y;
    b.nor[i * 3 + 2] = n.z;
    const hy = (p.y - minY) / Math.max(0.01, maxY - minY);
    const ao = (aoMin + (1 - aoMin) * smoothstep(0.15, 1.0, d)) * (0.72 + 0.28 * hy);
    b.ao[i] = clamp(ao, 0.15, 1);
  }
}

export interface TreeAsset {
  bark?: THREE.BufferGeometry;
  leaves: THREE.BufferGeometry;
  height: number;
}

// ---------- SUGI / HINOKI (conifers) ----------
export function makeConifer(seed: number, kind: 'cedar' | 'cypress' | 'pole'): TreeAsset {
  const r = mulberry32(seed);
  const bark = new GeoBuilder(), leaves = new GeoBuilder();
  const H = kind === 'cedar' ? rand(r, 22, 29) : kind === 'pole' ? rand(r, 24, 31) : rand(r, 17, 23);
  const rBase = kind === 'pole' ? rand(r, 0.16, 0.22) : kind === 'cedar' ? rand(r, 0.26, 0.36) : rand(r, 0.24, 0.32);
  const crownStart = kind === 'pole' ? rand(r, 0.68, 0.76) : kind === 'cedar' ? rand(r, 0.5, 0.6) : rand(r, 0.4, 0.5);
  const lean = new V(rand(r, -1, 1), 0, rand(r, -1, 1)).normalize().multiplyScalar(rand(r, 0, 0.025));
  const segs = 26;
  const axis: V3[] = [];
  const radii: number[] = [];
  const wph = rand(r, 0, 6);
  for (let i = 0; i <= segs; i++) {
    const t = i / segs;
    const y = -0.6 + t * (H + 0.6);
    axis.push(new V(lean.x * y + Math.sin(t * 5 + wph) * 0.05, y, lean.z * y + Math.cos(t * 4 + wph) * 0.05));
    radii.push(rBase * Math.pow(1 - t, 0.85) + 0.015);
  }
  const axisAt = (y: number) => {
    const t = clamp((y + 0.6) / (H + 0.6), 0, 1) * segs;
    const i = Math.min(segs - 1, Math.floor(t));
    return axis[i].clone().lerp(axis[i + 1], t - i);
  };
  tube(bark, axis, radii, {
    radial: 12, texH: 2.6, uRep: 2, flare: 0.75,
    ao: (p) => 0.55 + 0.45 * smoothstep(-0.5, 2.5, p.y),
  });
  const stubs = kind === 'pole' ? 26 : 16;
  for (let k = 0; k < stubs; k++) {
    const y = rand(r, 2.5, crownStart * H);
    const a = rand(r, 0, Math.PI * 2);
    const t = (y + 0.6) / (H + 0.6);
    const rr = rBase * Math.pow(1 - t, 0.85);
    const d = new V(Math.cos(a), rand(r, -0.5, 0.1), Math.sin(a)).normalize();
    const s = axisAt(y).addScaledVector(d, rr * 0.7);
    const pts = bentPath(r, s, d, rand(r, 0.25, 1.1), 2, -0.2, 0.1);
    tube(bark, pts, [0.035, 0.022, 0.008], { radial: 4, texH: 2.6, uRep: 0.5 });
  }
  const maxL = kind === 'pole' ? rand(r, 1.4, 2.0) : kind === 'cedar' ? rand(r, 2.4, 3.2) : rand(r, 2.6, 3.4);
  const step = kind === 'cypress' ? 0.38 : 0.45;
  let az = rand(r, 0, 6.28);
  const cardH = kind === 'cypress' ? 2.1 : kind === 'pole' ? 1.8 : 2.0;
  for (let y = crownStart * H; y < H - 0.4; y += step * rand(r, 0.7, 1.3)) {
    const t = (y - crownStart * H) / (H - crownStart * H);
    const whorl = kind === 'cypress' ? 3 : 2 + Math.floor(r() * 2);
    for (let w = 0; w < whorl; w++) {
      az += 2.39996 + rand(r, -0.3, 0.3);
      const prof = kind === 'cypress' ? Math.pow(1 - t, 0.7) * (0.75 + 0.25 * Math.sin(Math.PI * Math.min(1, t * 1.6))) : Math.pow(1 - t, 0.9);
      const L = maxL * prof * rand(r, 0.7, 1.15) + 0.25;
      const pitch = kind === 'cypress' ? rand(r, -0.25, 0.1) + t * 0.5 : rand(r, -0.35, 0.05) + t * 0.7;
      const d = new V(Math.cos(az) * Math.cos(pitch), Math.sin(pitch), Math.sin(az) * Math.cos(pitch)).normalize();
      const st = axisAt(y);
      const pts = bentPath(r, st, d, L, 4, kind === 'cypress' ? -0.15 : -0.25, 0.06);
      tube(bark, pts, [0.05 * (1 - t * 0.6), 0.03, 0.018, 0.01, 0.005], { radial: 4, texH: 2.6, uRep: 0.5 });
      const n = Math.max(3, Math.ceil(L / 0.38) + 2);
      for (let k = 0; k < n; k++) {
        const f = 0.3 + 0.7 * (k / Math.max(1, n - 1));
        const idx = Math.min(pts.length - 2, Math.floor(f * (pts.length - 1)));
        const base = pts[idx].clone().lerp(pts[idx + 1], f * (pts.length - 1) - idx);
        const bd = new V().subVectors(pts[idx + 1], pts[idx]).normalize();
        const cd = bd.clone().add(new V(rand(r, -0.6, 0.6), rand(r, -0.1, 0.7), rand(r, -0.6, 0.6))).normalize();
        const side = randomPerp(r, cd);
        side.y *= 0.4;
        side.normalize();
        const h = cardH * rand(r, 0.7, 1.15) * (0.55 + 0.45 * prof);
        card(leaves, base.addScaledVector(cd, -h * 0.25), cd, side, h, h * 0.95, kind === 'cypress' ? 0.18 : 0.25);
      }
    }
  }
  const top = axisAt(H);
  for (let k = 0; k < 9; k++) {
    const cd = new V(rand(r, -0.35, 0.35), 1, rand(r, -0.35, 0.35)).normalize();
    const h = rand(r, 0.9, 1.4);
    card(leaves, top.clone().add(new V(0, -h * 0.9, 0)), cd, randomPerp(r, cd), h, h * 0.8, 0.05);
  }
  const crownR = maxL + 0.6;
  finalizeLeaves(leaves, (p) => axisAt(p.y - 1.5), new V(1, 1, 1), crownR, 0.45, 0.32);
  return { bark: bark.build(), leaves: leaves.build(), height: H };
}

// ---------- BROADLEAF (recursive) ----------
interface BroadParams {
  H: number;
  trunkR: number;
  trunkFrac: number;
  leaders: number;
  levels: number;
  children: [number, number];
  spread: number;
  gravity: number;
  lenRatio: number;
  cardsPerTip: number;
  cardSize: [number, number];
  horizontal: number;
  barkTexH: number;
}

export function makeBroadleaf(seed: number, P: BroadParams): TreeAsset {
  const r = mulberry32(seed);
  const bark = new GeoBuilder(), leaves = new GeoBuilder();
  const tips: { p: V3; d: V3; s: number }[] = [];

  const grow = (start: V3, dir: V3, len: number, rad: number, level: number) => {
    const segs = level === 0 ? 10 : Math.max(3, 7 - level * 2);
    const pts = bentPath(r, start, dir, len, segs, P.gravity * (level === 0 ? 0.2 : 1), level === 0 ? 0.03 : 0.12);
    const radii = pts.map((_, i) => rad * (1 - (i / segs) * 0.55) + 0.006);
    tube(bark, pts, radii, {
      radial: level === 0 ? 12 : level === 1 ? 7 : 5,
      texH: P.barkTexH, uRep: level === 0 ? 2 : 1,
      flare: level === 0 && start.y < 0 ? 0.55 : 0,
      ao: (p) => 0.6 + 0.4 * smoothstep(-0.4, 3, p.y),
    });
    if (level === P.levels - 1) tips.push({ p: pts[pts.length - 1], d: dir.clone(), s: 0.6 });
    if (level >= P.levels) {
      tips.push({ p: pts[pts.length - 1], d: new V().subVectors(pts[pts.length - 1], pts[pts.length - 2]).normalize(), s: 1 });
      tips.push({ p: pts[Math.floor(pts.length * 0.55)], d: dir.clone(), s: 0.8 });
      return;
    }
    const nc = Math.floor(rand(r, P.children[0], P.children[1] + 1));
    for (let c = 0; c < nc; c++) {
      const f = level === 0 ? 1 - c * 0.08 * rand(r, 0, 1) : rand(r, 0.35, 1);
      const idx = Math.min(pts.length - 1, Math.round(f * (pts.length - 1)));
      const d = new V().subVectors(pts[Math.min(pts.length - 1, idx)], pts[Math.max(0, idx - 1)]).normalize();
      const az = (c / nc) * Math.PI * 2 + rand(r, -0.5, 0.5);
      const perp = randomPerp(r, d);
      const q = new THREE.Quaternion().setFromAxisAngle(d, az);
      perp.applyQuaternion(q);
      const nd = d.clone().multiplyScalar(Math.cos(P.spread)).addScaledVector(perp, Math.sin(P.spread * rand(r, 0.8, 1.2))).normalize();
      grow(pts[idx], nd, len * P.lenRatio * rand(r, 0.8, 1.15), rad * 0.55, level + 1);
    }
  };

  const lean = new V(rand(r, -0.08, 0.08), 1, rand(r, -0.08, 0.08)).normalize();
  const trunkLen = P.H * P.trunkFrac;
  const tpts = bentPath(r, new V(0, -0.5, 0), lean, trunkLen + 0.5, 8, 0, 0.03);
  tube(bark, tpts, tpts.map((_, i) => P.trunkR * (1 - (i / 8) * 0.3)), {
    radial: 12, texH: P.barkTexH, uRep: 2, flare: 0.6,
    ao: (p) => 0.55 + 0.45 * smoothstep(-0.4, 3, p.y),
  });
  const forkP = tpts[tpts.length - 1];
  const leaderLen = (P.H - trunkLen) * 0.55;
  for (let l = 0; l < P.leaders; l++) {
    const az = (l / P.leaders) * Math.PI * 2 + rand(r, -0.4, 0.4);
    const out = P.leaders === 1 ? 0.08 : rand(r, 0.35, 0.6);
    const d = new V(Math.cos(az) * out, 1, Math.sin(az) * out).normalize();
    grow(forkP, d, leaderLen * rand(r, 0.85, 1.1), P.trunkR * (P.leaders === 1 ? 0.8 : 0.6), 1);
  }

  for (const tp of tips) {
    for (let k = 0; k < P.cardsPerTip * tp.s; k++) {
      let cd = tp.d.clone().add(new V(rand(r, -0.9, 0.9), rand(r, -0.3, 0.9), rand(r, -0.9, 0.9))).normalize();
      let side = randomPerp(r, cd);
      if (P.horizontal > 0) {
        const hd = new V(cd.x, cd.y * (1 - P.horizontal), cd.z).normalize();
        cd = hd;
        side = new V(-cd.z, 0, cd.x).normalize();
        side.y = rand(r, -0.4, 0.4) * (1 - P.horizontal * 0.6);
        side.normalize();
      }
      const h = rand(r, P.cardSize[0], P.cardSize[1]);
      card(leaves, tp.p.clone().addScaledVector(cd, -h * 0.3), cd, side, h, h, 0.15);
    }
  }
  const bb = new THREE.Box3();
  for (const t of tips) bb.expandByPoint(t.p);
  const c = bb.getCenter(new V());
  const sz = bb.getSize(new V());
  const sc = new V(Math.max(1, sz.x / 2), Math.max(1, sz.y / 2), Math.max(1, sz.z / 2));
  finalizeLeaves(leaves, () => c, sc, 1.15, 0.5, 0.3);
  return { bark: bark.build(), leaves: leaves.build(), height: P.H };
}

export const makeMaple = (seed: number) => {
  const r = mulberry32(seed * 7 + 1);
  return makeBroadleaf(seed, {
    H: rand(r, 8, 11.5), trunkR: rand(r, 0.16, 0.22), trunkFrac: rand(r, 0.15, 0.25), leaders: 3 + Math.floor(r() * 2),
    levels: 3, children: [2, 3], spread: 0.75, gravity: -0.05, lenRatio: 0.62,
    cardsPerTip: 9, cardSize: [1.7, 2.5], horizontal: 0.55, barkTexH: 2,
  });
};
export const makeBeech = (seed: number) => {
  const r = mulberry32(seed * 7 + 2);
  return makeBroadleaf(seed, {
    H: rand(r, 14, 19), trunkR: rand(r, 0.24, 0.32), trunkFrac: rand(r, 0.38, 0.5), leaders: 2 + Math.floor(r() * 2),
    levels: 3, children: [2, 4], spread: 0.6, gravity: 0.12, lenRatio: 0.6,
    cardsPerTip: 9, cardSize: [2.0, 2.8], horizontal: 0.15, barkTexH: 3,
  });
};
export const makeSapling = (seed: number) => {
  const r = mulberry32(seed * 7 + 3);
  return makeBroadleaf(seed, {
    H: rand(r, 4, 6.5), trunkR: rand(r, 0.05, 0.08), trunkFrac: rand(r, 0.3, 0.45), leaders: 1,
    levels: 2, children: [3, 4], spread: 0.85, gravity: 0.0, lenRatio: 0.6,
    cardsPerTip: 6, cardSize: [1.0, 1.5], horizontal: 0.35, barkTexH: 1.5,
  });
};

// ---------- BUSHES ----------
export function makeSasa(seed: number): TreeAsset {
  const r = mulberry32(seed);
  const b = new GeoBuilder();
  const n = 18;
  for (let i = 0; i < n; i++) {
    const a = rand(r, 0, Math.PI * 2), d = Math.sqrt(r()) * 0.8;
    const base = new V(Math.cos(a) * d, -0.05, Math.sin(a) * d);
    const cd = new V(Math.cos(a) * rand(r, 0.2, 0.7), 1, Math.sin(a) * rand(r, 0.2, 0.7)).normalize();
    const h = rand(r, 0.9, 1.5);
    card(b, base, cd, randomPerp(r, cd), h, h, 0.2);
  }
  finalizeLeaves(b, () => new V(0, 0.1, 0), new V(1, 0.9, 1), 1.1, 0.8, 0.4);
  return { leaves: b.build(), height: 1.4 };
}
export function makeShrub(seed: number): TreeAsset {
  const r = mulberry32(seed);
  const b = new GeoBuilder();
  const R = rand(r, 0.8, 1.2);
  for (let i = 0; i < 46; i++) {
    const u = rand(r, 0, Math.PI * 2), v = Math.acos(rand(r, -0.2, 1));
    const n = new V(Math.sin(v) * Math.cos(u), Math.cos(v), Math.sin(v) * Math.sin(u));
    const c = new V(0, R * 0.75, 0).addScaledVector(n, R * rand(r, 0.5, 0.95));
    const side = randomPerp(r, n);
    const up = new V().crossVectors(n, side).normalize();
    const s = rand(r, 0.7, 1.1);
    card(b, c.clone().addScaledVector(up, -s / 2), up, side, s, s, 0.05);
  }
  finalizeLeaves(b, () => new V(0, R * 0.7, 0), new V(1, 0.85, 1), R, 0.4, 0.3);
  return { leaves: b.build(), height: R * 1.6 };
}
export function makeFern(seed: number): TreeAsset {
  const r = mulberry32(seed);
  const b = new GeoBuilder();
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2 + rand(r, -0.3, 0.3);
    const cd = new V(Math.cos(a), rand(r, 0.5, 1.1), Math.sin(a)).normalize();
    const side = new V(-Math.sin(a), 0, Math.cos(a));
    const h = rand(r, 0.8, 1.2);
    card(b, new V(0, -0.02, 0), cd, side, h, h * 0.8, 0.55);
  }
  finalizeLeaves(b, () => new V(0, -0.2, 0), new V(1, 1, 1), 1, 0.9, 0.45);
  return { leaves: b.build(), height: 0.8 };
}

// ---------- GRASS TUFT ----------
export function makeGrassTuft(): THREE.BufferGeometry {
  const b = new GeoBuilder();
  for (let k = 0; k < 3; k++) {
    const a = (k / 3) * Math.PI;
    const side = new V(Math.cos(a), 0, Math.sin(a));
    const s = b.count;
    const w = 0.7, h = 0.55;
    for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) {
      const p = side.clone().multiplyScalar((j - 0.5) * w);
      p.y = i * h;
      b.v(p, new V(0, 1, 0), j, i, 0.55 + i * 0.45);
    }
    b.idx.push(s, s + 2, s + 1, s + 1, s + 2, s + 3);
  }
  return b.build();
}
