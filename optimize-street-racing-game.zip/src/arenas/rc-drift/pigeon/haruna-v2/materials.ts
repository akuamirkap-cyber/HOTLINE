import * as THREE from 'three';
import type { V2TextureSet } from './textures';

export const globalUniforms = {
  uTime: { value: 0 },
  uWind: { value: 1 },
  uTransl: { value: 1 },
};

interface WindOpts {
  bend: number;
  flutter: number;
  grass?: boolean;
  transl?: number;
  ao?: boolean;
}

const RE_LINE = 'RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );';

function windVertex(o: WindOpts) {
  return /* glsl */ `
    #include <begin_vertex>
    {
      vec3 instOrigin = vec3(0.0);
      #ifdef USE_INSTANCING
        instOrigin = instanceMatrix[3].xyz;
      #endif
      vec4 wo = modelMatrix * vec4(instOrigin, 1.0);
      float ph = dot(wo.xz, vec2(0.11, 0.073));
      float gust = 0.65 + 0.35 * sin(uTime * 0.31 + wo.x * 0.02) * sin(uTime * 0.17 + wo.z * 0.015);
      ${o.grass
        ? `float hgt = uv.y * uv.y;
           vec2 sway = vec2(sin(uTime * 1.6 + ph * 3.0 + wo.x * 0.4), cos(uTime * 1.3 + ph * 2.0 + wo.z * 0.4)) * 0.12 * hgt;
           transformed.xz += sway * uWind * gust;`
        : `float hgt = max(position.y, 0.0);
           float bend = hgt * hgt * ${o.bend.toFixed(6)};
           vec2 sway = vec2(sin(uTime * 0.9 + ph) + 0.4 * sin(uTime * 2.1 + ph * 2.3), cos(uTime * 0.7 + ph * 1.3)) * bend;
           transformed.xz += sway * uWind * gust;`}
      ${o.flutter > 0
        ? `float fl = sin(uTime * 7.0 + dot(position, vec3(2.1, 1.7, 2.9)) + ph * 4.0) * ${o.flutter.toFixed(4)};
           transformed += normal * fl * uWind * gust * (0.5 + 0.5 * sin(uTime*1.3 + position.x));`
        : ''}
    }
  `;
}

export function patchMaterial<T extends THREE.Material>(mat: T, o: WindOpts, extraUniforms?: Record<string, THREE.IUniform>) {
  const useAO = o.ao !== false;
  mat.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, globalUniforms, extraUniforms || {});
    shader.vertexShader =
      `uniform float uTime;\nuniform float uWind;\n${useAO ? 'attribute float aAO;\nvarying float vAO;\n' : ''}` +
      shader.vertexShader.replace('#include <begin_vertex>', windVertex(o) + (useAO ? '\nvAO = aAO;\n' : ''));
    if (shader.fragmentShader.includes('#include <map_fragment>')) {
      shader.fragmentShader =
        `uniform float uTransl;\n${useAO ? 'varying float vAO;\n' : ''}` +
        shader.fragmentShader.replace(
          '#include <map_fragment>',
          `#include <map_fragment>\n${useAO ? 'diffuseColor.rgb *= vAO;' : ''}`,
        );
      if (o.transl && o.transl > 0) {
        shader.fragmentShader = shader.fragmentShader.split(RE_LINE).join(
          `${RE_LINE}
          {
            float backL = saturate(-dot(geometryViewDir, directLight.direction));
            float tr = pow(backL, 4.0) * 1.6 + 0.35 * saturate(dot(-geometryNormal, directLight.direction)) + 0.08;
            reflectedLight.directDiffuse += directLight.color * diffuseColor.rgb * tr * uTransl * ${o.transl.toFixed(3)};
          }`,
        );
      }
    }
  };
  mat.customProgramCacheKey = () => `v2wind-${o.bend}-${o.flutter}-${o.grass ? 1 : 0}-${o.transl || 0}-${useAO}`;
  return mat;
}

export function foliageMaterial(map: THREE.Texture, o: { bend: number; flutter: number; transl: number; color?: THREE.ColorRepresentation; rough?: number }) {
  const m = new THREE.MeshStandardMaterial({
    map,
    color: o.color ?? 0xffffff,
    alphaTest: 0.42,
    side: THREE.DoubleSide,
    roughness: o.rough ?? 0.72,
    metalness: 0,
    alphaToCoverage: true,
    envMapIntensity: 0.55,
  });
  patchMaterial(m, { bend: o.bend, flutter: o.flutter, transl: o.transl });
  const depth = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map, alphaTest: 0.42, side: THREE.DoubleSide });
  patchMaterial(depth, { bend: o.bend, flutter: o.flutter, ao: false });
  return { mat: m, depth };
}

export function barkMaterial(map: THREE.Texture, normal: THREE.Texture, bend: number) {
  const m = new THREE.MeshStandardMaterial({
    map,
    normalMap: normal,
    normalScale: new THREE.Vector2(1.4, 1.4),
    roughness: 0.93,
    metalness: 0,
    envMapIntensity: 0.4,
  });
  patchMaterial(m, { bend, flutter: 0 });
  const depth = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking });
  patchMaterial(depth, { bend, flutter: 0, ao: false });
  return { mat: m, depth };
}

export function grassMaterial(map: THREE.Texture) {
  const m = new THREE.MeshStandardMaterial({
    map,
    alphaTest: 0.4,
    side: THREE.DoubleSide,
    roughness: 0.8,
    alphaToCoverage: true,
    envMapIntensity: 0.5,
  });
  patchMaterial(m, { bend: 0, flutter: 0, grass: true, transl: 0.8, ao: true });
  return m;
}

export function createGroundMaterial(tex: V2TextureSet, opts?: { farSkyline?: boolean; doubleSide?: boolean }) {
  const farSkyline = Boolean(opts?.farSkyline);
  const tMat = new THREE.MeshStandardMaterial({
    map: tex.litter.map,
    normalMap: tex.litter.normal,
    normalScale: new THREE.Vector2(1.3, 1.3),
    roughness: 0.96,
    envMapIntensity: 0.35,
    color: '#c8b8a6',
    side: opts?.doubleSide ? THREE.DoubleSide : THREE.FrontSide,
  });
  tMat.onBeforeCompile = (sh) => {
    sh.uniforms.mossMap = { value: tex.moss.map };
    sh.uniforms.mossNormal = { value: tex.moss.normal };
    sh.vertexShader = 'attribute float aMoss;\nattribute float aAO;\nvarying float vMoss;\nvarying float vAO;\nvarying vec3 vWp;\n' +
      sh.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvMoss = aMoss; vAO = aAO; vWp = (modelMatrix * vec4(position,1.0)).xyz;');
    let frag = 'uniform sampler2D mossMap;\nuniform sampler2D mossNormal;\nvarying float vMoss;\nvarying float vAO;\nvarying vec3 vWp;\n' +
      sh.fragmentShader
        .replace('#include <map_fragment>', `
          vec4 cL = texture2D(map, vMapUv);
          vec4 cL2 = texture2D(map, vMapUv * 0.27 + 0.31);
          vec4 cM = texture2D(mossMap, vMapUv * 0.8);
          float breakup = texture2D(mossMap, vWp.xz * 0.013).g;
          float m = smoothstep(0.25, 0.75, vMoss + (breakup - 0.22) * 1.6);
          vec4 lit = mix(cL, cL2, 0.35);
          diffuseColor *= mix(lit, cM, m);
          diffuseColor.rgb *= vAO;
        `)
        .replace('#include <normal_fragment_maps>', `
          vec3 mapN = mix(texture2D(normalMap, vNormalMapUv).xyz, texture2D(mossNormal, vNormalMapUv * 0.8).xyz, m) * 2.0 - 1.0;
          mapN.xy *= normalScale;
          normal = normalize(tbn * mapN);
        `);
    if (farSkyline) {
      frag = frag.replace('#include <fog_fragment>', `
        #ifdef USE_FOG
          #ifdef FOG_EXP2
            float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
          #else
            float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
          #endif
          fogFactor = min(fogFactor, 0.84);
          gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
        #endif
      `);
    }
    sh.fragmentShader = frag;
  };
  tMat.customProgramCacheKey = () => `v2ground-${farSkyline ? 1 : 0}-${opts?.doubleSide ? 1 : 0}`;
  return tMat;
}
