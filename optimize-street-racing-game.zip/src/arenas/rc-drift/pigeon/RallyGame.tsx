import './index.css';
import PigeonApp from './App';

/** Rally Group B Lab: Group B car body, wheels, cockpit, garage & volumetric 3D smoke — driven 100% by 3D Car Drift Simulator physics. */
export default function RallyGame({ onExit, initialMode }: { onExit: () => void; initialMode?: 'drive' | 'garage' }) {
  return (
    <div className="fixed inset-0 overflow-hidden">
      <PigeonApp onExit={onExit} initialMode={initialMode} />
    </div>
  );
}
