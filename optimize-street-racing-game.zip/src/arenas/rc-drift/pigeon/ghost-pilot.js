const limit=(n,min,max)=>Math.max(min,Math.min(max,n));
const wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));
const yaw=frame=>Math.atan2(frame.tx,frame.tz);

export const pilotStep=1/30;
const paceLimits={lateral:8.1,topSpeed:27.2,braking:5.2,steer:3.25,damp:.37,slip:1.82,look:.61,brakeGain:.34};

export function createPacePilot(track) {
  const point=track.at(0),before=track.at(0),after=track.at(0);
  const rounds=Array.from({length:Math.ceil(track.length)+2},(_,i)=>{
    const turn=wrap(yaw(track.at(track.start+i+4.8,after))-yaw(track.at(track.start+i-4.8,before)));
    return Math.abs(turn)/9.6;
  });
  return function pace(run, leg={}) {
    const state=run.state, d=run.progress, remains=(leg.until??track.length)-d;
    const projection=limit(state.speed*paceLimits.look,4.6,16.4);
    // Set up on the outside, then brake against the tightest curve in the next 44 metres.
    const lead=track.at(track.start+d+projection,point), offset=(leg.offset??0)*limit(1-(remains-projection)/(leg.width??22),0,1);
    const aim=Math.atan2(lead.x+lead.tz*offset-state.x,lead.z-lead.tx*offset-state.z);
    const error=wrap(aim-state.yaw),steer=limit(error*paceLimits.steer-state.yawRate*paceLimits.damp+state.beta*paceLimits.slip,-1,1);
    let target=leg.pace??paceLimits.topSpeed;
    for(const ahead of [2,7,12,21,32,44]) {
      const marker=((d+ahead)%track.length+track.length)%track.length;
      const curvature=rounds[Math.floor(marker)];
      target=Math.min(target,Math.sqrt(paceLimits.lateral/(.0025+curvature)+2*paceLimits.braking*ahead));
    }
    if(leg.entry!==undefined)target=Math.min(target,Math.sqrt(leg.entry**2+2*paceLimits.braking*Math.max(0,remains-2.6)));
    if(Math.abs(error)>.55)target=Math.min(target,Math.max(6.6,14-Math.abs(error)*7.4));
    const difference=target-state.speed;
    const gas=limit(.16+difference*.24,0,Math.abs(steer)>.65?.75:1);
    const brake=state.speed>3?limit((-difference-.39)*paceLimits.brakeGain,0,.95):0;
    return {steer,gas:brake>0?0:gas,brake,handbrake:false,assist:false};
  };
}

export function createGhostPilot(track, plan) {
  const pace=createPacePilot(track);
  let at=0,age=0;
  return function command(run) {
    while(at<plan.length) {
      const leg=plan[at];
      if('until' in leg) {
        if(run.progress<leg.until) return pace(run,leg);
      } else if(age<Math.round(leg.seconds/pilotStep)) {
        age++;
        // The planner chooses manoeuvres; steering, throttle and brake still go through the tyre model.
        return {steer:leg.steer??0,gas:leg.gas??0,brake:leg.brake??0,handbrake:leg.handbrake??false,assist:leg.assist??true};
      }
      at++;age=0;
    }
    return pace(run);
  };
}