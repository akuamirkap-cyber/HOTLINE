import * as T from 'three';
import { DEFAULT_ATMOSPHERE, DEFAULT_LIGHTING, SKY_THEMES, type AtmosphereState, type LightingMood, type LightingState, type MountainLook } from '../drive-lighting';
import type { PigeonAssets } from './assets';
import type { MountainSpec } from './route';
import { createSunAtmosphere } from './sun-atmosphere';
import type { GroundAt } from './suspension';

const SUN_DIR = new T.Vector3(0.22, 1, 0.16).normalize();
const DARK_SUN = new T.Vector3(-0.38, 0.81, -0.19).normalize();
const palettes = {
  day:   { zenith: 0xbcd3e2, horizon: 0xeef1e6, background: 0xe3e9de, fog: 0xd6e0cf, hemi: 0xdfeadf, ground: 0x52623a, sun: 0xfff0d2, halo: 0xfff2cc, h: 2.0, d: 3.4, a: 0.35, skyGlow: 1 },
  rain:  { zenith: 0x6e7c84, horizon: 0xaab5b8, background: 0xaab5b8, fog: 0x9da9a8, hemi: 0xd4e2e5, ground: 0x4b5046, sun: 0xc9dbef, halo: 0xc9dbef, h: 1.85, d: 0.72, a: 0.28, skyGlow: 0.12 },
  night: { zenith: 0x101d33, horizon: 0x283340, background: 0x283340, fog: 0x202d39, hemi: 0x829dc0, ground: 0x333f31, sun: 0xb6cdf7, halo: 0xb6cdf7, h: 0.95, d: 0.62, a: 0.15, skyGlow: 0.17 },
} as const;
// Pencahayaan V2 Alami — technically-grounded daylight rig modelled on the reference drift photo:
// warm high sun (≈5500K), blue-sky zenith with warm haze horizon, green bounce from sunlit grass,
// slightly deeper contrast, soft contact shadows. Rain/night inherit the base rig.
const v2Palettes = {
  day:   { zenith: 0x6ea9dc, horizon: 0xe9e9d8, background: 0xdde3d2, fog: 0xd3dfca, hemi: 0xc2deec, ground: 0x5d7038, sun: 0xffe8b8, halo: 0xffe9ac, h: 2.15, d: 3.55, a: 0.38, skyGlow: 1.5 },
  rain:  { zenith: 0x6a7880, horizon: 0xa9b4b6, background: 0xa9b4b6, fog: 0x99a5a4, hemi: 0xd0dfe2, ground: 0x47503f, sun: 0xc6d9ec, halo: 0xc6d9ec, h: 1.95, d: 0.78, a: 0.28, skyGlow: 0.14 },
  night: { zenith: 0x0e1b30, horizon: 0x27313f, background: 0x27313f, fog: 0x1f2b37, hemi: 0x7e9abb, ground: 0x2f3b2d, sun: 0xb2cbf5, halo: 0xb2cbf5, h: 0.98, d: 0.66, a: 0.15, skyGlow: 0.18 },
} as const;

export function createPigeonLighting(scene: T.Scene, spec: MountainSpec, groundAt: GroundAt, renderer: T.WebGLRenderer, assets: PigeonAssets, shadowResolution?: number) {
  let state = { ...DEFAULT_LIGHTING };
  let atmosphere: AtmosphereState = { ...DEFAULT_ATMOSPHERE };
  let mood: LightingMood = 'day';
  let look: MountainLook = 'pigeon';
  const sunDirection = SUN_DIR.clone();
  const ambient = new T.AmbientLight(0x9db394);
  const hemi = new T.HemisphereLight();
  const dir = new T.DirectionalLight();
  dir.castShadow = true;
  const extent = 55;
  const size = Math.min(renderer.capabilities.maxTextureSize, shadowResolution ?? 2048);
  dir.shadow.mapSize.set(size, size);
  const c = dir.shadow.camera;
  Object.assign(c, { left: -extent, right: extent, top: extent, bottom: -extent, near: 10, far: 220 });
  c.updateProjectionMatrix();
  dir.shadow.bias = -0.00025;
  dir.shadow.normalBias = 0.03;
  dir.shadow.radius = 3;
  scene.add(hemi, ambient, dir, dir.target);

  const background = new T.Color(0xe3e9de);
  const fog = new T.Fog(0xd6e0cf, 58, 300);
  scene.background = background;
  scene.fog = fog;
  const uniforms = { sunDir: { value: sunDirection }, zenith: { value: new T.Color() },
    horizon: { value: new T.Color() }, sunCol: { value: new T.Color() }, gain: { value: 1 } };
  const dome = new T.Mesh(new T.SphereGeometry(300, 32, 16), new T.ShaderMaterial({
    side: T.BackSide, depthWrite: false, fog: false, uniforms,
    vertexShader: `varying vec3 vDir; void main() { vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
    fragmentShader: `
      uniform vec3 sunDir, zenith, horizon, sunCol; uniform float gain; varying vec3 vDir;
      void main() {
        float h = clamp(vDir.y, 0.0, 1.0);
        vec3 col = mix(horizon, zenith, pow(h, 0.55));
        float s = max(dot(normalize(vDir), sunDir), 0.0);
         col += sunCol * (pow(s, 6.0) * 0.55 + pow(s, 60.0) * 1.6) * gain;
        gl_FragColor = vec4(col, 1.0);
      }`,
  }));
  dome.name = 'PIGEON gradient sky';
  dome.renderOrder = -10;
  dome.frustumCulled = false;
  scene.add(dome);

  const atmosphereRef = createSunAtmosphere(spec, groundAt, assets, SUN_DIR);
  scene.add(atmosphereRef.group);

  const last = new T.Vector3(Infinity, Infinity, Infinity);
  let lastYaw = Infinity;
  let lastUpdate = -Infinity;

  function sync() {
    const p = look === 'v2' ? v2Palettes[mood] : palettes[mood];
    const theme = mood === 'day' ? SKY_THEMES[atmosphere.skyTheme] : null;
    const fill = state.hemiOn ? state.hemi / 100 : 0;
    const direct = state.dirOn ? state.dir / 100 : 0;
    const shadowWasActive = dir.intensity > 0 && dir.shadow.intensity > 0;
    const nextDirection = mood === 'night' ? DARK_SUN : SUN_DIR;
    if (!sunDirection.equals(nextDirection) || (!shadowWasActive && direct > 0 && state.shadow > 0)) last.x = Infinity;
    hemi.color.set(p.hemi); hemi.groundColor.set(p.ground); hemi.intensity = p.h * fill;
    ambient.intensity = p.a * fill;
    dir.color.set(p.sun); dir.intensity = p.d * direct;
    dir.shadow.intensity = state.shadow / 100;
    sunDirection.copy(nextDirection);
    background.set(theme ? theme.background : p.background);
    fog.color.set(theme ? theme.fog : p.fog);
    // Tebal & jarak kabut (FOG linear): tebal = kepekatan, jarak = batas jarak pandang.
    const far = T.MathUtils.clamp(atmosphere.fogDistance, 80, 10000) * (mood === 'rain' ? 0.72 : 1);
    fog.far = far;
    fog.near = Math.max(15, far * (1 - atmosphere.fogThickness / 100) ** 2);
    uniforms.zenith.value.set(theme ? theme.zenith : p.zenith);
    uniforms.horizon.value.set(theme ? theme.horizon : p.horizon);
    uniforms.sunCol.value.set(p.halo);
    uniforms.gain.value = p.skyGlow * direct;
    atmosphereRef.setStrength(mood === 'day' ? direct : 0);
  }

  function update(car: T.Vector3, view: T.Vector3, yaw: number, now: number, seconds: number) {
    dome.position.copy(view);
    atmosphereRef.update(car, seconds);
    if (last.x === Infinity || (now - lastUpdate >= (size < 2048 ? 70 : 28) && (last.distanceToSquared(car) > 0.085 || Math.abs(yaw - lastYaw) > 0.07))) {
      last.copy(car);
      lastYaw = yaw;
      lastUpdate = now;
      dir.target.position.copy(car);
      dir.position.copy(dir.target.position).addScaledVector(sunDirection, 90);
      if (!dir.shadow.map || (dir.shadow.intensity > 0 && dir.intensity > 0)) renderer.shadowMap.needsUpdate = true;
    }
  }

  sync();
  return {
    scene, hemi, dir, dome, background, fog, sunDirection, update,
    get state() { return state; },
    get mood() { return mood; },
    get hasDaylightAtmosphere() { return atmosphereRef.group.visible; },
    get sunGain() { return state.dirOn ? state.dir / 100 * (look === 'v2' ? v2Palettes[mood] : palettes[mood]).skyGlow : 0; },
    get look() { return look; },
    get atmosphereState() { return { ...atmosphere }; },
    setMood(next: LightingMood) { mood = next; sync(); },
    setLook(next: MountainLook) {
      look = next;
      // Soft, natural contact shadows under the car (like the reference photo) instead of hard CG edges.
      dir.shadow.radius = next === 'v2' ? 5 : 3;
      dir.shadow.bias = next === 'v2' ? -0.00018 : -0.00025;
      dir.shadow.normalBias = next === 'v2' ? 0.055 : 0.03;
      last.x = Infinity; // force the shadow volume to re-anchor on the next update
      sync();
    },
    apply(next: Partial<LightingState>) {
      state = { ...state, ...next };
      for (const key of ['hemi', 'dir', 'shadow'] as const) state[key] = T.MathUtils.clamp(state[key], 0, 100);
      sync();
      return state;
    },
    applyAtmosphere(next: Partial<AtmosphereState>) {
      const theme = next.skyTheme === 'lightsky' || next.skyTheme === 'cloudy' ? next.skyTheme : 'normal';
      atmosphere = {
        fogThickness: T.MathUtils.clamp(next.fogThickness ?? atmosphere.fogThickness, 0, 100),
        fogDistance: T.MathUtils.clamp(next.fogDistance ?? atmosphere.fogDistance, 80, 10000),
        skyTheme: theme,
      };
      sync();
      return { ...atmosphere };
    },
  };
}