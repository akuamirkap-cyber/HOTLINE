import type { DriverInput } from '../drift-physics.js';
import { CAR_SCALE, createDriftCar } from '../rmx-drift-adapter';

export const enum GroundKind { Void, Asphalt, Gutter, Earth }
export type Ground = { y: number; kind: GroundKind };
export type GroundAt = (x: number, z: number, out?: Ground) => Ground;

const GRAVITY = 9.81;
const WHEELBASE = (1.665 + 1.433) * CAR_SCALE;
const AXLE_WIDTH = 2 * 1.038 * CAR_SCALE;
const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));

export function createMountainCar(groundAt: GroundAt) {
  const wheelGround: Ground = { y: 0, kind: GroundKind.Void };
  const center: Ground = { y: 0, kind: GroundKind.Void };
  const drive = createDriftCar((x, z) => {
    const { y, kind } = groundAt(x, z, wheelGround);
    const roughness = kind === GroundKind.Asphalt ? 0 : kind === GroundKind.Gutter ? 0.22 : 0.68;
    return { worldY: y, height: 0, roughness, grip: 1 - roughness * 0.47 };
  }, { isolated: false, touge: true });
  const { state } = drive;
  const wheels = [state.wheels.FL, state.wheels.FR, state.wheels.RL, state.wheels.RR];
  // The adapter replaces wheel objects only on construction; reset keeps their identity.
  const pose = { y: 0, pitch: 0, roll: 0, grounded: true, vy: 0, kind: GroundKind.Asphalt, impact: 0 };
  const support = { y: 0, pitch: 0, roll: 0, forwardSlope: 0, sideSlope: 0, contact: 0, earthy: 0 };

  function sampleSupport() {
    groundAt(state.x, state.z, center);
    let count = 0, high = -Infinity, earth = 0;
    for (const w of wheels) {
      const g = groundAt(w.x, w.z, wheelGround);
      w.worldY = g.y;
      if (g.kind !== GroundKind.Void) { count++; high = Math.max(high, g.y); }
      if (g.kind === GroundKind.Earth) earth++;
    }
    const fl = wheels[0].worldY!, fr = wheels[1].worldY!, rl = wheels[2].worldY!, rr = wheels[3].worldY!;
    const front = (fl + fr) * 0.5, rear = (rl + rr) * 0.5;
    // Model +X is the left side. Limit chassis rotation, not the grade used by gravity.
    const lateral = (wheels[0].side * (fl - fr) + wheels[2].side * (rl - rr)) * 0.5;
    support.y = count === 4 ? Math.max((front + rear) * 0.5, center.y - 0.12) : high;
    support.forwardSlope = count === 4 ? clamp((front - rear) / WHEELBASE, -1.6, 1.6) : 0;
    support.sideSlope = count === 4 ? clamp(lateral / AXLE_WIDTH, -1.6, 1.6) : 0;
    support.pitch = -Math.atan(clamp(support.forwardSlope, -1.2, 1.2));
    support.roll = Math.atan(clamp(support.sideSlope, -1.0, 1.0));
    support.contact = count;
    support.earthy = earth / 4;
  }

  function reset(x: number, z: number, yaw: number) {
    drive.reset(x, z, yaw);
    drive.refresh();
    sampleSupport();
    Object.assign(pose, { y: support.y, pitch: support.pitch, roll: support.roll, grounded: true, vy: 0, kind: center.kind, impact: 0 });
  }

  function step(dt: number, input: DriverInput) {
    pose.impact = Math.max(0, pose.impact - dt * 6);
    if (pose.grounded) {
      // Project gravity onto the ground plane so throttle must overcome uphill grade.
      const f = support.forwardSlope, r = support.sideSlope;
      const grade = Math.hypot(f, r);
      const stationary = state.speed < 0.16 && !input.gas && (grade < 0.26 || input.brake || input.handbrake);
      drive.step(dt, input);
      if (!stationary) {
        const factor = -GRAVITY * dt / (1 + grade * grade);
        const s = Math.sin(state.yaw), c = Math.cos(state.yaw);
        state.vx += (s * f + c * r) * factor;
        state.vz += (c * f - s * r) * factor;
      }
      if (support.earthy > 0) {
        const drag = Math.exp(-dt * support.earthy * (0.21 + state.speed * 0.024));
        state.vx *= drag; state.vz *= drag;
      }
    } else {
      // No steering, braking or drive force acts on the chassis while the wheels are clear.
      state.x += state.vx * dt;
      state.z += state.vz * dt;
      state.yaw += state.yawRate * dt;
      state.yawRate *= Math.exp(-dt * 1.2);
      state.throttle = Number(input.gas) || 0;
      state.rearSlip = 0;
      state.tireNoise = 0;
    }
    drive.refresh();
    sampleSupport();

    const ballistic = pose.y + (pose.vy - GRAVITY * dt * 0.5) * dt;
    const haveSupport = support.contact >= 2;
    const wasGrounded = pose.grounded;
    const ballisticGap = ballistic - support.y;
    const springExtending = wasGrounded && state.speed > 3 && ballisticGap > 0.022;
    if (haveSupport && springExtending && ballisticGap < 0.19) {
      // The wheels can extend briefly over a crest. At full droop the chassis goes ballistic.
      pose.y = ballistic;
      pose.vy -= GRAVITY * dt;
      pose.pitch = support.pitch;
      pose.roll = support.roll;
    } else if (haveSupport && (wasGrounded ? !springExtending : ballisticGap <= 0.036)) {
      if (!wasGrounded) {
        pose.impact = clamp(Math.abs(pose.vy) * 0.21, 0, 2.4);
        const loss = clamp(1 - Math.abs(pose.vy) * 0.033, 0.48, 0.92);
        state.vx *= loss; state.vz *= loss;
        drive.refresh();
      }
      pose.vy = wasGrounded ? clamp((support.y - pose.y) / dt, -5.5, 9) : 0;
      pose.y = support.y;
      pose.pitch = support.pitch;
      pose.roll = support.roll;
      pose.grounded = true;
    } else {
      pose.grounded = false;
      pose.y = ballistic;
      pose.vy -= GRAVITY * dt;
      const pitch = clamp(-Math.atan2(pose.vy, Math.max(7, state.speed)) * 0.46, -0.36, 0.55);
      pose.pitch += (pitch - pose.pitch) * (1 - Math.exp(-dt * 4));
      pose.roll *= Math.exp(-dt * 1.1);
    }
    pose.kind = center.kind;
  }

  return { state, pose, reset, step, setFeintMode: drive.setFeintMode };
}