import * as T from 'three';
import { buildLake } from '../../../haruna-downhill/game/terrain';
import { createPigeonAssets, type PigeonAssets } from './assets';
import { buildPigeonForest } from './forest';
import { buildArchivedHarunaRoad } from './haruna-road';
import { createRoadContact, type RoadContact } from './road-contact';
import { makeHarunaFarGrid, makeReliefGrid, retainHarunaSkyline, type ReliefGrid } from './haruna-relief';
import { smoothstep, lerp } from './noise';
import { GroundKind, type GroundAt } from './suspension';
import type { Frame, MountainSpec, pigeonRoute } from './route';

export function buildMountainWorld(scene: T.Scene, spec: MountainSpec, assets = createPigeonAssets(), opts: { foliageShadows?: boolean } = {}) {
  const { route, bounds, cell } = spec;
  const edge = route.half + route.gutter;
  const haruna = spec.id === 'haruna';
  const { forestFloor, realisticGrass, asphalt } = assets;
  const floor = haruna
    ? new T.MeshStandardMaterial({ map: realisticGrass, bumpMap: realisticGrass, bumpScale: 0.05, vertexColors: true, roughness: 0.92, color: 0xffffff })
    : new T.MeshStandardMaterial({ map: forestFloor, vertexColors: true, roughness: 1, color: 0xd1c8b4 });
  const pavement = new T.MeshStandardMaterial({ map: asphalt.map, roughnessMap: asphalt.roughness, bumpMap: asphalt.bump,
    bumpScale: 0.016, color: 0xdcdad6, roughness: 1 });
  const concrete = new T.MeshStandardMaterial({ map: assets.concrete, roughness: 0.95, color: 0xd6d1c7 });
  const nearGrid = makeReliefGrid(bounds, cell, (x, z) => {
    if (haruna) return spec.terrain(x, z);
    const q = route.nearest(x, z);
    const recess = 1.5 * (1 - smoothstep(edge + 2.2, spec.corridor - 2.2, q.dist));
    return spec.terrain(x, z, q) - recess;
  }, haruna);
  const farGrid = haruna ? makeHarunaFarGrid(bounds) : null;
  if (haruna) retainHarunaSkyline(floor);

  const tint = new T.Color();
  function soilColor(x: number, z: number, slope = 0) {
    const n = 0.5 + 0.26 * Math.sin(x * 0.081 + z * 0.123) + 0.21 * Math.cos(z * 0.29 - x * 0.13);
    return tint.setRGB(lerp(0.57 + n * 0.19, 0.84, slope), lerp(0.73 + n * 0.24, 0.67, slope), lerp(0.44 + n * 0.15, 0.42, slope));
  }
  // Mt. Haruna meadow tint — bright multipliers over the new grass albedo:
  // broad lush↔dry sweeps, dark clover clumps, packed earth on steep cuts.
  function grassTint(x: number, z: number, slope = 0) {
    const meadow = 0.5 + 0.30 * Math.sin(x * 0.021 + z * 0.033 + 1.7) + 0.20 * Math.sin(x * 0.047 - z * 0.028 + 0.4) + 0.18 * Math.cos(z * 0.09 + x * 0.017);
    const clump = 0.5 + 0.5 * Math.sin(x * 0.16 + z * 0.13) * Math.cos(z * 0.21 - x * 0.11);
    const dry = smoothstep(0.56, 0.92, meadow + 0.22 * clump);
    const deep = smoothstep(0.55, 0.95, 1 - meadow);
    let r = lerp(lerp(0.80, 0.55, deep), 1.14, dry);
    let g = lerp(lerp(1.03, 0.80, deep), 1.04, dry);
    let b = lerp(lerp(0.64, 0.48, deep), 0.60, dry);
    const dirt = smoothstep(0.5, 1.05, slope);
    r = lerp(r, 1.02, dirt); g = lerp(g, 0.82, dirt); b = lerp(b, 0.60, dirt);
    const jitter = 0.93 + 0.14 * (0.5 + 0.5 * Math.sin(x * 1.7 + z * 2.3));
    return tint.setRGB(r * jitter, g * jitter, b * jitter);
  }
  const groundTint = haruna ? grassTint : soilColor;

  // Chunks of 128 m keep terrain culling while halving the draw-call count.
  const groundGroup = renderRelief(nearGrid, 128 / cell, floor, groundTint, true, haruna ? 1 / 6.4 : 1 / 9);
  groundGroup.name = haruna ? 'Mt. Haruna original hills (4 m) — realistic meadow grass' : 'PIGEON terrain (shared render and collision grid)';
  scene.add(groundGroup);
  if (farGrid) {
    const distant = renderRelief(farGrid, 16, floor, groundTint, false, 1 / 13);
    distant.name = 'Mt. Haruna original mountain ranges (48 m)';
    const lake = buildLake();
    lake.name = 'Mt. Haruna caldera lake';
    scene.add(distant, lake);
  }

  const contact = createRoadContact();
  const archivedRoad = spec.id === 'haruna' ? buildArchivedHarunaRoad(spec, contact, pavement, concrete, floor) : null;
  if (archivedRoad) scene.add(archivedRoad.group);
  else if (spec.id === 'pigeon') scene.add(buildPigeonRoad(spec, nearGrid, contact, pavement, concrete, floor, soilColor));

  const scratch = { y: 0, kind: GroundKind.Void };
  // Probe the same relief, paved surfaces and shoulders used for rendering.
  const groundAt: GroundAt = (x, z, out = scratch) => {
    out.y = Math.max(nearGrid.heightAt(x, z), farGrid?.heightAt(x, z) ?? -Infinity);
    out.kind = Number.isFinite(out.y) ? GroundKind.Earth : GroundKind.Void;
    contact.sample(x, z, out);
    if (out.kind === GroundKind.Void) out.y = -200;
    return out;
  };

  const forest = buildPigeonForest(spec, groundAt, assets, opts.foliageShadows ?? true);
  scene.add(forest.group);
  if (!archivedRoad) scene.add(roadSigns(spec, groundAt, assets));
  return { groundAt, tick: forest.tick, setOpenTerrain(enabled: boolean) {
    if (archivedRoad) archivedRoad.guardrails.visible = !enabled;
  } };
}

function buildPigeonRoad(spec: ReturnType<typeof pigeonRoute>, nearGrid: ReliefGrid, contact: RoadContact,
  pavement: T.Material, concrete: T.Material, floor: T.Material, soilColor: (x: number, z: number, slope: number) => T.Color) {
  const { route, corridor } = spec;
  const { half, gutter } = route;
  const edge = half + gutter;
  const inner = [-half, -half * 0.56, 0, half * 0.56, half];
  const shoulder = [0.25, 0.85, 1.65, 2.8, 4.4, 6.0, 8.4].map(d => edge + d).filter(d => d < corridor - 0.35);
  const stations = [-corridor, ...shoulder.slice().reverse().map(d => -d), -edge, -half - gutter * 0.48,
    ...inner, half + gutter * 0.48, edge, ...shoulder, corridor];
  const cols = stations.length;
  const numRows = route.rows.length;
  const vertices = new Float64Array(numRows * cols * 3);
  const kinds: GroundKind[] = stations.slice(1).map((offset, j) => {
    const mid = Math.abs((offset + stations[j]) * 0.5);
    return mid < half ? GroundKind.Asphalt : mid < edge ? GroundKind.Gutter : GroundKind.Earth;
  });
  const materials = { [GroundKind.Asphalt]: pavement, [GroundKind.Gutter]: concrete, [GroundKind.Earth]: floor };
  const ribbonGroup = new T.Group();
  ribbonGroup.name = 'PIGEON asphalt, concrete and embankment';

  function position(f: Frame, lane: number) {
    const x = f.x - f.tz * lane, z = f.z + f.tx * lane;
    const d = Math.abs(lane);
    let y = f.y - half * 0.012;
    if (d <= half) y = f.y - d * 0.012;
    else if (d < edge - 0.01) y -= 0.036 * Math.sin(Math.PI * (d - half) / gutter);
    else if (d > edge) {
      const side = d - edge;
      const base = nearGrid.heightAt(x, z);
      const cover = lerp(y, spec.terrain(x, z), smoothstep(0, 0.85, side));
      y = Number.isFinite(base) ? lerp(cover, base - 0.015, smoothstep(corridor - 2.8, corridor, d)) : cover;
    }
    return [x, y, z] as const;
  }

  route.rows.forEach((row, i) => stations.forEach((lane, j) => vertices.set(position(row, lane), (i * cols + j) * 3)));
  const intervals = [GroundKind.Asphalt, GroundKind.Gutter, GroundKind.Earth] as const;
  for (let start = 0; start < numRows - 1; start += 66) {
    const last = Math.min(start + 66, numRows - 1);
    for (const kind of intervals) {
      const positions: number[] = [], uv: number[] = [], colors: number[] = [], indices: number[] = [];
      // Adjacent bands share their vertices, so normals follow the crown instead of showing seams.
      const shared = new Map<string, number>();
      function vertex(i: number, j: number, gutterSide: number) {
        const ref = `${i * cols + j}:${gutterSide}`;
        const found = shared.get(ref);
        if (found !== undefined) return found;
        const offset = (i * cols + j) * 3, s = positions.length / 3;
        const x = vertices[offset], y = vertices[offset + 1], z = vertices[offset + 2], lane = stations[j];
        positions.push(x, y, z);
        if (kind === GroundKind.Asphalt) uv.push((lane + half) / (2 * half), route.rows[i].s / (route.loop ? route.length / Math.round(route.length / 7) : 7));
        else if (kind === GroundKind.Gutter) uv.push((Math.abs(lane) - half) / gutter, route.rows[i].s / 4);
        else {
          const c = soilColor(x, z, 0.14 + 0.25 * Math.max(0, Math.sin(x * 0.17 - z * 0.24)));
          colors.push(c.r, c.g, c.b);
          uv.push(x / 9, z / 9);
        }
        shared.set(ref, s);
        return s;
      }
      for (let i = start; i < last; i++) {
        for (let j = 0; j < cols - 1; j++) {
          if (kinds[j] !== kind) continue;
          const side = kind === GroundKind.Gutter ? Math.sign(stations[j]) : 0;
          const a = vertex(i, j, side), b = vertex(i + 1, j, side), c = vertex(i, j + 1, side), d = vertex(i + 1, j + 1, side);
          indices.push(a, c, b, c, d, b);
        }
      }
      const mesh = addMesh(ribbonGroup, materials[kind], positions, uv, indices, colors);
      contact.add(mesh, kind);
    }
  }
  return ribbonGroup;
}

function renderRelief(grid: ReliefGrid, stride: number, material: T.Material,
  soilColor: (x: number, z: number, slope: number) => T.Color, shadow: boolean, uvScale = 1 / 9) {
  const { bounds, cell, nx, nz, width, heights } = grid;
  const group = new T.Group();
  for (let iz = 0; iz < nz; iz += stride) for (let ix = 0; ix < nx; ix += stride) {
    const w = Math.min(stride, nx - ix), h = Math.min(stride, nz - iz);
    const positions: number[] = [], colors: number[] = [], uv: number[] = [], indices: number[] = [];
    for (let z = 0; z <= h; z++) for (let x = 0; x <= w; x++) {
      const gx = ix + x, gz = iz + z, index = gx + gz * width;
      const wx = bounds.x0 + gx * cell, wz = bounds.z0 + gz * cell, y = heights[index];
      const slope = Math.hypot((heights[index + (gx < nx ? 1 : -1)] - y) / cell, (heights[index + (gz < nz ? width : -width)] - y) / cell);
      const c = soilColor(wx, wz, smoothstep(0.35, 1.15, slope));
      positions.push(wx, y, wz); colors.push(c.r, c.g, c.b); uv.push(wx * uvScale, wz * uvScale);
      if (x < w && z < h && grid.filled(gx, gz)) {
        const a = x + z * (w + 1), b = a + w + 1;
        if (grid.alternate(gx, gz)) indices.push(a, b, b + 1, a, b + 1, a + 1);
        else indices.push(a, b, a + 1, a + 1, b, b + 1);
      }
    }
    if (indices.length) addMesh(group, material, positions, uv, indices, colors, shadow);
  }
  return group;
}

function addMesh(parent: T.Group, mat: T.Material, p: number[], uv: number[], idx: number[], color: number[], shadow = true) {
  const geo = new T.BufferGeometry();
  geo.setAttribute('position', new T.Float32BufferAttribute(p, 3));
  geo.setAttribute('uv', new T.Float32BufferAttribute(uv, 2));
  if (color.length) geo.setAttribute('color', new T.Float32BufferAttribute(color, 3));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  const mesh = new T.Mesh(geo, mat);
  mesh.receiveShadow = shadow;
  parent.add(mesh);
  return mesh;
}

function roadSigns(spec: MountainSpec, groundAt: GroundAt, assets: PigeonAssets) {
  const group = new T.Group();
  const route = spec.route;
  const sign = new T.MeshStandardMaterial({ map: assets.sign, roughness: 0.68 });
  const pipe = new T.MeshStandardMaterial({ color: 0x8e9690, roughness: 0.64, metalness: 0.35 });
  const poleGeo = new T.CylinderGeometry(0.038, 0.043, 1.95, 8);
  const faceGeo = new T.PlaneGeometry(0.63, 0.63);
  let next = spec.start + 12;
  for (let s = next; s < route.length - 18; s += 6) {
    if (s < next || Math.abs(route.at(s + 19).curv) < 0.012) continue;
    next = s + 57;
    const f = route.at(s), off = route.half + route.gutter + 1.25;
    const x = f.x - f.tz * off, z = f.z + f.tx * off;
    const { y } = groundAt(x, z);
    const pole = new T.Mesh(poleGeo, pipe);
    pole.position.set(x, y + 0.95, z); pole.castShadow = true;
    const plate = new T.Mesh(faceGeo, sign);
    plate.position.set(x - f.tx * 0.055, y + 1.92, z - f.tz * 0.055);
    plate.rotation.order = 'YXZ'; plate.rotation.set(0, Math.atan2(-f.tx, -f.tz), Math.PI * 0.25);
    plate.receiveShadow = true;
    group.add(pole, plate);
  }

  const lineCount = Math.floor(route.length / 12);
  const post = new T.InstancedMesh(new T.BoxGeometry(0.105, 0.72, 0.13), new T.MeshStandardMaterial({ color: 0xd4d5c6, roughness: 0.86 }), lineCount);
  const reflector = new T.InstancedMesh(new T.BoxGeometry(0.108, 0.14, 0.137), new T.MeshStandardMaterial({ color: 0xe1a446, roughness: 0.53 }), lineCount);
  const dummy = new T.Object3D();
  for (let i = 0; i < lineCount; i++) {
    const f = route.at(i * 12 + 4), off = route.half + route.gutter + 0.62;
    const x = f.x + f.tz * off, z = f.z - f.tx * off, { y } = groundAt(x, z);
    dummy.position.set(x, y + 0.34, z);
    dummy.rotation.y = Math.atan2(f.tx, f.tz); dummy.updateMatrix(); post.setMatrixAt(i, dummy.matrix);
    dummy.position.y += 0.26; dummy.updateMatrix(); reflector.setMatrixAt(i, dummy.matrix);
  }
  post.receiveShadow = reflector.receiveShadow = true;
  group.add(post, reflector);
  return group;
}