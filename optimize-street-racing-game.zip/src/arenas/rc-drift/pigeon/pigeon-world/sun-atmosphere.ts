import * as T from 'three';
import type { PigeonAssets } from './assets';
import { curve, terrainHeight, TRACK_LENGTH } from './donor-track';
import { mulberry32 } from './noise';
import type { MountainSpec } from './route';
import type { GroundAt } from './suspension';

type Beam = { matrix: T.Matrix4; opacity: number; phase: number };

export function createSunAtmosphere(spec: MountainSpec, groundAt: GroundAt, assets: PigeonAssets, sun: T.Vector3) {
  const group = new T.Group();
  group.name = 'PIGEON sunlight and pollen';
  const time = { value: 0 };
  const beamMaterial = new T.MeshBasicMaterial({ map: assets.shafts, color: 0xfff3cf, transparent: true,
    blending: T.AdditiveBlending, side: T.DoubleSide, depthWrite: false, fog: false });
  // Instance the original crossed gradient planes without losing their individual opacity pulses.
  beamMaterial.onBeforeCompile = shader => {
    shader.uniforms.atmosphereTime = time;
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nattribute vec2 shaftOpacityPhase; uniform float atmosphereTime; varying float vShaftOpacity;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvShaftOpacity = shaftOpacityPhase.x * (0.75 + 0.25 * sin(atmosphereTime * 0.35 + shaftOpacityPhase.y));');
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', '#include <common>\nvarying float vShaftOpacity;')
      .replace('#include <color_fragment>', '#include <color_fragment>\ndiffuseColor.a *= vShaftOpacity;');
  };

  const isReferenceRoute = spec.id === 'pigeon';
  const rng = mulberry32(808), center = new T.Vector3(), direction = new T.Vector3(), scale = new T.Vector3();
  const rotation = new T.Quaternion(), align = new T.Quaternion().setFromUnitVectors(new T.Vector3(0, 1, 0), sun);
  const count = isReferenceRoute ? 150 : Math.round(150 * spec.route.length / TRACK_LENGTH);
  const tiles = new Map<string, Beam[]>();
  for (let i = 0; i < count; i++) {
    const t = rng(), f = isReferenceRoute ? null : spec.route.at(t * spec.route.length);
    if (f) {
      center.set(f.x, f.y, f.z);
      direction.set(f.tx, 0, f.tz);
    } else {
      curve.getPointAt(t, center);
      curve.getTangentAt(t, direction).setY(0).normalize();
    }
    const lateral = (rng() - 0.5) * 16, along = (rng() - 0.5) * 6;
    center.x += -direction.z * lateral + direction.x * along;
    center.z += direction.x * lateral + direction.z * along;
    center.y = isReferenceRoute ? terrainHeight(center.x, center.z) : groundAt(center.x, center.z).y;
    const height = 26 + rng() * 22;
    center.addScaledVector(sun, height * 0.45);
    const key = `${Math.floor(center.x / 48)},${Math.floor(center.z / 48)}`;
    const batch = tiles.get(key) ?? [];
    for (let plane = 0; plane < 2; plane++) {
      rotation.setFromAxisAngle(sun, rng() * Math.PI).multiply(align);
      scale.set(1.5 + rng() * 5, height, 1);
      batch.push({ matrix: new T.Matrix4().compose(center, rotation, scale), opacity: 0.07 + rng() * 0.12, phase: rng() * Math.PI * 2 });
    }
    tiles.set(key, batch);
  }

  for (const batch of tiles.values()) {
    const geometry = new T.PlaneGeometry(1, 1);
    const pulse = new Float32Array(batch.length * 2);
    const mesh = new T.InstancedMesh(geometry, beamMaterial, batch.length);
    mesh.name = 'PIGEON crossed sunlight shafts';
    mesh.renderOrder = 5;
    batch.forEach((beam, i) => {
      mesh.setMatrixAt(i, beam.matrix);
      pulse[i * 2] = beam.opacity;
      pulse[i * 2 + 1] = beam.phase;
    });
    geometry.setAttribute('shaftOpacityPhase', new T.InstancedBufferAttribute(pulse, 2));
    mesh.computeBoundingSphere();
    group.add(mesh);
  }

  const dustRandom = mulberry32(99), coords = new Float32Array(900 * 3);
  for (let i = 0; i < coords.length; i += 3) {
    coords[i] = (dustRandom() - 0.5) * 60;
    coords[i + 1] = dustRandom() * 14;
    coords[i + 2] = (dustRandom() - 0.5) * 60;
  }
  const dustGeometry = new T.BufferGeometry();
  const positions = new T.BufferAttribute(coords.slice(), 3).setUsage(T.DynamicDrawUsage);
  dustGeometry.setAttribute('position', positions);
  const dustMaterial = new T.PointsMaterial({ color: 0xfff3cc, size: 0.16, map: assets.motes,
    transparent: true, depthWrite: false, sizeAttenuation: true, blending: T.AdditiveBlending });
  const dust = new T.Points(dustGeometry, dustMaterial);
  dust.name = 'PIGEON pollen motes';
  group.add(dust);

  return {
    group,
    setStrength(strength: number) {
      group.visible = strength > 0;
      beamMaterial.opacity = strength;
      dustMaterial.opacity = 0.5 * strength;
    },
    update(car: T.Vector3, seconds: number) {
      if (!group.visible) return;
      dust.position.copy(car);
      if (seconds === time.value) return;
      time.value = seconds;
      dust.rotation.y = seconds * 0.01;
      for (let i = 0; i < positions.count; i += 7) {
        // The source's small vertical drift, integrated independent of frame rate.
        positions.setY(i, coords[i * 3 + 1] + 0.065 * (Math.cos(i) - Math.cos(seconds + i)));
      }
      positions.needsUpdate = true;
    },
  };
}