// Deterministic PRNG (Mulberry32) & fast multi-octave 2D value/gradient noise (from realistic-3d-nature-assets)

export function createRng(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function randRange(rng: () => number, min: number, max: number): number {
  return min + rng() * (max - min);
}

function hash2(ix: number, iy: number, seed = 1337): number {
  let n = Math.imul(ix, 374761393) + Math.imul(iy, 668265263) + Math.imul(seed, 1442695041);
  n = (n ^ (n >>> 13)) >>> 0;
  n = Math.imul(n, 1274126177) >>> 0;
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
}

function fade(t: number): number {
  return t * t * t * (t * (t * 6 - 15) + 10);
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export function noise2D(x: number, y: number, seed = 1337): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;

  const u = fade(fx);
  const v = fade(fy);

  const a = hash2(ix, iy, seed);
  const b = hash2(ix + 1, iy, seed);
  const c = hash2(ix, iy + 1, seed);
  const d = hash2(ix + 1, iy + 1, seed);

  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}

export function tileableNoise2D(
  x: number,
  y: number,
  periodX: number,
  periodY: number,
  seed = 1337
): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;

  const u = fade(fx);
  const v = fade(fy);

  const x0 = ((ix % periodX) + periodX) % periodX;
  const y0 = ((iy % periodY) + periodY) % periodY;
  const x1 = (x0 + 1) % periodX;
  const y1 = (y0 + 1) % periodY;

  const a = hash2(x0, y0, seed);
  const b = hash2(x1, y0, seed);
  const c = hash2(x0, y1, seed);
  const d = hash2(x1, y1, seed);

  return lerp(lerp(a, b, u), lerp(c, d, u), v);
}

export function fbm2D(
  x: number,
  y: number,
  octaves = 4,
  lacunarity = 2.0,
  gain = 0.5,
  seed = 1337
): number {
  let sum = 0;
  let amp = 0.5;
  let freq = 1.0;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += amp * noise2D(x * freq, y * freq, seed + i * 97);
    norm += amp;
    freq *= lacunarity;
    amp *= gain;
  }
  return sum / norm;
}

export function tileableFbm2D(
  u: number,
  v: number,
  basePeriod: number,
  octaves = 4,
  seed = 1337
): number {
  let sum = 0;
  let amp = 0.5;
  let period = basePeriod;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    sum += amp * tileableNoise2D(u * period, v * period, period, period, seed + i * 101);
    norm += amp;
    period *= 2;
    amp *= 0.5;
  }
  return sum / norm;
}

export function ridgedNoise2D(x: number, y: number, octaves = 4, seed = 42): number {
  let sum = 0;
  let amp = 0.5;
  let freq = 1.0;
  let norm = 0;
  for (let i = 0; i < octaves; i++) {
    const n = noise2D(x * freq, y * freq, seed + i * 53);
    const ridge = 1.0 - Math.abs(n * 2.0 - 1.0);
    sum += amp * ridge * ridge;
    norm += amp;
    freq *= 2.05;
    amp *= 0.5;
  }
  return sum / norm;
}

export function smoothstep(edge0: number, edge1: number, x: number): number {
  const t = Math.max(0, Math.min(1, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}
