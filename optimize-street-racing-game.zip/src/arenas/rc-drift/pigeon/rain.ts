import type * as Three from 'three';

/**
 * Cheap stylized rain for 'Hujan Siang' — a box of falling streaks that follows the camera.
 * One LineSegments draw call, ~460 streaks, recycles above the camera forever.
 */
export type Rain = {
  object: Three.LineSegments;
  setVisible(visible: boolean): void;
  update(camera: Three.Camera, dt: number): void;
  dispose(): void;
};

export function createRain(T: typeof Three, count = 460): Rain {
  const span = 34, height = 15;
  const positions = new Float32Array(count * 2 * 3);
  const speeds = new Float32Array(count);
  const offsets = new Float32Array(count * 2);
  const rand = () => Math.random();
  for (let i = 0; i < count; i++) {
    const x = (rand() - 0.5) * span, z = (rand() - 0.5) * span, y = rand() * height;
    positions[i * 6 + 0] = x; positions[i * 6 + 1] = y; positions[i * 6 + 2] = z;
    positions[i * 6 + 3] = x + 0.055; positions[i * 6 + 4] = y - 0.6; positions[i * 6 + 5] = z + 0.055;
    speeds[i] = 21 + rand() * 7;
    offsets[i * 2] = x; offsets[i * 2 + 1] = z;
  }
  const geometry = new T.BufferGeometry();
  geometry.setAttribute('position', new T.BufferAttribute(positions, 3));
  const material = new T.LineBasicMaterial({ color: 0xd7e8ef, transparent: true, opacity: 0.52, depthWrite: false });
  const object = new T.LineSegments(geometry, material);
  object.name = 'Hujan siang streaks';
  object.frustumCulled = false;
  object.visible = false;
  object.renderOrder = 20;

  function update(camera: Three.Camera, dt: number) {
    if (!object.visible) return;
    const pos = geometry.attributes.position as Three.BufferAttribute;
    const arr = pos.array as Float32Array;
    const fall = Math.min(dt, 0.05);
    for (let i = 0; i < count; i++) {
      for (let k = 0; k < 2; k++) {
        const idx = i * 6 + k * 3 + 1;
        arr[idx] -= speeds[i] * fall;
      }
      if (arr[i * 6 + 1] < 0) {
        const ny = height + rand() * 2;
        arr[i * 6 + 1] = ny; arr[i * 6 + 4] = ny - 0.6;
        arr[i * 6 + 0] = (rand() - 0.5) * span; arr[i * 6 + 3] = arr[i * 6 + 0] + 0.055;
        arr[i * 6 + 2] = (rand() - 0.5) * span; arr[i * 6 + 5] = arr[i * 6 + 2] + 0.055;
      }
    }
    pos.needsUpdate = true;
    // keep the rain box centred on the camera, rooted at the road plane
    object.position.set(camera.position.x, 0, camera.position.z);
  }

  function setVisible(visible: boolean) { object.visible = visible; }
  function dispose() {
    object.removeFromParent();
    geometry.dispose();
    material.dispose();
  }
  return { object, setVisible, update, dispose };
}
