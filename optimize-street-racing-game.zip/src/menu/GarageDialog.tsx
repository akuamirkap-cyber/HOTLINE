import { useEffect, useRef, useState } from 'react';
import { Box, Check, ChevronLeft, Lock, RotateCcw, Wrench } from 'lucide-react';
import { combinationCount, PartDrawing, parts } from '../arenas/rc-drift/pigeon/BuildPanel';
import { defaultBuild, skins, themes, type RallyBuild } from '../arenas/rc-drift/pigeon/rally-config';

const groups = [
  { key: 'nose', label: 'Bodi depan' }, { key: 'rear', label: 'Bodi belakang' },
  { key: 'wing', label: 'Spoiler' }, { key: 'vinyl', label: 'Stiker vinyl' },
] as const;
const lockedCars = ['BMW E30', 'Lancia Fulvia', 'Volkswagen Golf', 'Cupra Leon WTCC', 'Ford Escort RS Cosworth', 'Mitsubishi Lancer Evo VIII', 'Alpine A110'];

export default function GarageDialog({ draft, onDraft, onApply, onClose, onStudio }: {
  draft: RallyBuild; onDraft: (next: RallyBuild) => void; onApply: () => void; onClose: () => void; onStudio: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [saved, setSaved] = useState(false);
  const timer = useRef<number | undefined>(undefined);
  useEffect(() => {
    const element = dialog.current;
    element?.showModal();
    return () => { element?.close(); if (timer.current !== undefined) window.clearTimeout(timer.current); };
  }, []);

  function apply() {
    onApply();
    setSaved(true);
    timer.current = window.setTimeout(onClose, 460);
  }

  return <dialog ref={dialog} className="garage-shell" aria-label="Modifikasi garasi"
    onCancel={event => { event.preventDefault(); onClose(); }}>
    <button type="button" className="garage-back" onClick={onClose} aria-label="Kembali ke menu" autoFocus>
      <ChevronLeft size={22} strokeWidth={3}/><span>Garage</span>
    </button>
    <div className="coin-pill garage-count" aria-label={`${combinationCount} kombinasi modifikasi`}>
      <span className="coin-disc"><Wrench size={13}/></span><b>{combinationCount}</b>
      <button type="button" className="coin-plus" onClick={() => { onApply(); onStudio(); }} disabled={saved}
        aria-label="Simpan dan buka Studio 3D" title="Simpan dan buka Studio 3D"><Box size={17} strokeWidth={2.6}/></button>
    </div>

    <aside className="garage-carlist" aria-label="Daftar mobil">
      <div className="car-item car-item-active"><i className="car-item-bar" aria-hidden="true"/>
        <span className="car-item-name">RALLY GROUP B</span><span className="car-item-year">1986 / IMPRESA LEGACY</span></div>
      {lockedCars.map(name => <button type="button" key={name} className="car-item car-item-locked" disabled aria-label={`${name} terkunci`}>
        <span className="car-item-name">{name}</span><Lock size={12} aria-hidden="true"/>
      </button>)}
    </aside>

    <section className="mod-panel" aria-labelledby="garage-mod-title">
      <header className="mod-header">
        <div><p className="mod-kicker">PILIH PART &amp; LIVERY</p><h2 className="mod-title" id="garage-mod-title">Modifikasi</h2></div>
        <button type="button" className="mod-reset" aria-label="Kembalikan semua part ke bawaan" disabled={saved} onClick={() => onDraft({ ...defaultBuild })}>
          <RotateCcw size={12}/><span>Reset</span>
        </button>
      </header>
      <div className="mod-sections" role="region" aria-label="Pilihan part dan livery" tabIndex={0}>
        {groups.map(({ key, label }, i) => <section className="mod-section" key={key} aria-labelledby={`garage-part-${key}`}>
          <h3 id={`garage-part-${key}`} className="mod-section-title"><span>0{i + 1}</span>{label}</h3>
          <div className="mod-options">
            {parts[key].map(option => <button key={option.id} type="button" aria-pressed={draft[key] === option.id}
              className={`mod-option${draft[key] === option.id ? ' option-active' : ''}`} disabled={saved}
              onClick={() => onDraft({ ...draft, [key]: option.id })}>
              <PartDrawing id={option.id}/><span>{option.label}</span>
            </button>)}
          </div>
        </section>)}
        <section className="mod-section" aria-labelledby="garage-part-theme">
          <h3 id="garage-part-theme" className="mod-section-title"><span>05</span>Tema warna</h3>
          <div className="mod-options mod-swatches">
            {themes.map(theme => <button key={theme.id} type="button" aria-pressed={draft.theme === theme.id}
              className={`mod-option mod-swatch${draft.theme === theme.id ? ' option-active' : ''}`} disabled={saved}
              title={theme.label} onClick={() => onDraft({ ...draft, theme: theme.id })}>
              <span className="mod-trio" aria-hidden="true"><i/><i style={{ background: theme.accent }}/><i/></span><span>{theme.name}</span>
            </button>)}
          </div>
        </section>
        <section className="mod-section" aria-labelledby="garage-part-skin">
          <h3 id="garage-part-skin" className="mod-section-title"><span>06</span>Warna tangan</h3>
          <div className="mod-options mod-swatches">
            {skins.map(skin => <button key={skin.id} type="button" aria-pressed={draft.skin === skin.id}
              className={`mod-option mod-swatch${draft.skin === skin.id ? ' option-active' : ''}`} disabled={saved}
              title={skin.label} onClick={() => onDraft({ ...draft, skin: skin.id })}>
              <span className="skin-swatch" aria-hidden="true" style={{ background: `radial-gradient(circle at 36% 32%, ${skin.tone}, ${skin.shade})` }}/><span>{skin.name}</span>
            </button>)}
          </div>
        </section>
      </div>
      <div className="mod-footer"><span><i aria-hidden="true"/>{combinationCount} kombinasi</span><span className="mod-footer-hint">Apply untuk pakai</span></div>
    </section>

    <div className="garage-bigname" aria-hidden="true"><i/>GARAGE</div>
    <button type="button" className={`garage-apply${saved ? ' apply-flash' : ''}`} onClick={apply} aria-disabled={saved} disabled={saved}>
      <Check size={25} strokeWidth={3.4}/><span>{saved ? 'Tersimpan!' : 'Apply'}</span>
    </button>
  </dialog>;
}