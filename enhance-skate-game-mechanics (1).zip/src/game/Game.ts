import * as THREE from 'three';
import { Box, Circle, RevoluteJoint, World } from 'planck';
import type { Body, Contact, ContactImpulse, Fixture } from 'planck';
import {
  BOOST_ACC,
  BOOST_SPEED,
  BRAKE_ACC,
  BRAKE_SPEED,
  COLORS,
  CRUISE_SPEED,
  DECK_HH,
  DECK_HW,
  GRAVITY,
  JUMP_SPEED,
  PHYS_DT,
  PUSH_ACC,
  RIDE_CLEAR,
  ROT_SPEED,
  WATER_Y,
  WHEEL_R,
  WHEEL_X,
  WHEEL_Y,
} from './constants';
import {
  buildCloudGeometry,
  buildCoinGeometry,
  buildDizzyStarGeometry,
  buildRoadConeGeometry,
  buildTokyoTowerGeometry,
} from './voxel';
import { getPlace } from './themes';
import type { PlaceTheme } from './themes';
import { buildBoardVisual, buildCharRig, getBoard, getChar, SEGS } from './skins';
import type { BoardVisual, CharRig, PivName, SegName } from './skins';
import { FAMILY_ORDER, FREESTYLE_CYCLE, TRICK_MAP as TRICK_DEFS, ZERO_POSE, trickPose } from './tricks';
import type { TrickDef, TrickFamily, TrickPose } from './tricks';
import { LevelGen, baseAt, buildPiece, disposePiece, surfAt } from './terrain';
import type { BuiltPiece, GapInfo, RailInfo, RampInfo, RoadConeObj } from './terrain';
import { Particles } from './particles';
import { Sfx } from './audio';
import { CHAIN_PALETTES, SkateMotionTrails } from './trail';

export type Phase = 'menu' | 'playing' | 'crashed' | 'over';
export type PopupKind = 'trick' | 'perfect' | 'good' | 'bad' | 'crash' | 'coin';
export type CrashReason = 'head' | 'landing' | 'wall' | 'fall' | 'water' | 'stuck' | 'bail' | 'cone';

export interface HudState {
  score: number;
  distance: number;
  coins: number;
  combo: number;
  best: number;
  speed: number;
  autoLand: boolean;
}

export interface GameResult {
  score: number;
  distance: number;
  coins: number;
  best: number;
  newBest: boolean;
  reason: CrashReason;
  flips: number;
}

export interface GameCallbacks {
  onHud(h: HudState): void;
  onPhase(p: Phase, r?: GameResult): void;
  onPopup(text: string, kind: PopupKind, sub?: string): void;
  onPause(p: boolean): void;
  onParallax?(camX: number, camY: number, speed: number, dt: number): void;
}

interface Pose {
  x: number;
  y: number;
  a: number;
}

interface RagPart {
  body: Body;
  mesh: THREE.Mesh;
  z: number;
  vz: number;
  kind: 'torso' | 'head' | 'wing' | 'leg';
  qRes: THREE.Quaternion;
  inWater: boolean;
  px: number;
  py: number;
  pa: number;
}

const BEST_KEY = 'ayam-skater-best-v1';
const CHAR_KEY = 'ayam-skater-char-v1';
const BOARD_KEY = 'ayam-skater-board-v1';
const PLACE_KEY = 'ayam-skater-place-v1';
const AUTOLAND_KEY = 'ayam-skater-autoland-v1';
const Z_AXIS = new THREE.Vector3(0, 0, 1);

type GrindStyle = 'fifty' | 'boardslide' | 'lipslide' | 'feeble';

function railAt(rail: RailInfo, x: number): { y: number; ang: number } {
  const pts = rail.pts;
  if (x <= pts[0].x) return { y: pts[0].y, ang: 0 };
  for (let i = 1; i < pts.length; i++) {
    if (x <= pts[i].x) {
      const a = pts[i - 1];
      const b = pts[i];
      const dx = b.x - a.x || 1;
      const t = (x - a.x) / dx;
      return { y: a.y + (b.y - a.y) * t, ang: Math.atan2(b.y - a.y, dx) };
    }
  }
  const a = pts[pts.length - 2];
  const b = pts[pts.length - 1];
  return { y: b.y, ang: Math.atan2(b.y - a.y, b.x - a.x || 1) };
}

const TAU = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];

function makeBlockTexture(): THREE.Texture {
  const cv = document.createElement('canvas');
  cv.width = 64;
  cv.height = 64;
  const g = cv.getContext('2d')!;
  for (let cy = 0; cy < 4; cy++) {
    for (let cx = 0; cx < 4; cx++) {
      const v = 236 + Math.floor(Math.random() * 19);
      g.fillStyle = `rgb(${v},${v},${v})`;
      g.fillRect(cx * 16, cy * 16, 16, 16);
      for (let k = 0; k < 5; k++) {
        const s = 218 + Math.floor(Math.random() * 22);
        g.fillStyle = `rgb(${s},${s},${s})`;
        g.fillRect(cx * 16 + 1 + Math.floor(Math.random() * 13), cy * 16 + 1 + Math.floor(Math.random() * 13), 2, 2);
      }
      g.fillStyle = 'rgba(255,255,255,0.45)';
      g.fillRect(cx * 16, cy * 16, 16, 1);
      g.fillRect(cx * 16, cy * 16, 1, 16);
      g.fillStyle = 'rgba(0,0,0,0.12)';
      g.fillRect(cx * 16, cy * 16 + 15, 16, 1);
      g.fillRect(cx * 16 + 15, cy * 16, 1, 16);
    }
  }
  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

export class Game {
  private container: HTMLElement;
  private cb: GameCallbacks;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sun: THREE.DirectionalLight;
  private hemi: THREE.HemisphereLight;
  private placeId = 'hijau';
  private theme!: PlaceTheme;
  private voxelMat: THREE.MeshLambertMaterial;
  private terrainMat: THREE.MeshLambertMaterial;
  private coinMat: THREE.MeshLambertMaterial;
  private coinGeo: THREE.BufferGeometry;
  private roadConeGeo: THREE.BufferGeometry;
  private dizzyStarGeo: THREE.BufferGeometry;
  private trails: SkateMotionTrails;
  private sparkleTimer = 0;
  private noseTmp = new THREE.Vector3();
  private tailTmp = new THREE.Vector3();
  private scarfTmp = new THREE.Vector3();
  private wheelLTmp = new THREE.Vector3();
  private wheelRTmp = new THREE.Vector3();
  private trickColorHex = 0xffd60a;
  private coneSlowTimer = 0;
  private camRoll = 0;
  private dizzyGroup = new THREE.Group();
  private dizzyStars: THREE.Mesh[] = [];
  private rig!: CharRig;
  private boardVis!: BoardVisual;
  private charId = 'ayam';
  private boardId = 'ayam';
  private riderRoot = new THREE.Group();
  private spinG = new THREE.Group();
  private facingG = new THREE.Group();
  private bodyYaw = -1.15;
  private headYawW = -1.15;
  private headTarget = -1.15;
  private headTimer = 2;
  private pushing = false;
  private boardTrickG = new THREE.Group();
  private riderTiltG = new THREE.Group();
  private riderOffG = new THREE.Group();
  private hipG = new THREE.Group();
  private pivG = {} as Record<PivName, THREE.Group>;
  private trick: { def: TrickDef; t: number; dir: number; caught: boolean; holdBonus: number } | null = null;
  private holdGrab = false;
  private holdPhase = 0;
  private ollieAnim = 0;
  private onRamp = false;
  private airPops = 0;
  private trickCamZoom = 0;
  private smoothPose: TrickPose = { ...ZERO_POSE };
  private carrySpin = { flip: 0, boardYaw: 0, boardPitch: 0, yaw: 0 };
  private grinding: { rail: RailInfo; style: GrindStyle; dist: number; pts: number } | null = null;
  private grindStyle: GrindStyle = 'fifty';
  private trickQueue: TrickFamily | null = null;
  private trickQueueT = 0;
  private cycleIdx = 0;
  private freestyleQueue = false;
  private familyIdx: Record<TrickFamily, number> = { flip: 0, grab: 0, spin: 0 };
  private airTricks: TrickDef[] = [];
  private pose: TrickPose = { ...ZERO_POSE };
  private tmpQ = new THREE.Quaternion();
  private preview = false;
  private particles: Particles;
  private sfx = new Sfx();
  private water: THREE.Mesh;
  private clouds: { obj: THREE.Mesh; speed: number }[] = [];
  private landmarks: THREE.Mesh[] = [];
  private ro: ResizeObserver | null = null;
  private raf = 0;
  private lastT = 0;

  // physics world
  private world!: World;
  private gen!: LevelGen;
  private pieces: BuiltPiece[] = [];
  private board!: Body;
  private headFix: Fixture | null = null;
  private wheelFix: Fixture[] = [];
  private rag: RagPart[] = [];
  private bPrev = { x: 0, y: 0, a: 0 };
  private boardTumble = { rx: 0, ry: 0, vx: 0, vy: 0 };

  // state
  phase: Phase = 'menu';
  private paused = false;
  private autoLand = true;
  private input = { left: false, right: false, jump: false };
  private jumpBuffer = 0;
  private jumpCooldown = 0;
  private grounded = true;
  private groundN = { x: 0, y: 1 };
  private coyote = 0;
  private airTime = 0;
  private groundTime = 0;
  private airRot = 0;
  private flipsAnnounced = 0;
  private takeoffX = 0;
  private maxAirClear = 0;
  private clearedConeGroups = new Set<number>();
  private prevVel = { x: 0, y: 0 };
  private accS = { x: 0, y: 0 };
  private headHit = false;
  private wallHit = false;
  private stuckTime = 0;
  private accum = 0;
  private slowmo = 0;
  private realTime = 0;
  private crashTimer = 0;
  private overTime = 0;
  private crashReason: CrashReason = 'head';
  private shake = 0;
  private boardInWater = false;
  private splashCooldown = 0;
  private petalTimer = 0;

  // score
  private startX = 0;
  private distance = 0;
  private trickScore = 0;
  private coinCount = 0;
  private combo = 0;
  private flipsTotal = 0;
  private best = 0;
  private hudTimer = 0;
  private coinChain = 0;
  private lastCoinT = -10;
  private impactCooldown = 0;
  private boardClatterCooldown = 0;

  // rig springs (secondary motion → expressive jelly / skate flow)
  private rig_s = {
    crouch: 0,
    crouchV: 0,
    lean: 0,
    leanV: 0,
    head: 0,
    headV: 0,
    squash: 0,
    squashV: 0,
    flap: 0,
    flapPhase: 0,
    push: -1,
    blinkT: 2,
    blink: 0,
  };
  private wheelSpin = 0;

  // camera
  private camT = new THREE.Vector3(0, 1, 0);
  private camDist = 12;

  constructor(container: HTMLElement, cb: GameCallbacks) {
    this.container = container;
    this.cb = cb;
    try {
      this.best = Number(localStorage.getItem(BEST_KEY) || 0) || 0;
      const savedAuto = localStorage.getItem(AUTOLAND_KEY);
      if (savedAuto !== null) this.autoLand = savedAuto !== '0';
    } catch {
      this.best = 0;
    }

    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(w, h);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.setClearColor(0x000000, 0);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.touchAction = 'none';
    container.appendChild(renderer.domElement);
    this.renderer = renderer;

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0xd6f3ff, 78, 235);
    this.scene = scene;

    this.camera = new THREE.PerspectiveCamera(40, w / h, 0.5, 500);

    const hemi = new THREE.HemisphereLight(0xffffff, 0x99b08a, 2.08);
    scene.add(hemi);
    this.hemi = hemi;
    const sun = new THREE.DirectionalLight(0xfff3db, 1.98);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const sc = sun.shadow.camera;
    sc.left = -36;
    sc.right = 36;
    sc.top = 26;
    sc.bottom = -26;
    sc.near = 1;
    sc.far = 140;
    sun.shadow.bias = -0.0006;
    sun.shadow.normalBias = 0.035;
    scene.add(sun);
    scene.add(sun.target);
    this.sun = sun;

    this.voxelMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    this.terrainMat = new THREE.MeshLambertMaterial({ vertexColors: true, map: makeBlockTexture() });
    this.coinMat = new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0x5a3a00 });

    this.coinGeo = buildCoinGeometry();
    this.roadConeGeo = buildRoadConeGeometry();
    this.dizzyStarGeo = buildDizzyStarGeometry();

    this.trails = new SkateMotionTrails();
    scene.add(this.trails.group);

    for (let i = 0; i < 3; i++) {
      const star = new THREE.Mesh(this.dizzyStarGeo, this.coinMat);
      this.dizzyGroup.add(star);
      this.dizzyStars.push(star);
    }
    this.dizzyGroup.visible = false;
    scene.add(this.dizzyGroup);

    try {
      this.charId = localStorage.getItem(CHAR_KEY) || 'ayam';
      this.boardId = localStorage.getItem(BOARD_KEY) || 'ayam';
      this.placeId = localStorage.getItem(PLACE_KEY) || 'hijau';
    } catch {
      /* ignore */
    }
    this.theme = getPlace(this.placeId);
    scene.add(this.riderRoot);
    this.riderRoot.add(this.spinG);
    this.spinG.add(this.boardTrickG, this.trails.vortexGroup, this.facingG);
    this.boardTrickG.add(this.trails.deckSpinMesh);
    this.facingG.add(this.riderTiltG);
    this.riderTiltG.add(this.riderOffG);
    this.riderOffG.add(this.hipG);
    this.hipG.rotation.order = 'ZYX';
    this.riderTiltG.rotation.order = 'ZYX';
    this.buildSkin();

    this.particles = new Particles(1200);
    scene.add(this.particles.mesh);

    const water = new THREE.Mesh(
      new THREE.BoxGeometry(800, 40, 160),
      new THREE.MeshLambertMaterial({ color: COLORS.water }),
    );
    water.position.set(0, WATER_Y - 20, -75);
    water.receiveShadow = true;
    scene.add(water);
    this.water = water;

    this.buildBackground();
    this.applyTheme();
    this.resetWorld();
    this.snapCamera();

    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);
    window.addEventListener('blur', this.onBlur);
    document.addEventListener('visibilitychange', this.onVisibility);
    if (typeof ResizeObserver !== 'undefined') {
      this.ro = new ResizeObserver(this.onResize);
      this.ro.observe(container);
    }
    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.loop);
    this.emitHud();
  }

  /* ================================================================ */
  /* Public API                                                       */
  /* ================================================================ */

  start() {
    this.sfx.init();
    if (this.phase !== 'menu') return;
    this.phase = 'playing';
    this.cb.onPhase('playing');
    this.board.setLinearVelocity({ x: 6.8, y: 0 });
    this.rig_s.push = 0;
  }

  restart() {
    this.sfx.init();
    this.resetWorld();
    this.snapCamera();
    this.phase = 'playing';
    this.paused = false;
    this.cb.onPause(false);
    this.cb.onPhase('playing');
    this.board.setLinearVelocity({ x: 6.8, y: 0 });
    this.rig_s.push = 0;
  }

  toggleAutoLand() {
    this.autoLand = !this.autoLand;
    try {
      localStorage.setItem(AUTOLAND_KEY, this.autoLand ? '1' : '0');
    } catch {
      /* ignore */
    }
    this.emitHud();
    this.cb.onPopup(this.autoLand ? 'AUTO-LAND: AKTIF' : 'AUTO-LAND: PRO', 'good');
  }

  setControl(name: 'left' | 'right' | 'jump' | 'flip' | 'grab' | 'spin', down: boolean) {
    if (name === 'grab') {
      if (down) this.pressGrabPose();
      else this.holdGrab = false;
      return;
    }
    if (name === 'flip' || name === 'spin') {
      if (down) this.pressTrick(name);
      return;
    }
    if (name === 'jump') {
      if (down) this.pressJump();
      else this.input.jump = false;
    } else {
      this.input[name] = down;
      if (down) this.sfx.init();
    }
  }

  setMuted(m: boolean) {
    this.sfx.setMuted(m);
  }

  getSkin() {
    return { charId: this.charId, boardId: this.boardId };
  }

  setSkin(charId: string, boardId: string) {
    if (this.phase !== 'menu') return;
    this.charId = charId;
    this.boardId = boardId;
    try {
      localStorage.setItem(CHAR_KEY, charId);
      localStorage.setItem(BOARD_KEY, boardId);
    } catch {
      /* ignore */
    }
    this.buildSkin();
    this.resetWorld();
    this.snapCamera();
    const p = this.board.getPosition();
    this.particles.burst(p.x, p.y + 0.8, 0.3, 18, [0xffe066, 0xffffff, 0x7fe3ff, 0xff8fd1], 3.8, {
      up: 2.2,
      life: 0.8,
      size: 0.12,
      gravity: 3,
      drag: 2,
    });
    this.rig_s.squashV -= 3;
    this.sfx.init();
    this.sfx.coin(1.2);
  }

  setPreview(on: boolean) {
    this.preview = on;
  }

  toMenu() {
    this.resetWorld();
    this.snapCamera();
    this.phase = 'menu';
    this.paused = false;
    this.cb.onPause(false);
    this.cb.onPhase('menu');
  }

  private buildSkin() {
    if (this.rig) {
      for (const sg of SEGS) this.rig.meshes[sg].removeFromParent();
      this.rig.dispose();
    }
    if (this.boardVis) {
      this.boardVis.group.removeFromParent();
      this.boardVis.dispose();
    }
    this.charId = getChar(this.charId).id;
    this.boardId = getBoard(this.boardId).id;
    this.rig = buildCharRig(this.charId, this.voxelMat);
    this.boardVis = buildBoardVisual(this.boardId, this.rig.def.deck, this.voxelMat);
    this.boardTrickG.add(this.boardVis.group);
    for (const k of Object.keys(this.pivG) as PivName[]) this.pivG[k].removeFromParent();
    this.pivG = {} as Record<PivName, THREE.Group>;
    for (const k of ['head', 'armN', 'armF', 'legN', 'legF'] as PivName[]) {
      const g = new THREE.Group();
      g.rotation.order = 'ZYX';
      (k === 'legN' || k === 'legF' ? this.riderOffG : this.hipG).add(g);
      this.pivG[k] = g;
    }
    this.attachRig();
  }

  private attachRig() {
    const r = this.rig;
    const put = (m: THREE.Mesh, parent: THREE.Object3D) => {
      parent.add(m);
      m.position.set(0, 0, 0);
      m.quaternion.identity();
      m.scale.set(1, 1, 1);
    };
    put(r.meshes.torso, this.hipG);
    for (const k of ['head', 'armN', 'armF', 'legN', 'legF'] as PivName[]) put(r.meshes[k], this.pivG[k]);
    if (r.eyes) r.eyes.visible = true;
    if (r.deadEyes) r.deadEyes.visible = false;
  }

  /** Dedicated S-key Grab Pose handler: Indy Grab -> Melon Grab -> Airwalk -> Method... */
  pressGrabPose() {
    this.sfx.init();
    if (this.phase === 'menu') {
      this.start();
      return;
    }
    if (this.phase !== 'playing' || this.paused) return;
    this.holdGrab = true;
    this.holdPhase = 0;

    if (this.grinding) {
      this.exitGrind(6.2);
      this.trickQueue = 'grab';
      this.trickQueueT = 0;
      return;
    }

    // If on the ground, automatically pop a stylish Ollie right into the Grab pose!
    if (this.grounded || this.coyote > 0) {
      if (this.jumpCooldown <= 0) {
        this.doJump(1.08);
      }
      this.trickQueue = 'grab';
      this.trickQueueT = 0;
      return;
    }

    // In mid-air: immediately strike (or cycle to the next!) Grab pose!
    if (this.trick && this.trick.def.family === 'grab' && this.trick.t > 0.1) {
      this.completeTrick(true);
    } else if (this.trick && this.trick.t / this.trick.def.dur >= 0.45) {
      this.completeTrick(true);
    } else if (this.trick) {
      this.captureSpinCarry();
      this.trick = null;
    }
    this.startTrick('grab');
  }

  private captureSpinCarry() {
    const wrapPi = (a: number) => Math.atan2(Math.sin(a), Math.cos(a));
    this.carrySpin.flip = wrapPi(this.pose.flip + this.carrySpin.flip);
    this.carrySpin.boardYaw = wrapPi(this.pose.boardYaw + this.carrySpin.boardYaw);
    this.carrySpin.boardPitch = wrapPi(this.pose.boardPitch + this.carrySpin.boardPitch);
    this.carrySpin.yaw = wrapPi(this.pose.yaw + this.carrySpin.yaw);
  }

  private triggerShockwave(colorHex: number, dur = 0.34) {
    const p = this.board.getPosition();
    this.trails.triggerHalo(p.x, p.y + 0.18, colorHex, dur);
  }

  pressTrick(fam: TrickFamily) {
    this.sfx.init();
    if (this.phase === 'menu') {
      this.start();
      return;
    }
    if (this.phase !== 'playing' || this.paused) return;
    if (this.grounded || this.trick) {
      this.trickQueue = fam;
      this.trickQueueT = 0;
      return;
    }
    this.startTrick(fam);
  }

  /**
   * Left Mouse Click Freestyle Showcase:
   * - On road / ramp: pops an energetic, high Freestyle Ollie right into a 3D trick + Silk Ribbon trail!
   * - In mid-air: triggers dazzling Freestyle tricks with floaty hang-time & evolving chromatic combo ribbons!
   */
  pressFreestyle() {
    this.sfx.init();
    if (this.phase === 'menu') {
      this.start();
      return;
    }
    if (this.phase === 'over') {
      if (this.overTime > 0.6) this.restart();
      return;
    }
    if (this.phase !== 'playing' || this.paused) return;

    if (this.grinding) {
      this.exitGrind(6.5);
      this.freestyleQueue = true;
      return;
    }

    if (this.grounded || this.coyote > 0) {
      if (this.jumpCooldown <= 0) {
        this.doJump(1.14);
      }
      this.freestyleQueue = true;
      return;
    }

    if (!this.trick && this.airTime > 0.01) {
      this.startNextCycle(true);
      return;
    }

    // Seamless Left-Click Spam Chaining: once 42% through current trick, morph smoothly into the next trick!
    if (this.trick && this.trick.t / this.trick.def.dur >= 0.42) {
      this.completeTrick(false);
      this.startNextCycle(true);
      return;
    }

    this.freestyleQueue = true;
  }

  private startNextCycle(stylishBoost = false) {
    const land = this.predictLanding();
    const p = this.board.getPosition();
    const bigAir = (land ? land.t > 0.6 : true) || p.y - this.heightAt(p.x) > 1.9;
    for (let i = 0; i < FREESTYLE_CYCLE.length; i++) {
      const idx = (this.cycleIdx + i) % FREESTYLE_CYCLE.length;
      const d = TRICK_DEFS[FREESTYLE_CYCLE[idx]];
      if (d.bigAirOnly && !bigAir) continue;
      this.cycleIdx = idx + 1;
      this.beginTrick(d, stylishBoost);
      return;
    }
  }

  private startTrick(fam: TrickFamily) {
    const land = this.predictLanding();
    const p = this.board.getPosition();
    const bigAir = (land ? land.t > 0.6 : true) || p.y - this.heightAt(p.x) > 1.9;
    const list = FAMILY_ORDER[fam];
    let def: TrickDef | null = null;
    for (let i = 0; i < list.length; i++) {
      const idx = (this.familyIdx[fam] + i) % list.length;
      const d = TRICK_DEFS[list[idx]];
      if (d.bigAirOnly && !bigAir) continue;
      def = d;
      this.familyIdx[fam] = idx + 1;
      break;
    }
    if (!def) return;
    this.beginTrick(def, true);
  }

  private beginTrick(def: TrickDef, stylishBoost = false) {
    const b = this.board;
    const p = b.getPosition();
    this.trick = { def, t: 0, dir: Math.random() < 0.5 ? 1 : -1, caught: false, holdBonus: 0 };

    // Floaty arcade hang-time cushion so Left-Click Freestyle spins & Silk Ribbons blossom fully in mid-air!
    const land = this.predictLanding();
    if (stylishBoost && !this.grounded && this.airPops < 4 && (!land || land.t > 0.2)) {
      const v = b.getLinearVelocity();
      const liftAdd = this.airPops === 0 ? 1.65 : this.airPops === 1 ? 1.1 : 0.75;
      if (v.y < 6.2) {
        b.setLinearVelocity({ x: Math.max(v.x, 7.2), y: Math.max(v.y + liftAdd, 2.35) });
      }
      this.airPops++;
    }

    const chainN = this.airTricks.length;
    const colHex = new THREE.Color(def.color).getHex();
    this.trickColorHex = colHex;
    const pal = CHAIN_PALETTES[chainN % CHAIN_PALETTES.length];
    this.trails.applyPalette(pal, colHex);
    this.triggerShockwave(colHex, 0.36);
    this.rig_s.squashV -= 1.65;

    this.sfx.freestyleSpark(chainN);
    if (def.family === 'grab') {
      this.sfx.grab();
    } else if (def.boardSpin) {
      this.sfx.boardSpin(def.dur >= 0.46);
    } else {
      this.sfx.whoosh();
    }

    // Crisp starlight sparkle burst (fine motes that complement the smooth Silk Ribbons!)
    this.particles.burst(p.x, p.y + 0.32, 0.35, 16, [colHex, 0xffffff, pal.tailHead], 3.8, {
      up: 1.7,
      life: 0.48,
      size: 0.085,
      gravity: 1.5,
      drag: 2.8,
      spread: 0.28,
    });
  }

  private completeTrick(silent = false) {
    if (!this.trick) return;
    this.captureSpinCarry();
    const d = this.trick.def;
    const bonus = Math.round(this.trick.holdBonus);
    this.trick = null;
    this.pose = { ...ZERO_POSE };
    const chainIdx = this.airTricks.length + 1;
    const chainBonus = chainIdx > 1 ? (chainIdx - 1) * 40 : 0;
    const totalPts = d.pts + bonus + chainBonus;
    this.airTricks.push({ ...d, pts: totalPts });
    if (!silent) {
      const subParts: string[] = [`+${totalPts}`];
      if (bonus > 0) subParts.push('HOLD!');
      if (chainIdx > 1) subParts.push(`⚡${chainIdx}x FREESTYLE!`);
      this.cb.onPopup(d.name, chainIdx > 1 ? 'perfect' : 'good', subParts.join(' • '));
      this.sfx.trick(Math.min(4, chainIdx + (bonus > 20 ? 1 : 0)));
    }
  }

  togglePause() {
    if (this.phase !== 'playing') return;
    this.paused = !this.paused;
    this.input.left = this.input.right = false;
    this.holdGrab = false;
    this.cb.onPause(this.paused);
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('blur', this.onBlur);
    document.removeEventListener('visibilitychange', this.onVisibility);
    this.ro?.disconnect();
    this.sfx.dispose();
    for (const p of this.pieces) disposePiece(p, this.world, this.scene, this.coinGeo, this.roadConeGeo);
    this.pieces = [];
    this.coinGeo.dispose();
    this.roadConeGeo.dispose();
    this.dizzyStarGeo.dispose();
    this.trails.dispose();
    this.rig.dispose();
    this.boardVis.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }

  /* ================================================================ */
  /* Setup & Scenic Background                                        */
  /* ================================================================ */

  private buildBackground() {
    const t = this.theme;
    // Subtle 3D landmarks for depth that complement our lush 2D illustrated ScenicBackdrop!
    if (t.bg === 'city' || t.bg === 'neon') {
      const neon = t.bg === 'neon';
      const tower = new THREE.Mesh(buildTokyoTowerGeometry(neon ? 0xff6e3a : 0xe8642c), this.voxelMat);
      tower.position.set(-55, WATER_Y - 1, -118);
      tower.scale.setScalar(1.25);
      this.scene.add(tower);
      this.landmarks.push(tower);
    }
    for (let i = 0; i < 8; i++) {
      const m = new THREE.Mesh(buildCloudGeometry(Math.random()), this.voxelMat);
      m.position.set(-150 + i * 42 + Math.random() * 12, 13 + Math.random() * 11, -46 - Math.random() * 34);
      m.scale.setScalar(0.65 + Math.random() * 0.65);
      this.scene.add(m);
      this.clouds.push({ obj: m, speed: 0.35 + Math.random() * 0.65 });
    }
  }

  private clearBackground() {
    for (const m of this.landmarks) {
      this.scene.remove(m);
      m.geometry.dispose();
    }
    for (const c of this.clouds) {
      this.scene.remove(c.obj);
      c.obj.geometry.dispose();
    }
    this.landmarks = [];
    this.clouds = [];
  }

  private applyTheme() {
    const t = this.theme;
    const fog = this.scene.fog as THREE.Fog;
    fog.color.set(t.fog);
    fog.near = t.fogNear;
    fog.far = t.fogFar;
    this.hemi.color.set(t.hemiSky);
    this.hemi.groundColor.set(t.hemiGround);
    this.hemi.intensity = t.hemiIntensity;
    this.sun.color.set(t.sunColor);
    this.sun.intensity = t.sunIntensity;
    (this.water.material as THREE.MeshLambertMaterial).color.set(t.water);
  }

  getPlaceId() {
    return this.placeId;
  }

  setPlace(id: string) {
    if (this.phase !== 'menu') return;
    this.placeId = getPlace(id).id;
    this.theme = getPlace(id);
    try {
      localStorage.setItem(PLACE_KEY, this.placeId);
    } catch {
      /* ignore */
    }
    this.clearBackground();
    this.buildBackground();
    this.applyTheme();
    this.resetWorld();
    this.snapCamera();
    const p = this.board.getPosition();
    this.particles.burst(p.x, p.y + 0.8, 0.3, 18, [0xffe066, 0xffffff, 0x7fe3ff, 0xff8fd1], 3.5, {
      up: 2,
      life: 0.8,
      size: 0.12,
      gravity: 3,
      drag: 2,
    });
    this.sfx.init();
    this.sfx.coin(1.2);
  }

  private resetWorld() {
    if (this.world) {
      for (const p of this.pieces) disposePiece(p, this.world, this.scene, this.coinGeo, this.roadConeGeo);
    }
    this.pieces = [];
    this.rag = [];
    this.dizzyGroup.visible = false;
    this.trails.clear();
    this.coneSlowTimer = 0;
    this.camRoll = 0;
    this.particles.clear();
    this.clearedConeGroups.clear();

    const world = new World({ gravity: { x: 0, y: -GRAVITY } });
    world.on('post-solve', this.onPostSolve);
    this.world = world;
    this.gen = new LevelGen((Math.random() * 1e9) | 0);
    this.gen.propSet = this.theme.props;
    this.camT.set(0, 1, 0);
    this.ensureTerrain(0);

    const b = world.createBody({
      type: 'dynamic',
      position: { x: 0, y: RIDE_CLEAR + 0.01 },
      angle: 0,
      bullet: true,
      allowSleep: false,
      linearDamping: 0,
      angularDamping: 0.08,
    });
    b.createFixture({
      shape: new Box(DECK_HW, DECK_HH),
      density: 6,
      friction: 0,
      restitution: 0,
      filterGroupIndex: -1,
      userData: 'deck',
    });
    // 4-wheel continuous glide base: eliminates the hollow center pocket so no ramp lip can ever snag the rear truck!
    this.wheelFix = [
      b.createFixture({
        shape: new Circle({ x: -WHEEL_X, y: WHEEL_Y }, WHEEL_R),
        density: 7,
        friction: 0,
        restitution: 0,
        filterGroupIndex: -1,
        userData: 'wheel',
      }),
      b.createFixture({
        shape: new Circle({ x: -0.21, y: WHEEL_Y }, WHEEL_R),
        density: 5,
        friction: 0,
        restitution: 0,
        filterGroupIndex: -1,
        userData: 'wheel',
      }),
      b.createFixture({
        shape: new Circle({ x: 0.21, y: WHEEL_Y }, WHEEL_R),
        density: 5,
        friction: 0,
        restitution: 0,
        filterGroupIndex: -1,
        userData: 'wheel',
      }),
      b.createFixture({
        shape: new Circle({ x: WHEEL_X, y: WHEEL_Y }, WHEEL_R),
        density: 7,
        friction: 0,
        restitution: 0,
        filterGroupIndex: -1,
        userData: 'wheel',
      }),
    ];
    this.headFix = b.createFixture({
      shape: (() => {
        const h = this.rig ? this.rig.height : 1.3;
        const lo = DECK_HH + Math.max(0.42, (this.rig ? this.rig.legLen : 0.26) + 0.16);
        const hi = DECK_HH + Math.max(lo + 0.26, h * 0.9);
        return new Box(0.18, (hi - lo) / 2, { x: 0.03, y: (hi + lo) / 2 }, 0);
      })(),
      isSensor: true,
      density: 0,
      filterGroupIndex: -1,
      userData: 'head',
    });
    this.board = b;
    this.bPrev = { x: 0, y: RIDE_CLEAR + 0.01, a: 0 };
    this.boardTumble = { rx: 0, ry: 0, vx: 0, vy: 0 };

    // reset state
    this.input.left = this.input.right = this.input.jump = false;
    this.holdGrab = false;
    this.holdPhase = 0;
    this.ollieAnim = 0;
    this.jumpBuffer = 0;
    this.jumpCooldown = 0;
    this.grounded = true;
    this.coyote = 0;
    this.airTime = 0;
    this.maxAirClear = 0;
    this.groundTime = 0;
    this.airRot = 0;
    this.flipsAnnounced = 0;
    this.prevVel = { x: 0, y: 0 };
    this.accS = { x: 0, y: 0 };
    this.headHit = false;
    this.wallHit = false;
    this.stuckTime = 0;
    this.accum = 0;
    this.slowmo = 0;
    this.crashTimer = 0;
    this.shake = 0;
    this.boardInWater = false;
    this.startX = 0;
    this.distance = 0;
    this.trickScore = 0;
    this.coinCount = 0;
    this.combo = 0;
    this.flipsTotal = 0;
    this.coinChain = 0;
    Object.assign(this.rig_s, {
      crouch: 0,
      crouchV: 0,
      lean: 0,
      leanV: 0,
      head: 0,
      headV: 0,
      squash: 0,
      squashV: 0,
      flap: 0,
      push: -1,
    });
    this.trick = null;
    this.onRamp = false;
    this.airPops = 0;
    this.trickCamZoom = 0;
    this.freestyleQueue = false;
    this.cycleIdx = 0;
    this.grinding = null;
    this.pushing = false;
    this.bodyYaw = -1.15;
    this.headYawW = -1.15;
    this.headTarget = -1.15;
    this.headTimer = 2;
    this.trickQueue = null;
    this.airTricks = [];
    this.pose = { ...ZERO_POSE };
    this.smoothPose = { ...ZERO_POSE };
    this.carrySpin = { flip: 0, boardYaw: 0, boardPitch: 0, yaw: 0 };
    if (this.rig) this.attachRig();
    this.emitHud();
  }

  private ensureTerrain(x: number) {
    this.gen.generateUntil(x + 160);
    while (this.gen.out.length) {
      const d = this.gen.out.shift()!;
      this.pieces.push(
        buildPiece(
          d,
          this.world,
          { terrain: this.terrainMat, voxel: this.voxelMat, coin: this.coinMat },
          this.coinGeo,
          this.roadConeGeo,
          this.scene,
          this.theme.palette,
        ),
      );
    }
    const cutoff = Math.min(this.camT.x, x) - 90;
    while (this.pieces.length > 1 && this.pieces[0].data.maxX < cutoff) {
      disposePiece(this.pieces.shift()!, this.world, this.scene, this.coinGeo, this.roadConeGeo);
    }
    while (this.gen.gaps.length && this.gen.gaps[0].x1 < cutoff) this.gen.gaps.shift();
  }

  private heightAt(x: number): number {
    for (const p of this.pieces) {
      if (x >= p.data.minX && x <= p.data.maxX) return surfAt(p.data.pts, x);
    }
    for (const p of this.pieces) if (p.data.minX > x) return p.data.pts[0].y;
    return 0;
  }

  /** Road slope strictly within continuous terrain (never samples across cliff drops or wooden ramp walls!) */
  private slopeAtRoad(x: number): number {
    for (const p of this.pieces) {
      if (x >= p.data.minX - 0.65 && x <= p.data.maxX + 0.65) {
        const xA = Math.max(p.data.minX, x - 0.65);
        const xB = Math.min(p.data.maxX, x + 0.65);
        if (xB - xA < 0.12) return 0;
        return clamp(Math.atan2(baseAt(p.data.pts, xB) - baseAt(p.data.pts, xA), xB - xA), -0.75, 0.75);
      }
    }
    return 0;
  }

  /** Returns active wooden ramp info & true upward launch tangent if the board is on or leaving a ramp */
  private rampAt(x: number, y: number): { ramp: RampInfo; y: number; slope: number } | null {
    for (const p of this.pieces) {
      if (p.data.minX > x + 2 || p.data.maxX + 2 < x) continue;
      for (const r of p.ramps) {
        if (x < r.x0 - 0.7 || x > r.x1 + 0.75) continue;
        if (y < r.baseY + 0.05) continue;
        const pts = r.pts;
        if (x >= r.x1 - 0.12) {
          return { ramp: r, y: r.lipY, slope: r.exitAng };
        }
        for (let i = 1; i < pts.length; i++) {
          if (x <= pts[i].x) {
            const a = pts[i - 1];
            const b = pts[i];
            const dx = Math.max(0.02, b.x - a.x);
            const t = clamp((x - a.x) / dx, 0, 1);
            return {
              ramp: r,
              y: a.y + (b.y - a.y) * t,
              slope: clamp(Math.atan2(b.y - a.y, dx), 0, r.exitAng),
            };
          }
        }
        return { ramp: r, y: r.lipY, slope: r.exitAng };
      }
    }
    return null;
  }

  private gapAt(x: number): GapInfo | null {
    for (const g of this.gen.gaps) if (x > g.x0 && x < g.x1) return g;
    return null;
  }

  /* ================================================================ */
  /* Input                                                            */
  /* ================================================================ */

  private pressJump() {
    this.sfx.init();
    if (this.phase === 'menu') {
      this.start();
      return;
    }
    if (this.phase === 'over') {
      if (this.overTime > 0.6) this.restart();
      return;
    }
    if (this.phase === 'playing') {
      if (this.paused) {
        this.togglePause();
        return;
      }
      // If already high in the air, pressing Space again spins a super cool Skate Flip Freestyle!
      if (!this.grounded && this.coyote <= 0 && !this.grinding && this.airTime > 0.08) {
        const land = this.predictLanding();
        if (!land || land.t > 0.2) {
          this.pressTrick('flip');
          return;
        }
      }
      this.input.jump = true;
      this.jumpBuffer = 0.18;
    }
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.code;
    if (k === 'ArrowLeft' || k === 'ArrowRight' || k === 'ArrowUp' || k === 'ArrowDown' || k === 'Space') {
      e.preventDefault();
    }
    if (k === 'ArrowLeft' || k === 'KeyA') {
      this.input.left = true;
      this.sfx.init();
    } else if (k === 'ArrowRight' || k === 'KeyD') {
      this.input.right = true;
      this.sfx.init();
    } else if (k === 'Space' || k === 'ArrowUp' || k === 'KeyW') {
      if (!e.repeat) this.pressJump();
    } else if (k === 'KeyZ' || k === 'KeyJ' || k === 'KeyF') {
      if (!e.repeat) this.pressTrick('flip');
    } else if (k === 'KeyS' || k === 'ArrowDown') {
      if (!e.repeat) this.pressGrabPose();
    } else if (k === 'KeyX' || k === 'KeyK') {
      if (!e.repeat) this.pressGrabPose();
    } else if (k === 'KeyC' || k === 'KeyL') {
      if (!e.repeat) this.pressTrick('spin');
    } else if (k === 'Enter') {
      if (this.phase === 'menu') this.start();
      else if (this.phase === 'over' && this.overTime > 0.6) this.restart();
    } else if (k === 'KeyR') {
      if (this.phase === 'playing' || this.phase === 'over' || this.phase === 'crashed') this.restart();
    } else if (k === 'Escape' || k === 'KeyP') {
      this.togglePause();
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    const k = e.code;
    if (k === 'ArrowLeft' || k === 'KeyA') this.input.left = false;
    else if (k === 'ArrowRight' || k === 'KeyD') this.input.right = false;
    else if (k === 'Space' || k === 'ArrowUp' || k === 'KeyW') this.input.jump = false;
    else if (k === 'KeyS' || k === 'ArrowDown' || k === 'KeyX' || k === 'KeyK') this.holdGrab = false;
  };

  private onBlur = () => {
    this.input.left = this.input.right = this.input.jump = false;
    this.holdGrab = false;
  };

  private onVisibility = () => {
    if (document.hidden && this.phase === 'playing' && !this.paused) this.togglePause();
  };

  private onResize = () => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  /* ================================================================ */
  /* Main loop                                                        */
  /* ================================================================ */

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    let dt = (now - this.lastT) / 1000;
    this.lastT = now;
    if (!(dt > 0)) dt = 0;
    dt = Math.min(dt, 0.05);

    if (this.paused) {
      this.renderer.render(this.scene, this.camera);
      return;
    }
    this.realTime += dt;

    let timeScale = 1;
    if (this.slowmo > 0) {
      this.slowmo -= dt;
      timeScale = this.slowmo > 0.55 ? 0.24 : 0.24 + (1 - this.slowmo / 0.55) * 0.76;
    }
    const gdt = dt * timeScale;
    this.accum += gdt;
    let steps = 0;
    while (this.accum >= PHYS_DT && steps < 10) {
      this.fixedStep(PHYS_DT);
      this.accum -= PHYS_DT;
      steps++;
    }
    if (steps >= 10) this.accum = 0;
    const alpha = clamp(this.accum / PHYS_DT, 0, 1);

    const bp = this.board.getPosition();
    this.ensureTerrain(bp.x);
    this.updateVisuals(gdt, dt, alpha);
    this.renderer.render(this.scene, this.camera);
  };

  private fixedStep(dt: number) {
    const b = this.board;
    const bp = b.getPosition();
    this.bPrev.x = bp.x;
    this.bPrev.y = bp.y;
    this.bPrev.a = b.getAngle();
    for (const r of this.rag) {
      const p = r.body.getPosition();
      r.px = p.x;
      r.py = p.y;
      r.pa = r.body.getAngle();
    }

    if (this.phase === 'playing') this.controls(dt);

    const v0 = b.getLinearVelocity();
    this.prevVel.x = v0.x;
    this.prevVel.y = v0.y;

    this.world.step(dt, 8, 3);

    const v1 = b.getLinearVelocity();
    const k = 1 - Math.exp(-dt * 22);
    this.accS.x += ((v1.x - this.prevVel.x) / dt - this.accS.x) * k;
    this.accS.y += ((v1.y - this.prevVel.y) / dt - this.accS.y) * k;
    if (this.impactCooldown > 0) this.impactCooldown -= dt;
    if (this.boardClatterCooldown > 0) this.boardClatterCooldown -= dt;
    if (this.splashCooldown > 0) this.splashCooldown -= dt;

    this.updateFlyingCones(dt);

    if (this.phase === 'playing') this.afterStep(dt);
    else if (this.phase === 'crashed' || this.phase === 'over') this.ragdollPhysics(dt);
  }

  /* ================================================================ */
  /* Skating & Comfortable Auto-Landing                               */
  /* ================================================================ */

  private controls(dt: number) {
    const b = this.board;
    const v = b.getLinearVelocity();
    const vx = v.x;
    const vy = v.y;
    const ang = b.getAngle();
    const m = b.getMass();

    if (this.jumpBuffer > 0) this.jumpBuffer -= dt;
    if (this.jumpCooldown > 0) this.jumpCooldown -= dt;
    if (this.grinding) {
      if (this.jumpBuffer > 0) {
        this.jumpBuffer = 0;
        this.exitGrind(5.8);
      }
      return;
    }
    if (this.jumpBuffer > 0 && (this.grounded || this.coyote > 0) && this.jumpCooldown <= 0) {
      this.doJump();
      return;
    }

    if (this.coneSlowTimer > 0) this.coneSlowTimer = Math.max(0, this.coneSlowTimer - dt);

    const L = this.input.left;
    const R = this.input.right;
    if (this.grounded) {
      const bp = b.getPosition();
      const rInfo = this.onRamp ? this.rampAt(bp.x, bp.y) : null;
      const slope = rInfo ? rInfo.slope : ang;
      const tx = Math.cos(slope);
      const ty = Math.sin(slope);
      const s = vx * tx + vy * ty;
      // Smoothly recover from cone-hit slowdown over 0.85s, while keeping wooden jump ramps brisk!
      const rawTarget = R && !L ? BOOST_SPEED : L && !R ? (this.onRamp ? 10.5 : BRAKE_SPEED) : CRUISE_SPEED;
      const slowBlend = clamp(this.coneSlowTimer / 0.85, 0, 1);
      const slowedTarget = rawTarget * (1 - slowBlend * 0.52);
      const target = this.onRamp ? Math.max(12.6, slowedTarget) : slowedTarget;
      this.pushing = (R && !L) || s < target - 0.4;
      let a = 0;
      if (s < target) {
        a = (R ? BOOST_ACC : this.onRamp ? 16 : PUSH_ACC) * (1 - slowBlend * 0.35);
        if (s < 3.5) a += 6;
      } else if (L && s > target && !this.onRamp) {
        a = -BRAKE_ACC;
      }
      // Compensate uphill gravity along the tangent so hills & jump ramps NEVER stall!
      const uphillComp = slope > 0.03 ? GRAVITY * Math.sin(slope) * (this.onRamp ? 1.12 : 0.92) : 0;
      const totalAcc = a + uphillComp;
      if (totalAcc !== 0) {
        b.applyForceToCenter({ x: totalAcc * tx * m, y: totalAcc * ty * m }, true);
      }
    } else {
      this.pushing = false;
      this.landCacheAge += dt;
      if (this.landCacheAge > 0.025) {
        this.landCache = this.predictLanding();
        this.landCacheAge = 0;
      }
      const land = this.landCache;
      const nearGround = this.autoLand && land !== null && land.t < 0.28;

      if (L && !R && !nearGround) {
        // Backflip spin in air while safe clearance remains
        let w = b.getAngularVelocity();
        w += (ROT_SPEED - w) * Math.min(1, dt * 11);
        b.setAngularVelocity(w);
      } else {
        // Subtle forward air-drive if holding Right, plus silky-smooth Auto-Level Assist!
        if (R && !L && vx < BOOST_SPEED * 0.92) {
          b.applyForceToCenter({ x: 5.5 * m, y: 0 }, true);
        }
        this.levelAssist(dt, nearGround);
      }
    }

    const sp = Math.hypot(vx, vy);
    if (sp > 0.1) {
      const k = 0.003 * sp * m;
      b.applyForceToCenter({ x: -vx * k, y: -vy * k }, true);
    }
    if (sp > 30) b.setLinearVelocity({ x: (vx * 30) / sp, y: (vy * 30) / sp });
  }

  /** Ballistic prediction of where the board will touch down (skips gaps). */
  private predictLanding(): { x: number; slope: number; t: number } | null {
    const b = this.board;
    const p = b.getPosition();
    const v = b.getLinearVelocity();
    let x = p.x;
    let y = p.y;
    const vx = v.x;
    let vy = v.y;
    const st = 0.03;
    for (let t = st; t < 3.2; t += st) {
      vy -= GRAVITY * st;
      x += vx * st;
      y += vy * st;
      if (y < WATER_Y) return null;
      if (this.gapAt(x)) continue;
      const h = this.heightAt(x);
      if (y - RIDE_CLEAR < h + 0.06) {
        return { x, slope: this.slopeAtRoad(x), t };
      }
    }
    return null;
  }

  private landCache: { x: number; slope: number; t: number } | null = null;
  private landCacheAge = 99;

  /**
   * Smart Magnetic Auto-Landing Assist:
   * Guides the board upright from ANY angle (even inverted after a flip!)
   * so landings feel effortlessly smooth and satisfying instead of frustrating.
   */
  private levelAssist(dt: number, urgent = false) {
    const b = this.board;
    const land = this.landCache;
    const target = land ? land.slope : 0;
    const cur = b.getAngle();
    let diff = Math.atan2(Math.sin(target - cur), Math.cos(target - cur));
    let w = b.getAngularVelocity();

    if (!this.autoLand) {
      // Pro mode: gentle original assist only when nearly upright
      if (Math.abs(diff) < 1.15) {
        w += (diff * 4 - w) * Math.min(1, dt * 5);
        b.setAngularVelocity(clamp(w, -5, 5));
      }
      return;
    }

    // If spinning fast and past 130 deg, continue along spin momentum to finish the flip!
    if (Math.abs(diff) > 2.2 && Math.abs(w) > 3.2) {
      diff = w > 0 ? Math.abs(diff) : -Math.abs(diff);
    }

    const tRem = land ? land.t : 1.2;
    const close = urgent || tRem < 0.48;
    const maxW = close ? 12.5 : 8.5;
    const gainP = close ? 11.5 : 6.2;
    const blend = close ? 18 : 9;

    const desiredW = clamp(diff * gainP, -maxW, maxW);
    w += (desiredW - w) * Math.min(1, dt * blend);
    b.setAngularVelocity(w);

    // Extra soft angle glide in the final 0.16s before touchdown for pillow-soft landings!
    if (land && land.t < 0.16 && Math.abs(diff) < 1.8) {
      b.setAngle(cur + diff * Math.min(1, dt * 16));
    }
  }

  private doJump(boost = 1) {
    const b = this.board;
    const v = b.getLinearVelocity();
    const ang = b.getAngle();
    let dx = -Math.sin(ang) * 0.5;
    let dy = Math.cos(ang) * 0.52 + 0.48;
    const l = Math.hypot(dx, dy) || 1;
    dx /= l;
    dy /= l;
    let vx = v.x;
    let vy = v.y;
    const vn = vx * dx + vy * dy;
    if (vn < 0) {
      vx -= dx * vn;
      vy -= dy * vn;
    }
    const jSpd = JUMP_SPEED * boost * 1.05;
    vx += dx * jSpd;
    vy += dy * jSpd;
    b.setLinearVelocity({ x: vx, y: vy });
    b.setAngularVelocity(clamp(b.getAngularVelocity() * 0.35 + 0.32, -2.5, 2.5));
    this.landCacheAge = 99;
    if (this.grounded || this.coyote > 0) {
      this.takeoffX = b.getPosition().x;
      this.airRot = 0;
      this.flipsAnnounced = 0;
      this.airTricks = [];
      this.airPops = 0;
      this.maxAirClear = 0;
    }
    this.ollieAnim = 0.001;
    this.jumpBuffer = 0;
    this.coyote = 0;
    this.jumpCooldown = 0.22;
    this.grounded = false;
    this.onRamp = false;
    this.airTime = 0.001;
    this.rig_s.crouchV += 2.2;
    this.rig_s.squashV -= 2.8;
    this.sfx.pop(boost);
    this.dust(3.5);
    // Crisp white/gold tail-pop spark burst!
    const tail = b.getWorldPoint({ x: -DECK_HW * 0.9, y: -0.08 });
    this.particles.burst(tail.x, tail.y, 0.15, 7, [0xffe066, 0xffffff, 0xff9f1c], 2.6, {
      up: 1.1,
      life: 0.32,
      size: 0.08,
      gravity: 6,
      drag: 2.5,
    });
  }

  private scanContacts() {
    const b = this.board;
    let wheels = 0;
    let nx = 0;
    let ny = 0;
    let deck = false;
    let rampHit = false;
    this.wallHit = false;
    this.headHit = false;
    for (let ce = b.getContactList(); ce; ce = ce.next) {
      const c = ce.contact;
      if (!c.isTouching()) continue;
      const fa = c.getFixtureA();
      const fb = c.getFixtureB();
      const mineIsA = fa.getBody() === b;
      const mine = mineIsA ? fa : fb;
      const other = mineIsA ? fb : fa;
      const oud = other.getUserData();
      if (oud !== 'terrain' && oud !== 'ramp' && oud !== 'rail') continue;
      const isRamp = oud === 'ramp';
      const ud = mine.getUserData();
      const wm = c.getWorldManifold(null);
      let cnx = 0;
      let cny = 1;
      if (wm) {
        const s = mineIsA ? -1 : 1;
        cnx = wm.normal.x * s;
        cny = wm.normal.y * s;
      }
      if (ud === 'head') {
        if (!isRamp) this.headHit = true;
        continue;
      }
      if (!isRamp && cnx < -0.88) this.wallHit = true;
      if (ud === 'wheel') {
        if (cny > 0.25) {
          wheels++;
          nx += cnx;
          ny += cny;
          if (isRamp) rampHit = true;
        }
      } else if (ud === 'deck') {
        if (isRamp) rampHit = true;
        else deck = true;
      }
    }
    return { wheels, nx, ny, deck, rampHit };
  }

  /* ================================================================ */
  /* Road Cone Obstacles (Jump Bonus / Tip Kick / Non-Lethal Slowdown)*/
  /* ================================================================ */

  private kickCone(rc: RoadConeObj, vx: number, power = 1, sideBias = 0) {
    rc.state = 'hit';
    rc.vx = (Math.max(9.5, vx * 1.38) + Math.random() * 3.2) * power;
    rc.vy = (7.8 + Math.random() * 3.8) * power;
    const zSign = sideBias !== 0 ? sideBias : Math.random() < 0.5 ? 1 : -1;
    rc.vz = zSign * (1.8 + Math.random() * 2.6);
    rc.rx = (Math.random() - 0.5) * 22;
    rc.ry = (Math.random() - 0.5) * 18;
    rc.rz = -(13 + Math.random() * 12);
    this.sfx.coneBonk();
    this.particles.burst(rc.x, rc.y + 0.42, 0.2, 15, [0xff731d, 0xffffff, 0xffd23f], 4.8, {
      up: 2.5,
      life: 0.58,
      size: 0.115,
      gravity: 8.5,
      drag: 1.7,
    });
  }

  private updateFlyingCones(dt: number) {
    for (const pc of this.pieces) {
      for (const rc of pc.roadCones) {
        if (rc.state !== 'hit') continue;
        rc.vy -= GRAVITY * 1.08 * dt;
        rc.x += rc.vx * dt;
        rc.y += rc.vy * dt;
        const mz = rc.mesh.position.z + rc.vz * dt;
        rc.mesh.position.set(rc.x, rc.y, mz);
        rc.mesh.rotation.x += rc.rx * dt;
        rc.mesh.rotation.y += rc.ry * dt;
        rc.mesh.rotation.z += rc.rz * dt;
        if (Math.abs(mz) < 2.6 && !this.gapAt(rc.x)) {
          const gy = this.heightAt(rc.x);
          if (rc.y < gy + 0.2 && rc.vy < 0) {
            rc.y = gy + 0.2;
            rc.vy = -rc.vy * 0.54;
            rc.vx *= 0.78;
            rc.rx *= 0.76;
            rc.rz *= 0.76;
          }
        }
      }
    }
  }

  private checkRoadCones(px: number, py: number, vx: number, vy: number) {
    const footY = py - RIDE_CLEAR;
    for (const pc of this.pieces) {
      if (pc.data.minX > px + 3 || pc.data.maxX + 3 < px) continue;
      for (const rc of pc.roadCones) {
        if (rc.state !== 'idle') continue;
        const dx = px - rc.x;
        const clearH = footY - rc.y;

        // 1) Skater jumped cleanly over the cone!
        if (dx > 0.52 && dx < 3.2) {
          rc.state = 'cleared';
          if (!this.clearedConeGroups.has(rc.groupId) && (!this.grounded || this.maxAirClear > 0.25)) {
            this.clearedConeGroups.add(rc.groupId);
            const groupSize = pc.roadCones.filter((c) => c.groupId === rc.groupId).length;
            for (const sib of pc.roadCones) {
              if (sib.groupId === rc.groupId && sib.state === 'idle' && px > sib.x + 0.4) sib.state = 'cleared';
            }
            const basePts = groupSize > 1 ? 130 : 60;
            const mult = this.mult();
            const earned = basePts * mult;
            this.trickScore += earned;
            this.combo++;
            this.sfx.coneClear(groupSize);
            this.cb.onPopup(
              groupSize > 1 ? 'LOMPAT DOUBLE CONE!' : 'LOMPAT CONE!',
              'good',
              `+${earned}${mult > 1 ? ` (x${mult})` : ''}`,
            );
            this.particles.burst(rc.x, rc.y + 0.85, 0.2, 12, [0xffd23f, 0xffffff, 0xff7a1f], 3.5, {
              up: 2.2,
              life: 0.6,
              size: 0.11,
              gravity: 4,
              drag: 2,
            });
          }
          continue;
        }

        // 2) Horizontal overlap with the road cone
        if (Math.abs(dx) < 0.45) {
          if (clearH >= 0.62) {
            // Soaring cleanly above the cone — track max clearance!
            this.maxAirClear = Math.max(this.maxAirClear, clearH);
            continue;
          }
          if (clearH >= 0.25 || (!this.grounded && vy < -3.0 && this.airTime > 0.25)) {
            // Airborne tip-clip: kick the cone flying with bonus style & zero slowdown!
            this.kickCone(rc, vx, 1.25);
            this.clearedConeGroups.add(rc.groupId);
            const pts = 45 * this.mult();
            this.trickScore += pts;
            this.shake = Math.max(this.shake, 0.16);
            this.cb.onPopup('CONE KICK!', 'good', `+${pts}`);
            continue;
          }

          // 3) Rolled into the cone without jumping: NEVER crash!
          // Launch the cone(s) flying dramatically ("CONE MENTAL!") and slow the skater down!
          this.kickCone(rc, vx, 1.32, 1);
          for (const sib of pc.roadCones) {
            if (sib !== rc && sib.groupId === rc.groupId && sib.state === 'idle') {
              this.kickCone(sib, vx * 1.08, 1.28, -1);
            }
          }
          this.clearedConeGroups.add(rc.groupId);

          const b = this.board;
          const ang = b.getAngle();
          const curSpd = Math.hypot(vx, vy);
          const slowedSpd = clamp(curSpd * 0.45, 3.8, 5.4);
          if (this.grounded) {
            b.setLinearVelocity({ x: slowedSpd * Math.cos(ang), y: slowedSpd * Math.sin(ang) });
          } else {
            b.setLinearVelocity({ x: Math.max(3.8, vx * 0.52), y: Math.max(vy, 1.2) });
          }
          this.coneSlowTimer = 0.85;
          this.stuckTime = 0;
          // Fun, bouncy stumble wobble on the rider without falling!
          this.rig_s.leanV += 5.2;
          this.rig_s.squashV += 2.3;
          this.rig_s.crouchV -= 1.6;
          this.shake = Math.max(this.shake, 0.24);
          this.cb.onPopup('CONE MENTAL!', 'bad', 'LAJU MELAMBAT!');
        }
      }
    }
  }

  private afterStep(dt: number) {
    if (this.grinding) {
      this.grindFollow(dt);
      return;
    }
    if (!this.grounded) this.board.setAngularDamping(0.08);
    const b = this.board;
    const pos = b.getPosition();
    const px = pos.x;
    const py = pos.y;
    const v = b.getLinearVelocity();
    const { wheels, nx, ny, deck, rampHit } = this.scanContacts();
    const was = this.grounded;
    const wasOnRamp = this.onRamp;

    const rInfo = this.rampAt(px, py);
    this.onRamp = rampHit || (wheels > 0 && rInfo !== null && py >= rInfo.ramp.baseY + RIDE_CLEAR + 0.04);

    // True continuous surface slope: uses upward ramp tangent when on a ramp, or cliff-safe road slope otherwise!
    const slopeHere = this.onRamp && rInfo ? rInfo.slope : !this.gapAt(px) ? this.slopeAtRoad(px) : 0;
    let slopeDiff = Math.atan2(Math.sin(slopeHere - b.getAngle()), Math.cos(slopeHere - b.getAngle()));

    // Auto-land wheel recovery: ONLY when actually descending from air onto normal road (never on ramps!)
    let autoRecovered = false;
    if (
      wheels === 0 &&
      !was &&
      this.airTime > 0.16 &&
      v.y < 0.2 &&
      !this.onRamp &&
      rInfo === null &&
      (deck || this.headHit) &&
      this.autoLand &&
      !this.gapAt(px) &&
      Math.abs(slopeDiff) < 2.25
    ) {
      const surfY = this.heightAt(px);
      if (py >= surfY - 0.25) {
        b.setTransform({ x: px, y: Math.max(py, surfY + RIDE_CLEAR) }, slopeHere);
        b.setAngularVelocity(0);
        b.setLinearVelocity({ x: Math.max(v.x, 5.2) * Math.cos(slopeHere), y: Math.max(v.x, 5.2) * Math.sin(slopeHere) });
        slopeDiff = 0;
        this.headHit = false;
        autoRecovered = true;
      }
    }

    this.grounded = wheels > 0 || autoRecovered;

    // Anti-snag failsafe on wooden ramps: guarantee brisk upward/forward flow along the ramp curve!
    if (this.onRamp && rInfo) {
      const tx = Math.cos(rInfo.slope);
      const ty = Math.sin(rInfo.slope);
      const along = v.x * tx + v.y * ty;
      if (along < 9.5) {
        const boostSpd = 11.2;
        b.setLinearVelocity({ x: boostSpd * tx, y: boostSpd * ty });
      }
    }

    if (this.grounded) {
      const l = Math.hypot(nx, ny) || 1;
      this.groundN.x = wheels > 0 ? nx / l : -Math.sin(slopeHere);
      this.groundN.y = wheels > 0 ? ny / l : Math.cos(slopeHere);
      let sDiff = slopeHere - b.getAngle();
      sDiff = Math.atan2(Math.sin(sDiff), Math.cos(sDiff));
      b.setAngle(b.getAngle() + sDiff * Math.min(1, dt * 36));
      b.setAngularVelocity(0);
    } else if (wasOnRamp) {
      // Just launched off the lip of a wooden jump ramp! Give a clean, exhilarating skyward launch!
      const launchSlope = rInfo ? rInfo.ramp.exitAng : Math.max(0.38, b.getAngle());
      const tx = Math.cos(launchSlope);
      const ty = Math.sin(launchSlope);
      const curSpd = Math.hypot(v.x, v.y);
      const launchSpd = Math.max(12.8, curSpd * 1.04);
      b.setLinearVelocity({ x: Math.max(v.x, launchSpd * tx), y: Math.max(v.y, launchSpd * ty + 1.1) });
      b.setAngularVelocity(clamp(b.getAngularVelocity(), 0, 1.1));
      this.ollieAnim = 0.001;
      this.sfx.rampLaunch();
      this.particles.burst(px, py - 0.1, 0.2, 14, [0xffd23f, 0xffffff, 0xe0aa68], 3.8, {
        up: 1.8,
        life: 0.5,
        size: 0.11,
        gravity: 4,
        drag: 2.2,
      });
    }

    // Grind rail mount
    if (!this.grinding) {
      for (const pc of this.pieces) {
        if (pc.data.minX > px + 2 || pc.data.maxX + 2 < px) continue;
        for (const rail of pc.rails) {
          if (px < rail.x0 - 0.4 || px > rail.x1 + 0.4) continue;
          const ra = railAt(rail, px);
          const dy = py - (ra.y + RIDE_CLEAR);
          if (dy > -0.38 && dy < 0.58 && v.y < 4.2) {
            this.startGrind(rail);
            return;
          }
        }
      }
    }

    if (this.grounded) {
      if (!was && this.airTime > 0.13) {
        this.onLand();
        if (this.phase !== 'playing') return;
      }
      this.coyote = 0.15;
      this.airTime = 0;
      this.airPops = 0;
      this.ollieAnim = 0;
      this.groundTime += dt;
    } else {
      if (was) {
        this.takeoffX = px;
        this.airRot = 0;
        this.flipsAnnounced = 0;
        this.landCacheAge = 99;
        this.airTricks = [];
        this.airPops = 0;
        this.maxAirClear = 0;
      }
      this.coyote -= dt;
      this.airTime += dt;
      if (this.ollieAnim > 0) this.ollieAnim += dt;
      if (!this.gapAt(px)) {
        this.maxAirClear = Math.max(this.maxAirClear, py - RIDE_CLEAR - this.heightAt(px));
      }
      this.groundTime = 0;
      this.airRot += b.getAngularVelocity() * dt;
      const f = Math.floor((Math.abs(this.airRot) + 0.8) / TAU);
      if (f > this.flipsAnnounced) {
        this.flipsAnnounced = f;
        this.sfx.whoosh();
      }
    }

    // Road Cone obstacle checks!
    this.checkRoadCones(px, py, v.x, v.y);
    if (this.phase !== 'playing') return;

    // Crash checks (forgiving on slopes, strict on actual chasms & water!)
    const upY = Math.cos(b.getAngle());
    if (this.headHit && upY < (this.autoLand ? -0.58 : 0.15)) return this.crash('head');
    if (deck && upY < (this.autoLand ? -0.55 : 0.2)) return this.crash('head');
    if (this.wallHit && this.prevVel.x - v.x > 3.8 && (this.gapAt(px - 0.6) !== null || py < this.heightAt(px + 0.3) - 0.35)) {
      return this.crash('wall');
    }
    const gap = this.gapAt(px);
    if (gap && !this.grounded && py < Math.min(gap.y0, gap.y1) - 1.1) return this.crash('fall');
    if (py < WATER_Y + 0.5) return this.crash('water');
    const speed = Math.hypot(v.x, v.y);
    if (speed < 0.7) this.stuckTime += dt;
    else this.stuckTime = 0;
    if (this.stuckTime > 2.8) return this.crash('stuck');

    // Freestyle & Hold-Grab timing
    if (this.trick) {
      const def = this.trick.def;
      const land = this.landCache;
      const holdingS = this.holdGrab && def.family === 'grab' && (!land || land.t > 0.16);
      if (holdingS && this.trick.t >= def.dur * 0.48) {
        // Hold the peak Grab / Airwalk pose while S is held!
        this.trick.t = def.dur * 0.5;
        this.holdPhase += dt;
        this.trick.holdBonus = Math.min(120, this.trick.holdBonus + dt * 65);
      } else {
        this.trick.t += dt;
        this.holdPhase = Math.max(0, this.holdPhase - dt * 3);
      }
      // Mid-air foot catch effect at 80% of spinning skate tricks!
      if (def.boardSpin && !this.trick.caught && this.trick.t / def.dur >= 0.8) {
        this.trick.caught = true;
        this.sfx.deckCatch();
        this.rig_s.squashV += 1.4;
        this.triggerShockwave(0xffffff, 0.48);
        this.particles.burst(px, py + 0.15, 0.25, 10, [0xffffff, 0xffe066, this.trickColorHex], 2.8, {
          up: 0.7,
          life: 0.35,
          size: 0.095,
          gravity: 2,
          drag: 3,
        });
      }
      // If player queued another Freestyle click, chain seamlessly once past 55%!
      if (this.freestyleQueue && this.trick.t / def.dur >= 0.55) {
        this.freestyleQueue = false;
        this.completeTrick(false);
        this.startNextCycle(true);
      } else if (this.trick.t >= def.dur) {
        this.completeTrick();
      }
    }

    if (this.trickQueue) {
      this.trickQueueT += dt;
      if (!this.grounded && !this.trick && this.airTime > 0.02) {
        const f = this.trickQueue;
        this.trickQueue = null;
        this.startTrick(f);
      } else if (this.grounded && this.trickQueueT > 0.5) {
        this.trickQueue = null;
      }
    }
    if (this.freestyleQueue && !this.trick && !this.grounded && this.airTime > 0.02) {
      this.freestyleQueue = false;
      this.startNextCycle(true);
    }

    this.distance = Math.max(this.distance, px - this.startX);
    if (this.combo > 0 && this.grounded && this.groundTime > 5.0) this.combo = 0;

    // Speed dust trail
    if (this.grounded && speed > 10.5 && Math.random() < (speed - 10.5) * 0.028) {
      const wp = b.getWorldPoint({ x: -WHEEL_X, y: WHEEL_Y - WHEEL_R });
      this.particles.spawn({
        x: wp.x,
        y: wp.y + 0.05,
        z: (Math.random() - 0.5) * 0.5,
        vx: -v.x * 0.15 + (Math.random() - 0.5),
        vy: 0.6 + Math.random() * 0.8,
        vz: (Math.random() - 0.5) * 1.2,
        life: 0.5,
        size: 0.12,
        color: 0xe6dcc6,
        gravity: 1,
        drag: 3,
      });
    }

    // Ambient floating sakura petals in Sakura Valley!
    if (this.theme.id === 'sakura') {
      this.petalTimer -= dt;
      if (this.petalTimer <= 0) {
        this.petalTimer = 0.09;
        this.particles.spawn({
          x: px + 14 + (Math.random() - 0.5) * 18,
          y: py + 6 + Math.random() * 5,
          z: -2 + Math.random() * 4,
          vx: -2.2 - Math.random() * 1.5,
          vy: -0.9 - Math.random() * 0.6,
          vz: (Math.random() - 0.5) * 0.8,
          life: 4.2,
          size: 0.13,
          color: Math.random() < 0.5 ? 0xff9ebb : 0xffd1e1,
          gravity: 0.15,
          drag: 0.4,
          flat: true,
          sway: 4.5,
          spin: 3.5,
        });
      }
    }

    this.collectCoins(px, py, b.getAngle());
  }

  private mult() {
    return Math.min(8, 1 + this.combo);
  }

  private onLand() {
    const b = this.board;
    const px = b.getPosition().x;
    const slope = this.slopeAtRoad(px);
    const ang = b.getAngle();
    const ux = -Math.sin(ang);
    const uy = Math.cos(ang);
    const n = this.groundN;
    const dot = ux * n.x + uy * n.y;
    const diff = Math.acos(clamp(dot, -1, 1));
    const pv = this.prevVel;
    const impact = Math.max(0, -(pv.x * n.x + pv.y * n.y));

    if (this.wallHit && this.gapAt(px - 0.5) !== null) {
      this.crash('wall');
      return;
    }

    // Comfortable Auto-Landing: generous angle tolerance & smooth snap to slope!
    const maxSafeDiff = this.autoLand ? 2.42 : 1.42;
    if (diff > maxSafeDiff) {
      this.crash('landing');
      return;
    }
    if (diff > 0.35) {
      b.setAngle(slope);
      b.setAngularVelocity(0);
    }

    // Never punish players with frustrating mid-trick bails when autoLand is active!
    if (this.trick) {
      const prog = this.trick.t / this.trick.def.dur;
      if (prog >= 0.28 || this.autoLand) {
        if (prog >= 0.26) this.completeTrick();
        else {
          this.trick = null;
          this.pose = { ...ZERO_POSE };
        }
      } else {
        this.crash('bail');
        return;
      }
    }

    // Keep healthy forward roll momentum after landing!
    const curV = b.getLinearVelocity();
    if (curV.x < 5.5) {
      b.setLinearVelocity({ x: Math.max(curV.x, 5.8) * Math.cos(slope), y: Math.max(curV.x, 5.8) * Math.sin(slope) });
    }

    // Expressive landing suspension squash & rich dual-truck skate landing audio!
    const imp = Math.min(impact, 16);
    this.rig_s.crouchV -= imp * 0.14 + 0.9;
    this.rig_s.squashV += imp * 0.12 + 0.8;
    this.rig_s.leanV += (Math.random() - 0.5) * imp * 0.16;
    const clean = diff < 0.45;
    this.sfx.land(Math.max(2.2, impact), clean);
    this.dust(Math.max(2.5, impact));
    if (impact > 8.5) this.shake = Math.max(this.shake, Math.min(0.45, impact * 0.025));

    const rot = this.airRot;
    const flips = Math.floor((Math.abs(rot) + 0.85) / TAU);
    const gap = this.gen.gaps.find((g) => this.takeoffX < g.x0 + 0.6 && px > g.x1 - 0.3);
    let pts = 0;
    let title = '';
    if (flips > 0) {
      const name = rot > 0 ? 'BACKFLIP' : 'FRONTFLIP';
      const pre = flips === 1 ? '' : flips === 2 ? 'DOUBLE ' : flips === 3 ? 'TRIPLE ' : `${flips}x `;
      pts += [0, 150, 400, 800, 1400][Math.min(flips, 4)] + Math.max(0, flips - 4) * 700;
      title = `${pre}${name}!`;
      this.flipsTotal += flips;
    }
    if (gap) {
      pts += 100 + Math.round((gap.x1 - gap.x0) * 12);
      if (!title) title = 'LOMPAT JURANG!';
    }
    if (this.airTricks.length) {
      pts += this.airTricks.reduce((a, d) => a + d.pts, 0);
      const names = this.airTricks.map((d) => d.name);
      const tt = names.length === 1 ? names[0] : names.length === 2 ? `${names[0]} + ${names[1]}` : `${names.length}x TRIK COMBO`;
      title = title ? `${title.replace(/!$/, '')} + ${names.length > 1 ? names.length + ' TRIK' : names[0]}!` : `${tt}!`;
      this.airTricks = [];
    }
    if (this.airTime > 1.1) {
      pts += Math.round(this.airTime * 45);
      if (!title) title = `TERBANG ${this.airTime.toFixed(1)}s!`;
    }
    const perfect = diff < 0.34;
    if (pts > 0) {
      if (perfect) pts += 75;
      const mult = this.mult();
      const total = pts * mult;
      this.trickScore += total;
      this.combo++;
      const extras: string[] = [];
      if (flips > 0 && gap) extras.push('+ JURANG');
      if (flips > 0 && this.airTime > 1.1) extras.push(`AIR ${this.airTime.toFixed(1)}s`);
      this.cb.onPopup(
        title,
        'trick',
        `+${total}${mult > 1 ? `  (x${mult})` : ''}${extras.length ? '  ' + extras.join(' ') : ''}`,
      );
      this.sfx.trick(flips);
      if (perfect) {
        this.cb.onPopup('PERFECT LAND!', 'perfect');
        this.sfx.perfect();
        const fx = Math.cos(slope);
        const fy = Math.sin(slope);
        const v = b.getLinearVelocity();
        b.setLinearVelocity({ x: v.x + fx * 1.8, y: v.y + fy * 1.8 });
        const p = b.getPosition();
        this.particles.burst(p.x, p.y + 0.6, 0, 16, [0xffe066, 0xffffff, 0x7fe3ff], 4.2, {
          up: 2.2,
          life: 0.7,
          size: 0.12,
          gravity: 4,
          drag: 2,
        });
      }
    } else if (!this.autoLand && diff > 0.62) {
      this.cb.onPopup('NYARIS!', 'bad');
      this.rig_s.leanV += 3 * (Math.random() < 0.5 ? -1 : 1);
    }
  }

  private collectCoins(px: number, py: number, ang: number) {
    const cx = px - Math.sin(ang) * 0.65;
    const cy = py + Math.cos(ang) * 0.65;
    for (const p of this.pieces) {
      if (p.data.minX > cx + 2 || p.data.maxX + 22 < cx) continue;
      for (const c of p.coins) {
        if (c.taken) continue;
        const dx = c.x - cx;
        if (dx > 1.15 || dx < -1.15) continue;
        const dy = c.y - cy;
        if (dx * dx + dy * dy < 1.02 * 1.02) {
          c.taken = true;
          c.mesh.visible = false;
          this.coinCount++;
          if (this.realTime - this.lastCoinT < 0.75) this.coinChain = Math.min(this.coinChain + 1, 12);
          else this.coinChain = 0;
          this.lastCoinT = this.realTime;
          this.sfx.coin(1 + this.coinChain * 0.06);
          this.particles.burst(c.x, c.y, 0, 7, [0xffe066, 0xffc61a, 0xffffff], 3, {
            up: 1.5,
            life: 0.5,
            size: 0.1,
            gravity: 5,
            drag: 2,
          });
        }
      }
    }
  }

  private dust(impact: number) {
    const b = this.board;
    const n = Math.min(16, 4 + Math.floor(impact * 0.85));
    for (const wx of [-WHEEL_X, WHEEL_X]) {
      const wp = b.getWorldPoint({ x: wx, y: WHEEL_Y - WHEEL_R });
      this.particles.burst(wp.x, wp.y + 0.05, 0, n, [0xe2d3b3, 0xcdb994, 0xf2eadb], 1.6 + impact * 0.19, {
        up: 0.9,
        life: 0.62,
        size: 0.15,
        gravity: 3,
        drag: 3.4,
        spread: 0.3,
      });
    }
  }

  private feathers(x: number, y: number, n: number, power: number) {
    const cols = this.rig ? this.rig.def.fx.map((c) => new THREE.Color(c).getHex()) : [0xffffff];
    this.particles.burst(x, y, 0.2, n, cols, power, {
      up: 2.3,
      life: 2.5,
      size: 0.17,
      gravity: 2.1,
      drag: 2.2,
      flat: true,
      sway: 7.5,
      spin: 5.5,
      spread: 0.55,
    });
  }

  private splash(x: number, n: number) {
    this.particles.burst(x, WATER_Y + 0.1, 0.6, n, [0xffffff, 0xc4ecff, 0x84d6ff], 5, {
      up: 5,
      life: 1.1,
      size: 0.2,
      gravity: 15,
      drag: 0.6,
      spread: 0.7,
    });
  }

  /* ================================================================ */
  /* Upgraded Expressive Ragdoll & Wipeouts                           */
  /* ================================================================ */

  private crash(reason: CrashReason) {
    if (this.phase !== 'playing') return;
    this.phase = 'crashed';
    this.crashReason = reason;
    this.crashTimer = 0;
    this.holdGrab = false;
    this.trails.clear();
    this.cb.onPhase('crashed');

    const b = this.board;
    const v = b.getLinearVelocity();
    const pv = this.prevVel;
    const useV = pv.x * pv.x + pv.y * pv.y > v.x * v.x + v.y * v.y ? { x: pv.x, y: pv.y } : { x: v.x, y: v.y };
    const w = b.getAngularVelocity();
    const center = { x: b.getWorldCenter().x, y: b.getWorldCenter().y };
    const launch = reason === 'water' ? 0.3 : reason === 'fall' ? 0.55 : reason === 'cone' ? 1.18 : 1.05;
    const base = {
      x: useV.x * (0.85 + 0.22 * launch) + (reason === 'cone' ? 2.2 : 0),
      y: Math.max(useV.y, 0) + 4.2 * launch,
    };

    const R = this.rig;
    // Preserve natural rider orientation (only remove scale squash) so ragdoll launches seamlessly!
    this.trick = null;
    this.pose = { ...ZERO_POSE };
    this.smoothPose = { ...ZERO_POSE };
    this.carrySpin = { flip: 0, boardYaw: 0, boardPitch: 0, yaw: 0 };
    this.rig_s.squash = 0;
    this.rig_s.flap = 0.75;
    this.rig_s.push = -1;
    const savedYaw = this.bodyYaw;
    const savedHead = this.headYawW;
    this.bodyYaw = 0;
    this.headYawW = 0;
    this.applyRig();
    this.riderRoot.updateMatrixWorld(true);
    this.bodyYaw = savedYaw;
    this.headYawW = savedHead;

    const wpos = new THREE.Vector3();
    const wq = new THREE.Quaternion();
    const wsc = new THREE.Vector3();
    const tumbleSpin = clamp(w, -8, 8) + (reason === 'cone' ? -7.5 : (Math.random() < 0.5 ? -1 : 1) * 6.5);

    const mk = (seg: SegName, kind: RagPart['kind'], density: number, extraSpin = 0) => {
      const mesh = R.meshes[seg];
      mesh.matrixWorld.decompose(wpos, wq, wsc);
      const e = mesh.matrixWorld.elements;
      let ang = Math.atan2(-e[4], e[5]);
      if (Math.hypot(e[4], e[5]) < 0.25 * Math.max(0.01, wsc.y)) ang = Math.atan2(e[1], e[0]);
      const qRes = new THREE.Quaternion().setFromAxisAngle(Z_AXIS, -ang).multiply(wq);
      this.scene.add(mesh);
      mesh.position.copy(wpos);
      mesh.quaternion.copy(wq);
      mesh.scale.set(1, 1, 1);
      const bx = R.boxes[seg];
      return this.makeRag(
        { x: wpos.x, y: wpos.y, a: ang },
        mesh,
        wpos.z,
        kind,
        bx.hw,
        bx.hh,
        bx.cx,
        bx.cy,
        density,
        base,
        tumbleSpin + extraSpin,
        center,
        qRes,
      );
    };

    const torso = mk('torso', 'torso', 1.05, 0);
    const head = mk('head', 'head', 0.85, (Math.random() - 0.5) * 8);
    const wingN = mk('armN', 'wing', 0.35, 11);
    const wingF = mk('armF', 'wing', 0.35, -11);
    const legN = mk('legN', 'leg', 0.55, 8);
    const legF = mk('legF', 'leg', 0.55, -8);

    this.airTricks = [];
    const joint = (a: Body, bb: Body, lo: number, hi: number, motorSpeed = 0, maxTorque = 0.8) => {
      this.world.createJoint(
        new RevoluteJoint(
          {
            enableLimit: true,
            lowerAngle: lo,
            upperAngle: hi,
            enableMotor: maxTorque > 0,
            motorSpeed,
            maxMotorTorque: maxTorque,
          },
          a,
          bb,
          bb.getPosition(),
        ),
      );
    };
    // Articulated springy joints with wider, funnier ragdoll range!
    joint(torso.body, head.body, -1.05, 1.05, 0, 0.5);
    joint(torso.body, wingN.body, -1.4, 2.8, 2.5, 0.35);
    joint(torso.body, wingF.body, -1.4, 2.8, -2.5, 0.35);
    joint(torso.body, legN.body, -1.85, 1.85, 1.5, 0.45);
    joint(torso.body, legF.body, -1.85, 1.85, -1.5, 0.45);

    if (this.headFix) {
      b.destroyFixture(this.headFix);
      this.headFix = null;
    }
    for (const f of this.wheelFix) f.setFriction(0.45);
    // Pop & tumble the skateboard itself in 3D when crashing!
    b.setLinearVelocity({ x: useV.x * 0.55 - 1.2, y: Math.max(2.8, useV.y * 0.5 + 3.4) });
    b.setAngularVelocity((Math.random() < 0.5 ? 1 : -1) * (9 + Math.random() * 7));
    this.boardTumble = {
      rx: 0,
      ry: 0,
      vx: (Math.random() < 0.5 ? 1 : -1) * (11 + Math.random() * 6),
      vy: (Math.random() - 0.5) * 9,
    };

    if (R.eyes) R.eyes.visible = false;
    if (R.deadEyes) R.deadEyes.visible = true;
    this.dizzyGroup.visible = true;

    const tp = torso.body.getPosition();
    this.feathers(tp.x, tp.y + 0.35, 32, 5.8);
    // Comic impact star sparks!
    this.particles.burst(tp.x, tp.y + 0.4, 0.35, 16, [0xffe066, 0xff5a36, 0xffffff], 5.2, {
      up: 2.5,
      life: 0.75,
      size: 0.14,
      gravity: 8,
      drag: 1.6,
    });
    this.sfx.crash();
    this.sfx.squawk();
    if (reason === 'water') {
      this.sfx.splash();
      this.splash(tp.x, 32);
    }
    this.slowmo = 1.05;
    this.shake = 0.75;
    this.combo = 0;

    const msgs: Record<CrashReason, string[]> = {
      head: ['AYAM GEPREK!', 'BRUAKK!', 'ADUH BIYUNG!', 'KWEKK!'],
      landing: ['SALAH MENDARAT!', 'KRAKK!', 'TERPELANTING!'],
      wall: ['NABRAK TEBING!', 'DUAKK!', 'GEDUBRAK!'],
      fall: ['JATUH KE JURANG!', 'WADUHHH!', 'TOLOOONG!'],
      water: ['BYURR!', 'BASAH KUYUP!'],
      stuck: ['NYANGKUT!', 'MACET!'],
      bail: ['GAGAL TRIK!', 'KESELEO!'],
      cone: ['TERSANDUNG CONE!', 'NABRAK CONE!', 'BONKK! AWAS CONE!'],
    };
    this.cb.onPopup(pick(msgs[reason]), 'crash');
  }

  private makeRag(
    pose: Pose,
    mesh: THREE.Mesh,
    z: number,
    kind: RagPart['kind'],
    hw: number,
    hh: number,
    cx: number,
    cy: number,
    density: number,
    baseV: { x: number; y: number },
    w: number,
    center: { x: number; y: number },
    qRes: THREE.Quaternion,
  ): RagPart {
    const body = this.world.createBody({
      type: 'dynamic',
      position: { x: pose.x, y: pose.y },
      angle: pose.a,
      linearDamping: 0.05,
      angularDamping: 0.22,
      bullet: true,
    });
    body.createFixture({
      shape: new Box(hw, hh, { x: cx, y: cy }, 0),
      density,
      friction: 0.55,
      restitution: kind === 'head' || kind === 'torso' ? 0.44 : 0.36,
      filterGroupIndex: -1,
      userData: 'rag',
    });
    const rx = pose.x - center.x;
    const ry = pose.y - center.y;
    body.setLinearVelocity({
      x: baseV.x - w * 0.25 * ry + (Math.random() - 0.5) * 1.4,
      y: baseV.y + w * 0.25 * rx + (Math.random() - 0.5) * 1.4,
    });
    body.setAngularVelocity(w);
    mesh.scale.set(1, 1, 1);
    const vz = (Math.random() - 0.5) * 0.8;
    const part: RagPart = { body, mesh, z, vz, kind, qRes, inWater: false, px: pose.x, py: pose.y, pa: pose.a };
    this.rag.push(part);
    return part;
  }

  /* ================================================================ */
  /* Grind rails (50-50 / boardslide / lipslide / feeble)             */
  /* ================================================================ */

  private startGrind(rail: RailInfo) {
    const roll = Math.random();
    const style: GrindStyle = roll < 0.5 ? 'fifty' : roll < 0.72 ? 'boardslide' : roll < 0.86 ? 'lipslide' : 'feeble';
    this.grinding = { rail, style, dist: 0, pts: 0 };
    this.grindStyle = style;
    this.board.setType('kinematic');
    if (this.trick && this.trick.t / this.trick.def.dur >= 0.35) this.completeTrick();
    else this.trick = null;
    this.trickQueue = null;
    this.trails.updateVortex(0, 0, 0, 0);
    this.cb.onPopup('GRIND!', 'good', { fifty: '50-50', boardslide: 'BOARDSLIDE', lipslide: 'LIPSLIDE', feeble: 'FEEBLE' }[style]);
    this.sfx.grindStart();
    this.shake = Math.max(this.shake, 0.15);
  }

  private grindFollow(dt: number) {
    const g = this.grinding!;
    const b = this.board;
    const p = b.getPosition();
    const v = b.getLinearVelocity();
    const ra = railAt(g.rail, p.x);
    b.setTransform({ x: p.x, y: ra.y + RIDE_CLEAR }, ra.ang);
    const vx = Math.max(4.5, v.x * (1 - 0.05 * dt));
    b.setLinearVelocity({ x: vx, y: Math.tan(ra.ang) * vx });
    b.setAngularVelocity(0);
    this.grounded = true;
    this.groundN.x = -Math.sin(ra.ang);
    this.groundN.y = Math.cos(ra.ang);
    g.dist += vx * dt;
    g.pts += vx * dt * 3.5;
    if (Math.random() < 0.75) {
      const wp = b.getWorldPoint({ x: -WHEEL_X, y: WHEEL_Y - WHEEL_R });
      this.particles.spawn({
        x: wp.x,
        y: wp.y + 0.05,
        z: 0.25,
        vx: -vx * 0.25 + (Math.random() - 0.5) * 2,
        vy: 1.2 + Math.random() * 2.2,
        vz: (Math.random() - 0.5) * 2,
        life: 0.35,
        size: 0.075,
        color: Math.random() < 0.5 ? 0xffd23f : 0xffffff,
        gravity: 10,
        drag: 1,
      });
    }
    this.distance = Math.max(this.distance, p.x - this.startX);
    this.collectCoins(p.x, p.y, b.getAngle());
    if (p.x >= g.rail.x1 - 0.15) this.exitGrind(3.0);
  }

  private exitGrind(pop: number) {
    const g = this.grinding;
    if (!g) return;
    this.grinding = null;
    const b = this.board;
    b.setType('dynamic');
    const v = b.getLinearVelocity();
    b.setLinearVelocity({ x: v.x, y: pop });
    b.setAngularVelocity(0);
    this.grounded = false;
    this.airTime = 0.001;
    this.ollieAnim = 0.001;
    this.takeoffX = b.getPosition().x;
    this.airRot = 0;
    this.flipsAnnounced = 0;
    this.airTricks = [];
    const pts = Math.round(g.pts);
    if (pts > 0) {
      this.trickScore += pts;
      this.combo++;
      this.cb.onPopup(`GRIND +${pts}`, 'trick');
    }
    this.sfx.pop(0.9);
  }

  private onPostSolve = (contact: Contact, impulse: ContactImpulse) => {
    if (this.phase !== 'crashed' && this.phase !== 'over') return;
    const fa = contact.getFixtureA();
    const fb = contact.getFixtureB();
    const ua = fa.getUserData();
    const ub = fb.getUserData();
    const ni = impulse.normalImpulses[0] ?? 0;

    // Detached skateboard clattering on pavement!
    if ((ua === 'deck' || ua === 'wheel' || ub === 'deck' || ub === 'wheel') && (ua === 'terrain' || ub === 'terrain')) {
      if (ni > 0.6 && this.boardClatterCooldown <= 0) {
        this.boardClatterCooldown = 0.14;
        this.sfx.boardClatter(ni);
        this.boardTumble.vx *= 0.55;
        this.boardTumble.vy *= 0.55;
      }
      return;
    }

    if (ua !== 'rag' && ub !== 'rag') return;
    if (ua !== 'terrain' && ub !== 'terrain') return;
    if (ni < 0.32 || this.impactCooldown > 0) return;
    this.impactCooldown = 0.095;
    const body = (ua === 'rag' ? fa : fb).getBody();
    const p = body.getPosition();
    this.sfx.thud(ni);
    // Add lively bounce spin & dust puffs on ragdoll impacts!
    if (ni > 0.55) {
      this.feathers(p.x, p.y + 0.2, Math.min(14, 3 + Math.floor(ni * 3)), 2.6 + ni);
      this.particles.burst(p.x, p.y + 0.08, 0.1, 6, [0xe2d3b3, 0xf2eadb], 2 + ni * 0.4, {
        up: 0.9,
        life: 0.45,
        size: 0.13,
        gravity: 3,
        drag: 3,
      });
    }
    if (ni > 1.2) this.shake = Math.max(this.shake, Math.min(0.42, ni * 0.12));
  };

  private ragdollPhysics(dt: number) {
    for (const r of this.rag) {
      r.z = clamp(r.z + r.vz * dt, -0.65, 0.85);
      r.vz *= Math.max(0, 1 - dt * 2.5);
      const entered = this.buoy(r.body, r.inWater, dt);
      if (entered) {
        r.inWater = true;
        if ((r.kind === 'torso' || r.kind === 'head') && this.splashCooldown <= 0) {
          this.splashCooldown = 0.25;
          this.splash(r.body.getPosition().x, 26);
          this.sfx.splash();
        }
      }
    }
    // Decay 3D skateboard crash tumble
    this.boardTumble.rx += this.boardTumble.vx * dt;
    this.boardTumble.ry += this.boardTumble.vy * dt;
    const damp = Math.max(0, 1 - dt * 1.8);
    this.boardTumble.vx *= damp;
    this.boardTumble.vy *= damp;
    if (Math.abs(this.boardTumble.vx) < 0.4) {
      this.boardTumble.rx *= Math.max(0, 1 - dt * 5);
    }

    if (this.buoy(this.board, this.boardInWater, dt)) {
      this.boardInWater = true;
      this.splash(this.board.getPosition().x, 14);
    }
  }

  private buoy(body: Body, wasIn: boolean, dt: number): boolean {
    const p = body.getPosition();
    const depth = WATER_Y - p.y + 0.15;
    if (depth <= 0) return false;
    const m = body.getMass();
    body.applyForceToCenter({ x: 0, y: m * GRAVITY * (1 + Math.min(depth, 0.8) * 2.4) }, true);
    const v = body.getLinearVelocity();
    const k = Math.max(0, 1 - dt * 3.5);
    body.setLinearVelocity({ x: v.x * k, y: v.y * k });
    body.setAngularVelocity(body.getAngularVelocity() * Math.max(0, 1 - dt * 2));
    return !wasIn;
  }

  private toOver() {
    this.phase = 'over';
    this.overTime = 0;
    const score = this.score();
    const newBest = score > this.best;
    if (newBest) {
      this.best = score;
      try {
        localStorage.setItem(BEST_KEY, String(score));
      } catch {
        /* ignore */
      }
    }
    this.emitHud();
    this.cb.onPhase('over', {
      score,
      distance: Math.floor(this.distance),
      coins: this.coinCount,
      best: this.best,
      newBest,
      reason: this.crashReason,
      flips: this.flipsTotal,
    });
  }

  private score() {
    return Math.floor(this.distance) + this.trickScore + this.coinCount * 25;
  }

  private emitHud() {
    const v = this.board ? this.board.getLinearVelocity() : { x: 0, y: 0 };
    this.cb.onHud({
      score: this.score(),
      distance: Math.floor(this.distance),
      coins: this.coinCount,
      combo: this.combo > 0 ? this.mult() : 1,
      best: this.best,
      speed: Math.hypot(v.x, v.y),
      autoLand: this.autoLand,
    });
  }

  /* ================================================================ */
  /* Visuals & Upgraded Character / Skateboard Animations             */
  /* ================================================================ */

  private updateRig(dt: number, speed: number) {
    if (dt <= 0) return;
    const r = this.rig_s;
    const b = this.board;
    const ang = b.getAngle();
    const c = Math.cos(ang);
    const s = Math.sin(ang);
    const fxw = this.accS.x;
    const fyw = this.accS.y + GRAVITY;
    const flx = c * fxw + s * fyw;
    const fly = -s * fxw + c * fyw;
    const menu = this.phase === 'menu';
    const t = this.realTime;

    let crouchT = clamp(-(fly - GRAVITY) * 0.006, -0.14, 0.06);
    if (r.push >= 0 && this.grounded) crouchT -= 0.032;
    if (this.input.right && this.grounded && !menu) crouchT -= 0.04; // aerodynamic speed tuck when boosting!
    if (!this.grounded && !menu) {
      crouchT += clamp(b.getLinearVelocity().y * 0.009, -0.05, 0.06);
    }
    if (menu) crouchT = Math.sin(t * 2.6) * 0.02;
    r.crouchV += ((crouchT - r.crouch) * 175 - r.crouchV * 13.5) * dt;
    r.crouch = clamp(r.crouch + r.crouchV * dt, -0.17, 0.1);

    let leanT = clamp(flx * 0.018, -0.45, 0.45);
    if (this.input.right && this.grounded && !menu) leanT -= 0.12; // forward boost lean
    if (!this.grounded && !menu) {
      if (this.input.left) leanT += 0.26;
      if (this.input.right) leanT -= 0.18;
      leanT += clamp(-b.getLinearVelocity().y * 0.01, -0.16, 0.16);
    }
    if (menu) leanT = Math.sin(t * 1.3) * 0.05;
    r.leanV += ((leanT - r.lean) * 85 - r.leanV * 8.5) * dt;
    r.lean = clamp(r.lean + r.leanV * dt, -0.7, 0.7);

    const headT = -r.leanV * 0.07 + (menu ? Math.sin(t * 1.7) * 0.14 : 0) + (!this.grounded && !menu ? 0.12 : 0);
    r.headV += ((headT - r.head) * 140 - r.headV * 9) * dt;
    r.head = clamp(r.head + r.headV * dt, -0.55, 0.55);

    r.squashV += (-r.squash * 280 - r.squashV * 9.5) * dt;
    r.squash = clamp(r.squash + r.squashV * dt, -0.24, 0.34);

    const air = !this.grounded && !menu;
    const spinning = air && this.input.left;
    r.flapPhase += dt * (air ? 26 : 10);
    let flapT: number;
    if (spinning) flapT = 1.25 + Math.sin(r.flapPhase) * 0.15;
    else if (air) flapT = 0.62 + Math.sin(r.flapPhase) * 0.48;
    else if (menu) flapT = Math.sin(t * 0.9) > 0.92 ? 0.7 + Math.sin(r.flapPhase * 2.4) * 0.5 : 0.08;
    else flapT = 0.08 + Math.abs(Math.sin(r.flapPhase)) * Math.min(0.16, speed * 0.01);
    r.flap += (flapT - r.flap) * Math.min(1, dt * 18);

    if (r.push >= 0) {
      r.push += dt / 0.4;
      if (r.push >= 1) r.push = this.grounded && this.phase === 'playing' && speed > 1.5 ? 0 : -1;
    } else if (this.grounded && this.phase === 'playing' && speed > 1.5) {
      r.push = 0;
    }

    const wantYaw = r.push >= 0 || !this.grounded || this.grinding ? 0 : -1.15;
    this.bodyYaw += (wantYaw - this.bodyYaw) * Math.min(1, dt * 6.5);
    this.headTimer -= dt;
    if (this.headTimer <= 0) {
      this.headTimer = 1.5 + Math.random() * 3.5;
      this.headTarget = Math.random() < 0.15 ? -1.15 : 0;
    }
    if (this.pushing || !this.grounded || this.grinding) this.headTarget = 0;
    this.headYawW += (this.headTarget - this.headYawW) * Math.min(1, dt * 3);

    r.blinkT -= dt;
    if (r.blinkT <= 0) {
      r.blink = 0.12;
      r.blinkT = 2 + Math.random() * 3;
    }
    if (r.blink > 0) r.blink -= dt;
  }

  private blendSmoothPose(dt: number) {
    const P = this.pose;
    const S = this.smoothPose;
    const k = dt > 0 ? 1 - Math.exp(-dt * 28) : 1;
    S.grab += (P.grab - S.grab) * k;
    S.trickPitch += (P.trickPitch - S.trickPitch) * k;
    S.boardLift += (P.boardLift - S.boardLift) * k;
    S.boardShiftX += (P.boardShiftX - S.boardShiftX) * k;
    S.hop += (P.hop - S.hop) * k;
    S.lift += (P.lift - S.lift) * k;
    S.legNAng += (P.legNAng - S.legNAng) * k;
    S.legFAng += (P.legFAng - S.legFAng) * k;
    S.legNTuck += (P.legNTuck - S.legNTuck) * k;
    S.legFTuck += (P.legFTuck - S.legFTuck) * k;
    S.armNPitch += (P.armNPitch - S.armNPitch) * k;
    S.armNRoll += (P.armNRoll - S.armNRoll) * k;
    S.armFPitch += (P.armFPitch - S.armFPitch) * k;
    S.armFRoll += (P.armFRoll - S.armFRoll) * k;
    S.spinGlow += (P.spinGlow - S.spinGlow) * (dt > 0 ? 1 - Math.exp(-dt * 20) : 1);
    const residualLimb =
      Math.abs(S.legNAng) +
      Math.abs(S.legFAng) +
      Math.abs(S.legNTuck) +
      Math.abs(S.armNPitch) +
      Math.abs(S.armFPitch);
    S.hasCustomLimbs = P.hasCustomLimbs || residualLimb > 0.03;

    const cd = dt > 0 ? Math.exp(-dt * 18) : 0;
    this.carrySpin.flip *= cd;
    this.carrySpin.boardYaw *= cd;
    this.carrySpin.boardPitch *= cd;
    this.carrySpin.yaw *= cd;
  }

  /** Pose the rider & skateboard scene graph: Ollie pop curve + 3D Freestyle Aura + Iconic Grab / Airwalk poses */
  private applyRig() {
    const r = this.rig_s;
    const R = this.rig;
    const P = this.pose;
    const S = this.smoothPose;
    const t = this.realTime;
    const g = S.grab;
    const tr = this.trick;
    const tk = tr ? tr.def.kind : null;

    // Authentic Ollie nose-pop & level-out wave on every jump!
    let olliePitch = 0;
    let ollieHop = 0;
    if (this.ollieAnim > 0 && this.ollieAnim < 0.44 && !this.trick && !this.grinding) {
      const u = this.ollieAnim / 0.44;
      olliePitch = Math.sin(u * Math.PI * 1.35) * (1 - u * 0.65) * 0.34;
      ollieHop = Math.sin(u * Math.PI) * 0.12;
    }

    this.spinG.rotation.set(0, P.yaw + this.carrySpin.yaw, 0);
    this.facingG.rotation.y = this.bodyYaw;

    const grabLift = g > 0 ? g * 0.24 : 0;
    const grabTuck = g < 0 ? -g * 0.16 : 0;
    const bob = this.boardVis.float ? Math.sin(t * 4.5) * 0.035 : 0;

    const deckY = S.boardLift + grabLift + grabTuck + bob + ollieHop * 0.5;
    this.boardTrickG.position.set(
      S.boardShiftX + (g > 0 ? -g * 0.18 : 0),
      deckY,
      0,
    );
    this.boardTrickG.rotation.set(
      P.flip + this.carrySpin.flip + (g > 0 ? g * 0.7 : 0),
      P.boardYaw + this.carrySpin.boardYaw,
      P.boardPitch + this.carrySpin.boardPitch + olliePitch + (g < 0 ? g * 0.28 : 0),
    );

    // Smooth Curved Anime Comet-Slash Vortex & Deck Spin Glow (zero blocky polygons!)
    const glow = this.grinding ? 0 : S.spinGlow;
    this.trails.updateVortex(t, glow, deckY, S.lift, tr ? tr.dir : 1);

    if (this.grinding) {
      const st = this.grindStyle;
      if (st === 'boardslide') this.boardTrickG.rotation.y = Math.PI / 2;
      else if (st === 'lipslide') {
        this.boardTrickG.rotation.y = -Math.PI / 2;
        this.boardTrickG.rotation.z += 0.22;
      } else if (st === 'feeble') {
        this.boardTrickG.rotation.y = -0.7;
        this.boardTrickG.rotation.z += 0.18;
      }
    }

    // Rider body center pivot
    const lift = this.boardVis.float ? 0.12 : 0;
    const cy = R.legLen + Math.min(0.45, R.height * 0.32);
    const crouchG = Math.abs(g) * 0.1;
    this.riderTiltG.position.set(0, DECK_HH + lift + bob + S.hop + ollieHop + grabLift + grabTuck - crouchG + cy + S.lift, 0);
    this.riderTiltG.rotation.set(P.trickRoll, 0, S.trickPitch + P.salto);
    this.riderOffG.position.set(0, -cy, 0);

    const pushDip = r.push >= 0 ? 0.07 : 0;
    const hipY = R.legLen + r.crouch - pushDip;
    this.hipG.position.set(0, hipY, 0);
    this.hipG.rotation.set(0, 0, r.lean);
    const sq = r.squash;
    this.hipG.scale.set(1 + sq * 0.42, 1 - sq * 0.78, 1 + sq * 0.42);
    if (this.grinding) {
      this.hipG.position.y -= 0.05;
      this.hipG.scale.y *= 0.92;
    }

    // Expressive head look: spots the landing / looks stylishly into turns during tricks!
    const styleHeadYaw = clamp(-P.yaw * 0.18, -0.35, 0.35);
    this.pivG.head.position.copy(R.piv.head);
    this.pivG.head.rotation.set(0, this.headYawW - this.bodyYaw + styleHeadYaw, r.head - S.trickPitch * 0.35);

    // Arms / Wings: custom iconic Grab / Airwalk / Flip poses + riding balance
    let sN = r.flap;
    let sF = r.flap;
    let wN = 0;
    let wF = 0;
    let stN = 1;
    let stF = 1;

    if (this.grinding) {
      const st = this.grindStyle;
      if (st === 'boardslide') sN = sF = 0.85;
      else if (st === 'lipslide') sN = sF = 0.7;
      else if (st === 'feeble') {
        sN = 0.2;
        sF = 0.9;
      } else sN = sF = 0.4;
    } else if (S.hasCustomLimbs) {
      sN = S.armNPitch;
      wN = S.armNRoll;
      sF = S.armFPitch;
      wF = S.armFRoll;
      if (Math.abs(wN) > 0.5) stN = 1.28;
      if (Math.abs(wF) > 0.5) stF = 1.28;
    } else if (tk === 'wingflap') {
      sN = sF = 0.9 + Math.sin(t * 42) * 0.6;
    } else if (tk === 'gazelle') {
      const wm = Math.sin(t * 18);
      sN = 0.9 + wm * 0.5;
      sF = 0.9 - wm * 0.5;
    } else if (tk === 'salto') {
      sN = sF = 0.14;
    } else if (Math.abs(g) > 0.05) {
      const k = Math.min(1, Math.abs(g) * 1.6);
      sN = r.flap * (1 - k) + 0.12 * k;
      wN = (g > 0 ? 0.9 : -0.75) * k;
      stN = 1 + 0.32 * k;
      sF = r.flap * (1 - k) + 1.2 * k;
    } else if (tr && tk && TRICK_DEFS[tk].family === 'spin') {
      sN = sF = 0.28;
    } else if (!this.grounded && this.phase !== 'menu') {
      const vy = this.board.getLinearVelocity().y;
      sN = 0.65 + clamp(vy * 0.07, -0.25, 0.45);
      sF = 0.55 + clamp(vy * 0.07, -0.25, 0.45);
    } else if (r.push >= 0) {
      const sw = Math.sin(r.push * Math.PI);
      sN = 0.42 + sw * 0.24;
      sF = 0.42 - sw * 0.24;
    }

    this.pivG.armN.position.copy(R.piv.armN);
    this.pivG.armF.position.copy(R.piv.armF);
    this.pivG.armN.rotation.set(-sN, 0, wN);
    this.pivG.armF.rotation.set(sF, 0, wF);
    this.pivG.armN.scale.set(1, stN, 1);
    this.pivG.armF.scale.set(1, stF, 1);

    // Legs: smooth independent front/back leg splits for Airwalk, Melon, Indy, Ollie & Pushing!
    for (const k of ['legN', 'legF'] as PivName[]) {
      const base = Math.max(0.05, R.legLen + R.piv[k].y);
      const h = Math.max(0.03, base + r.crouch - pushDip);
      let ang = -r.lean * 0.2;
      let sc = h / base;
      let dz = 0;

      if (k === 'legN' && r.push >= 0 && this.grounded) {
        const u = r.push;
        if (u < 0.22) {
          const q = u / 0.22;
          ang = -0.62 + q * 1.14;
          sc = (h / base) * (1 - Math.sin(q * Math.PI) * 0.32);
          dz = 0.1 * Math.sin(q * Math.PI);
        } else {
          const q = (u - 0.22) / 0.78;
          ang = 0.52 - q * 1.22;
          sc = Math.min(1.7, (h + RIDE_CLEAR) / (base * Math.max(0.45, Math.cos(ang))));
          dz = 0.16;
        }
      }

      if (this.grinding) sc *= 0.88;

      if (S.hasCustomLimbs && !this.grinding) {
        const customAng = k === 'legN' ? S.legNAng : S.legFAng;
        const customTuck = k === 'legN' ? S.legNTuck : S.legFTuck;
        ang += customAng;
        sc *= Math.max(0.55, 1 - customTuck);
      } else if (!this.grounded && this.phase !== 'menu') {
        const vy = this.board.getLinearVelocity().y;
        const tuck = clamp(vy * 0.048, -0.12, 0.26);
        sc *= 1 - tuck;
        ang += k === 'legN' ? tuck * 0.65 : -tuck * 0.25;
      }

      if (tk === 'salto') {
        sc *= 0.7;
        ang += 0.52;
      }

      this.pivG[k].position.set(R.piv[k].x, h, R.piv[k].z + dz);
      this.pivG[k].rotation.set(0, 0, ang);
      this.pivG[k].scale.set(1, sc, 1);
    }

    if (R.eyes) R.eyes.scale.y = r.blink > 0 ? 0.15 : 1;
  }

  private updateVisuals(gdt: number, rdt: number, alpha: number) {
    const b = this.board;
    const p = b.getPosition();
    const a = b.getAngle();
    const bx = this.bPrev.x + (p.x - this.bPrev.x) * alpha;
    const by = this.bPrev.y + (p.y - this.bPrev.y) * alpha;
    const ba = this.bPrev.a + (a - this.bPrev.a) * alpha;
    this.riderRoot.position.set(bx, by, 0);
    this.riderRoot.rotation.set(0, 0, ba);
    const v = b.getLinearVelocity();
    const speed = Math.hypot(v.x, v.y);
    const fwd = v.x * Math.cos(a) + v.y * Math.sin(a);
    this.wheelSpin -= (fwd * gdt) / WHEEL_R;
    for (const w of this.boardVis.wheels) w.rotation.z = this.wheelSpin;

    if (this.phase === 'menu' || this.phase === 'playing') {
      this.pose = this.trick
        ? trickPose(this.trick.def.kind, this.trick.t, this.trick.def.dur, this.trick.dir, this.holdPhase)
        : ZERO_POSE;
      this.blendSmoothPose(gdt);
      this.updateRig(gdt, speed);
      this.applyRig();
    } else {
      // Ragdoll mode: detached 3D tumbling skateboard + articulated limbs + orbiting dizzy stars!
      this.spinG.rotation.set(0, 0, 0);
      this.trails.updateVortex(0, 0, 0, 0);
      this.boardTrickG.position.set(0, this.boardVis.float ? Math.sin(this.realTime * 4.5) * 0.035 : 0, 0);
      this.boardTrickG.rotation.set(this.boardTumble.rx, this.boardTumble.ry, 0);

      for (const r of this.rag) {
        const rp = r.body.getPosition();
        const ra = r.body.getAngle();
        const x = r.px + (rp.x - r.px) * alpha;
        const y = r.py + (rp.y - r.py) * alpha;
        const ang = r.pa + (ra - r.pa) * alpha;
        r.mesh.position.set(x, y, r.z);
        this.tmpQ.setFromAxisAngle(Z_AXIS, ang).multiply(r.qRes);
        r.mesh.quaternion.copy(this.tmpQ);
      }

      // Orbiting 3D golden dizzy stars above the head!
      const headPart = this.rag[1] ?? this.rag[0];
      if (headPart && !headPart.inWater) {
        this.dizzyGroup.visible = true;
        this.dizzyGroup.position.set(headPart.mesh.position.x, headPart.mesh.position.y + 0.58, headPart.mesh.position.z);
        for (let i = 0; i < this.dizzyStars.length; i++) {
          const a0 = this.realTime * 5.2 + (i * TAU) / this.dizzyStars.length;
          const st = this.dizzyStars[i];
          st.position.set(Math.cos(a0) * 0.42, Math.sin(a0 * 2) * 0.07, Math.sin(a0) * 0.35);
          st.rotation.set(0, a0, this.realTime * 4);
        }
      } else {
        this.dizzyGroup.visible = false;
      }
    }

    const t = this.realTime;
    for (const pc of this.pieces) {
      for (const c of pc.coins) {
        if (c.taken) continue;
        c.mesh.rotation.y = t * 3 + c.phase;
        c.mesh.position.y = c.y + Math.sin(t * 3 + c.phase) * 0.08;
      }
      if (pc.waterMesh) pc.waterMesh.position.y = Math.sin(t * 1.6 + pc.data.id) * 0.07;
    }

    // Update camera first so billboarded 3D Silk Ribbons align with zero frame lag!
    this.updateCamera(rdt, bx, by);

    if (this.phase === 'playing') {
      this.riderRoot.updateMatrixWorld(true);
      this.noseTmp.set(0.7, 0.035, 0);
      this.tailTmp.set(-0.7, 0.035, 0);
      this.scarfTmp.set(-0.18, 0.36, 0);
      this.wheelLTmp.set(-0.52, -0.17, 0.2);
      this.wheelRTmp.set(-0.52, -0.17, -0.2);
      this.boardTrickG.localToWorld(this.noseTmp);
      this.boardTrickG.localToWorld(this.tailTmp);
      this.hipG.localToWorld(this.scarfTmp);
      this.boardTrickG.localToWorld(this.wheelLTmp);
      this.boardTrickG.localToWorld(this.wheelRTmp);

      const freestyleOn =
        !this.grinding &&
        (this.trick !== null || Math.abs(b.getAngularVelocity()) > 3.2 || this.smoothPose.spinGlow > 0.14);
      const windOn = !freestyleOn && (!this.grounded || this.grinding !== null || speed > 10.8);
      const spdFactor = clamp((speed - 7) / 14, 0, 1.4);

      this.trails.updateRibbons(gdt, this.camera.position, {
        freestyleActive: freestyleOn,
        nosePos: this.noseTmp,
        tailPos: this.tailTmp,
        scarfPos: this.scarfTmp,
        windActive: windOn,
        wheelLPos: this.wheelLTmp,
        wheelRPos: this.wheelRTmp,
        speedFactor: spdFactor,
        boardX: bx,
        boardY: by,
      });

      // Delicate zero-gravity starlight motes floating off the silk ribbon during Freestyle!
      if (freestyleOn) {
        this.sparkleTimer -= gdt;
        if (this.sparkleTimer <= 0) {
          this.sparkleTimer = 0.038;
          const useNose = Math.random() < 0.5;
          const sp = useNose ? this.noseTmp : this.tailTmp;
          this.particles.spawn({
            x: sp.x + (Math.random() - 0.5) * 0.15,
            y: sp.y + (Math.random() - 0.5) * 0.15,
            z: sp.z + (Math.random() - 0.5) * 0.15,
            vx: (Math.random() - 0.5) * 0.9,
            vy: 0.35 + Math.random() * 0.8,
            vz: (Math.random() - 0.5) * 0.9,
            life: 0.42,
            size: 0.068,
            color: Math.random() < 0.55 ? 0xffffff : this.trickColorHex,
            gravity: -0.4,
            drag: 3.5,
            spin: 8,
          });
        }
      }
    }

    this.particles.update(gdt);
    this.updateBackground(rdt);
    this.cb.onParallax?.(this.camT.x, this.camT.y, speed, rdt);
    this.sfx.update(speed, this.grounded, this.phase === 'playing');

    this.hudTimer -= rdt;
    if (this.hudTimer <= 0) {
      this.hudTimer = 0.1;
      this.emitHud();
    }
    if (this.phase === 'crashed') {
      this.crashTimer += rdt;
      if (this.crashTimer > 2.5) this.toOver();
    } else if (this.phase === 'over') {
      this.overTime += rdt;
      this.crashTimer += rdt;
    }
    this.shake = Math.max(0, this.shake - rdt * 1.7);
  }

  private focusPoint(bx: number, by: number) {
    if ((this.phase === 'crashed' || this.phase === 'over') && this.rag.length) {
      const tp = this.rag[0].body.getPosition();
      const tv = this.rag[0].body.getLinearVelocity();
      return { x: tp.x, y: tp.y, vx: tv.x * 0.4 };
    }
    return { x: bx, y: by, vx: this.board.getLinearVelocity().x };
  }

  private snapCamera() {
    const f = this.focusPoint(this.board.getPosition().x, this.board.getPosition().y);
    this.camT.set(f.x, f.y + 0.75, 0);
    this.camDist = 10;
    this.updateCamera(0, f.x, f.y);
  }

  private updateCamera(dt: number, bx: number, by: number) {
    const w = this.container.clientWidth || 1;
    const h = this.container.clientHeight || 1;
    const aspect = w / h;
    if (Math.abs(this.camera.aspect - aspect) > 1e-3) {
      this.camera.aspect = aspect;
      this.camera.updateProjectionMatrix();
    }
    const f = this.focusPoint(bx, by);
    const v = this.board.getLinearVelocity();
    const speed = Math.hypot(v.x, v.y);
    const tanH = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
    const ground = this.heightAt(f.x + 6);
    const above = Math.max(0, f.y - this.heightAt(f.x) - 1.2);
    // Subtle hero framing zoom during aerial freestyle combos!
    const wantZoom = this.phase === 'playing' && !this.grounded && (this.trick || this.airTricks.length > 0) ? 1 : 0;
    this.trickCamZoom += (wantZoom - this.trickCamZoom) * (dt > 0 ? Math.min(1, dt * 5.5) : 1);
    const heroScale = 1 - this.trickCamZoom * 0.065;

    let halfW = ((aspect < 1 ? 7.5 : 11) + Math.min(Math.max(speed - 6, 0), 16) * 0.3) * heroScale;
    let halfH = (6.2 + above * 0.45) * heroScale;
    let look = clamp(f.vx * 0.42, -2, halfW * 0.5);
    let ty = f.y * 0.62 + ground * 0.38 + 1.65;
    if (this.phase === 'menu') {
      halfW = aspect < 1 ? 4.2 : 6;
      halfH = 3.4;
      look = this.preview ? halfW * (aspect < 1 ? 0 : 0.5) : 0;
      ty = f.y + (this.preview && aspect < 1 ? -0.9 : 0.75);
    } else if (this.phase === 'crashed' || this.phase === 'over') {
      halfW *= 0.74;
      halfH *= 0.74;
      ty = f.y + 0.75;
    }
    const dist = Math.max(halfW / (tanH * aspect), halfH / tanH);
    const kz = dt > 0 ? 1 - Math.exp(-dt * 2.3) : 1;
    const kx = dt > 0 ? 1 - Math.exp(-dt * 6.2) : 1;
    const ky = dt > 0 ? 1 - Math.exp(-dt * 3.5) : 1;
    this.camDist += (dist - this.camDist) * kz;
    this.camT.x += (f.x + look - this.camT.x) * kx;
    this.camT.y += (ty - this.camT.y) * ky;
    const d = this.camDist;
    const sh = this.shake;
    const sx = (Math.random() - 0.5) * sh * 0.7;
    const sy = (Math.random() - 0.5) * sh * 0.7;
    this.camera.position.set(this.camT.x - d * 0.13 + sx, this.camT.y + d * 0.2 + sy, d);
    this.camera.lookAt(this.camT.x + sx * 0.5, this.camT.y + sy * 0.5, 0);
    // Subtle dynamic cinematic Dutch-roll sway during aerial Freestyle!
    const targetRoll =
      this.phase === 'playing' && !this.grounded && this.trick
        ? Math.sin(this.realTime * 6.5) * 0.022 * this.smoothPose.spinGlow
        : 0;
    this.camRoll += (targetRoll - this.camRoll) * (dt > 0 ? Math.min(1, dt * 8) : 1);
    this.camera.rotation.z += this.camRoll;

    this.sun.position.set(this.camT.x - 14, this.camT.y + 26, 22);
    this.sun.target.position.set(this.camT.x + 2, this.camT.y - 2, -2);
    this.water.position.x = this.camT.x;
  }

  private updateBackground(dt: number) {
    const cx = this.camT.x;
    for (const m of this.landmarks) {
      if (m.position.x < cx - 220) m.position.x += 440;
      else if (m.position.x > cx + 220) m.position.x -= 440;
    }
    for (const c of this.clouds) {
      c.obj.position.x -= c.speed * dt;
      if (c.obj.position.x < cx - 168) c.obj.position.x += 336;
      else if (c.obj.position.x > cx + 168) c.obj.position.x -= 336;
    }
  }
}
