/**
 * Enhanced Freestyle Trick & Grab Catalog for SKATECLUB.
 * Includes snappy pro-skate "catch" curves for multi-axis board spins
 * and expressive asymmetric limb poses for Grab tricks (Indy, Melon, Airwalk, Method, etc.).
 */
export type TrickKind =
  | 'kickflip'
  | 'salto'
  | 'heelflip'
  | 'spinL'
  | 'spinR'
  | 'shuvit'
  | 'impossible'
  | 'method'
  | 'indy'
  | 'wingflap'
  | 'coo540'
  | 'varial'
  | 'treflip'
  | 'hardflip'
  | 'laser'
  | 'inward'
  | 'dblflip'
  | 'pressure'
  | 'fingerflip'
  | 'hospital'
  | 'bigspin'
  | 'gazelle'
  | 'shifty'
  | 'air720'
  | 'melon'
  | 'nosegrab'
  | 'tailgrab'
  | 'stalefish'
  | 'benihana'
  | 'rocket'
  | 'christ'
  | 'airwalk'
  | 'helicop'
  | 'casper'
  | 'dragonflip'
  | 'mistycork';

export type TrickFamily = 'flip' | 'grab' | 'spin';

export interface TrickDef {
  kind: TrickKind;
  name: string;
  pts: number;
  color: string;
  dur: number;
  family: TrickFamily;
  bigAirOnly?: boolean;
  /** True if the skateboard visibly whirls / flips with a 3D spin trail */
  boardSpin?: boolean;
  desc: string;
}

export const TRICKS: TrickDef[] = [
  // —— FLIP & SKATE SPIN family ——
  { kind: 'treflip', name: '360 TRE FLIP', pts: 180, color: '#ff9f1c', dur: 0.48, family: 'flip', boardSpin: true, desc: 'Kickflip + putaran skate 360° legendaris!' },
  { kind: 'dragonflip', name: 'DRAGON FLIP', pts: 235, color: '#00f5d4', dur: 0.52, family: 'flip', boardSpin: true, desc: 'Dolphin flip menukik + putaran spiral 360° bak naga!' },
  { kind: 'helicop', name: 'HELICOPTER 540', pts: 210, color: '#38bdf8', dur: 0.52, family: 'flip', boardSpin: true, desc: 'Skate berputar cepat 540° bagai baling-baling!' },
  { kind: 'kickflip', name: 'KICKFLIP', pts: 70, color: '#ffd60a', dur: 0.38, family: 'flip', boardSpin: true, desc: 'Papan berputar 360° tajam lalu ditangkap kaki' },
  { kind: 'laser', name: 'LASER FLIP', pts: 200, color: '#c77dff', dur: 0.52, family: 'flip', boardSpin: true, desc: 'Double heelflip + putaran 360° frontside' },
  { kind: 'impossible', name: 'IMPOSSIBLE', pts: 160, color: '#c77dff', dur: 0.48, family: 'flip', boardSpin: true, desc: 'Skate membungkus vertikal mengelilingi kaki' },
  { kind: 'casper', name: 'CASPER WHIP', pts: 175, color: '#4cc9f0', dur: 0.5, family: 'flip', boardSpin: true, desc: 'Setengah flip lalu diputar balik super keren' },
  { kind: 'hospital', name: 'HOSPITAL FLIP', pts: 155, color: '#80ed99', dur: 0.48, family: 'flip', boardSpin: true, desc: 'Skate berputar lalu balik tajam dengan tendangan' },
  { kind: 'dblflip', name: 'DOUBLE FLIP', pts: 150, color: '#ffc93c', dur: 0.46, family: 'flip', boardSpin: true, desc: 'Skate berputar kickflip DUA kali di udara' },
  { kind: 'heelflip', name: 'HEELFLIP', pts: 70, color: '#ffd60a', dur: 0.38, family: 'flip', boardSpin: true, desc: 'Putaran papan cepat dengan tumit' },
  { kind: 'shuvit', name: 'POP SHUV-IT 360', pts: 95, color: '#f4a261', dur: 0.4, family: 'flip', boardSpin: true, desc: 'Papan memutar horizontal penuh di bawah kaki' },
  { kind: 'varial', name: 'VARIAL FLIP', pts: 110, color: '#ffd60a', dur: 0.42, family: 'flip', boardSpin: true, desc: 'Kickflip + pop shuv-it combo mulus' },
  { kind: 'hardflip', name: 'HARDFLIP', pts: 130, color: '#ffb703', dur: 0.45, family: 'flip', boardSpin: true, desc: 'Hidung papan mencelat vertikal di sela kaki' },
  { kind: 'inward', name: 'INWARD HEEL', pts: 120, color: '#ffd60a', dur: 0.44, family: 'flip', boardSpin: true, desc: 'Heelflip + backside shuv-it combo' },
  { kind: 'pressure', name: 'PRESSURE FLIP', pts: 135, color: '#ffb703', dur: 0.45, family: 'flip', boardSpin: true, desc: 'Skate dicungkil berputar diagonal tajam' },
  { kind: 'fingerflip', name: 'FINGER FLIP', pts: 105, color: '#ffd60a', dur: 0.4, family: 'flip', boardSpin: true, desc: 'Papan diputar langsung dengan tangan di udara' },

  // —— GRAB & STYLE family (Tombol S / X — Indy, Melon, Airwalk di urutan teratas!) ——
  { kind: 'indy', name: 'INDY GRAB', pts: 95, color: '#ff5c8a', dur: 0.46, family: 'grab', desc: 'Lutut ditekuk dalam, tangan mencengkeram tepi tengah papan!' },
  { kind: 'melon', name: 'MELON GRAB', pts: 135, color: '#ff5c8a', dur: 0.48, family: 'grab', desc: 'Grab silang + kaki depan diluruskan (boned-out) penuh gaya!' },
  { kind: 'airwalk', name: 'AIRWALK', pts: 150, color: '#5ee7ff', dur: 0.52, family: 'grab', desc: 'Pegang hidung papan sambil kaki melangkah lebar di udara!' },
  { kind: 'method', name: 'METHOD GRAB', pts: 115, color: '#ff5c8a', dur: 0.48, family: 'grab', desc: 'Punggung melengkung ekstrem, papan ditarik tinggi ke belakang' },
  { kind: 'nosegrab', name: 'NOSE GRAB', pts: 110, color: '#ff7aa8', dur: 0.44, family: 'grab', desc: 'Raih hidung papan vertikal di depan badan' },
  { kind: 'tailgrab', name: 'TAIL GRAB', pts: 110, color: '#ff7aa8', dur: 0.44, family: 'grab', desc: 'Cengkeram ekor papan sambil menukik keren' },
  { kind: 'stalefish', name: 'STALEFISH', pts: 125, color: '#ff85a1', dur: 0.46, family: 'grab', desc: 'Grab silang belakang dengan tweak papan miring' },
  { kind: 'benihana', name: 'BENIHANA', pts: 145, color: '#ff85a1', dur: 0.48, family: 'grab', desc: 'Pegang ekor papan, kaki belakang ditendang lepas!' },
  { kind: 'christ', name: 'CHRIST AIR', pts: 165, color: '#ffe066', dur: 0.54, family: 'grab', desc: 'Papan di satu tangan, rentangkan tubuh bak huruf T!' },
  { kind: 'rocket', name: 'ROCKET AIR', pts: 170, color: '#ff6b6b', dur: 0.52, family: 'grab', desc: 'Kedua tangan pegang nose papan meluncur bak roket!' },
  { kind: 'wingflap', name: 'SUPER FLAP', pts: 85, color: '#80ed99', dur: 0.48, family: 'grab', desc: 'Kepakan sayap/tangan heboh melayang di udara' },

  // —— SPIN family ——
  { kind: 'mistycork', name: 'MISTY CORK', pts: 225, color: '#ff5ca8', dur: 0.56, family: 'spin', boardSpin: true, desc: 'Salto miring corkscrew sambil mencengkeram skateboard!' },
  { kind: 'bigspin', name: 'BIG SPIN 360', pts: 155, color: '#4cc9f0', dur: 0.48, family: 'spin', boardSpin: true, desc: 'Badan 180° + papan berputar 360° mulus' },
  { kind: 'gazelle', name: 'GAZELLE SPIN', pts: 185, color: '#38bdf8', dur: 0.54, family: 'spin', boardSpin: true, desc: 'Badan & papan berputar berlawanan arah yang memukau' },
  { kind: 'spinL', name: 'BACKSIDE 360', pts: 115, color: '#4cc9f0', dur: 0.48, family: 'spin', desc: 'Putaran penuh 360° backside bersama papan' },
  { kind: 'spinR', name: 'FRONTSIDE 360', pts: 115, color: '#4cc9f0', dur: 0.48, family: 'spin', desc: 'Putaran penuh 360° frontside penuh gaya' },
  { kind: 'shifty', name: 'SHIFTY TWEAK', pts: 90, color: '#4cc9f0', dur: 0.42, family: 'spin', desc: 'Banting arah papan 90° di udara lalu kembalikan tajam' },
  { kind: 'salto', name: 'RODEO SALTO', pts: 220, color: '#ff6ad5', dur: 0.6, family: 'spin', boardSpin: true, desc: 'Salto akrobatik penuh bersama putaran skateboard' },
  { kind: 'coo540', name: 'MC TWIST 540', pts: 210, color: '#ff9f1c', dur: 0.56, family: 'spin', bigAirOnly: true, desc: 'Putaran 540° di udara tinggi (big air)' },
  { kind: 'air720', name: 'CORK 720', pts: 300, color: '#ff9f1c', dur: 0.64, family: 'spin', bigAirOnly: true, desc: 'Dua putaran penuh 720° legendaris (big air)' },
];

export const TRICK_MAP = Object.fromEntries(TRICKS.map((t) => [t.kind, t])) as Record<TrickKind, TrickDef>;

export const FAMILY_ORDER: Record<TrickFamily, TrickKind[]> = {
  flip: [
    'treflip',
    'dragonflip',
    'helicop',
    'laser',
    'kickflip',
    'impossible',
    'casper',
    'hospital',
    'dblflip',
    'varial',
    'hardflip',
    'shuvit',
    'heelflip',
    'inward',
    'pressure',
    'fingerflip',
  ],
  grab: [
    'indy',
    'melon',
    'airwalk',
    'method',
    'nosegrab',
    'tailgrab',
    'stalefish',
    'benihana',
    'christ',
    'rocket',
    'wingflap',
  ],
  spin: ['mistycork', 'bigspin', 'gazelle', 'spinL', 'spinR', 'shifty', 'salto', 'coo540', 'air720'],
};

export const FAMILY_LABEL: Record<TrickFamily, string> = { flip: 'FLIP', grab: 'GRAB', spin: 'SPIN' };

/** Showstopper Freestyle Cycle for Left-Mouse Click: weaves 3D DNA spirals, corkscrews & iconic grabs! */
export const FREESTYLE_CYCLE: TrickKind[] = [
  'treflip',
  'dragonflip',
  'melon',
  'helicop',
  'airwalk',
  'mistycork',
  'laser',
  'indy',
  'gazelle',
  'casper',
  'method',
  'impossible',
  'bigspin',
  'christ',
  'dblflip',
  'benihana',
  'hospital',
  'salto',
  'hardflip',
  'rocket',
  'varial',
  'coo540',
  'air720',
];

export const FAMILY_KEY: Record<TrickFamily, string> = { flip: 'Z / F', grab: 'S / X', spin: 'C' };

export interface TrickPose {
  flip: number;
  yaw: number;
  grab: number;
  boardYaw: number;
  trickRoll: number;
  trickPitch: number;
  boardPitch: number;
  boardLift: number;
  boardShiftX: number;
  salto: number;
  hop: number;
  /** Rider floats above the board (Airwalk / Christ Air) */
  lift: number;
  /** Independent limb overrides for expressive silhouettes */
  legNAng: number;
  legFAng: number;
  legNTuck: number;
  legFTuck: number;
  armNPitch: number;
  armNRoll: number;
  armFPitch: number;
  armFRoll: number;
  hasCustomLimbs: boolean;
  /** 0..1 intensity of 3D spin blur ring */
  spinGlow: number;
}

export const ZERO_POSE: TrickPose = {
  flip: 0,
  yaw: 0,
  grab: 0,
  boardYaw: 0,
  trickRoll: 0,
  trickPitch: 0,
  boardPitch: 0,
  boardLift: 0,
  boardShiftX: 0,
  salto: 0,
  hop: 0,
  lift: 0,
  legNAng: 0,
  legFAng: 0,
  legNTuck: 0,
  legFTuck: 0,
  armNPitch: 0,
  armNRoll: 0,
  armFPitch: 0,
  armFRoll: 0,
  hasCustomLimbs: false,
  spinGlow: 0,
};

const FLIP_HOP = new Set<TrickKind>([
  'kickflip',
  'heelflip',
  'shuvit',
  'impossible',
  'varial',
  'inward',
  'hardflip',
  'fingerflip',
  'pressure',
  'dblflip',
  'hospital',
  'treflip',
  'laser',
  'bigspin',
  'helicop',
  'casper',
  'dragonflip',
]);

const easeInOut = (u: number) => (u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2);
const smooth = (u: number) => u * u * (3 - 2 * u);

/** Snappy skate flip curve: finishes 100% of rotation at u = 0.80 so the feet "CATCH" the deck cleanly! */
const catchSpin = (u: number) => {
  if (u >= 0.8) return 1;
  const k = u / 0.8;
  return k < 0.45 ? 1.8 * k * k : 1 - Math.pow(1 - k, 2.4) * 0.76;
};

/** Motion formulas with pro-skate catch physics & expressive Grab / Airwalk silhouettes. */
export function trickPose(kind: TrickKind, t: number, dur: number, dir: number, holdPhase = 0): TrickPose {
  const u = Math.min(1, Math.max(0, t / dur));
  const e = easeInOut(u);
  const cs = catchSpin(u);
  const hump = Math.sin(Math.PI * u);
  // While holding S on a grab, hump stays near 1.0 and subtly breathes/pedals!
  const grabAmt = holdPhase > 0 ? Math.max(hump, 0.94) : hump;
  const spinBell = u < 0.82 ? Math.sin((Math.PI * u) / 0.82) : 0;

  const P: TrickPose = { ...ZERO_POSE };
  const PI = Math.PI;

  switch (kind) {
    // ——— SKATE SPIN / FLIP TRICKS ———
    case 'kickflip':
      P.flip = cs * PI * 2;
      P.boardPitch = spinBell * 0.24;
      P.spinGlow = spinBell * 0.85;
      break;
    case 'heelflip':
      P.flip = -cs * PI * 2;
      P.boardPitch = spinBell * 0.22;
      P.spinGlow = spinBell * 0.85;
      break;
    case 'shuvit':
      P.boardYaw = cs * PI * 2;
      P.boardPitch = spinBell * 0.16;
      P.spinGlow = spinBell * 0.95;
      break;
    case 'treflip':
      P.flip = cs * PI * 2;
      P.boardYaw = cs * PI * 2;
      P.boardPitch = spinBell * 0.36;
      P.spinGlow = spinBell;
      break;
    case 'dragonflip':
      // Forward dolphin flip + 360° spiral: nose dives vertically while spinning a DNA double-helix!
      P.boardPitch = -cs * PI * 2;
      P.flip = cs * PI * 2;
      P.boardYaw = spinBell * 0.9;
      P.boardLift = spinBell * 0.16;
      P.yaw = hump * 0.32;
      P.spinGlow = spinBell;
      break;
    case 'helicop':
      P.boardYaw = cs * PI * 3;
      P.flip = cs * PI * 2;
      P.boardPitch = Math.sin(u * PI * 2) * 0.22 * spinBell;
      P.boardLift = spinBell * 0.12;
      P.spinGlow = spinBell;
      break;
    case 'laser':
      P.flip = -cs * PI * 4;
      P.boardYaw = -cs * PI * 2;
      P.boardPitch = spinBell * 0.32;
      P.spinGlow = spinBell;
      break;
    case 'impossible':
      P.boardPitch = cs * PI * 2;
      P.boardYaw = spinBell * 0.45;
      P.flip = spinBell * 0.6;
      P.spinGlow = spinBell;
      break;
    case 'casper': {
      const half = u < 0.45 ? smooth(u / 0.45) : 1 - smooth((u - 0.45) / 0.38);
      const clampHalf = Math.max(0, half);
      P.flip = clampHalf * PI;
      P.boardYaw = cs * PI * 2;
      P.boardPitch = spinBell * 0.28;
      P.spinGlow = spinBell;
      break;
    }
    case 'hospital':
      P.flip = spinBell * PI * 1.35;
      P.boardYaw = spinBell * PI;
      P.boardPitch = spinBell * 0.34;
      P.spinGlow = spinBell * 0.9;
      break;
    case 'dblflip':
      P.flip = cs * PI * 4;
      P.boardPitch = spinBell * 0.2;
      P.spinGlow = spinBell;
      break;
    case 'varial':
      P.flip = cs * PI * 2;
      P.boardYaw = cs * PI;
      P.boardPitch = spinBell * 0.26;
      P.spinGlow = spinBell * 0.85;
      break;
    case 'inward':
      P.flip = -cs * PI * 2;
      P.boardYaw = cs * PI;
      P.boardPitch = -spinBell * 0.28;
      P.spinGlow = spinBell * 0.85;
      break;
    case 'hardflip':
      P.flip = cs * PI * 2;
      P.boardYaw = -cs * PI;
      P.boardPitch = spinBell * 0.82;
      P.spinGlow = spinBell * 0.95;
      break;
    case 'pressure':
      P.flip = -cs * PI * 2;
      P.boardYaw = -cs * PI;
      P.boardPitch = spinBell * 0.78;
      P.spinGlow = spinBell * 0.9;
      break;
    case 'fingerflip':
      P.flip = cs * PI * 2;
      P.grab = -hump * 0.55;
      P.boardPitch = spinBell * 0.24;
      P.trickPitch = hump * 0.22;
      P.spinGlow = spinBell * 0.8;
      break;

    // ——— ICONIC GRAB POSES (Press S!) ———
    case 'indy': {
      // Classic Indy Grab: deep squat, board pulled tightly up to hand, near hand grabs toe rail, back arm flares high!
      const g = grabAmt;
      P.grab = -g;
      P.boardLift = g * 0.26;
      P.boardPitch = g * 0.24;
      P.flip = -g * 0.36;
      P.trickPitch = -g * 0.22;
      P.yaw = g * 0.25;
      P.spinGlow = g * 0.55;
      P.hasCustomLimbs = true;
      P.legNAng = g * 0.44;
      P.legFAng = -g * 0.34;
      P.legNTuck = g * 0.32;
      P.legFTuck = g * 0.28;
      P.armNPitch = -0.15 * g;
      P.armNRoll = -0.9 * g;
      P.armFPitch = 1.45 * g;
      P.armFRoll = 0.28 * g;
      break;
    }
    case 'melon': {
      // Iconic Boned-Out Melon Grab: body tweaks sideways, front leg kicks straight forward, back knee tucks, cross-arm grab!
      const g = grabAmt;
      P.grab = -g * 0.9;
      P.yaw = g * 0.68;
      P.boardYaw = g * 0.44;
      P.boardLift = g * 0.28;
      P.boardPitch = g * 0.38;
      P.flip = g * 0.42;
      P.trickRoll = g * 0.28;
      P.trickPitch = g * 0.16;
      P.spinGlow = g * 0.62;
      P.hasCustomLimbs = true;
      P.legNAng = g * 0.98; // boned-out straight front leg!
      P.legFAng = -g * 0.7; // deeply tucked back leg
      P.legNTuck = -g * 0.1;
      P.legFTuck = g * 0.36;
      P.armNPitch = 1.38 * g;
      P.armNRoll = -0.22 * g;
      P.armFPitch = -0.2 * g;
      P.armFRoll = 0.88 * g;
      break;
    }
    case 'airwalk': {
      // Legendary Tony Hawk AIRWALK: rider floats above nose-held deck while legs scissor smoothly & walk in mid-air!
      const g = grabAmt;
      const walk = Math.sin((u * 2.4 + 0.35 + holdPhase * 3.0) * PI);
      P.lift = g * 0.5;
      P.boardPitch = -g * 0.42;
      P.boardShiftX = g * 0.18;
      P.boardLift = g * 0.14;
      P.trickPitch = -g * 0.14;
      P.yaw = g * -0.3;
      P.spinGlow = g * 0.68;
      P.hasCustomLimbs = true;
      P.legNAng = g * 1.12 * walk;
      P.legFAng = -P.legNAng; // smooth continuous opposing scissor stride!
      P.legNTuck = -g * 0.12;
      P.legFTuck = -g * 0.12;
      P.armNPitch = 0.25 * g;
      P.armNRoll = -0.95 * g;
      P.armFPitch = 1.48 * g;
      P.armFRoll = 0.3 * g;
      break;
    }
    case 'method': {
      // Arched-back Method Air: board yanked behind back, knees bent backward
      const g = grabAmt;
      P.grab = g;
      P.boardLift = g * 0.32;
      P.boardShiftX = -g * 0.28;
      P.boardPitch = g * 0.46;
      P.flip = g * 0.76;
      P.trickPitch = g * 0.42;
      P.spinGlow = g * 0.6;
      P.hasCustomLimbs = true;
      P.legNAng = -g * 0.85;
      P.legFAng = -g * 0.95;
      P.legNTuck = g * 0.32;
      P.legFTuck = g * 0.32;
      P.armNPitch = 0.1 * g;
      P.armNRoll = 0.92 * g;
      P.armFPitch = 1.35 * g;
      P.armFRoll = -0.2 * g;
      break;
    }
    case 'nosegrab': {
      const g = grabAmt;
      P.grab = g * 0.65;
      P.boardPitch = g * 0.68;
      P.boardLift = g * 0.22;
      P.trickPitch = -g * 0.34;
      P.spinGlow = g * 0.55;
      P.hasCustomLimbs = true;
      P.legNAng = g * 0.45;
      P.legFAng = -g * 0.35;
      P.legNTuck = g * 0.28;
      P.legFTuck = g * 0.22;
      P.armNPitch = 0.2 * g;
      P.armNRoll = -0.95 * g;
      P.armFPitch = 1.25 * g;
      P.armFRoll = 0.2 * g;
      break;
    }
    case 'tailgrab': {
      const g = grabAmt;
      P.grab = -g * 0.78;
      P.boardPitch = -g * 0.65;
      P.boardLift = g * 0.22;
      P.trickPitch = g * 0.3;
      P.spinGlow = g * 0.55;
      P.hasCustomLimbs = true;
      P.legNAng = g * 0.55;
      P.legFAng = -g * 0.45;
      P.legNTuck = g * 0.18;
      P.legFTuck = g * 0.3;
      P.armNPitch = -0.25 * g;
      P.armNRoll = 0.9 * g;
      P.armFPitch = 1.3 * g;
      P.armFRoll = 0.15 * g;
      break;
    }
    case 'stalefish': {
      const g = grabAmt;
      P.grab = -g;
      P.boardYaw = -g * 0.32;
      P.boardLift = g * 0.24;
      P.yaw = g * 0.38;
      P.trickRoll = -g * 0.35;
      P.spinGlow = g * 0.58;
      break;
    }
    case 'benihana': {
      const g = grabAmt;
      P.grab = g * 0.55;
      P.boardPitch = -g * 0.45;
      P.boardLift = g * 0.2;
      P.yaw = -g * 0.35;
      P.trickPitch = g * 0.38;
      P.spinGlow = g * 0.65;
      P.hasCustomLimbs = true;
      P.legNAng = -g * 1.28; // back leg kicked way out off the tail!
      P.legFAng = g * 0.55;
      P.legNTuck = -g * 0.15;
      P.legFTuck = g * 0.3;
      P.armNPitch = -0.2 * g;
      P.armNRoll = 0.88 * g;
      P.armFPitch = 1.25 * g;
      P.armFRoll = 0.2 * g;
      break;
    }
    case 'rocket': {
      const g = grabAmt;
      P.grab = -g * 0.9;
      P.boardPitch = -g * 0.92;
      P.boardLift = g * 0.22;
      P.trickPitch = -g * 0.32;
      P.spinGlow = g * 0.68;
      P.hasCustomLimbs = true;
      P.legNAng = g * 0.25;
      P.legFAng = g * 0.25;
      P.legNTuck = -g * 0.1;
      P.legFTuck = -g * 0.1;
      P.armNPitch = 0.15 * g;
      P.armNRoll = -0.95 * g;
      P.armFPitch = 0.15 * g;
      P.armFRoll = -0.95 * g;
      break;
    }
    case 'christ': {
      const g = grabAmt;
      P.lift = g * 0.42;
      P.boardShiftX = g * 0.32;
      P.boardPitch = g * 0.55;
      P.yaw = -g * 0.45;
      P.spinGlow = g * 0.72;
      P.hasCustomLimbs = true;
      P.legNAng = 0;
      P.legFAng = 0;
      P.legNTuck = -g * 0.12;
      P.legFTuck = -g * 0.12;
      P.armNPitch = 1.52 * g; // Wide T-pose arms!
      P.armFPitch = 1.52 * g;
      break;
    }
    case 'wingflap':
      P.grab = grabAmt * 0.3;
      P.lift = grabAmt * 0.24;
      P.spinGlow = grabAmt * 0.55;
      break;

    // ——— BODY + BOARD SPIN TRICKS ———
    case 'salto':
      P.flip = dir * cs * PI * 2;
      P.salto = -PI * 2 * dir * smooth(u);
      P.spinGlow = spinBell * 0.92;
      break;
    case 'spinL':
      P.yaw = e * PI * 2;
      P.spinGlow = spinBell * 0.78;
      break;
    case 'spinR':
      P.yaw = -e * PI * 2;
      P.spinGlow = spinBell * 0.78;
      break;
    case 'coo540':
      P.yaw = dir * e * PI * 3;
      P.spinGlow = spinBell * 0.9;
      break;
    case 'shifty':
      P.yaw = hump * PI * 0.68;
      P.boardYaw = hump * 0.48;
      P.trickRoll = hump * 0.28;
      P.spinGlow = hump * 0.65;
      break;
    case 'bigspin':
      P.yaw = e * PI;
      P.boardYaw = cs * PI * 2;
      P.trickPitch = hump * 0.18;
      P.spinGlow = spinBell * 0.95;
      break;
    case 'mistycork':
      // Diagonal off-axis corkscrew backflip while grabbing the rail!
      P.salto = PI * 2 * smooth(u);
      P.yaw = e * PI * 2;
      P.trickRoll = hump * 0.55;
      P.grab = -hump * 0.85;
      P.boardLift = hump * 0.22;
      P.boardPitch = hump * 0.28;
      P.spinGlow = spinBell * 0.96;
      P.hasCustomLimbs = true;
      P.legNAng = hump * 0.45;
      P.legFAng = -hump * 0.35;
      P.legNTuck = hump * 0.34;
      P.legFTuck = hump * 0.3;
      P.armNPitch = -0.15 * hump;
      P.armNRoll = -0.9 * hump;
      P.armFPitch = 1.45 * hump;
      P.armFRoll = 0.28 * hump;
      break;
    case 'gazelle':
      P.trickRoll = e * PI * 2;
      P.yaw = e * PI;
      P.boardYaw = -cs * PI * 2;
      P.spinGlow = spinBell;
      break;
    case 'air720':
      P.yaw = dir * e * PI * 4;
      P.trickRoll = dir * hump * 0.75;
      P.spinGlow = spinBell;
      break;
  }

  if (FLIP_HOP.has(kind)) {
    P.hop = spinBell * 0.34;
    if (!P.hasCustomLimbs) {
      // Knees tuck crisply up above the spinning deck, then extend to STOMP the catch!
      const stomp = u > 0.76 ? Math.sin(((u - 0.76) / 0.24) * PI) * 0.12 : 0;
      P.hasCustomLimbs = true;
      P.legNAng = spinBell * 0.38 - stomp * 0.2;
      P.legFAng = -spinBell * 0.28 + stomp * 0.15;
      P.legNTuck = spinBell * 0.32 - stomp;
      P.legFTuck = spinBell * 0.28 - stomp;
      P.armNPitch = 0.95 * spinBell + 0.25;
      P.armFPitch = 1.05 * spinBell + 0.25;
      P.armNRoll = -0.25 * spinBell;
      P.armFRoll = 0.25 * spinBell;
    }
  }

  return P;
}
