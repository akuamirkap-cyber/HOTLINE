/**
 * Place themes — Bukit Hijau (lush alpine valley), Lembah Sakura (cherry blossom spring),
 * Tokyo Senja (golden-hour sunset city) & Shibuya Malam (cyber-pop neon night).
 */
export type PlaceId = 'hijau' | 'sakura' | 'tokyo' | 'shibuya';
export type PropSet = 'park' | 'sakura' | 'city' | 'neon';
export type BgKind = 'mountains' | 'sakura' | 'city' | 'neon';

export interface TerrainPalette {
  grassA: number;
  grassB: number;
  curbR: number;
  curbW: number;
  asphalt: number;
  asphaltEdge: number;
  topsoil: number;
  dirt: number;
  rock: number;
}

export interface BackdropPalette {
  sunCore: string;
  sunGlow: string;
  cloudTop: string;
  cloudShade: string;
  farPeak: string;
  farSnow: string;
  midHill: string;
  nearHill: string;
  horizonMist: string;
  accent: string;
}

export interface PlaceTheme {
  id: PlaceId;
  name: string;
  emoji: string;
  desc: string;
  badge: string;
  /** CSS sky gradient for the 2D illustrated stage background */
  skyCss: string;
  backdrop: BackdropPalette;
  fog: number;
  fogNear: number;
  fogFar: number;
  hemiSky: number;
  hemiGround: number;
  hemiIntensity: number;
  sunColor: number;
  sunIntensity: number;
  water: number;
  palette: TerrainPalette;
  bg: BgKind;
  props: PropSet;
}

export const PLACES: PlaceTheme[] = [
  {
    id: 'hijau',
    name: 'Bukit Hijau',
    emoji: '🏞️',
    desc: 'Lembah pegunungan cerah: bukit hijau berlapis, kincir angin, awan lembut & sungai jernih',
    badge: 'ORIGINAL+',
    skyCss: 'linear-gradient(180deg, #2b95ff 0%, #63c5ff 34%, #a8e6ff 66%, #eef9ff 86%, #fff5d6 100%)',
    backdrop: {
      sunCore: '#fffbe0',
      sunGlow: 'rgba(255, 240, 165, 0.55)',
      cloudTop: '#ffffff',
      cloudShade: '#d9f0ff',
      farPeak: '#7ab8d9',
      farSnow: '#f7fcff',
      midHill: '#6bc489',
      nearHill: '#4ca96c',
      horizonMist: 'rgba(218, 246, 255, 0.65)',
      accent: '#ffd23f',
    },
    fog: 0xd6f3ff,
    fogNear: 78,
    fogFar: 235,
    hemiSky: 0xffffff,
    hemiGround: 0x99b08a,
    hemiIntensity: 2.08,
    sunColor: 0xfff3db,
    sunIntensity: 1.98,
    water: 0x3ec2f7,
    palette: {
      grassA: 0x8be04e,
      grassB: 0x7bd142,
      curbR: 0xf25244,
      curbW: 0xf8fafc,
      asphalt: 0x565d6b,
      asphaltEdge: 0x424753,
      topsoil: 0xb97f48,
      dirt: 0x946139,
      rock: 0x6d5c50,
    },
    bg: 'mountains',
    props: 'park',
  },
  {
    id: 'sakura',
    name: 'Lembah Sakura',
    emoji: '🌸',
    desc: 'Musim semi Jepang: Gunung Fuji, gerbang Torii, kelopak bunga sakura berterbangan',
    badge: 'BARU!',
    skyCss: 'linear-gradient(180deg, #749bff 0%, #b3bfff 34%, #f9c8e0 68%, #ffe5ec 88%, #fff6f0 100%)',
    backdrop: {
      sunCore: '#fff7eb',
      sunGlow: 'rgba(255, 210, 228, 0.62)',
      cloudTop: '#fff8fb',
      cloudShade: '#f5d0e4',
      farPeak: '#9ea8d8',
      farSnow: '#ffffff',
      midHill: '#c98bb9',
      nearHill: '#9f6b99',
      horizonMist: 'rgba(255, 232, 242, 0.65)',
      accent: '#ff7aa8',
    },
    fog: 0xfbe0ec,
    fogNear: 75,
    fogFar: 230,
    hemiSky: 0xfff0f6,
    hemiGround: 0x9e7d92,
    hemiIntensity: 2.0,
    sunColor: 0xffeaf0,
    sunIntensity: 1.85,
    water: 0x62b6ea,
    palette: {
      grassA: 0x9ad96c,
      grassB: 0x8bc95e,
      curbR: 0xff7aa8,
      curbW: 0xfff7fa,
      asphalt: 0x585b6e,
      asphaltEdge: 0x444757,
      topsoil: 0xb07c62,
      dirt: 0x8c5e4a,
      rock: 0x6b5862,
    },
    bg: 'sakura',
    props: 'sakura',
  },
  {
    id: 'tokyo',
    name: 'Tokyo Senja',
    emoji: '🗼',
    desc: 'Kota Tokyo sore keemasan: siluet Fuji, kereta Shinkansen melintas & Tokyo Tower',
    badge: 'PIGEON SK8',
    skyCss: 'linear-gradient(180deg, #2d3569 0%, #6d467c 30%, #d4686c 58%, #ff9d5c 80%, #ffe09e 100%)',
    backdrop: {
      sunCore: '#ffe89c',
      sunGlow: 'rgba(255, 138, 76, 0.58)',
      cloudTop: '#ffcaa6',
      cloudShade: '#b86884',
      farPeak: '#5f4370',
      farSnow: '#ffd4b8',
      midHill: '#4a3560',
      nearHill: '#362749',
      horizonMist: 'rgba(255, 182, 132, 0.5)',
      accent: '#ff7a3d',
    },
    fog: 0xf0b58e,
    fogNear: 72,
    fogFar: 225,
    hemiSky: 0xffd9b0,
    hemiGround: 0x6a5a6a,
    hemiIntensity: 1.75,
    sunColor: 0xffb273,
    sunIntensity: 1.82,
    water: 0x4580ad,
    palette: {
      grassA: 0xc2b7a6,
      grassB: 0xb3a896,
      curbR: 0xf27d42,
      curbW: 0xf6f1e7,
      asphalt: 0x484f61,
      asphaltEdge: 0x394050,
      topsoil: 0x9a8d82,
      dirt: 0x7a6e64,
      rock: 0x5a524c,
    },
    bg: 'city',
    props: 'city',
  },
  {
    id: 'shibuya',
    name: 'Shibuya Malam',
    emoji: '🌃',
    desc: 'Shibuya malam neon estetik: bintang berkelip, bulan sabit, sorot lampu & skyline cyber',
    badge: 'PIGEON SK8',
    skyCss: 'linear-gradient(180deg, #07091e 0%, #13163b 32%, #291f56 64%, #4f2a6e 86%, #75387d 100%)',
    backdrop: {
      sunCore: '#f6f8ff',
      sunGlow: 'rgba(138, 180, 255, 0.38)',
      cloudTop: '#3e326e',
      cloudShade: '#221b47',
      farPeak: '#1d1942',
      farSnow: '#5ad2ff',
      midHill: '#161436',
      nearHill: '#0f0e28',
      horizonMist: 'rgba(162, 82, 204, 0.35)',
      accent: '#ff5ad2',
    },
    fog: 0x2e234a,
    fogNear: 68,
    fogFar: 215,
    hemiSky: 0x9b8ce0,
    hemiGround: 0x2a2438,
    hemiIntensity: 1.48,
    sunColor: 0xb8d0ff,
    sunIntensity: 1.15,
    water: 0x24467a,
    palette: {
      grassA: 0x585f7a,
      grassB: 0x4c536c,
      curbR: 0xff5ad2,
      curbW: 0xd8e0f2,
      asphalt: 0x32384c,
      asphaltEdge: 0x272d3e,
      topsoil: 0x3a3f54,
      dirt: 0x2d3244,
      rock: 0x222636,
    },
    bg: 'neon',
    props: 'neon',
  },
];

export const getPlace = (id: string): PlaceTheme => PLACES.find((p) => p.id === id) ?? PLACES[0];
