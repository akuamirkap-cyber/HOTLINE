import * as THREE from 'three';

/**
 * Procedural soft-feathered ribbon texture:
 * - u (0..1): along trail length (bright head -> smooth exponential tail fade)
 * - v (0..1): across ribbon width (feathered transparent edges -> glowing center)
 */
function makeRibbonTexture(): THREE.CanvasTexture {
  const w = 128;
  const h = 64;
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const ctx = cv.getContext('2d')!;
  const img = ctx.createImageData(w, h);
  const d = img.data;

  for (let y = 0; y < h; y++) {
    const v = y / (h - 1);
    const edge = Math.sin(v * Math.PI);
    const crossAlpha = Math.pow(Math.max(0, edge), 1.35);

    for (let x = 0; x < w; x++) {
      const u = x / (w - 1);
      const headEase = u < 0.05 ? 0.55 + (u / 0.05) * 0.45 : 1.0;
      const tailFade = Math.pow(Math.max(0, 1 - u), 1.55);
      const alpha = headEase * tailFade * crossAlpha;

      const idx = (y * w + x) * 4;
      d[idx] = 255;
      d[idx + 1] = 255;
      d[idx + 2] = 255;
      d[idx + 3] = Math.round(Math.min(1, alpha) * 255);
    }
  }
  ctx.putImageData(img, 0, 0);

  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Procedural anime comet-slash texture (two sweeping tapered crescents around a cylinder band)
 */
function makeSlashTexture(): THREE.CanvasTexture {
  const w = 256;
  const h = 64;
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const ctx = cv.getContext('2d')!;
  const img = ctx.createImageData(w, h);
  const d = img.data;

  for (let y = 0; y < h; y++) {
    const v = y / (h - 1);
    const s = Math.sin(v * Math.PI);
    const cross = Math.pow(Math.max(0, s), 1.7);
    const hotCenter = Math.pow(Math.max(0, s), 6.0);

    for (let x = 0; x < w; x++) {
      // Two opposing comet streaks per circumference (0..0.5 and 0.5..1.0)
      const u = (x / w) * 2;
      const lu = u % 1;
      let streak = 0;
      if (lu < 0.72) {
        const k = lu / 0.72;
        const front = k < 0.08 ? Math.sin(((k / 0.08) * Math.PI) / 2) : 1;
        const tail = Math.pow(1 - k, 1.85);
        streak = front * tail;
      }
      const alpha = Math.min(1, streak * cross * 1.15);
      // Slight white boost along the razor center
      const boost = Math.min(255, Math.round(230 + hotCenter * 25));
      const idx = (y * w + x) * 4;
      d[idx] = boost;
      d[idx + 1] = boost;
      d[idx + 2] = boost;
      d[idx + 3] = Math.round(alpha * 255);
    }
  }
  ctx.putImageData(img, 0, 0);

  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Procedural radial shockwave halo ring texture
 */
function makeHaloTexture(): THREE.CanvasTexture {
  const sz = 128;
  const cv = document.createElement('canvas');
  cv.width = sz;
  cv.height = sz;
  const ctx = cv.getContext('2d')!;
  const cx = sz / 2;
  const grad = ctx.createRadialGradient(cx, cx, cx * 0.42, cx, cx, cx * 0.98);
  grad.addColorStop(0.0, 'rgba(255,255,255,0)');
  grad.addColorStop(0.45, 'rgba(255,255,255,0.25)');
  grad.addColorStop(0.72, 'rgba(255,255,255,0.95)');
  grad.addColorStop(0.88, 'rgba(255,255,255,0.45)');
  grad.addColorStop(1.0, 'rgba(255,255,255,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, sz, sz);

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

interface RawNode {
  x: number;
  y: number;
  z: number;
  age: number;
  c1: THREE.Color;
  c2: THREE.Color;
}

interface SubPoint {
  x: number;
  y: number;
  z: number;
  u: number;
  r: number;
  g: number;
  b: number;
}

const catmull = (p0: number, p1: number, p2: number, p3: number, t: number) => {
  const t2 = t * t;
  const t3 = t2 * t;
  return (
    0.5 *
    (2 * p1 +
      (-p0 + p2) * t +
      (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 +
      (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
  );
};

/**
 * Continuous 3D Catmull-Rom Silk Ribbon with Dual-Layer Core:
 * Layer 0 = Rich saturated colored outer aura
 * Layer 1 = Crisp luminous white inner core (gives authentic anime cel-glow!)
 */
class SilkRibbon {
  mesh: THREE.Mesh;
  private geo: THREE.BufferGeometry;
  private posArr: Float32Array;
  private colArr: Float32Array;
  private uvArr: Float32Array;
  private nodes: RawNode[] = [];
  private subs: SubPoint[] = [];
  private maxRaw: number;
  private subSteps: number;
  private maxLife: number;
  private baseWidth: number;
  private dualCore: boolean;
  private cHead = new THREE.Color(0xffd60a);
  private cTail = new THREE.Color(0xff5c8a);
  private tmpCol = new THREE.Color();

  constructor(
    mat: THREE.Material,
    opts: { maxRaw?: number; subSteps?: number; maxLife?: number; width?: number; dualCore?: boolean } = {},
  ) {
    this.maxRaw = opts.maxRaw ?? 26;
    this.subSteps = opts.subSteps ?? 3;
    this.maxLife = opts.maxLife ?? 0.34;
    this.baseWidth = opts.width ?? 0.2;
    this.dualCore = opts.dualCore ?? true;

    const maxPts = this.maxRaw * this.subSteps + 2;
    const layers = this.dualCore ? 2 : 1;
    const maxTris = (maxPts - 1) * 2 * layers;
    const maxVerts = maxTris * 3;

    this.posArr = new Float32Array(maxVerts * 3);
    this.colArr = new Float32Array(maxVerts * 3);
    this.uvArr = new Float32Array(maxVerts * 2);

    const geo = new THREE.BufferGeometry();
    const posAttr = new THREE.BufferAttribute(this.posArr, 3);
    const colAttr = new THREE.BufferAttribute(this.colArr, 3);
    const uvAttr = new THREE.BufferAttribute(this.uvArr, 2);
    posAttr.setUsage(THREE.DynamicDrawUsage);
    colAttr.setUsage(THREE.DynamicDrawUsage);
    uvAttr.setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('position', posAttr);
    geo.setAttribute('color', colAttr);
    geo.setAttribute('uv', uvAttr);
    geo.setDrawRange(0, 0);
    this.geo = geo;

    this.mesh = new THREE.Mesh(geo, mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 6;
  }

  setColors(headHex: number, tailHex: number) {
    this.cHead.setHex(headHex);
    this.cTail.setHex(tailHex);
  }

  setWidth(w: number) {
    this.baseWidth = w;
  }

  clear() {
    this.nodes.length = 0;
    this.geo.setDrawRange(0, 0);
    this.mesh.visible = false;
  }

  update(
    dt: number,
    emitting: boolean,
    emitPos: THREE.Vector3 | null,
    camPos: THREE.Vector3,
    widthScale = 1,
  ) {
    // Age existing nodes
    for (let i = this.nodes.length - 1; i >= 0; i--) {
      this.nodes[i].age += dt;
      if (this.nodes[i].age >= this.maxLife) {
        this.nodes.splice(i, 1);
      }
    }

    if (emitting && emitPos) {
      const head = this.nodes[0];
      if (!head) {
        this.nodes.unshift({
          x: emitPos.x,
          y: emitPos.y,
          z: emitPos.z,
          age: 0,
          c1: this.cHead.clone(),
          c2: this.cTail.clone(),
        });
      } else {
        const d2 =
          (head.x - emitPos.x) * (head.x - emitPos.x) +
          (head.y - emitPos.y) * (head.y - emitPos.y) +
          (head.z - emitPos.z) * (head.z - emitPos.z);
        // Always keep nodes[0] locked tightly to current skateboard tip for zero lag,
        // and drop a new history anchor whenever moved > 4.5cm!
        if (d2 > 0.045 * 0.045) {
          this.nodes.unshift({
            x: emitPos.x,
            y: emitPos.y,
            z: emitPos.z,
            age: 0,
            c1: this.cHead.clone(),
            c2: this.cTail.clone(),
          });
          if (this.nodes.length > this.maxRaw) this.nodes.pop();
        } else {
          head.x = emitPos.x;
          head.y = emitPos.y;
          head.z = emitPos.z;
          head.age = 0;
          head.c1.copy(this.cHead);
          head.c2.copy(this.cTail);
        }
      }
    }

    const nRaw = this.nodes.length;
    if (nRaw < 2) {
      this.geo.setDrawRange(0, 0);
      this.mesh.visible = false;
      return;
    }

    // Subdivide with Catmull-Rom splines for silky 3D corkscrews!
    this.subs.length = 0;
    const steps = nRaw >= 3 ? this.subSteps : 1;
    for (let i = 0; i < nRaw - 1; i++) {
      const p0 = this.nodes[Math.max(0, i - 1)];
      const p1 = this.nodes[i];
      const p2 = this.nodes[i + 1];
      const p3 = this.nodes[Math.min(nRaw - 1, i + 2)];

      const subCount = i === nRaw - 2 ? steps : steps - 1;
      for (let s = 0; s <= subCount; s++) {
        if (i < nRaw - 2 && s === steps) continue;
        const t = s / steps;
        const x = catmull(p0.x, p1.x, p2.x, p3.x, t);
        const y = catmull(p0.y, p1.y, p2.y, p3.y, t);
        const z = catmull(p0.z, p1.z, p2.z, p3.z, t);
        const age = p1.age + (p2.age - p1.age) * t;
        const u = Math.min(1, Math.max(0, age / this.maxLife));

        this.tmpCol.copy(p1.c1).lerp(p1.c2, Math.min(1, u * 1.25));
        this.subs.push({ x, y, z, u, r: this.tmpCol.r, g: this.tmpCol.g, b: this.tmpCol.b });
      }
    }

    const m = this.subs.length;
    if (m < 2) {
      this.geo.setDrawRange(0, 0);
      this.mesh.visible = false;
      return;
    }

    let vi = 0;
    const writeVert = (
      px: number,
      py: number,
      pz: number,
      cr: number,
      cg: number,
      cb: number,
      uu: number,
      vv: number,
    ) => {
      const p3 = vi * 3;
      const p2 = vi * 2;
      this.posArr[p3] = px;
      this.posArr[p3 + 1] = py;
      this.posArr[p3 + 2] = pz;
      this.colArr[p3] = cr;
      this.colArr[p3 + 1] = cg;
      this.colArr[p3 + 2] = cb;
      this.uvArr[p2] = uu;
      this.uvArr[p2 + 1] = vv;
      vi++;
    };

    const buildLayer = (widthMult: number, whiteBlend: number, zBias: number) => {
      let prevLx = 0,
        prevLy = 0,
        prevLz = 0;
      let prevRx = 0,
        prevRy = 0,
        prevRz = 0;

      for (let i = 0; i < m; i++) {
        const cur = this.subs[i];
        const prev = this.subs[Math.max(0, i - 1)];
        const next = this.subs[Math.min(m - 1, i + 1)];

        let tx = next.x - prev.x;
        let ty = next.y - prev.y;
        let tz = next.z - prev.z;
        const tl = Math.hypot(tx, ty, tz) || 1;
        tx /= tl;
        ty /= tl;
        tz /= tl;

        const vx = camPos.x - cur.x;
        const vy = camPos.y - cur.y;
        const vz = camPos.z - cur.z;

        // Side vector = tangent x viewDir (always faces camera cleanly!)
        let sx = ty * vz - tz * vy;
        let sy = tz * vx - tx * vz;
        let sz = tx * vy - ty * vx;
        const sl = Math.hypot(sx, sy, sz) || 1;
        sx /= sl;
        sy /= sl;
        sz /= sl;

        // Smooth teardrop width profile: sleek rounded nose -> full body -> needle-sharp tail!
        const u = cur.u;
        const headShape = u < 0.08 ? 0.55 + 0.45 * Math.sin(((u / 0.08) * Math.PI) / 2) : 1;
        const tailTaper = Math.pow(Math.max(0, 1 - u), 0.85);
        const halfW = this.baseWidth * widthScale * widthMult * headShape * tailTaper * 0.5;

        const lx = cur.x + sx * halfW;
        const ly = cur.y + sy * halfW;
        const lz = cur.z + sz * halfW + zBias;
        const rx = cur.x - sx * halfW;
        const ry = cur.y - sy * halfW;
        const rz = cur.z - sz * halfW + zBias;

        if (i > 0) {
          const p0 = this.subs[i - 1];
          const r0 = p0.r + (1 - p0.r) * whiteBlend;
          const g0 = p0.g + (1 - p0.g) * whiteBlend;
          const b0 = p0.b + (1 - p0.b) * whiteBlend;
          const r1 = cur.r + (1 - cur.r) * whiteBlend;
          const g1 = cur.g + (1 - cur.g) * whiteBlend;
          const b1 = cur.b + (1 - cur.b) * whiteBlend;

          writeVert(prevLx, prevLy, prevLz, r0, g0, b0, p0.u, 0);
          writeVert(prevRx, prevRy, prevRz, r0, g0, b0, p0.u, 1);
          writeVert(lx, ly, lz, r1, g1, b1, cur.u, 0);

          writeVert(prevRx, prevRy, prevRz, r0, g0, b0, p0.u, 1);
          writeVert(rx, ry, rz, r1, g1, b1, cur.u, 1);
          writeVert(lx, ly, lz, r1, g1, b1, cur.u, 0);
        }

        prevLx = lx;
        prevLy = ly;
        prevLz = lz;
        prevRx = rx;
        prevRy = ry;
        prevRz = rz;
      }
    };

    // Outer saturated aura ribbon
    buildLayer(1.0, 0.0, 0);
    // Crisp glowing white core ribbon inside!
    if (this.dualCore) {
      buildLayer(0.38, 0.88, 0.008);
    }

    this.geo.setDrawRange(0, vi);
    (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.uv as THREE.BufferAttribute).needsUpdate = true;
    this.mesh.visible = true;
  }

  dispose() {
    this.geo.dispose();
  }
}

export interface FreestylePalette {
  noseHead: number;
  noseTail: number;
  tailHead: number;
  tailTail: number;
  slashA: number;
  slashB: number;
}

/** Curated vibrant anime skate palettes that evolve with each chained Left-Click trick! */
export const CHAIN_PALETTES: FreestylePalette[] = [
  // 1st click: Solar Gold & Sunset Coral + Sky Cyan
  {
    noseHead: 0xffe047,
    noseTail: 0xff5a36,
    tailHead: 0x64ecff,
    tailTail: 0x3b82f6,
    slashA: 0xffdf4d,
    slashB: 0x7fe7ff,
  },
  // 2nd click chain: Electric Mint-Cyan & Hyper Violet
  {
    noseHead: 0x00f5d4,
    noseTail: 0x3a86ff,
    tailHead: 0xff70a6,
    tailTail: 0x9b5de5,
    slashA: 0x00f5d4,
    slashB: 0xff70a6,
  },
  // 3rd click chain: Sakura Neon Pink & Golden Starlight
  {
    noseHead: 0xff4d94,
    noseTail: 0xc77dff,
    tailHead: 0xfff066,
    tailTail: 0xff8500,
    slashA: 0xff5ca8,
    slashB: 0xffe866,
  },
  // 4th+ click chain: Prismatic Emerald-Aurora & Cyber Magenta
  {
    noseHead: 0x80ff72,
    noseTail: 0x00bbf9,
    tailHead: 0xf15bb5,
    tailTail: 0xfee440,
    slashA: 0x80ff72,
    slashB: 0xf15bb5,
  },
];

export class SkateMotionTrails {
  group = new THREE.Group();
  vortexGroup = new THREE.Group();

  private ribbonTex: THREE.CanvasTexture;
  private slashTex: THREE.CanvasTexture;
  private haloTex: THREE.CanvasTexture;

  private trickRibbonMat: THREE.MeshBasicMaterial;
  private windRibbonMat: THREE.MeshBasicMaterial;
  private slashMatA: THREE.MeshBasicMaterial;
  private slashMatB: THREE.MeshBasicMaterial;
  private deckSpinMat: THREE.MeshBasicMaterial;
  private haloMat: THREE.MeshBasicMaterial;

  private slashGeoA: THREE.CylinderGeometry;
  private slashGeoB: THREE.CylinderGeometry;
  private deckSpinGeo: THREE.CylinderGeometry;
  private haloGeo: THREE.PlaneGeometry;

  private noseRibbon: SilkRibbon;
  private tailRibbon: SilkRibbon;
  private scarfRibbon: SilkRibbon;
  private windL: SilkRibbon;
  private windR: SilkRibbon;

  slashMeshA: THREE.Mesh;
  slashMeshB: THREE.Mesh;
  deckSpinMesh: THREE.Mesh;
  private haloMesh: THREE.Mesh;
  private haloT = -1;
  private haloDur = 0.36;

  constructor() {
    this.ribbonTex = makeRibbonTexture();
    this.slashTex = makeSlashTexture();
    this.haloTex = makeHaloTexture();

    this.trickRibbonMat = new THREE.MeshBasicMaterial({
      map: this.ribbonTex,
      vertexColors: true,
      transparent: true,
      opacity: 0.94,
      side: THREE.DoubleSide,
      depthWrite: false,
    });

    this.windRibbonMat = new THREE.MeshBasicMaterial({
      map: this.ribbonTex,
      vertexColors: true,
      transparent: true,
      opacity: 0.46,
      side: THREE.DoubleSide,
      depthWrite: false,
    });

    this.slashMatA = new THREE.MeshBasicMaterial({
      map: this.slashTex,
      color: 0xffdf4d,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    this.slashMatB = new THREE.MeshBasicMaterial({
      map: this.slashTex,
      color: 0x7fe7ff,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    this.deckSpinMat = new THREE.MeshBasicMaterial({
      map: this.slashTex,
      color: 0xffffff,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    this.haloMat = new THREE.MeshBasicMaterial({
      map: this.haloTex,
      color: 0xffffff,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    // Smooth open-ended curved bands for zero-blockiness anime wind slashes!
    this.slashGeoA = new THREE.CylinderGeometry(1.02, 1.02, 0.22, 36, 1, true);
    this.slashGeoB = new THREE.CylinderGeometry(0.86, 0.86, 0.16, 32, 1, true);
    this.deckSpinGeo = new THREE.CylinderGeometry(0.82, 0.82, 0.14, 32, 1, true);
    this.haloGeo = new THREE.PlaneGeometry(1.5, 1.5);

    this.slashMeshA = new THREE.Mesh(this.slashGeoA, this.slashMatA);
    this.slashMeshB = new THREE.Mesh(this.slashGeoB, this.slashMatB);
    this.slashMeshA.renderOrder = 7;
    this.slashMeshB.renderOrder = 7;
    this.vortexGroup.add(this.slashMeshA, this.slashMeshB);
    this.vortexGroup.visible = false;

    this.deckSpinMesh = new THREE.Mesh(this.deckSpinGeo, this.deckSpinMat);
    this.deckSpinMesh.renderOrder = 7;
    this.deckSpinMesh.visible = false;

    this.haloMesh = new THREE.Mesh(this.haloGeo, this.haloMat);
    this.haloMesh.renderOrder = 8;
    this.haloMesh.visible = false;

    // 3D Catmull-Rom Silk Ribbons
    this.noseRibbon = new SilkRibbon(this.trickRibbonMat, {
      maxRaw: 28,
      subSteps: 3,
      maxLife: 0.36,
      width: 0.22,
      dualCore: true,
    });
    this.tailRibbon = new SilkRibbon(this.trickRibbonMat, {
      maxRaw: 28,
      subSteps: 3,
      maxLife: 0.34,
      width: 0.19,
      dualCore: true,
    });
    this.scarfRibbon = new SilkRibbon(this.trickRibbonMat, {
      maxRaw: 22,
      subSteps: 2,
      maxLife: 0.3,
      width: 0.13,
      dualCore: true,
    });

    // Subtle, clean aerodynamic wind lines behind the wheels when fast / jumping / boosting!
    this.windL = new SilkRibbon(this.windRibbonMat, {
      maxRaw: 16,
      subSteps: 2,
      maxLife: 0.22,
      width: 0.065,
      dualCore: false,
    });
    this.windR = new SilkRibbon(this.windRibbonMat, {
      maxRaw: 16,
      subSteps: 2,
      maxLife: 0.22,
      width: 0.065,
      dualCore: false,
    });
    this.windL.setColors(0xffffff, 0xb8ecff);
    this.windR.setColors(0xffffff, 0xb8ecff);

    this.group.add(
      this.noseRibbon.mesh,
      this.tailRibbon.mesh,
      this.scarfRibbon.mesh,
      this.windL.mesh,
      this.windR.mesh,
      this.haloMesh,
    );
  }

  applyPalette(pal: FreestylePalette, accentHex?: number) {
    const main = accentHex ?? pal.noseHead;
    this.noseRibbon.setColors(main, pal.noseTail);
    this.tailRibbon.setColors(pal.tailHead, pal.tailTail);
    this.scarfRibbon.setColors(0xffffff, main);
    this.slashMatA.color.setHex(main);
    this.slashMatB.color.setHex(pal.slashB);
    this.deckSpinMat.color.setHex(0xfff6d6);
  }

  triggerHalo(x: number, y: number, colorHex: number, dur = 0.34) {
    this.haloMat.color.setHex(colorHex);
    this.haloMat.opacity = 0.92;
    this.haloMesh.position.set(x, y, 0.22);
    this.haloMesh.scale.setScalar(0.35);
    this.haloMesh.visible = true;
    this.haloT = 0;
    this.haloDur = dur;
  }

  updateVortex(time: number, glow: number, deckY: number, liftY: number, dir = 1) {
    if (glow > 0.03) {
      this.deckSpinMesh.visible = true;
      this.deckSpinMat.opacity = Math.min(0.88, glow * 0.92);
      this.deckSpinMesh.rotation.set(0.18, time * 16 * dir, 0.12);
      const dSc = 0.88 + glow * 0.22;
      this.deckSpinMesh.scale.set(dSc, 1, dSc * 0.76);

      this.vortexGroup.visible = true;
      this.vortexGroup.position.set(0, deckY + 0.2 + liftY * 0.42, 0);
      this.slashMatA.opacity = Math.min(0.86, glow * 0.88);
      this.slashMatB.opacity = Math.min(0.7, glow * 0.74);

      // Smooth flowing UV scroll + tilted 3D gyroscopic precession!
      this.slashTex.offset.x = (time * 2.6) % 1;
      this.slashMeshA.rotation.set(0.42 + Math.sin(time * 7) * 0.22, time * 11 * dir, 0.28);
      this.slashMeshB.rotation.set(-0.58, -time * 9 * dir, -0.36);
      const vSc = 0.86 + glow * 0.28;
      this.slashMeshA.scale.set(vSc, 1, vSc * 0.8);
      this.slashMeshB.scale.set(vSc * 0.92, 1, vSc * 0.75);
    } else {
      this.deckSpinMesh.visible = false;
      this.vortexGroup.visible = false;
    }
  }

  updateRibbons(
    dt: number,
    camPos: THREE.Vector3,
    opts: {
      freestyleActive: boolean;
      nosePos: THREE.Vector3;
      tailPos: THREE.Vector3;
      scarfPos: THREE.Vector3;
      windActive: boolean;
      wheelLPos: THREE.Vector3;
      wheelRPos: THREE.Vector3;
      speedFactor: number;
      boardX: number;
      boardY: number;
    },
  ) {
    const trickW = 0.95 + Math.min(0.45, opts.speedFactor * 0.35);
    this.noseRibbon.update(dt, opts.freestyleActive, opts.nosePos, camPos, trickW);
    this.tailRibbon.update(dt, opts.freestyleActive, opts.tailPos, camPos, trickW);
    this.scarfRibbon.update(dt, opts.freestyleActive, opts.scarfPos, camPos, trickW * 0.85);

    const windW = 0.7 + Math.min(0.6, opts.speedFactor * 0.5);
    this.windRibbonMat.opacity = 0.28 + Math.min(0.32, opts.speedFactor * 0.28);
    this.windL.update(dt, opts.windActive, opts.wheelLPos, camPos, windW);
    this.windR.update(dt, opts.windActive, opts.wheelRPos, camPos, windW);

    if (this.haloT >= 0) {
      this.haloT += dt;
      if (this.haloT >= this.haloDur) {
        this.haloT = -1;
        this.haloMesh.visible = false;
      } else {
        const u = this.haloT / this.haloDur;
        const ease = 1 - Math.pow(1 - u, 2.6);
        this.haloMesh.position.set(opts.boardX, opts.boardY + 0.22, 0.22);
        this.haloMesh.scale.setScalar(0.4 + ease * 1.95);
        this.haloMesh.rotation.z = u * 1.8;
        this.haloMat.opacity = (1 - u) * 0.86;
      }
    }
  }

  clear() {
    this.noseRibbon.clear();
    this.tailRibbon.clear();
    this.scarfRibbon.clear();
    this.windL.clear();
    this.windR.clear();
    this.vortexGroup.visible = false;
    this.deckSpinMesh.visible = false;
    this.haloMesh.visible = false;
    this.haloT = -1;
  }

  dispose() {
    this.noseRibbon.dispose();
    this.tailRibbon.dispose();
    this.scarfRibbon.dispose();
    this.windL.dispose();
    this.windR.dispose();
    this.slashGeoA.dispose();
    this.slashGeoB.dispose();
    this.deckSpinGeo.dispose();
    this.haloGeo.dispose();
    this.ribbonTex.dispose();
    this.slashTex.dispose();
    this.haloTex.dispose();
    this.trickRibbonMat.dispose();
    this.windRibbonMat.dispose();
    this.slashMatA.dispose();
    this.slashMatB.dispose();
    this.deckSpinMat.dispose();
    this.haloMat.dispose();
  }
}
