type OscType = OscillatorType;

export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private whiteNoise: AudioBuffer | null = null;
  private brownNoise: AudioBuffer | null = null;
  private rollGain: GainNode | null = null;
  private rollFilter: BiquadFilterNode | null = null;
  private bearingGain: GainNode | null = null;
  private bearingFilter: BiquadFilterNode | null = null;
  private windGain: GainNode | null = null;
  private windFilter: BiquadFilterNode | null = null;
  private crackDist = 0;
  private rollBoost = 0;
  private lastT = 0;
  muted = false;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    const AC: typeof AudioContext | undefined =
      window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    this.lastT = ctx.currentTime;

    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -12;
    comp.knee.value = 14;
    comp.ratio.value = 3.5;
    comp.attack.value = 0.003;
    comp.release.value = 0.12;
    comp.connect(ctx.destination);

    const master = ctx.createGain();
    master.gain.value = this.muted ? 0 : 0.62;
    master.connect(comp);
    this.master = master;

    const len = ctx.sampleRate * 2;
    // Crisp white/pink-ish noise for griptape, gravel, snaps
    const wBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const wd = wBuf.getChannelData(0);
    // Warm brown-ish noise for asphalt rumble & wind
    const bBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const bd = bBuf.getChannelData(0);
    let lastB = 0;
    let lastW = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      lastW = lastW * 0.25 + w * 0.75;
      wd[i] = lastW * 1.15;
      lastB = lastB * 0.68 + w * 0.32;
      bd[i] = lastB * 1.65;
    }
    this.whiteNoise = wBuf;
    this.brownNoise = bBuf;

    // Asphalt urethane wheel rumble loop
    const src = ctx.createBufferSource();
    src.buffer = bBuf;
    src.loop = true;
    const rf = ctx.createBiquadFilter();
    rf.type = 'lowpass';
    rf.frequency.value = 420;
    rf.Q.value = 2.4;
    const rg = ctx.createGain();
    rg.gain.value = 0;
    src.connect(rf).connect(rg).connect(master);
    src.start();
    this.rollFilter = rf;
    this.rollGain = rg;

    // High-frequency ABEC bearing whirr loop
    const srcBear = ctx.createBufferSource();
    srcBear.buffer = wBuf;
    srcBear.loop = true;
    const bf = ctx.createBiquadFilter();
    bf.type = 'bandpass';
    bf.frequency.value = 2600;
    bf.Q.value = 3.8;
    const bg = ctx.createGain();
    bg.gain.value = 0;
    srcBear.connect(bf).connect(bg).connect(master);
    srcBear.start();
    this.bearingFilter = bf;
    this.bearingGain = bg;

    // Wind rush loop
    const src2 = ctx.createBufferSource();
    src2.buffer = bBuf;
    src2.loop = true;
    src2.playbackRate.value = 0.75;
    const wf = ctx.createBiquadFilter();
    wf.type = 'bandpass';
    wf.frequency.value = 900;
    wf.Q.value = 0.65;
    const wg = ctx.createGain();
    wg.gain.value = 0;
    src2.connect(wf).connect(wg).connect(master);
    src2.start();
    this.windFilter = wf;
    this.windGain = wg;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.62, this.ctx.currentTime, 0.02);
  }

  update(speed: number, grounded: boolean, active: boolean) {
    const ctx = this.ctx;
    if (!ctx || !this.rollGain || !this.rollFilter || !this.windGain || !this.windFilter || !this.bearingGain || !this.bearingFilter) return;
    const t = ctx.currentTime;
    const dt = Math.min(0.06, Math.max(0, t - this.lastT));
    this.lastT = t;

    this.rollBoost = Math.max(0, this.rollBoost - dt * 5.5);

    const rollBase = active && grounded ? Math.min(0.34, 0.055 + speed * 0.021) + this.rollBoost * 0.16 : 0;
    this.rollGain.gain.setTargetAtTime(rollBase, t, 0.03);
    this.rollFilter.frequency.setTargetAtTime(175 + speed * 58 + this.rollBoost * 360, t, 0.06);

    const bear = active ? (grounded ? Math.min(0.055, speed * 0.0032) : Math.min(0.028, speed * 0.0016)) : 0;
    this.bearingGain.gain.setTargetAtTime(bear, t, 0.05);
    this.bearingFilter.frequency.setTargetAtTime(2100 + speed * 85, t, 0.08);

    const wind = active ? Math.min(0.22, Math.max(0, speed - 5) * 0.014) * (grounded ? 0.42 : 1) : 0;
    this.windGain.gain.setTargetAtTime(wind, t, 0.14);
    this.windFilter.frequency.setTargetAtTime(500 + speed * 62, t, 0.18);

    // Subtle sidewalk / asphalt joint clicks ("ka-klack") while rolling
    if (active && grounded && speed > 3.2) {
      this.crackDist += speed * dt;
      if (this.crackDist >= 4.6) {
        this.crackDist = 0;
        this.pavementSeam(Math.min(1, speed / 18));
      }
    }
  }

  private pavementSeam(vel: number) {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const t = ctx.currentTime;
    const v = 0.045 + vel * 0.065;
    // Front wheels seam click -> rear wheels seam click 24ms later
    this.noiseBurst(t, 0.018, v, 'bandpass', 1800, 1100, 3.2, true);
    this.tone(240, t, 0.024, 'triangle', v * 0.65, 120);
    this.noiseBurst(t + 0.024, 0.018, v * 0.85, 'bandpass', 1650, 1000, 3.2, true);
    this.tone(215, t + 0.024, 0.024, 'triangle', v * 0.55, 110);
  }

  private tone(freq: number, t0: number, dur: number, type: OscType, vol: number, endFreq?: number, attack = 0.005) {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(Math.max(20, freq), t0);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(this.master);
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }

  private noiseBurst(
    t0: number,
    dur: number,
    vol: number,
    type: BiquadFilterType,
    f0: number,
    f1?: number,
    q = 1,
    crisp = false,
  ) {
    const ctx = this.ctx;
    const buf = crisp ? this.whiteNoise : this.brownNoise;
    if (!ctx || !this.master || !buf) return;
    const s = ctx.createBufferSource();
    s.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(Math.max(40, f0), t0);
    if (f1) f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t0 + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + 0.004);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    s.connect(f).connect(g).connect(this.master);
    s.start(t0, Math.random() * 1.4);
    s.stop(t0 + dur + 0.05);
  }

  /** Authentic Ollie Jump: 7-ply maple tail snap + hollow wood pop + sneaker griptape slide! */
  pop(power = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const p = Math.min(1.25, Math.max(0.75, power));
    const jitter = 0.95 + Math.random() * 0.1;

    // 1) Sharp wooden tail-on-asphalt "CLACK!"
    this.noiseBurst(t, 0.032, 0.62 * p, 'bandpass', 1320 * jitter, 880, 4.0, true);
    this.noiseBurst(t, 0.024, 0.45 * p, 'highpass', 3100 * jitter, 1800, 1.4, true);

    // 2) Maple deck resonant pop body + wood harmonic ping
    this.tone(360 * jitter, t, 0.068, 'triangle', 0.36 * p, 118, 0.003);
    this.tone(740 * jitter, t + 0.002, 0.042, 'sine', 0.22 * p, 410, 0.002);
    this.tone(165 * jitter, t, 0.075, 'sine', 0.32 * p, 68, 0.004);

    // 3) Sneaker sliding up the griptape ("SHHHK!") 20ms after tail pop
    this.noiseBurst(t + 0.02, 0.072, 0.28 * p, 'bandpass', 2300, 5100, 2.1, true);

    // 4) Brief free-spinning wheel bearing zip on liftoff
    this.noiseBurst(t + 0.035, 0.08, 0.09 * p, 'bandpass', 3800, 2900, 5.0, true);
  }

  /** Rich Skate Touchdown: dual-truck staggered urethane slap + wood deck flex + truck clink + roll surge! */
  land(intensity: number, clean = true) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = Math.min(1.15, 0.34 + intensity * 0.062);
    const j = 0.94 + Math.random() * 0.12;

    // Surge rolling asphalt rumble immediately upon landing
    this.rollBoost = Math.min(1, 0.45 + intensity * 0.05);

    // 1) Front truck & urethane wheels hitting pavement
    this.tone(162 * j, t, 0.13, 'sine', 0.56 * v, 44, 0.003);
    this.noiseBurst(t, 0.085, 0.52 * v, 'lowpass', 1150, 240, 1.3, false);
    this.noiseBurst(t, 0.036, 0.36 * v, 'bandpass', 2400 * j, 1100, 2.2, true);

    // 2) Rear truck micro-staggered slap (14ms later — classic real skate "BA-CLACK!")
    const t2 = t + (clean ? 0.013 : 0.024);
    this.tone(145 * j, t2, 0.14, 'sine', 0.48 * v, 40, 0.003);
    this.tone(460 * j, t2, 0.058, 'triangle', 0.26 * v, 195, 0.003);
    this.noiseBurst(t2, 0.045, 0.4 * v, 'bandpass', 1550 * j, 780, 3.0, true);
    this.noiseBurst(t2 + 0.004, 0.032, 0.24 * v, 'highpass', 3200, 1600, 1.1, true);

    // 3) Subtle metal truck kingpin / bushing compression clink
    this.tone(1780 * j, t2 + 0.005, 0.032, 'sine', 0.085 * v, 1340, 0.002);
    this.tone(2560 * j, t2 + 0.008, 0.025, 'sine', 0.055 * v, 2100, 0.002);
  }

  /** Fast spinning skateboard air-cut whoosh + bearing whirr */
  boardSpin(fast = false) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const dur = fast ? 0.34 : 0.26;
    this.noiseBurst(t, dur, 0.32, 'bandpass', 520, fast ? 2600 : 1950, 1.5, true);
    this.noiseBurst(t + 0.08, dur * 0.7, 0.22, 'bandpass', 2100, 720, 2.2, true);
    this.tone(fast ? 340 : 270, t + 0.03, 0.16, 'sine', 0.09, fast ? 620 : 460, 0.02);
  }

  /** Mid-air foot catch slap when locking a flip/spin trick */
  deckCatch() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.028, 0.36, 'bandpass', 1480, 920, 3.6, true);
    this.tone(295, t, 0.045, 'triangle', 0.2, 135, 0.002);
  }

  /** Wooden kicker / quarter-pipe ramp launch whoosh + hollow wood zip */
  rampLaunch() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.16, 0.36, 'bandpass', 480, 2200, 1.8, false);
    this.tone(210, t, 0.12, 'triangle', 0.24, 520, 0.006);
    this.noiseBurst(t + 0.03, 0.1, 0.14, 'highpass', 2800, 4200, 1.2, true);
  }

  /** Sparkling musical shimmer when clicking Left Mouse for Freestyle! */
  freestyleSpark(chain = 0) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const mult = Math.pow(1.06, Math.min(8, chain));
    this.tone(659.25 * mult, t, 0.09, 'sine', 0.13, 880 * mult, 0.004);
    this.tone(987.77 * mult, t + 0.035, 0.13, 'triangle', 0.14, 1318.5 * mult, 0.004);
    this.tone(1567.98 * mult, t + 0.07, 0.16, 'sine', 0.11, 1760 * mult, 0.004);
  }

  /** Crisp hand/wing grabbing skateboard rail (Indy / Melon / Airwalk) */
  grab() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.035, 0.34, 'bandpass', 1650, 1050, 2.8, true);
    this.tone(380, t, 0.05, 'triangle', 0.16, 210, 0.003);
    this.tone(784, t + 0.02, 0.09, 'sine', 0.12, 1047, 0.005);
  }

  /** Hollow PVC plastic traffic cone BONK! */
  coneBonk() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const f = 310 + Math.random() * 50;
    this.tone(f, t, 0.13, 'triangle', 0.42, f * 0.58, 0.002);
    this.tone(f * 1.88, t, 0.075, 'sine', 0.22, f * 1.25, 0.002);
    this.noiseBurst(t, 0.045, 0.35, 'bandpass', 1200, 650, 2.6, true);
  }

  /** Celebratory sparkle chime when jumping cleanly over a road cone */
  coneClear(count = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const base = count > 1 ? 784 : 659;
    this.tone(base, t, 0.09, 'triangle', 0.2);
    this.tone(base * 1.25, t + 0.05, 0.12, 'triangle', 0.22);
    this.tone(base * 1.5, t + 0.1, 0.18, 'sine', 0.2);
  }

  /** Wooden skateboard clattering during ragdoll crash */
  boardClatter(intensity: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = Math.min(0.9, 0.18 + intensity * 0.1);
    const j = 0.9 + Math.random() * 0.2;
    this.noiseBurst(t, 0.035, 0.42 * v, 'bandpass', 1500 * j, 950, 3.8, true);
    this.tone(420 * j, t, 0.055, 'triangle', 0.24 * v, 180, 0.002);
    this.tone(1950 * j, t + 0.006, 0.028, 'sine', 0.07 * v, 1500, 0.002);
  }

  coin(pitch = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(988 * pitch, t, 0.07, 'square', 0.085);
    this.tone(1319 * pitch, t + 0.062, 0.19, 'square', 0.085);
  }

  trick(level = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];
    const n = Math.min(notes.length, 3 + level);
    for (let i = 0; i < n; i++) this.tone(notes[i], t + i * 0.055, 0.16, 'triangle', 0.22);
  }

  perfect() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(1046.5, t, 0.1, 'sine', 0.16);
    this.tone(1568, t + 0.05, 0.13, 'sine', 0.2);
    this.tone(2093, t + 0.11, 0.28, 'sine', 0.2);
  }

  crash() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.tone(120, t, 0.36, 'sine', 0.78, 32);
    this.noiseBurst(t, 0.34, 0.75, 'lowpass', 1500, 120, 1.2, false);
    this.noiseBurst(t + 0.015, 0.14, 0.45, 'bandpass', 2400, 750, 2.2, true);
    this.boardClatter(4);
  }

  thud(intensity: number) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const v = Math.min(1, 0.16 + intensity * 0.12);
    this.tone(125 + Math.random() * 45, t, 0.12, 'sine', 0.52 * v, 46);
    this.noiseBurst(t, 0.08, 0.36 * v, 'lowpass', 780, 150, 1.2, false);
  }

  squawk() {
    const ctx = this.ctx;
    if (!ctx || !this.master) return;
    const t = ctx.currentTime;
    for (let k = 0; k < 2; k++) {
      const t0 = t + 0.04 + k * 0.19;
      const f = 490 + Math.random() * 130;
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(f, t0);
      o.frequency.linearRampToValueAtTime(f * 1.92, t0 + 0.035);
      o.frequency.linearRampToValueAtTime(f * 1.35, t0 + 0.11);
      o.frequency.linearRampToValueAtTime(f * 0.74, t0 + 0.18);
      const lfo = ctx.createOscillator();
      lfo.frequency.value = 44;
      const lg = ctx.createGain();
      lg.gain.value = 115;
      lfo.connect(lg).connect(o.frequency);
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.value = 1520;
      bp.Q.value = 2.2;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.52, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.19);
      o.connect(bp).connect(g).connect(this.master);
      o.start(t0);
      o.stop(t0 + 0.22);
      lfo.start(t0);
      lfo.stop(t0 + 0.22);
    }
  }

  splash() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.58, 0.68, 'lowpass', 4200, 240, 1.1, true);
    this.noiseBurst(t + 0.05, 0.3, 0.32, 'bandpass', 1800, 580, 1.5, true);
    this.tone(310, t, 0.2, 'sine', 0.25, 85);
  }

  grindStart() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.26, 0.42, 'bandpass', 3300, 1450, 2.2, true);
    this.tone(1850, t, 0.15, 'square', 0.065, 920);
  }

  whoosh() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.noiseBurst(t, 0.24, 0.28, 'bandpass', 620, 1950, 1.3, true);
  }

  dispose() {
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
  }
}
