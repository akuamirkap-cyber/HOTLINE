import { forwardRef, useImperativeHandle, useRef } from 'react';
import { getPlace } from '../game/themes';
import type { PlaceId } from '../game/themes';

export interface ScenicBackdropHandle {
  update(camX: number, camY: number, speed: number, dt: number): void;
}

const wrap = (v: number, period: number) => (((v % period) + period) % period);

export const ScenicBackdrop = forwardRef<ScenicBackdropHandle, { placeId: string }>(function ScenicBackdrop(
  { placeId },
  ref,
) {
  const theme = getPlace(placeId);
  const pid: PlaceId = theme.id;
  const b = theme.backdrop;

  const cloudRef = useRef<HTMLDivElement>(null);
  const farRef = useRef<HTMLDivElement>(null);
  const midRef = useRef<HTMLDivElement>(null);
  const nearRef = useRef<HTMLDivElement>(null);
  const trainRef = useRef<SVGGElement>(null);
  const birdsRef = useRef<HTMLDivElement>(null);
  const speedRef = useRef<HTMLDivElement>(null);

  const driftRef = useRef({ cloud: 0, train: 200, birds: 0 });

  useImperativeHandle(ref, () => ({
    update(camX: number, camY: number, speed: number, dt: number) {
      const d = driftRef.current;
      d.cloud = wrap(d.cloud + dt * 9, 1200);
      d.birds = wrap(d.birds + dt * 22, 1200);
      d.train = wrap(d.train + dt * 95, 1600);

      const py = Math.max(-36, Math.min(42, (camY - 1) * 2.4));

      if (cloudRef.current) {
        const cx = -wrap(camX * 4.2 + d.cloud, 1200);
        cloudRef.current.style.transform = `translate3d(${cx.toFixed(1)}px, ${(py * 0.2).toFixed(1)}px, 0)`;
      }
      if (birdsRef.current) {
        const bx = -wrap(camX * 6.5 + d.birds, 1200);
        birdsRef.current.style.transform = `translate3d(${bx.toFixed(1)}px, ${(py * 0.28).toFixed(1)}px, 0)`;
      }
      if (farRef.current) {
        const fx = -wrap(camX * 6.8, 1200);
        farRef.current.style.transform = `translate3d(${fx.toFixed(1)}px, ${(py * 0.35).toFixed(1)}px, 0)`;
      }
      if (midRef.current) {
        const mx = -wrap(camX * 14.5, 1200);
        midRef.current.style.transform = `translate3d(${mx.toFixed(1)}px, ${(py * 0.62).toFixed(1)}px, 0)`;
      }
      if (nearRef.current) {
        const nx = -wrap(camX * 26.0, 1200);
        nearRef.current.style.transform = `translate3d(${nx.toFixed(1)}px, ${(py * 0.92).toFixed(1)}px, 0)`;
      }
      if (trainRef.current) {
        const tx = 1400 - d.train;
        trainRef.current.setAttribute('transform', `translate(${tx.toFixed(1)}, 0)`);
      }
      if (speedRef.current) {
        const op = Math.max(0, Math.min(0.65, (speed - 17) / 11));
        speedRef.current.style.opacity = op.toFixed(2);
      }
    },
  }));

  const isNight = pid === 'shibuya';
  const isDusk = pid === 'tokyo';
  const isSakura = pid === 'sakura';

  return (
    <div
      className="pointer-events-none absolute inset-0 overflow-hidden select-none"
      style={{ background: theme.skyCss }}
      aria-hidden="true"
    >
      {/* Subtle atmospheric top glow & diagonal sunbeams */}
      {!isNight ? (
        <div
          className="absolute inset-0"
          style={{
            background: isDusk
              ? 'radial-gradient(circle at 72% 46%, rgba(255,232,156,0.55) 0%, rgba(255,142,83,0.26) 26%, transparent 62%)'
              : isSakura
                ? 'radial-gradient(circle at 74% 26%, rgba(255,250,242,0.72) 0%, rgba(255,196,220,0.32) 28%, transparent 60%)'
                : 'radial-gradient(circle at 76% 22%, rgba(255,252,220,0.78) 0%, rgba(255,240,170,0.28) 25%, transparent 58%)',
          }}
        />
      ) : (
        <>
          {/* Starfield & Neon Aurora for Shibuya Night */}
          <svg className="absolute inset-0 h-full w-full opacity-90" preserveAspectRatio="none" viewBox="0 0 1200 700">
            <defs>
              <linearGradient id="auroraGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#5ad2ff" stopOpacity="0.16" />
                <stop offset="50%" stopColor="#ff5ad2" stopOpacity="0.14" />
                <stop offset="100%" stopColor="#7dff6a" stopOpacity="0" />
              </linearGradient>
              <linearGradient id="beamA" x1="0" y1="1" x2="0.3" y2="0">
                <stop offset="0%" stopColor="#5ad2ff" stopOpacity="0.24" />
                <stop offset="100%" stopColor="#5ad2ff" stopOpacity="0" />
              </linearGradient>
              <linearGradient id="beamB" x1="1" y1="1" x2="0.6" y2="0">
                <stop offset="0%" stopColor="#ff5ad2" stopOpacity="0.22" />
                <stop offset="100%" stopColor="#ff5ad2" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d="M0,160 Q320,40 660,150 T1200,90 L1200,320 Q820,240 480,310 T0,260 Z" fill="url(#auroraGrad)" />
            <polygon points="240,700 300,700 470,80 370,80" fill="url(#beamA)" className="anim-beam-slow" />
            <polygon points="880,700 940,700 740,60 650,60" fill="url(#beamB)" className="anim-beam-slow-rev" />
            {Array.from({ length: 48 }).map((_, i) => {
              const sx = ((i * 173 + 41) % 1180) + 10;
              const sy = ((i * 97 + 19) % 340) + 12;
              const sr = i % 5 === 0 ? 2.3 : i % 2 === 0 ? 1.5 : 1.0;
              return (
                <circle
                  key={i}
                  cx={sx}
                  cy={sy}
                  r={sr}
                  fill={i % 7 === 0 ? '#9be7ff' : i % 11 === 0 ? '#ffc2ef' : '#ffffff'}
                  opacity={0.45 + (i % 5) * 0.11}
                />
              );
            })}
          </svg>
        </>
      )}

      {/* Celestial Body: Sun / Sunset Orb / Crescent Moon */}
      <div
        className="absolute"
        style={{
          right: isDusk ? '20%' : '16%',
          top: isDusk ? '28%' : '10%',
          width: isDusk ? '150px' : '112px',
          height: isDusk ? '150px' : '112px',
        }}
      >
        <div
          className="absolute -inset-8 rounded-full blur-xl"
          style={{ background: b.sunGlow }}
        />
        {isNight ? (
          <svg viewBox="0 0 100 100" className="relative h-full w-full drop-shadow-[0_0_18px_rgba(180,210,255,0.65)]">
            <path
              d="M62 14 A38 38 0 1 0 86 68 A30 30 0 1 1 62 14 Z"
              fill={b.sunCore}
            />
          </svg>
        ) : (
          <div
            className="relative h-full w-full rounded-full"
            style={{
              background: isDusk
                ? 'linear-gradient(180deg, #fff5b8 0%, #ffb35c 58%, #ff625c 100%)'
                : b.sunCore,
              boxShadow: `0 0 48px ${b.sunGlow}`,
            }}
          />
        )}
      </div>

      {/* Layer 1: Seamless 2D Stylized Clouds (2x 1200px = 2400px) */}
      <div
        ref={cloudRef}
        className="absolute top-[6%] left-0 h-[38%] w-[2400px] will-change-transform"
      >
        <svg viewBox="0 0 2400 260" preserveAspectRatio="none" className="h-full w-full">
          {[0, 1200].map((off) => (
            <g key={off} transform={`translate(${off}, 0)`}>
              {/* Cloud cluster 1 */}
              <g transform="translate(80, 48)" opacity={isNight ? 0.55 : 0.92}>
                <rect x="18" y="34" width="170" height="26" rx="13" fill={b.cloudShade} />
                <rect x="10" y="24" width="166" height="28" rx="14" fill={b.cloudTop} />
                <circle cx="58" cy="24" r="24" fill={b.cloudTop} />
                <circle cx="96" cy="16" r="31" fill={b.cloudTop} />
                <circle cx="134" cy="25" r="21" fill={b.cloudTop} />
              </g>
              {/* Cloud cluster 2 */}
              <g transform="translate(410, 92) scale(0.85)" opacity={isNight ? 0.45 : 0.85}>
                <rect x="14" y="32" width="145" height="24" rx="12" fill={b.cloudShade} />
                <rect x="8" y="22" width="142" height="26" rx="13" fill={b.cloudTop} />
                <circle cx="52" cy="22" r="22" fill={b.cloudTop} />
                <circle cx="88" cy="14" r="27" fill={b.cloudTop} />
                <circle cx="120" cy="24" r="18" fill={b.cloudTop} />
              </g>
              {/* Cloud cluster 3 */}
              <g transform="translate(740, 34) scale(1.08)" opacity={isNight ? 0.5 : 0.9}>
                <rect x="18" y="36" width="190" height="26" rx="13" fill={b.cloudShade} />
                <rect x="10" y="26" width="186" height="28" rx="14" fill={b.cloudTop} />
                <circle cx="60" cy="25" r="25" fill={b.cloudTop} />
                <circle cx="104" cy="14" r="34" fill={b.cloudTop} />
                <circle cx="148" cy="23" r="24" fill={b.cloudTop} />
              </g>
              {/* Cloud cluster 4 */}
              <g transform="translate(1030, 84) scale(0.76)" opacity={isNight ? 0.42 : 0.8}>
                <rect x="12" y="30" width="130" height="22" rx="11" fill={b.cloudShade} />
                <rect x="8" y="22" width="128" height="24" rx="12" fill={b.cloudTop} />
                <circle cx="48" cy="20" r="20" fill={b.cloudTop} />
                <circle cx="82" cy="15" r="25" fill={b.cloudTop} />
              </g>
            </g>
          ))}
        </svg>
      </div>

      {/* Layer 1B: Gliding Birds / Sakura Petals / Neon Sparks */}
      <div
        ref={birdsRef}
        className="absolute top-[14%] left-0 h-[30%] w-[2400px] will-change-transform"
      >
        <svg viewBox="0 0 2400 200" preserveAspectRatio="none" className="h-full w-full">
          {[0, 1200].map((off) => (
            <g key={off} transform={`translate(${off}, 0)`}>
              {isSakura ? (
                /* Floating 2D Sakura Blossoms */
                Array.from({ length: 18 }).map((_, i) => {
                  const px = (i * 67 + 25) % 1180;
                  const py = (i * 43 + 15) % 180;
                  const rot = (i * 37) % 360;
                  return (
                    <ellipse
                      key={i}
                      cx={px}
                      cy={py}
                      rx={i % 3 === 0 ? 6 : 4.5}
                      ry={2.8}
                      transform={`rotate(${rot} ${px} ${py})`}
                      fill={i % 2 === 0 ? '#ff9ebb' : '#ffd4e3'}
                      opacity="0.88"
                    />
                  );
                })
              ) : isNight ? (
                /* Floating Cyber Bokeh Orbs */
                Array.from({ length: 12 }).map((_, i) => (
                  <circle
                    key={i}
                    cx={(i * 103 + 40) % 1180}
                    cy={(i * 53 + 24) % 175}
                    r={i % 3 === 0 ? 3.5 : 2.2}
                    fill={i % 2 === 0 ? '#5ad2ff' : '#ff5ad2'}
                    opacity="0.55"
                  />
                ))
              ) : (
                /* V-Flock of Birds */
                <>
                  {[
                    [260, 58, 1],
                    [282, 48, 0.85],
                    [302, 62, 0.78],
                    [860, 42, 0.95],
                    [884, 34, 0.8],
                    [905, 48, 0.72],
                  ].map(([bx, by, sc], idx) => (
                    <path
                      key={idx}
                      d={`M${bx},${by} q7,-8 14,0 q7,-8 14,0`}
                      fill="none"
                      stroke={isDusk ? '#4a2e52' : '#2f5e80'}
                      strokeWidth={2.2 * sc}
                      strokeLinecap="round"
                      opacity="0.65"
                    />
                  ))}
                </>
              )}
            </g>
          ))}
        </svg>
      </div>

      {/* Layer 2: Far Horizon Mountains / Mount Fuji / Distant Mega-Skyline */}
      <div
        ref={farRef}
        className="absolute bottom-[18%] left-0 h-[52%] w-[2400px] will-change-transform"
      >
        <svg viewBox="0 0 2400 360" preserveAspectRatio="none" className="h-full w-full">
          {[0, 1200].map((off) => (
            <g key={off} transform={`translate(${off}, 0)`}>
              {pid === 'hijau' && (
                <>
                  {/* Faceted Alpine Peaks with Crisp Snow Caps */}
                  <polygon points="0,360 0,220 140,95 290,235 430,78 610,245 770,108 940,230 1085,88 1200,220 1200,360" fill={b.farPeak} />
                  {/* Shaded right slopes for 2D faceted art style */}
                  <polygon points="140,95 290,235 205,235" fill="#65a5c9" opacity="0.55" />
                  <polygon points="430,78 610,245 505,245" fill="#65a5c9" opacity="0.55" />
                  <polygon points="770,108 940,230 845,230" fill="#65a5c9" opacity="0.55" />
                  <polygon points="1085,88 1200,220 1135,220" fill="#65a5c9" opacity="0.55" />
                  {/* Snow caps */}
                  <polygon points="140,95 104,127 122,134 140,122 158,136 178,129" fill={b.farSnow} />
                  <polygon points="430,78 386,120 410,128 430,114 452,130 478,121" fill={b.farSnow} />
                  <polygon points="770,108 734,140 754,146 770,135 788,147 808,140" fill={b.farSnow} />
                  <polygon points="1085,88 1046,126 1068,133 1085,120 1104,134 1124,124" fill={b.farSnow} />
                </>
              )}

              {(pid === 'sakura' || pid === 'tokyo') && (
                <>
                  {/* Iconic Mount Fuji Silhouette + Distant Peaks */}
                  <polygon points="0,360 0,250 180,190 360,260 540,255 1200,255 1200,360" fill={b.farPeak} opacity="0.78" />
                  {/* Mount Fuji sweeping curve */}
                  <path
                    d="M250,360 Q450,245 545,86 L625,86 Q720,245 920,360 Z"
                    fill={b.farPeak}
                  />
                  {/* Fuji snow crown */}
                  <path
                    d="M545,86 L625,86 Q648,132 666,158 L636,144 L614,164 L586,140 L558,164 L535,144 L505,158 Q523,132 545,86 Z"
                    fill={b.farSnow}
                  />
                  {/* Distant secondary mountain */}
                  <polygon points="820,360 1020,165 1200,250 1200,360" fill={b.farPeak} opacity="0.85" />
                </>
              )}

              {pid === 'shibuya' && (
                <>
                  {/* Distant Cyber Megatowers */}
                  {[
                    [40, 140, 74],
                    [130, 95, 88],
                    [245, 155, 64],
                    [340, 75, 96],
                    [465, 130, 78],
                    [580, 105, 84],
                    [695, 65, 104],
                    [825, 135, 76],
                    [930, 92, 90],
                    [1055, 125, 82],
                  ].map(([x, topY, w], idx) => (
                    <g key={idx}>
                      <rect x={x} y={topY} width={w} height={360 - topY} fill={b.farPeak} />
                      <rect x={x + 4} y={topY} width={w - 8} height="4" fill={idx % 2 === 0 ? '#5ad2ff' : '#ff5ad2'} opacity="0.7" />
                      <rect x={x + w / 2 - 2} y={topY - 26} width="4" height="26" fill={b.farPeak} />
                      <circle cx={x + w / 2} cy={topY - 28} r="3" fill="#ff5ad2" />
                    </g>
                  ))}
                </>
              )}
            </g>
          ))}
        </svg>
      </div>

      {/* Layer 3: Midground Rolling Hills / Windmills / Pagodas / Shinkansen Viaduct / Neon Skyline */}
      <div
        ref={midRef}
        className="absolute bottom-[12%] left-0 h-[42%] w-[2400px] will-change-transform"
      >
        <svg viewBox="0 0 2400 290" preserveAspectRatio="none" className="h-full w-full">
          {[0, 1200].map((off) => (
            <g key={off} transform={`translate(${off}, 0)`}>
              {pid === 'hijau' && (
                <>
                  <path
                    d="M0,290 L0,175 Q160,92 340,165 T700,152 T1040,168 L1200,175 L1200,290 Z"
                    fill={b.midHill}
                  />
                  {/* Cute 2D Windmills on the Hills */}
                  {[215, 790].map((wx, idx) => (
                    <g key={idx} transform={`translate(${wx}, ${idx === 0 ? 106 : 114})`}>
                      <polygon points="-10,48 10,48 6,0 -6,0" fill="#f7fafc" />
                      <polygon points="-8,0 8,0 0,-10" fill="#ef476f" />
                      <g className="anim-spin-slow">
                        <rect x="-2" y="-32" width="4" height="64" rx="2" fill="#ffffff" />
                        <rect x="-32" y="-2" width="64" height="4" rx="2" fill="#ffffff" />
                      </g>
                    </g>
                  ))}
                </>
              )}

              {pid === 'sakura' && (
                <>
                  <path
                    d="M0,290 L0,180 Q200,108 410,172 T830,155 T1200,180 L1200,290 Z"
                    fill={b.midHill}
                  />
                  {/* Traditional Japanese Pagoda Silhouette */}
                  {[285, 895].map((px, idx) => (
                    <g key={idx} transform={`translate(${px}, ${idx === 0 ? 92 : 102})`} fill="#6f416d">
                      <rect x="-2" y="-22" width="4" height="24" />
                      <polygon points="-24,6 24,6 15,-4 -15,-4" />
                      <rect x="-12" y="6" width="24" height="10" />
                      <polygon points="-28,22 28,22 18,12 -18,12" />
                      <rect x="-15" y="22" width="30" height="11" />
                      <polygon points="-33,39 33,39 21,29 -21,29" />
                      <rect x="-18" y="39" width="36" height="22" />
                    </g>
                  ))}
                </>
              )}

              {pid === 'tokyo' && (
                <>
                  {/* Dusk Midground Skyline */}
                  {[
                    [20, 125, 68],
                    [105, 95, 58],
                    [180, 138, 82],
                    [290, 88, 66],
                    [380, 128, 72],
                    [485, 102, 64],
                    [580, 135, 88],
                    [700, 82, 70],
                    [795, 122, 65],
                    [885, 96, 78],
                    [990, 132, 84],
                    [1095, 105, 76],
                  ].map(([x, y, w], idx) => (
                    <g key={idx}>
                      <rect x={x} y={y} width={w} height={290 - y} fill={b.midHill} />
                      {/* Warm sunset lit windows */}
                      {Array.from({ length: 3 }).map((__, r) => (
                        <rect
                          key={r}
                          x={x + 10 + (r % 2) * 22}
                          y={y + 14 + r * 22}
                          width="12"
                          height="8"
                          fill="#ffd27d"
                          opacity="0.65"
                        />
                      ))}
                    </g>
                  ))}
                  {/* Elevated Shinkansen Bullet Train Viaduct */}
                  <rect x="0" y="214" width="1200" height="10" fill="#2c1e3d" />
                  {Array.from({ length: 15 }).map((_, i) => (
                    <rect key={i} x={i * 80 + 20} y="224" width="12" height="66" fill="#2c1e3d" />
                  ))}
                </>
              )}

              {pid === 'shibuya' && (
                <>
                  {/* Neon Shibuya Midground Towers + Glowing Billboards */}
                  {[
                    [15, 100, 76, '#5ad2ff'],
                    [110, 74, 68, '#ff5ad2'],
                    [200, 118, 86, '#ffe066'],
                    [310, 68, 74, '#7dff6a'],
                    [408, 108, 78, '#5ad2ff'],
                    [510, 82, 70, '#ff5ad2'],
                    [605, 115, 90, '#ffe066'],
                    [720, 64, 78, '#5ad2ff'],
                    [822, 104, 72, '#ff5ad2'],
                    [918, 78, 82, '#7dff6a'],
                    [1024, 112, 86, '#5ad2ff'],
                  ].map(([x, y, w, col], idx) => (
                    <g key={idx}>
                      <rect x={Number(x)} y={Number(y)} width={Number(w)} height={290 - Number(y)} fill={b.midHill} />
                      <rect
                        x={Number(x) + 8}
                        y={Number(y) + 14}
                        width={Number(w) - 16}
                        height="18"
                        rx="3"
                        fill={String(col)}
                        opacity="0.8"
                      />
                      <rect
                        x={Number(x) + 12}
                        y={Number(y) + 44}
                        width="8"
                        height={Math.max(20, 220 - Number(y))}
                        fill={String(col)}
                        opacity="0.45"
                      />
                    </g>
                  ))}
                </>
              )}
            </g>
          ))}

          {/* Gliding Shinkansen Train on Tokyo Senja */}
          {pid === 'tokyo' && (
            <g ref={trainRef}>
              <path d="M0,213 L26,202 L230,202 L245,213 Z" fill="#fff7eb" />
              <rect x="24" y="209" width="214" height="3" fill="#ff6b4a" />
              {Array.from({ length: 9 }).map((_, i) => (
                <rect key={i} x={34 + i * 21} y="204" width="13" height="4" rx="1" fill="#ffe082" />
              ))}
            </g>
          )}
        </svg>
      </div>

      {/* Layer 4: Near Silhouettes (Pine Treeline / Sakura Groves / Rooftops) */}
      <div
        ref={nearRef}
        className="absolute bottom-[6%] left-0 h-[28%] w-[2400px] will-change-transform"
      >
        <svg viewBox="0 0 2400 200" preserveAspectRatio="none" className="h-full w-full">
          {[0, 1200].map((off) => (
            <g key={off} transform={`translate(${off}, 0)`}>
              {pid === 'hijau' || pid === 'sakura' ? (
                <>
                  <path
                    d="M0,200 L0,128 Q140,86 290,124 T600,114 T910,126 T1200,120 L1200,200 Z"
                    fill={b.nearHill}
                  />
                  {Array.from({ length: 22 }).map((_, i) => {
                    const tx = i * 55 + (i % 3) * 11;
                    const ty = 98 + (i % 4) * 8;
                    return pid === 'sakura' ? (
                      <circle key={i} cx={tx} cy={ty + 14} r={18 + (i % 3) * 5} fill={i % 2 === 0 ? '#f49ac1' : '#e07aa8'} opacity="0.85" />
                    ) : (
                      <polygon
                        key={i}
                        points={`${tx},${ty - 16} ${tx - 15},${ty + 26} ${tx + 15},${ty + 26}`}
                        fill="#3b8f59"
                      />
                    );
                  })}
                </>
              ) : (
                <path
                  d="M0,200 L0,132 L90,132 L90,108 L195,108 L195,138 L320,138 L320,102 L430,102 L430,134 L565,134 L565,112 L690,112 L690,140 L830,140 L830,106 L960,106 L960,132 L1095,132 L1095,115 L1200,115 L1200,200 Z"
                  fill={b.nearHill}
                />
              )}
            </g>
          ))}
        </svg>
      </div>

      {/* Soft Horizon Mist blending 2D illustration seamlessly into the 3D Voxel stage */}
      <div
        className="absolute inset-x-0 bottom-0 h-[34%]"
        style={{
          background: `linear-gradient(180deg, transparent 0%, ${b.horizonMist} 58%, ${b.horizonMist} 100%)`,
        }}
      />

      {/* Anime Speed Lines when Boosting */}
      <div
        ref={speedRef}
        className="absolute inset-0 transition-opacity duration-150"
        style={{ opacity: 0 }}
      >
        <svg viewBox="0 0 1200 700" preserveAspectRatio="none" className="h-full w-full">
          {Array.from({ length: 16 }).map((_, i) => {
            const y = 45 + i * 40;
            const w = 140 + (i % 4) * 75;
            const leftSide = i % 2 === 0;
            return (
              <rect
                key={i}
                x={leftSide ? 0 : 1200 - w}
                y={y}
                width={w}
                height="2.5"
                rx="1.2"
                fill="#ffffff"
                opacity="0.45"
              />
            );
          })}
        </svg>
      </div>
    </div>
  );
});
