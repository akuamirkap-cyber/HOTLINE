import type { ReactNode } from 'react';
import type { HudState, PopupKind } from '../game/Game';
import { cn } from '../utils/cn';
import { FlagIcon, PauseIcon, SpeakerIcon, TrophyIcon } from './Icons';

export interface PopupItem {
  id: number;
  text: string;
  kind: PopupKind;
  sub?: string;
}

interface HudProps {
  hud: HudState;
  muted: boolean;
  touch: boolean;
  onMute: () => void;
  onPause: () => void;
  onToggleAutoLand: () => void;
  showPause: boolean;
}

export function Hud({ hud, muted, touch, onMute, onPause, onToggleAutoLand, showPause }: HudProps) {
  return (
    <>
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-3 sm:p-5">
        <div className="flex flex-col items-start gap-1">
          <div className="font-game txt-outline text-6xl leading-none text-white sm:text-7xl">
            {hud.score.toLocaleString('id-ID')}
          </div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <Stat className="text-white">
              <FlagIcon className="h-5 w-5 text-[#ff5a36] drop-shadow-[0_2px_0_rgba(0,0,0,0.35)]" /> {hud.distance} m
            </Stat>
            <Stat className="text-[#ffd23f]">
              <CoinIcon /> {hud.coins}
            </Stat>
            {hud.combo > 1 && (
              <Stat key={hud.combo} className="anim-combo text-[#ff7a1a]">
                COMBO x{hud.combo}
              </Stat>
            )}
          </div>
        </div>
        <div className="pointer-events-auto flex items-center gap-2 sm:gap-3">
          <button
            type="button"
            onClick={onToggleAutoLand}
            onPointerDown={(e) => e.stopPropagation()}
            title="Mode Auto-Mendarat Nyaman"
            className={cn(
              'voxel-btn font-game hidden items-center gap-1.5 rounded-xl px-3 py-1.5 text-sm sm:flex',
              hud.autoLand ? 'bg-[#5ee36a] text-[#0f3d14]' : 'bg-white/90 text-slate-700',
            )}
          >
            <span>{hud.autoLand ? '🛡️ AUTO-LAND ON' : '⚡ MODE PRO'}</span>
          </button>
          <Stat className="pointer-events-none hidden text-white sm:flex">
            <TrophyIcon className="h-5 w-5 text-[#ffd23f] drop-shadow-[0_2px_0_rgba(0,0,0,0.35)]" /> {hud.best.toLocaleString('id-ID')}
          </Stat>
          {showPause && (
            <IconBtn onClick={onPause} label="Pause">
              <PauseIcon />
            </IconBtn>
          )}
          <IconBtn onClick={onMute} label={muted ? 'Suara nyala' : 'Suara mati'}>
            <SpeakerIcon muted={muted} />
          </IconBtn>
        </div>
      </div>

      {!touch && showPause && (
        <div className="pointer-events-none absolute inset-x-0 bottom-3 hidden justify-center sm:flex">
          <div className="font-game rounded-full border-2 border-[#1c1c28]/70 bg-[#1c1c28]/50 px-4 py-1 text-xs tracking-wide text-white/95 backdrop-blur-xs">
            <span className="text-[#ffd23f]">SPASI</span> Lompat •{' '}
            <span className="text-[#5ee7ff]">KLIK KIRI</span> Freestyle Combo 3D •{' '}
            <span className="text-[#ff7aa8]">S</span> Pose Grab (Indy / Melon / Airwalk) •{' '}
            <span className="text-[#8dff6a]">KLIK KANAN / →</span> Ngebut
          </div>
        </div>
      )}
    </>
  );
}

function Stat({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn('font-game txt-outline-sm flex items-center gap-1.5 text-xl sm:text-2xl', className)}>{children}</div>
  );
}

export function IconBtn({ children, onClick, label }: { children: ReactNode; onClick: () => void; label: string }) {
  return (
    <button
      aria-label={label}
      title={label}
      onClick={onClick}
      onPointerDown={(e) => e.stopPropagation()}
      className="font-game flex h-11 w-11 items-center justify-center rounded-full text-2xl text-white drop-shadow-[0_3px_0_rgba(0,0,0,0.35)] transition active:translate-y-0.5"
    >
      {children}
    </button>
  );
}

export function CoinIcon({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        'inline-block h-4 w-4 rotate-0 border-2 border-[#8a5a00] bg-[#ffcf2e] shadow-[inset_-3px_-3px_0_#ffa800]',
        className,
      )}
    />
  );
}

export function Popups({ popups }: { popups: PopupItem[] }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-[16%] flex flex-col items-center gap-1">
      {popups.map((p) => (
        <div
          key={p.id}
          className={cn('font-game text-center', p.kind === 'crash' ? 'anim-crash' : 'anim-popup')}
        >
          <div
            className={cn(
              'txt-outline leading-none',
              p.kind === 'trick' && 'text-4xl text-[#ffd23f] sm:text-6xl',
              p.kind === 'perfect' && 'text-3xl text-[#5ee7ff] sm:text-5xl',
              p.kind === 'good' && 'text-3xl text-[#8dff6a] sm:text-4xl',
              p.kind === 'bad' && 'text-3xl text-[#ff9b3d] sm:text-4xl',
              p.kind === 'coin' && 'text-2xl text-[#ffd23f]',
              p.kind === 'crash' && 'text-5xl text-[#ff4b3e] sm:text-7xl',
            )}
          >
            {p.text}
          </div>
          {p.sub && <div className="txt-outline-sm mt-1 text-xl text-white sm:text-2xl">{p.sub}</div>}
        </div>
      ))}
    </div>
  );
}
