import { useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import type { CrashReason, GameResult } from '../game/Game';
import { cn } from '../utils/cn';
import { CoinIcon } from './Hud';
import { ArrowIcon, StarIcon, TrophyIcon } from './Icons';

/* ------------------------------------------------------------------ */
/* Menu                                                                */
/* ------------------------------------------------------------------ */

export function Menu({
  best,
  onPlay,
  touch,
  onSkins,
  onTricks,
  onPlace,
  skinLabel,
  placeLabel,
}: {
  best: number;
  onPlay: () => void;
  touch: boolean;
  onSkins: () => void;
  onTricks: () => void;
  onPlace: () => void;
  skinLabel: string;
  placeLabel: string;
}) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-between overflow-y-auto p-4 sm:p-8">
      <div className="anim-fade-up mt-2 flex flex-col items-center text-center sm:mt-4">
        <div className="anim-bob font-game txt-outline text-7xl leading-[0.9] text-white sm:text-9xl short:text-6xl">
          SKATE<span className="text-[#ffd23f]">CLUB</span>
        </div>
        <div className="font-game txt-outline-sm mt-3 text-lg text-[#bff3ff] sm:text-2xl short:mt-1 short:text-base">
          Freestyle Skate • Lompat Cone • Pose Grab & Auto-Land!
        </div>
        <div className="font-game txt-outline-sm mt-2 hidden rounded-xl bg-[#1c1c28]/35 px-3 py-1 text-sm text-white tiny:block">
          {touch
            ? 'LOMPAT = lewati cone • GRAB = Indy/Melon/Airwalk • FLIP = putar skate'
            : 'SPASI = lompat cone • S = Pose Grab • Z / F / Klik = Putar Skate'}
        </div>
      </div>

      <div className="anim-fade-up flex w-full max-w-6xl flex-col items-center gap-4 [animation-delay:120ms] sm:flex-row sm:items-end sm:justify-between">
        <div className="voxel-panel font-game w-full max-w-md rounded-2xl p-4 text-slate-800 sm:p-5 short:p-3 short:text-sm tiny:hidden">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xl text-[#ff5a36]">CARA MAIN</span>
            <span className="rounded-lg bg-[#5ee36a] px-2 py-0.5 text-xs text-[#0f3d14]">🛡️ AUTO-LAND NYAMAN</span>
          </div>
          {touch ? (
            <ul className="space-y-2 text-base sm:text-lg">
              <Row keys={['LOMPAT']}>Ollie lompati Cone Jalan & Jurang</Row>
              <Row keys={['GRAB']}>Pose Indy Grab, Melon Grab & Airwalk!</Row>
              <Row keys={['FLIP', 'SPIN']}>Freestyle putar skate 3D keren!</Row>
              <Row keys={['▶', '◀']}>▶ Ngebut • ◀ Backflip di udara / Rem</Row>
              <li className="pt-1 text-xs text-slate-500">Auto-Mendarat aktif biar mendarat mulus & nyaman!</li>
            </ul>
          ) : (
            <ul className="space-y-1.5 text-base sm:text-[17px]">
              <Row keys={['SPASI', '↑']}>Lompati Cone Jalan & Jurang</Row>
              <Row keys={['S']}>Pose GRAB (Indy, Melon, Airwalk — bisa ditahan!)</Row>
              <Row keys={['Z', 'F']}>Putar Skate 3D (Tre Flip, Helicopter 540!)</Row>
              <Row keys={['C', '←']}>C = Spin 360 • ← = Salto Backflip</Row>
              <li className="pt-1 text-xs leading-snug text-slate-500">
                🛡️ <b>Auto-Mendarat</b> menjaga papan tetap sejajar jalan saat mendarat! Klik Kiri = Freestyle bervariasi, Klik Kanan (tahan) / → = Ngebut 3x!
              </li>
            </ul>
          )}
        </div>
        <div className="flex flex-col items-center gap-3 short:gap-2">
          <div className="flex flex-wrap items-center justify-center gap-2">
            <button
              onClick={onSkins}
              onPointerDown={(e) => e.stopPropagation()}
              className="voxel-btn font-game rounded-2xl bg-[#ff8fd1] px-5 py-3 text-2xl text-[#4a0d33] short:py-1 short:text-lg"
            >
              GANTI SKIN
            </button>
            <button
              onClick={onTricks}
              onPointerDown={(e) => e.stopPropagation()}
              className="voxel-btn font-game rounded-2xl bg-[#7fe3ff] px-5 py-3 text-2xl text-[#0b3a4a] short:py-1 short:text-lg"
            >
              DAFTAR TRIK
            </button>
            <button
              onClick={onPlace}
              onPointerDown={(e) => e.stopPropagation()}
              className="voxel-btn font-game rounded-2xl bg-[#b8f27a] px-5 py-3 text-2xl text-[#1d3a0a] short:py-1 short:text-lg"
            >
              TEMPAT
            </button>
          </div>
          <div className="font-game txt-outline-sm max-w-[22rem] truncate text-center text-base text-white">
            {skinLabel} • {placeLabel}
          </div>
          <button
            onClick={onPlay}
            onPointerDown={(e) => e.stopPropagation()}
            className="voxel-btn font-game anim-pulse-pop rounded-3xl bg-[#ffd23f] px-16 py-5 text-5xl text-[#3d2a00] sm:text-6xl short:px-8 short:py-2 short:text-3xl"
          >
            MAIN!
          </button>
          <div className="font-game txt-outline-sm flex items-center gap-2 text-xl text-white">
            <TrophyIcon className="h-6 w-6 text-[#ffd23f] drop-shadow-[0_2px_0_#1c1c28]" /> REKOR: {best.toLocaleString('id-ID')}
          </div>
          {!touch && <div className="font-game txt-outline-sm text-sm text-white/90">tekan SPASI untuk mulai</div>}
        </div>
      </div>
    </div>
  );
}

function Row({ keys, children }: { keys: string[]; children: ReactNode }) {
  return (
    <li className="flex items-center gap-3">
      <span className="flex shrink-0 gap-1">
        {keys.map((k) => (
          <span key={k} className="key-cap">
            {k}
          </span>
        ))}
      </span>
      <span>{children}</span>
    </li>
  );
}

/* ------------------------------------------------------------------ */
/* Game over                                                           */
/* ------------------------------------------------------------------ */

const TITLES: Record<CrashReason, string> = {
  head: 'AYAM GEPREK!',
  landing: 'SALAH MENDARAT!',
  wall: 'NABRAK TEBING!',
  fall: 'JATUH KE JURANG!',
  water: 'BYUR! BASAH KUYUP!',
  stuck: 'NYANGKUT!',
  bail: 'GAGAL FREESTYLE!',
  cone: 'TERSANDUNG CONE!',
};

const TIPS = [
  'Klik Kiri Mouse buat Freestyle 3D dengan pita cahaya Silk Ribbon (spam di udara buat Combo Chain)!',
  'Nabrak Cone Jalan gak bikin jatuh — conenya bakal mental jauh & laju cuma melambat sebentar!',
  'Lompati Cone Jalan oranye dengan bersih buat dapat bonus poin + COMBO!',
  'Tekan S kapan saja untuk lompat sambil pose Indy Grab, Melon Grab, atau Airwalk!',
  'Tahan tombol S di udara buat menahan pose GRAB & melangkah Airwalk lebih lama!',
  'Auto-Mendarat otomatis meluruskan papan skate biar mendarat mulus & nyaman.',
  'Lompat ke rail besi buat GRIND! 50-50, Boardslide, Lipslide & Feeble.',
  'Coba ganti suasana latar 2D ke Lembah Sakura, Tokyo Senja, atau Shibuya Malam di Menu!',
];

export function GameOver({
  result,
  onRetry,
  onMenu,
  touch,
}: {
  result: GameResult;
  onRetry: () => void;
  onMenu: () => void;
  touch: boolean;
}) {
  const tip = useMemo(() => TIPS[Math.floor(Math.random() * TIPS.length)], []);
  return (
    <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-[#1c1c28]/25 p-4">
      <div className="anim-fade-up voxel-panel font-game w-full max-w-md rounded-3xl p-5 text-center text-slate-800 sm:p-7 short:max-w-lg short:p-3">
        <div className="txt-outline text-4xl leading-none text-[#ff4b3e] sm:text-5xl short:text-3xl">{TITLES[result.reason]}</div>
        {result.newBest && (
          <div className="anim-pulse-pop mx-auto mt-3 short:mt-1 inline-block rounded-xl border-[3px] border-[#1c1c28] bg-[#ffd23f] px-3 py-1 text-lg shadow-[0_4px_0_#1c1c28]">
            <span className="flex items-center gap-1">
              <StarIcon className="h-5 w-5" /> REKOR BARU! <StarIcon className="h-5 w-5" />
            </span>
          </div>
        )}
        <div className="mt-4 text-6xl leading-none text-[#1c1c28] short:mt-1 short:text-4xl">{result.score.toLocaleString('id-ID')}</div>
        <div className="text-sm tracking-widest text-slate-500">SKOR</div>
        <div className="mt-4 grid grid-cols-3 gap-2 short:mt-2">
          <Stat label="JARAK" value={`${result.distance} m`} />
          <Stat
            label="KOIN"
            value={
              <span className="inline-flex items-center gap-1">
                <CoinIcon /> {result.coins}
              </span>
            }
          />
          <Stat label="FLIP" value={String(result.flips)} />
        </div>
        <div className="mt-3 flex items-center justify-center gap-1 text-base text-slate-600 short:mt-1 short:text-sm">
          <TrophyIcon className="h-5 w-5 text-[#e0a800]" /> Rekor: {result.best.toLocaleString('id-ID')}
        </div>
        <div className="mt-3 rounded-xl bg-[#e9f8ff] px-3 py-2 text-sm text-[#1f6f99] short:mt-2 short:py-1 tiny:hidden">
          <span className="text-[#ff7a1a]">TIPS:</span> {tip}
        </div>
        <button
          onClick={onRetry}
          onPointerDown={(e) => e.stopPropagation()}
          className="voxel-btn mt-5 w-full rounded-2xl bg-[#5ee36a] py-3 text-3xl text-[#0f3d14] short:mt-3 short:py-2 short:text-2xl"
        >
          MAIN LAGI
        </button>
        <button
          onClick={onMenu}
          onPointerDown={(e) => e.stopPropagation()}
          className="voxel-btn mt-3 w-full rounded-2xl bg-[#ff8fd1] py-2 text-xl text-[#4a0d33] short:mt-2 short:py-1 short:text-lg"
        >
          GANTI SKIN / TEMPAT
        </button>
        {!touch && <div className="mt-2 text-sm text-slate-500 short:mt-1 short:text-xs">atau tekan SPASI / ENTER</div>}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="rounded-xl border-[3px] border-[#1c1c28] bg-white px-2 py-2 shadow-[0_4px_0_#1c1c28]">
      <div className="text-xl leading-none sm:text-2xl">{value}</div>
      <div className="mt-1 text-xs tracking-widest text-slate-500">{label}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Pause                                                               */
/* ------------------------------------------------------------------ */

export function PauseOverlay({
  autoLand,
  onToggleAutoLand,
  onResume,
  onRestart,
  onMenu,
}: {
  autoLand: boolean;
  onToggleAutoLand: () => void;
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
}) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[#1c1c28]/35 p-4">
      <div className="anim-fade-up voxel-panel font-game w-full max-w-xs rounded-3xl p-6 text-center">
        <div className="txt-outline text-5xl text-white">PAUSE</div>
        <button
          onClick={onResume}
          onPointerDown={(e) => e.stopPropagation()}
          className="voxel-btn mt-5 w-full rounded-2xl bg-[#ffd23f] py-3 text-3xl text-[#3d2a00]"
        >
          LANJUT
        </button>
        <button
          onClick={onToggleAutoLand}
          onPointerDown={(e) => e.stopPropagation()}
          className={cn(
            'voxel-btn mt-3 w-full rounded-2xl py-2.5 text-lg',
            autoLand ? 'bg-[#5ee36a] text-[#0f3d14]' : 'bg-slate-200 text-slate-700',
          )}
        >
          {autoLand ? '🛡️ AUTO-LAND: NYAMAN' : '⚡ AUTO-LAND: MATI (PRO)'}
        </button>
        <button
          onClick={onRestart}
          onPointerDown={(e) => e.stopPropagation()}
          className="voxel-btn mt-3 w-full rounded-2xl bg-white py-2 text-2xl text-slate-700"
        >
          ULANG
        </button>
        <button
          onClick={onMenu}
          onPointerDown={(e) => e.stopPropagation()}
          className="voxel-btn mt-3 w-full rounded-2xl bg-[#ff8fd1] py-2 text-xl text-[#4a0d33]"
        >
          KE MENU
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Touch controls                                                      */
/* ------------------------------------------------------------------ */

function HoldButton({
  onChange,
  className,
  children,
  label,
}: {
  onChange: (down: boolean) => void;
  className: string;
  children: ReactNode;
  label: string;
}) {
  const [down, setDown] = useState(false);
  const downRef = useRef(false);
  const set = (d: boolean) => {
    if (downRef.current === d) return;
    downRef.current = d;
    setDown(d);
    onChange(d);
  };
  return (
    <button
      aria-label={label}
      className={cn('voxel-btn font-game select-none touch-none', className, down && 'is-down')}
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        try {
          (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        } catch {
          /* ignore */
        }
        set(true);
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        set(false);
      }}
      onPointerCancel={() => set(false)}
      onLostPointerCapture={() => set(false)}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}

export function TouchControls({
  onControl,
}: {
  onControl: (name: 'left' | 'right' | 'jump' | 'flip' | 'grab' | 'spin', down: boolean) => void;
}) {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between p-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:p-6">
      <div className="pointer-events-auto flex gap-3">
        <HoldButton
          label="Kiri"
          onChange={(d) => onControl('left', d)}
          className="flex h-20 w-20 items-center justify-center rounded-2xl bg-white/90 text-4xl text-slate-800 sm:h-24 sm:w-24"
        >
          <ArrowIcon dir="left" />
        </HoldButton>
        <HoldButton
          label="Kanan"
          onChange={(d) => onControl('right', d)}
          className="flex h-20 w-20 items-center justify-center rounded-2xl bg-white/90 text-4xl text-slate-800 sm:h-24 sm:w-24"
        >
          <ArrowIcon dir="right" />
        </HoldButton>
      </div>
      <div className="pointer-events-auto flex items-end gap-2">
        <div className="flex flex-col gap-2">
          {(['spin', 'grab', 'flip'] as const).map((f) => (
            <HoldButton
              key={f}
              label={f}
              onChange={(d) => onControl(f, d)}
              className={cn(
                'flex h-12 w-24 items-center justify-center rounded-xl text-base sm:h-14 sm:w-28 sm:text-lg',
                f === 'flip'
                  ? 'bg-[#ffd60a]/95 text-[#3d2a00]'
                  : f === 'grab'
                    ? 'bg-[#ff5c8a]/95 text-white'
                    : 'bg-[#4cc9f0]/95 text-[#05303d]',
              )}
            >
              {f === 'grab' ? 'GRAB (S)' : f.toUpperCase()}
            </HoldButton>
          ))}
        </div>
        <HoldButton
          label="Lompat"
          onChange={(d) => onControl('jump', d)}
          className="flex h-24 w-24 items-center justify-center rounded-full bg-[#ffd23f]/95 text-2xl text-[#3d2a00] sm:h-28 sm:w-28"
        >
          LOMPAT
        </HoldButton>
      </div>
    </div>
  );
}
