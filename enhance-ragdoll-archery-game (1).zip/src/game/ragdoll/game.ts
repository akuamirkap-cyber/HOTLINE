// "Ragdoll Archer" mode. Black stickmen on floating grounds, drag-back-and-release archery, and every body
// is a live ragdoll: drawing leans it back, the release kicks it, a hit staggers it, a kill lets it crumple.
// Each level adds grounds and enemies. RagWorld is DOM-free (it is fed a size, a clock and pointer events,
// and paints into any 2D context); RagdollGame at the bottom wires it to a real canvas.
// The same world also runs behind the title screen as a self-playing demo.
import { Ctx, V, v, add, mul, dist, clamp, damp, ease, fromAngle, lerpV, segDist } from '../util';
import { ArcherRag, RAG_STICKS, punchRag } from '../archerRag';
import { ambStart, ambStop, ambTick, audioDuck, audioInit, snd } from './audio';
import { ARROW_LEN, BossId, BowId, HEAD_R, Slab2, Stick, StickLook, angLerp, drawArrow, drawAxe, drawBolt, drawBossHeldWeapon, drawBow, drawSimFlame, drawSkeleton, drawStick, fireAngle, impulse, makeStick, onString, startReact, stepStick, woundPoint } from './stick';
import { CanvasLike, MakeCanvas, Scene, THEMES, Theme, glowSprite, paintScene } from './scenery';

export type { BowId, BossId };
export const BOSS_IDS: BossId[] = ['axer', 'thunder_lord', 'inferno_king', 'xeno_queen', 'thorn_warden'];

const bossBowOf = (b?: BossId): BowId =>
  b === 'thunder_lord' ? 'thunder'
  : b === 'inferno_king' ? 'fire'
  : b === 'xeno_queen' ? 'poison'
  : b === 'thorn_warden' ? 'spike'
  : 'wood';

const bossWeaponLabel = (b?: BossId): string =>
  b === 'thunder_lord' ? 'TRISULA'
  : b === 'inferno_king' ? 'PEDANG'
  : b === 'xeno_queen' ? 'SABIT'
  : b === 'thorn_warden' ? 'GADA DURI'
  : 'KAPAK';

const bossEmbedAng = (b: BossId | undefined, flightAng: number): number =>
  b === 'thunder_lord' || b === 'inferno_king' || b === 'thorn_warden'
    ? flightAng
    : flightAng + Math.PI + 0.24;

const bossTitleOf = (b: BossId): [string, string] =>
  b === 'thunder_lord' ? ['BOS KAISAR PETIR!', 'PANAH TRISULA PETIRNYA DI UDARA!']
  : b === 'inferno_king' ? ['BOS RAJA IBLIS MAGMA!', 'PANAH PEDANG APINYA DI UDARA!']
  : b === 'xeno_queen' ? ['BOS RATU XENOMORPH!', 'PANAH SABIT ASAMNYA DI UDARA!']
  : b === 'thorn_warden' ? ['BOS PANGLIMA DURI!', 'PANAH GADA DURINYA DI UDARA!']
  : ['BOS RAJA VIKING KAPAK!', 'PANAH KAPAKNYA SAAT DI UDARA!'];

const H = 1 / 120;
const AG = 980; // gravity on arrows
const DEFAULT_SPEED_MULT = 1.4; // Default arrow speed is 1.4x normal
const MAX_SPEED_MULT = 1.9;     // Max arrow speed is 1.9x normal
const speedMultOf = (pull: number, upDmg = 0) => {
  const pullBoost = Math.pow(clamp((pull - 0.5) / 0.5, 0, 1), 1.3);
  const upBoost = clamp(upDmg / 8, 0, 1) * 0.35;
  return clamp(DEFAULT_SPEED_MULT + (MAX_SPEED_MULT - DEFAULT_SPEED_MULT) * clamp(pullBoost + upBoost, 0, 1), DEFAULT_SPEED_MULT, MAX_SPEED_MULT);
};
/** Player arrow speed: 1.4x normal by default, ramping up to 1.9x max at full draw */
const speedOf = (pull: number, upDmg = 0) => (430 + 800 * pull) * speedMultOf(pull, upDmg);
/** Enemy arrow speed: scales with enemy level (`lvl` 1 = 1.0x, `lvl` 3 = 1.24x sharpshooter!) */
const foeSpeedOf = (pull: number, lvl = 1) => (430 + 800 * pull) * clamp(1 + (lvl - 1) * 0.12, 1, 1.45);
const rand = Math.random;
const gauss = () => (rand() + rand() + rand() - 1.5) * 1.15;
const FONT = '"Russo One","Arial Black","Segoe UI Black",system-ui,sans-serif';
const BEST_KEY = 'perfectshot.ragdoll.best';
const BOW_KEY = 'perfectshot.ragdoll.bow';

export type UpId = 'hp' | 'dmg' | 'multi' | 'leech';
export const UP_MAX: Record<UpId, number> = { hp: 8, dmg: 8, multi: 2, leech: 5 };
export type RangeMult = 1 | 1.5 | 2;

export interface RUi {
  stage: 'play' | 'clear' | 'shop' | 'dying' | 'dead';
  demo: boolean; level: number; kills: number; total: number; grounds: number; coins: number; shown: number; bump: number;
  /** the prisoner this level: 0 none, 1 still tied, 2 freed */
  hostage: number; totalKills: number; headshots: number;
  hp: number; maxHp: number; best: number; boss: boolean; hint: boolean; paused: boolean; theme: string; stars: number; reward: number;
  up: Record<UpId, number>; cost: Record<UpId, number | null>;
  bow: BowId;
  /** whether the Image-1 style dotted parabolic trajectory arc is shown */
  showGuide: boolean;
  /** spawn distance multiplier for this round: 1x normal, 1.5x medium-far, or 2x sniper far */
  rangeMult: RangeMult;
  /** true when MAX POWER mode is active (instant 1.9x full draw, pierces 2 enemies, auto-dead, embeds half-through in the last enemy!) */
  maxPower: boolean;
}

type Kind = 'player' | 'archer' | 'helm' | 'heavy' | 'boss' | 'axer' | 'hostage';
interface Plat {
  x: number; y: number; w: number; h: number; fx: number; fy: number;
  rise: number; state: 'rise' | 'on' | 'sink' | 'off'; phase: number; amp: number; sway: number; sinkT: number;
  /** a little spring: the ground dips when its archer is struck or looses an arrow */
  off: number; vel: number;
}
interface Stuck {
  stick: number; u: number; lx: number; ly: number; rel: number; bow: BowId; fxT: number;
  isAxe?: boolean; bossKind?: BossId; s?: number;
  /** true when a MAX POWER arrow lodged half-way through (`ARROW_LEN * 0.5`) the final enemy hit */
  halfThrough?: boolean;
}
interface Ai { state: 'wait' | 'draw' | 'hold'; t: number; aim: number; pull: number; drawT: number; spread: number; floor: number }
interface Fighter {
  k: Stick; kind: Kind; bossKind?: BossId; team: 0 | 1;
  /** fighter level (1 = normal, 2 = veteran, 3+ = thick HP & sharpshooter aim!) */
  lvl: number;
  hp: number; maxHp: number;
  /** delayed white damage catch-up bar value & hold timer (like Image 1) */
  hpLag: number; hpLagHold: number; barBump: number;
  helm: boolean; plat: Plat; stuck: Stuck[];
  vib: number; hpShow: number; flash: number; deadT: number; dmg: number; pitch: number; ai: Ai;
  /** elemental simulation timers: electrocution, fire combustion, poison acid */
  shockT: number; burnT: number; poisonT: number; dotTick: number;
}
interface Arrow {
  p: V; prev: V; vel: V; ang: number; team: 0 | 1; dmg: number; main: boolean; near: boolean;
  stuckIn: Plat | null; ox: number; oy: number; life: number; dead: boolean; bow: BowId;
  /** MAX POWER arrow: pierces up to 2 enemies (auto-kill) and lodges half-through in the 2nd enemy */
  maxPower?: boolean; pierced?: number; hitIds?: Set<Fighter>;
}
interface Part {
  p: V; prev?: V; vel: V; life: number; max: number; r: number; col: string; grav: number;
  kind?: 'helm' | 'ring' | 'fire' | 'smoke' | 'spark' | 'ember' | 'thorn' | 'acid' | 'acidSmoke' | 'acidBubble';
  rot?: number; drag?: number; turb?: number; seed?: number;
}
interface ArcFx { a: V; b: V; life: number; max: number; spread: number; segs: number; col: string; lw: number; seed: number }
/** a coin on its way to the purse (screen space, CSS px) */
interface Coin {
  x: number; y: number; ox: number; oy: number; slx: number; sly: number; t: number; i: number; n: number; sc: number;
  fly: number; sx: number; sy: number; cx: number; cy: number; val: number; spin: number; trail: V[]; done: boolean; born: boolean;
  from: V | null; at: V | null;
}
/** `full`: the whole-screen head shot; otherwise a small window over just the bone that was hit */
interface Xray { f: Fighter; stick: number; u: number; pt: V; ang: number; t: number; dur: number; full: boolean }
interface Axe {
  p: V; vel: V; ang: number; vr: number; s: number; dmg: number; spent: boolean; life: number; dead: boolean;
  bossKind: BossId; stuckIn: Plat | null; ox: number; oy: number;
}
interface Txt { x: number; y: number; life: number; max: number; text: string; col: string; size: number }
interface LooseBow { p: V; vel: V; ang: number; vr: number; s: number; bow: BowId }
interface Balloon { x: number; y: number; kind: 'heart' | 'coin'; phase: number }

const toSlab = (p: Plat): Slab2 => ({ x0: p.x - p.w / 2, x1: p.x + p.w / 2, top: p.y, bot: p.y + p.h });

export class RagWorld {
  w = 960; h = 600; dpr = 1; VW = 1200; VH = 680; sc = 1; cy = 380; span = 180; pullPx = 140;
  t = 0; rt = 0; private acc = 0; private ts = 1; private slowT = 0; private slowK = 1; private hitStop = 0;
  private shake = 0; private hurt = 0; private banner = 0; private bannerText = ''; private bannerSub = '';
  private cam = 0; private zoom = 1; private zoomTo = 1; private focus: V = v(0, 0);
  private camX = 600; private camY = 340;
  stage: RUi['stage'] = 'play'; paused = false; hint = true; demo = true;
  /** Shows the clean Image-1 style parabolic dotted trajectory arc from the arrow tip (no circle/ring UI!) */
  showGuide = true;
  /** Spawn distance multiplier for the current round: 1 (Normal), 1.5 (1.5x Far), or 2 (2x Sniper Far) */
  rangeMult: RangeMult = 1;
  /** MAX POWER mode: full 1.9x power draw, pierces up to 2 enemies (auto-dead!) & embeds half-through in the last enemy */
  maxPower = false;
  level = 1; kills = 0; total = 2; spawned = 0; maxAlive = 1;
  coins = 70; totalKills = 0; headshots = 0; best = 1; stars = 0;
  bow: BowId = 'thunder';
  up: Record<UpId, number> = { hp: 0, dmg: 0, multi: 0, leech: 0 };
  private check = { coins: 70, totalKills: 0, headshots: 0, up: { hp: 0, dmg: 0, multi: 0, leech: 0 } as Record<UpId, number> };
  private spawnT = 0; private clearT = 0; private deadT = 0; private holdAim = 0; private balloonT = 9;
  private creakAt = 0.14; private heartT = 0; private combo = 0; private coinSeq = 0;
  private lvShots = 0; private lvHits = 0; private lvHurt = 0;
  private pFyT = 0.25;
  pPlat: Plat = { x: 200, y: 400, w: 66, h: 30, fx: 0.17, fy: 0.25, rise: 1, state: 'on', phase: 0.6, amp: 5, sway: 0, sinkT: 0, off: 0, vel: 0 };
  player!: Fighter;
  foes: Fighter[] = []; plats: Plat[] = []; arrows: Arrow[] = [];
  private parts: Part[] = []; private arcs: ArcFx[] = []; private texts: Txt[] = []; private bows: LooseBow[] = []; private balloons: Balloon[] = [];
  private drag = { on: false, sx: 0, sy: 0, x: 0, y: 0 };
  private theme: Theme = THEMES[0]; private scene: Scene | null = null; private sceneKey = '';
  private flySpr: CanvasLike | null = null; private mistSpr: CanvasLike | null = null;
  private cyanSpr: CanvasLike | null = null; private fireSpr: CanvasLike | null = null; private acidSpr: CanvasLike | null = null;
  // the living backdrop (all in 0..1 screen fractions, so it survives any resize)
  private flies: { x: number; y: number; ph: number; sp: number; bl: number; r: number; front: boolean }[] = [];
  private leaves: { x: number; y: number; ph: number; sp: number; rs: number; r: number }[] = [];
  private rays: { x: number; w: number; ph: number }[] = [];
  private mists: { x: number; y: number; sp: number }[] = [];
  private vines: { x: number; len: number; ph: number }[] = [];
  private blades: { x: number; h: number; w: number; ph: number }[] = [];
  private birds: { x: number; y: number; vx: number; n: number; ph: number }[] = []; private birdT = 5;
  private coinFx: Coin[] = []; private pending = 0; private bumpN = 0; private hudFlash = 0; private rewardPaid = false;
  private goldSpr: CanvasLike | null = null;
  private xray: Xray | null = null; private panK = 0;
  private axes: Axe[] = [];
  hostage: Fighter | null = null; hostState = 0; private freeT = 0;
  private last = '';

  constructor(private emit: (ui: RUi) => void, private make: MakeCanvas) {
    try {
      this.best = Math.max(1, Number(localStorage.getItem(BEST_KEY) ?? 1) || 1);
      const savedBow = localStorage.getItem(BOW_KEY) as BowId | null;
      if (savedBow && ['thunder', 'fire', 'wood', 'spike', 'poison'].includes(savedBow)) this.bow = savedBow;
    } catch { this.best = 1; }
    for (let i = 0; i < 38; i++) {
      const front = i >= 27;
      this.flies.push({ x: rand(), y: 0.28 + rand() * 0.66, ph: rand() * 6.28, sp: 0.25 + rand() * 0.45, bl: 0.6 + rand() * 1.3, r: front ? 13 + rand() * 12 : 4.5 + rand() * 5, front });
    }
    for (let i = 0; i < 13; i++) this.leaves.push({ x: rand(), y: rand(), ph: rand() * 6.28, sp: 0.018 + rand() * 0.03, rs: (rand() - 0.5) * 1.6, r: 4 + rand() * 4 });
    for (let i = 0; i < 5; i++) this.rays.push({ x: 0.08 + i * 0.2 + rand() * 0.1, w: 0.03 + rand() * 0.05, ph: rand() * 6.28 });
    for (let i = 0; i < 3; i++) this.mists.push({ x: rand() * 1.4, y: 0.74 + i * 0.07, sp: (0.006 + rand() * 0.008) * (i % 2 ? -1 : 1) });
    for (let i = 0; i < 6; i++) this.vines.push({ x: (i + 0.2 + rand() * 0.6) / 6, len: 0.1 + rand() * 0.2, ph: rand() * 6.28 });
    for (let i = 0; i < 96; i++) this.blades.push({ x: (i + rand()) / 96, h: 10 + rand() * 30 + (rand() < 0.12 ? 22 : 0), w: 2 + rand() * 2.4, ph: rand() * 6.28 });
    this.resize(960, 600, 1);
    this.makePlayer();
    this.setupDemo();
    audioDuck(0.3);
  }

  setBow(b: BowId) {
    this.bow = b;
    try { localStorage.setItem(BOW_KEY, b); } catch { /* ignore */ }
    snd.buy();
    this.previewShot();
    this.emitUi();
  }

  /** Fires a live demonstration shot from the player stickman in the gameplay arena */
  previewShot() {
    const pf = this.player;
    const pk = pf.k;
    if (!pk.alive) return;
    let tgt: Fighter | null = null;
    for (const f of this.foes) {
      if (f.k.alive && f.plat.state === 'on') { tgt = f; break; }
    }
    if (tgt) {
      this.aimAt(pf, tgt);
      pk.aim = pf.ai.aim;
      pk.pull = pf.ai.pull;
    } else {
      pk.aim = -0.26;
      pk.pull = 0.88;
    }
    pk.aiming = 1;
    pk.nock = 1;
    this.holdAim = 0.7;
    this.fire(pf);
  }

  addCoins(n: number) {
    this.coins += n;
    this.bumpN++;
    this.hudFlash = 1;
    snd.coinPop();
    snd.buy();
    this.emitUi();
  }

  /** Toggle the Image-1 style parabolic dotted trajectory arc on/off */
  toggleGuide() {
    this.showGuide = !this.showGuide;
    snd.tap();
    this.emitUi();
  }

  /** Toggle MAX POWER mode on/off (instant 1.9x draw, pierces 2 enemies -> auto-dead, lodges half-through in the last enemy!) */
  toggleMaxPower(force?: boolean) {
    this.maxPower = force !== undefined ? force : !this.maxPower;
    this.banner = 1.9;
    this.bannerText = this.maxPower ? '⚡ MAX POWER AKTIF!' : 'MAX POWER MATI';
    this.bannerSub = this.maxPower
      ? 'PANAH TEMBUS 2 MUSUH (AUTO DEAD) & NANCEP SETENGAH DI MUSUH TERAKHIR!'
      : 'MODE TEMBAKAN STANDAR';
    snd.buy();
    this.emitUi();
  }

  /** Cycle or set enemy spawn distance multiplier: 1x Normal -> 1.5x Jarak Menengah -> 2x Jarak Jauh */
  cycleRange(force?: RangeMult) {
    const next: RangeMult =
      force !== undefined
        ? force
        : this.rangeMult === 1
          ? 1.5
          : this.rangeMult === 1.5
            ? 2
            : 1;
    this.rangeMult = next;
    for (const f of this.foes) {
      if (!f.k.alive) continue;
      const big = f.kind === 'boss' || f.kind === 'axer';
      if (next === 2) {
        f.plat.fx = big ? 1.32 + rand() * 0.32 : 1.05 + rand() * 0.58;
      } else if (next === 1.5) {
        f.plat.fx = big ? 1.02 + rand() * 0.24 : 0.78 + rand() * 0.44;
      } else {
        f.plat.fx = big ? 0.68 + rand() * 0.22 : 0.5 + rand() * 0.42;
      }
      this.placePlat(f.plat);
    }
    this.banner = 2.0;
    this.bannerText =
      next === 2 ? 'RONDE JARAK JAUH 2X!' : next === 1.5 ? 'RONDE JARAK 1.5X!' : 'RONDE JARAK 1X NORMAL';
    this.bannerSub =
      next === 1
        ? 'JARAK PIJAKAN STANDAR'
        : `MUSUH SPAWN ${next}X LEBIH JAUH · KAMERA ZOOM OUT OTOMATIS!`;
    snd.banner();
    this.emitUi();
  }

  /* ---------------- layout ---------------- */

  resize(w: number, h: number, dpr: number) {
    this.w = w; this.h = h; this.dpr = dpr;
    let VW = clamp((w / h) * 680, 660, 1400);
    let sc = w / VW; let VH = h / sc;
    if (VH < 560) { sc = h / 560; VW = w / sc; VH = 560; }
    this.VW = VW; this.VH = VH; this.sc = sc;
    const topSafe = (h < 520 ? 80 : 120) / sc; // the HUD lives up there
    this.cy = (topSafe + VH) / 2 + 12;
    this.span = clamp((VH - topSafe) / 2 - 112, 80, 240);
    this.pullPx = clamp(Math.min(w, h) * 0.3, 90, 170);
    this.pPlat.fx = clamp(VW * 0.17, 110, 260) / VW;
    this.camX = VW * 0.5; this.camY = VH * 0.5;
    this.sceneKey = '';
  }

  private placePlat(p: Plat) {
    const ty = this.cy + p.fy * this.span;
    const e = ease.out(clamp(p.rise, 0, 1));
    p.x = p.fx * this.VW + Math.sin(this.t * 0.7 + p.phase * 1.7) * p.sway;
    p.y = ty + (1 - e) * (this.VH - ty + 170) + Math.sin(this.t * 1.3 + p.phase) * p.amp + p.off;
  }
  private pan(x: number) { return clamp((x / this.VW) * 2 - 1, -0.85, 0.85); }

  /* ---------------- run / level flow ---------------- */

  private makePlayer() {
    this.pPlat.off = 0; this.pPlat.vel = 0;
    this.placePlat(this.pPlat);
    const maxHp = 100 + 20 * this.up.hp;
    const lvl = Math.max(1, 1 + Math.floor((this.level - 1) / 2) + Math.floor((this.up.hp + this.up.dmg) / 2));
    this.player = {
      k: makeStick(v(this.pPlat.x, this.pPlat.y), 1, 1, false, true), kind: 'player', team: 0,
      lvl, hp: maxHp, maxHp, hpLag: maxHp, hpLagHold: 0, barBump: 0,
      helm: false, plat: this.pPlat, stuck: [], vib: 9, hpShow: 0, flash: 0, deadT: 0, dmg: 0, pitch: 1.12,
      ai: { state: 'wait', t: 1.2, aim: 0, pull: 0.9, drawT: 0.6, spread: 0.045, floor: 0.045 },
      shockT: 0, burnT: 0, poisonT: 0, dotTick: 0,
    };
  }

  private setupLevel() {
    const L = this.level;
    this.kills = 0; this.spawned = 0;
    this.total = Math.min(2 + L, 14);
    this.maxAlive = Math.min(2 + Math.floor(L / 2), 5);
    this.spawnT = 0.45; this.clearT = 0; this.stage = 'play';
    this.theme = THEMES[Math.floor((L - 1) / 3) % THEMES.length];
    this.pFyT = [0.25, -0.05, 0.4, 0.1, -0.2][(L - 1) % 5];
    this.pPlat.amp = 4 + Math.min(L, 8) * 0.7;
    // Rounds cycle across 1x Normal (Level 1, 4, 7...), 1.5x Medium-Far (Level 2, 5, 8...), and 2x Sniper Far (Level 3, 6, 9...)!
    this.rangeMult = L % 3 === 0 ? 2 : L % 3 === 2 ? 1.5 : 1;
    this.banner = 2.4;
    this.bannerText =
      this.rangeMult === 2
        ? `LEVEL ${L} — JARAK JAUH 2X!`
        : this.rangeMult === 1.5
          ? `LEVEL ${L} — JARAK 1.5X!`
          : `LEVEL ${L} — BOS KAPAK!`;
    const prisoner = L % 4 === 3 && L % 5 !== 0; // only some rounds have someone to rescue
    this.bannerSub =
      this.rangeMult > 1
        ? `MUSUH ${this.rangeMult}X LEBIH JAUH · KAMERA ZOOM OUT OTOMATIS!`
        : prisoner ? 'PANAH KAPAK BOS & BEBASKAN TAWANAN!' : 'AWAS! PANAH SENJATA BOS DI UDARA!';
    this.check = { coins: this.coins, totalKills: this.totalKills, headshots: this.headshots, up: { ...this.up } };
    this.lvShots = 0; this.lvHits = 0; this.lvHurt = 0; this.combo = 0; this.stars = 0; this.rewardPaid = false;
    if (L > this.best) { this.best = L; try { localStorage.setItem(BEST_KEY, String(L)); } catch { /* not kept */ } }
    this.axes = []; this.hostage = null; this.hostState = 0;
    if (prisoner) this.spawnHostage();
    snd.banner();
  }

  /** the title screen: he fights on by himself, forever */
  private setupDemo() {
    this.level = 1; this.kills = 0; this.spawned = 0; this.total = 1e9; this.maxAlive = 2;
    this.spawnT = 0.6; this.stage = 'play'; this.theme = THEMES[0]; this.pFyT = 0.25; this.pPlat.amp = 5;
    this.rangeMult = 1;
    this.banner = 0; this.hint = false;
  }

  private clearWorld() {
    this.foes = []; this.plats = []; this.arrows = []; this.parts = []; this.arcs = []; this.texts = []; this.bows = []; this.balloons = [];
    this.slowT = 0; this.hitStop = 0; this.hurt = 0; this.drag.on = false; this.balloonT = 9;
    this.zoom = 1; this.zoomTo = 1; this.camX = this.VW * 0.5; this.camY = this.VH * 0.5; this.ts = 1;
    this.coinFx = []; this.pending = 0; this.xray = null; this.panK = 0;
    this.axes = []; this.hostage = null; this.hostState = 0;
  }

  nextLevel() {
    if (this.stage !== 'shop') return;
    this.level++;
    this.setupLevel();
  }

  /** again from the start of this level, with what you had when it began */
  retry() {
    this.coins = this.check.coins; this.totalKills = this.check.totalKills; this.headshots = this.check.headshots; this.up = { ...this.check.up };
    this.clearWorld(); this.makePlayer(); this.setupLevel(); this.paused = false;
  }

  restart() {
    this.level = 1; this.coins = Math.max(this.coins, 70); this.totalKills = 0; this.headshots = 0; this.up = { hp: 0, dmg: 0, multi: 0, leech: 0 };
    this.clearWorld(); this.makePlayer(); this.setupLevel(); this.paused = false; this.hint = true;
  }

  /** leave the title screen and start a run */
  startRun() { this.demo = false; audioDuck(1); this.restart(); }
  /** back to the self-playing title screen */
  toDemo() {
    this.demo = true; audioDuck(0.3);
    this.coins = Math.max(this.coins, 70); this.totalKills = 0; this.headshots = 0; this.up = { hp: 0, dmg: 0, multi: 0, leech: 0 };
    this.clearWorld(); this.makePlayer(); this.setupDemo(); this.paused = false;
  }

  setPaused(p: boolean) { this.paused = p; if (p) this.drag.on = false; }

  costOf(id: UpId): number | null {
    const n = this.up[id];
    if (n >= UP_MAX[id]) return null;
    if (id === 'hp') return 25 + 20 * n;
    if (id === 'dmg') return 30 + 25 * n;
    if (id === 'multi') return [90, 220][n];
    return 35 + 25 * n;
  }

  buy(id: UpId) {
    const c = this.costOf(id);
    if (c === null || this.coins < c) { snd.deny(); return; }
    this.coins -= c; this.up[id]++;
    if (id === 'hp') { this.player.maxHp += 20; this.player.hp += 20; this.player.hpLag = this.player.hp; }
    this.player.lvl = Math.max(1, 1 + Math.floor((this.level - 1) / 2) + Math.floor((this.up.hp + this.up.dmg) / 2));
    snd.buy();
  }

  /* ---------------- input ---------------- */

  pointerDown(x: number, y: number) {
    audioInit();
    if (this.paused || this.stage === 'shop' || this.stage === 'dead' || this.stage === 'dying') return;
    this.drag = { on: true, sx: x, sy: y, x, y };
  }
  pointerMove(x: number, y: number) { if (this.drag.on) { this.drag.x = x; this.drag.y = y; } }
  pointerUp() {
    if (!this.drag.on) return;
    this.drag.on = false;
    const k = this.player.k;
    if (k.alive && onString(k) && k.pull > 0.12 && !this.paused) this.fire(this.player);
  }
  pointerCancel() { this.drag.on = false; }

  /* ---------------- coins ---------------- */

  /** where the HUD Coin Icon sits (CSS px) — coins tuck directly behind the Coin Icon */
  private purse(): V { return this.w >= 640 ? v(36, 36) : v(26, 24); }
  /** a point in the world → CSS px on screen, through the current zoom */
  private toScreen(p: V): V {
    const [ck, cx0, cy0] = this.camTf();
    return v(p.x * ck + cx0, p.y * ck + cy0);
  }
  /**
   * The camera: scale and offset (CSS px).
   * In normal/long-range play (`zoom <= 1`), it frames the span from the player's ground to the furthest active enemy ground
   * by centering `camX, camY` at mid-screen. When zooming in (`zoom > 1` or headshot `X-ray`), it zooms about `this.focus`.
   */
  private camTf(): [number, number, number] {
    const k = this.sc * this.zoom;
    const F = this.focus;
    const baseCx = this.w * 0.5 - this.camX * k;
    const baseCy = this.h * 0.5 - this.camY * k;
    const focusScreenX = F.x * this.sc + (this.w * 0.5 - F.x * this.sc) * this.panK;
    const focusScreenY = F.y * this.sc + (this.h * 0.5 - F.y * this.sc) * this.panK;
    const focusCx = focusScreenX - F.x * k;
    const focusCy = focusScreenY - F.y * k;
    const useFocus = clamp(Math.max(this.panK, (this.zoom - 1) * 5), 0, 1);
    return [
      k,
      baseCx + (focusCx - baseCx) * useFocus,
      baseCy + (focusCy - baseCy) * useFocus,
    ];
  }

  /** a haul of coins: they pop out big into a neat fan, hang there a beat, then stream home in single file */
  private spawnCoins(at: V, total: number, screen = false) {
    if (this.demo || total <= 0) return;
    const n = Math.min(total, clamp(Math.round(total / 1.5), 4, 10));
    this.coins += total; this.pending += total;
    const hold = this.xray && this.xray.full ? this.xray.dur - this.xray.t + 0.12 : 0;
    const outer = Math.min(n, 6);
    for (let i = 0; i < n; i++) {
      const row = i < outer ? 0 : 1; const cnt = row ? n - outer : outer; const j = row ? i - outer : i;
      const ang = -Math.PI / 2 + (j - (cnt - 1) / 2) * (row ? 0.86 : 0.44);
      const R = row ? 38 : 74;
      this.coinFx.push({
        x: 0, y: 0, ox: 0, oy: 0, slx: Math.cos(ang) * R, sly: Math.sin(ang) * R, t: -hold, i, n, sc: 0, fly: -1, sx: 0, sy: 0, cx: 0, cy: 0,
        val: Math.floor(total / n) + (i < total % n ? 1 : 0), spin: i * 0.7, trail: [], done: false, born: false,
        from: screen ? null : { ...at }, at: screen ? { ...at } : null,
      });
    }
  }

  private stepCoins(dt: number) {
    this.hudFlash = Math.max(0, this.hudFlash - dt * 3.8);
    if (!this.coinFx.length) return;
    const tgt = this.purse();
    for (const c of this.coinFx) {
      c.t += dt;
      if (c.t < 0) continue;
      if (!c.born) {
        c.born = true;
        const o = c.from ? this.toScreen(c.from) : (c.at as V);
        c.ox = clamp(o.x, 84, this.w - 84); c.oy = clamp(o.y - 8, 100, this.h - 30);
        c.x = c.ox; c.y = c.oy;
      }
      const lt = c.t - c.i * 0.035;
      if (lt < 0) continue;
      if (lt - dt < 0) snd.coinTick(c.i);
      c.spin += dt * (c.fly < 0 ? 7.5 : 11.5);
      const depart = c.n * 0.035 + 0.48 + c.i * 0.068;
      if (c.t < depart) {
        const u = Math.min(1, lt / 0.34); const e = ease.outBack(u);
        c.x = c.ox + c.slx * e;
        c.y = c.oy + c.sly * e + (u >= 1 ? Math.sin(c.t * 6.5 - c.i * 0.7) * 2.5 : 0);
        c.sc = 1.65 * Math.min(1.08, 0.18 + e * 0.9);
        continue;
      }
      if (c.fly < 0) {
        // Curve smoothly toward the left/bottom of the HUD Coin Icon so it tucks directly BEHIND the coin icon
        // without crossing over the score digits
        c.fly = 0; c.sx = c.x; c.sy = c.y;
        c.cx = tgt.x + (c.sx - tgt.x) * 0.24;
        c.cy = Math.max(tgt.y + 42, (c.sy + tgt.y) * 0.54 - Math.min(75, Math.abs(c.sx - tgt.x) * 0.08));
      }
      c.fly = Math.min(1, c.fly + dt / 0.64);
      // Ultra-smooth C1 cubic/quintic blend: gentle liftoff, smooth glide, soft arrival
      const u = c.fly;
      const smoothStep = u * u * (3 - 2 * u);
      const e = 0.55 * smoothStep + 0.45 * (u * u);
      const m = 1 - e;
      const nx = m * m * c.sx + 2 * m * e * c.cx + e * e * tgt.x;
      const ny = m * m * c.sy + 2 * m * e * c.cy + e * e * tgt.y;
      if (Math.hypot(nx - c.x, ny - c.y) > 1.2) {
        c.trail.push(v(c.x, c.y));
        if (c.trail.length > 14) c.trail.shift();
      }
      c.x = nx; c.y = ny;
      // Keep coin large and plump all the way to the HUD Coin Icon (no tiny shrinking!)
      c.sc = 1.65 - 0.16 * e;
      if (c.fly >= 1) {
        c.done = true;
        this.pending = Math.max(0, this.pending - c.val); this.bumpN++; this.hudFlash = 1;
        snd.coin(this.coinSeq++);
      }
    }
    this.coinFx = this.coinFx.filter((c) => !c.done);
    if (!this.coinFx.length) { snd.coinEnd(this.coinSeq - 1); this.coinSeq = 0; this.pending = 0; }
  }

  private drawCoins(ctx: Ctx) {
    const gold = this.goldSpr;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';

    // PASS 1 (BACK LAYER — strictly behind the coin images):
    // Draw the purse landing ring, golden glow halos, and smooth tapered light ribbons first!
    if (this.hudFlash > 0.01) {
      const tgt = this.purse(); const u = 1 - this.hudFlash;
      if (gold) {
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = this.hudFlash * 0.55;
        const gr = 28 + u * 18;
        ctx.drawImage(gold as unknown as CanvasImageSource, tgt.x - gr, tgt.y - gr, gr * 2, gr * 2);
        ctx.globalCompositeOperation = 'source-over';
      }
      ctx.strokeStyle = '#ffe27a';
      ctx.globalAlpha = this.hudFlash * 0.85; ctx.lineWidth = 2.8 * this.hudFlash + 0.8;
      ctx.beginPath(); ctx.arc(tgt.x, tgt.y, 13 + u * 18, 0, Math.PI * 2); ctx.stroke();
    }

    for (const c of this.coinFx) {
      if (!c.born || c.t - c.i * 0.035 < 0) continue;
      const r = 7.5 * c.sc;
      // Smooth quadratic ribbon trail behind the coin
      if (c.trail.length > 1) {
        for (let i = 1; i < c.trail.length; i++) {
          const u = i / c.trail.length;
          ctx.strokeStyle = '#ffe27a';
          ctx.globalAlpha = u * u * 0.55;
          ctx.lineWidth = r * 0.88 * u;
          ctx.beginPath();
          ctx.moveTo(c.trail[i - 1].x, c.trail[i - 1].y);
          ctx.lineTo(c.trail[i].x, c.trail[i].y);
          ctx.stroke();
        }
      }
      // Soft golden halo in the back layer behind the coin face
      if (gold) {
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = 0.42;
        ctx.drawImage(gold as unknown as CanvasImageSource, c.x - r * 2.1, c.y - r * 2.1, r * 4.2, r * 4.2);
        ctx.globalCompositeOperation = 'source-over';
      }
    }

    // PASS 2 (FRONT LAYER — the crisp spinning gold coin images themselves):
    for (const c of this.coinFx) {
      if (!c.born || c.t - c.i * 0.035 < 0) continue;
      const r = 7.5 * c.sc;
      ctx.globalAlpha = 1;
      const wx = c.fly < 0 ? 0.84 + 0.16 * Math.cos(c.spin) : 0.25 + 0.75 * Math.abs(Math.cos(c.spin));
      ctx.fillStyle = '#9a6200'; ctx.beginPath(); ctx.ellipse(c.x, c.y + r * 0.1, r * wx + r * 0.16, r * 1.08, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#ffc933'; ctx.beginPath(); ctx.ellipse(c.x, c.y, r * wx + r * 0.07, r, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#e39a00'; ctx.lineWidth = Math.max(0.8, r * 0.13);
      ctx.beginPath(); ctx.ellipse(c.x, c.y, Math.max(0.4, r * wx * 0.68), r * 0.68, 0, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = '#e39a00'; ctx.fillRect(c.x - r * 0.12 * wx, c.y - r * 0.4, r * 0.24 * wx, r * 0.8);
      ctx.fillStyle = '#fff6c8'; ctx.beginPath(); ctx.ellipse(c.x - r * wx * 0.34, c.y - r * 0.4, Math.max(0.3, r * wx * 0.2), r * 0.17, -0.5, 0, Math.PI * 2); ctx.fill();
      const tw = Math.max(0, Math.sin(c.t * 8 + c.i * 2.1)) ** 6;
      if (tw > 0.05) {
        const gx = c.x + r * 0.5; const gy = c.y - r * 0.55; const gl = r * 0.65 * tw;
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.3; ctx.globalAlpha = tw;
        ctx.beginPath(); ctx.moveTo(gx - gl, gy); ctx.lineTo(gx + gl, gy); ctx.moveTo(gx, gy - gl); ctx.lineTo(gx, gy + gl); ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
    ctx.globalAlpha = 1;
  }

  /* ---------------- the prisoner ---------------- */

  /** some rounds a prisoner stands tied on a ground of his own, leashed to a peg above: cut the rope, not him */
  private spawnHostage() {
    const plat: Plat = {
      x: 0, y: 0, w: 58, h: 28, fx: 0.4 + rand() * 0.11, fy: -0.15 + rand() * 0.6, rise: 0, state: 'rise', phase: rand() * 6.28,
      amp: 6, sway: 0, sinkT: 0, off: 0, vel: 0,
    };
    this.placePlat(plat);
    this.plats.push(plat);
    this.hostage = {
      k: makeStick(v(plat.x, plat.y), -1, 1, false, true, 'hostage'), kind: 'hostage', team: 0,
      lvl: 1, hp: 1, maxHp: 1, hpLag: 1, hpLagHold: 0, barBump: 0,
      helm: false, plat, stuck: [],
      vib: 9, hpShow: 0, flash: 0, deadT: 0, dmg: 0, pitch: 1.3,
      ai: { state: 'wait', t: 0, aim: 0, pull: 0, drawT: 1, spread: 0, floor: 0 },
      shockT: 0, burnT: 0, poisonT: 0, dotTick: 0,
    };
    this.hostState = 1; this.freeT = 0;
  }
  /** the taut stretch of rope you have to hit: from the peg down to just above his head */
  private rope(hs: Fighter): [V, V] {
    return [v(hs.plat.x, hs.plat.y - 176), v(hs.k.p[0].x, hs.k.p[0].y - HEAD_R - 3)];
  }

  private freeHostage(at: V) {
    const hs = this.hostage;
    if (!hs || this.hostState !== 1) return;
    const k = hs.k; const pan = this.pan(at.x);
    this.hostState = 2; this.freeT = 0;
    this.burst(at, v(0, -1), 9, '#e3c283', 170);
    for (let i = 0; i < 8; i++) this.parts.push({ p: lerpV(k.p[2], k.p[1], 0.3 + rand() * 0.4), vel: v((rand() - 0.5) * 220, -60 - rand() * 120), life: 0, max: 0.7 + rand() * 0.3, r: 2.2, col: '#e3c283', grav: 900 });
    this.parts.push({ p: { ...at }, vel: v(0, 0), life: 0, max: 0.25, r: 20, col: '#ffe9b0', grav: 0, kind: 'ring' });
    snd.ropeSnap(pan); snd.yay(pan); snd.heal();
    this.say(k.p[0].x, k.p[0].y - 64, 'BEBAS!  TERIMA KASIH!', '#7dffa0', 19, 1.7);
    this.spawnCoins(k.p[1], 15);
    const pf = this.player; pf.hp = Math.min(pf.maxHp, pf.hp + 20);
    this.lvHits++; this.combo++;
    if (this.kills >= this.total) this.beginClear(null);
  }

  /** you shot the man you were meant to save */
  private hostageHit(a: Arrow, hs: Fighter, hit: { stick: number; u: number }) {
    const k = hs.k; const pan = this.pan(a.p.x);
    this.lodge(a, hs, hit);
    a.dead = true;
    punchRag(k as unknown as ArcherRag, hit.stick, hit.u, a.vel, false);
    k.muscle = Math.min(k.muscle, 0.5); k.hurt = 1; k.hurtDir = Math.sign(a.vel.x) || 1; k.wound = { stick: hit.stick, u: hit.u };
    hs.flash = 1; hs.plat.vel += 70;
    this.burst(a.p, mul(a.vel, -1), 6, '#d3141f', 200);
    this.hitStop = 0.04; this.shake = Math.max(this.shake, 5);
    snd.hit(pan, false); snd.grunt(pan, hs.pitch); snd.deny();
    this.coins = Math.max(0, this.coins - 10); this.combo = 0;
    this.say(k.p[0].x, k.p[0].y - 56, 'JANGAN TEMBAK TAWANAN!  -10', '#ff6b6b', 16, 1.5);
  }

  private drawHostage(ctx: Ctx) {
    const hs = this.hostage;
    if (!hs) return;
    const k = hs.k; const th = this.theme; const pl = hs.plat;
    const al = pl.state === 'on' ? 1 : clamp(pl.rise * 1.5, 0, 1);
    const [top, bot] = this.rope(hs);
    ctx.globalAlpha = al;
    // the peg: a chip of floating rock with an iron ring under it
    ctx.fillStyle = th.plat; ctx.fillRect(top.x - 14, top.y - 14, 28, 12);
    ctx.fillStyle = th.platTop; ctx.fillRect(top.x - 14, top.y - 14, 28, 3);
    ctx.strokeStyle = '#9fb4bb'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(top.x, top.y + 2, 4, 0, Math.PI * 2); ctx.stroke();
    ctx.lineCap = 'round';
    const rope = (a: V, b: V, sag: number) => {
      for (const [col, lw] of [['#8a6a34', 4.2], ['#e3c283', 2.4]] as [string, number][]) {
        ctx.strokeStyle = col; ctx.lineWidth = lw;
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.quadraticCurveTo((a.x + b.x) / 2 + sag, (a.y + b.y) / 2, b.x, b.y); ctx.stroke();
      }
    };
    if (this.hostState === 1) {
      rope(v(top.x, top.y + 5), k.p[1], Math.sin(this.t * 2.1) * 2.5);
      // a ring on the rope: this is the place to hit
      const m = lerpV(top, bot, 0.52); const pu = 0.5 + 0.5 * Math.sin(this.rt * 5);
      ctx.strokeStyle = '#ffe27a'; ctx.globalAlpha = al * (0.45 + 0.5 * pu); ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(m.x, m.y, 10 + pu * 4, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(m.x - 17 - pu * 4, m.y); ctx.lineTo(m.x - 11, m.y); ctx.moveTo(m.x + 11, m.y); ctx.lineTo(m.x + 17 + pu * 4, m.y); ctx.stroke();
      ctx.globalAlpha = al;
    } else {
      // what is left of it swings from the peg
      const sw = Math.sin(this.freeT * 9) * 9 * Math.exp(-this.freeT * 1.4);
      rope(v(top.x, top.y + 5), v(top.x + sw, top.y + 34), sw * 0.5);
    }
    this.drawFighter(ctx, hs);
    if (this.hostState === 1 && pl.state === 'on' && Math.sin(this.rt * 1.6 + 1) > -0.2) {
      this.text(ctx, 'TOLONG!', k.p[0].x + 44, k.p[0].y - 26 + Math.sin(this.rt * 9) * 1.5, 13, '#ffffff', 0.95);
    }
    ctx.globalAlpha = 1;
  }

  /* ---------------- the axe boss ---------------- */

  /** Hurls the Boss's unique signature weapon (`bossKind`); it lands and EMBEDS (`nancep`) unless shot down in mid-air */
  private throwAxe(f: Fighter) {
    const k = f.k; const pk = this.player.k;
    const from = { ...k.p[4] }; const to = lerpV(pk.p[1], pk.p[2], 0.3);
    const T = 1.62 + rand() * 0.28; const g = 620; // slow enough to answer with an arrow
    const bk: BossId = f.bossKind ?? 'axer';
    const initVel = v((to.x - from.x) / T, (to.y - from.y) / T - 0.5 * g * T);
    // Zeus's Thunderbolt Trident flies point-first like a javelin (`vr = 0`), while the Axe, Greatsword, Scythe & Morning-Star spin!
    const vr = bk === 'thunder_lord' ? 0 : bk === 'thorn_warden' ? -k.face * 15 : -k.face * 12;
    this.axes.push({
      p: from, vel: initVel,
      ang: Math.atan2(initVel.y, initVel.x), vr, s: 1.38, dmg: f.dmg * 1.4,
      spent: false, life: 0, dead: false, bossKind: bk, stuckIn: null, ox: 0, oy: 0,
    });
    impulse(k, 4, v(k.face * 260, -40)); impulse(k, 1, v(k.face * 90, 0)); impulse(k, 0, v(k.face * 120, 20));
    k.muscle = Math.min(k.muscle, 0.6); k.exert = Math.min(1, k.exert + 0.4);
    k.pull = 0; k.nock = 0; f.plat.vel += 40;
    snd.throwAxe(this.pan(from.x), f.pitch);
    const shout =
      bk === 'thunder_lord' ? '⚡ TERIMA TRISULA PETIR!'
      : bk === 'inferno_king' ? '🔥 PEDANG IBLIS MAGMA!'
      : bk === 'xeno_queen' ? '🧪 SABIT EKOR XENO!'
      : bk === 'thorn_warden' ? '🌿 GADA BINTANG DURI!'
      : '🪓 TERIMA KAPAK VIKING!';
    const sCol =
      bk === 'thunder_lord' ? '#5cf4ff'
      : bk === 'inferno_king' ? '#ff942e'
      : bk === 'xeno_queen' ? '#d4ff00'
      : bk === 'thorn_warden' ? '#8eff3b'
      : '#ff8a47';
    if (!this.demo) this.say(k.p[0].x, k.p[0].y - 68 * k.s, shout, sCol, 16, 1.0);
  }

  private parry(ax: Axe, a: Arrow) {
    ax.dead = true; a.dead = true;
    const pan = this.pan(ax.p.x);
    this.burst(ax.p, a.vel, 14, '#dbe8ec', 360);
    this.burst(ax.p, v(0, -1), 9, '#7a4a2a', 240);
    this.parts.push({ p: { ...ax.p }, vel: v(0, 0), life: 0, max: 0.28, r: 42, col: '#ffffff', grav: 0, kind: 'ring' });
    this.hitStop = 0.06; this.slowT = 0.32; this.slowK = 0.28;
    this.shake = Math.max(this.shake, 9);
    snd.parry(pan);

    // Elemental impact when shooting the Boss's weapon mid-air
    if (a.bow === 'thunder') this.triggerThunderHit(ax.p, a.ang, null, null, pan);
    else if (a.bow === 'fire') this.triggerFireHit(ax.p, a.ang, null, null, pan);
    else if (a.bow === 'spike') this.triggerSpikeHit(ax.p, a.ang, null, pan);
    else if (a.bow === 'poison') this.triggerPoisonHit(ax.p, a.ang, null, null, pan);

    const wName = bossWeaponLabel(ax.bossKind);
    this.say(ax.p.x, ax.p.y - 28, `${wName} HANCUR! +10`, '#ffe24a', 21, 1.25);
    this.spawnCoins(ax.p, 10);
    this.lvHits++; this.combo++;
  }

  /**
   * Lodge the Boss's thrown weapon (`ax`) deeply into the bone `hit.stick` at `hit.u` so it stays embedded (`nancep`)
   * and moves with the ragdoll instead of bouncing off!
   */
  private lodgeAxe(ax: Axe, f: Fighter, hit: { stick: number; u: number }): V {
    const k = f.k;
    const [ia, ib] = RAG_STICKS[hit.stick];
    const A = k.p[ia]; const B = k.p[ib];
    const tip = hit.stick === 0 ? lerpV(k.p[1], k.p[0], 0.85) : lerpV(A, B, hit.u);
    const ba = Math.atan2(B.y - A.y, B.x - A.x);
    const rx = tip.x - A.x; const ry = tip.y - A.y; const c = Math.cos(-ba); const sn = Math.sin(-ba);
    const flightAng = Math.atan2(ax.vel.y, ax.vel.x);
    const embedAng = bossEmbedAng(ax.bossKind, flightAng);
    const bowElem = bossBowOf(ax.bossKind);
    const fxDur = bowElem === 'wood' ? 0 : 2.2;
    f.stuck.push({
      stick: hit.stick, u: hit.u,
      lx: rx * c - ry * sn, ly: rx * sn + ry * c,
      rel: embedAng - ba,
      bow: bowElem, fxT: fxDur,
      isAxe: true, bossKind: ax.bossKind, s: ax.s * 0.92,
    });
    if (f.stuck.length > 7) f.stuck.shift();
    return tip;
  }

  private axeHit(ax: Axe, hit: { stick: number; u: number }) {
    const pf = this.player; const k = pf.k; const pan = this.pan(ax.p.x);
    const tip = this.lodgeAxe(ax, pf, hit);
    ax.dead = true; // The Boss weapon is now embedded (`nancep`) inside `pf.stuck`, NOT bouncing away!

    const flightAng = Math.atan2(ax.vel.y, ax.vel.x);
    const bowElem = bossBowOf(ax.bossKind);
    if (bowElem === 'thunder') this.triggerThunderHit(tip, flightAng, pf, hit, pan);
    else if (bowElem === 'fire') this.triggerFireHit(tip, flightAng, pf, hit, pan);
    else if (bowElem === 'poison') this.triggerPoisonHit(tip, flightAng, pf, hit, pan);
    else if (bowElem === 'spike') this.triggerSpikeHit(tip, flightAng, pf, pan);

    const dmg = Math.max(1, Math.round(ax.dmg));
    pf.hpLag = Math.max(pf.hpLag, pf.hp);
    pf.hpLagHold = 0.28;
    pf.barBump = 1;
    pf.hp -= dmg; pf.flash = 1; this.lvHurt += dmg;
    const fatal = pf.hp <= 0;
    punchRag(k as unknown as ArcherRag, hit.stick, hit.u, mul(ax.vel, 2.2), fatal);
    k.muscle = Math.min(k.muscle, 0.3); k.hurt = 1; k.hurtDir = Math.sign(ax.vel.x) || -1; k.wound = { stick: hit.stick, u: hit.u }; k.exert = 1;
    pf.plat.vel += 140;
    this.burst(tip, mul(ax.vel, -1), 14, '#d3141f', 320);
    this.parts.push({ p: { ...tip }, vel: v(0, 0), life: 0, max: 0.24, r: 30, col: '#ffffff', grav: 0, kind: 'ring' });
    this.hitStop = 0.08; this.shake = Math.max(this.shake, 13); this.hurt = 1;
    snd.hit(pan, true);
    if (!fatal) snd.grunt(pan, pf.pitch);
    const wName = bossWeaponLabel(ax.bossKind);
    this.say(k.p[0].x, k.p[0].y - 52, `${wName} NANCEP! -${dmg}`, '#ff6b6b', 20);
    if (fatal) this.die(pf, false);
  }

  /** the round is won: every enemy down and nobody left tied up */
  private beginClear(focus: V | null) {
    this.stage = 'clear'; this.clearT = 0; this.drag.on = false;
    if (focus) { this.zoomTo = 1.13; if (!(this.xray && this.xray.full)) this.focus = { ...focus }; }
    const acc = this.lvHits / Math.max(1, this.lvShots);
    this.stars = 1 + (acc >= 0.5 ? 1 : 0) + (this.lvHurt <= this.player.maxHp * 0.35 ? 1 : 0);
    snd.win();
  }

  /* ---------------- spawning ---------------- */

  /** Summon one of the 5 Bosses immediately (or force an existing one to throw his axe) */
  spawnAxeBossNow(bossKind?: BossId) {
    if (this.stage !== 'play') return;
    if (!bossKind) {
      const aliveAxer = this.foes.find((f) => f.k.alive && f.kind === 'axer');
      if (aliveAxer) {
        this.throwAxe(aliveAxer);
        const [bt, bs] = bossTitleOf(aliveAxer.bossKind ?? 'axer');
        this.banner = 1.8; this.bannerText = bt; this.bannerSub = bs;
        return;
      }
    } else {
      const existingSame = this.foes.find((f) => f.k.alive && f.kind === 'axer' && f.bossKind === bossKind);
      if (existingSame) {
        this.throwAxe(existingSame);
        const [bt, bs] = bossTitleOf(bossKind);
        this.banner = 1.8; this.bannerText = bt; this.bannerSub = bs;
        return;
      }
    }
    this.total++;
    this.spawnEnemy('axer', bossKind);
  }

  private spawnEnemy(forceKind?: Kind, forceBoss?: BossId) {
    const L = this.level;
    const hasAliveAxer = this.foes.some((f) => f.k.alive && f.kind === 'axer');
    // Guarantee one of the 5 Bosses appears in every level!
    const boss = !this.demo && (forceKind === 'axer' || !hasAliveAxer || this.spawned === this.total - 1);
    const r = rand();
    const kind: Kind =
      forceKind ? forceKind
      : boss ? 'axer'
      : this.demo && r < 0.45 ? 'axer'
      : L >= 3 && r < 0.26 ? 'heavy'
      : (L >= 1 || this.demo) && r < 0.55 ? 'helm'
      : 'archer';
    const big = kind === 'boss' || kind === 'axer';
    const bossKind: BossId | undefined = big ? (forceBoss ?? BOSS_IDS[(L - 1 + this.spawned) % BOSS_IDS.length]) : undefined;

    // Enemy Level (`lvl`):
    // - Level 1: Normal HP & normal archery
    // - Level 2: Veteran (thicker HP & tighter aim)
    // - Level 3+: Elite / Boss ("lebih tebal dan dia manahnya lebih jago!")
    const roll = rand();
    const foeLvl =
      big ? Math.max(3, 3 + Math.floor((L - 1) / 2))
      : kind === 'heavy' ? Math.max(3, 2 + Math.floor(L / 2))
      : kind === 'helm' ? (roll < 0.48 ? 3 : 2)
      : roll < 0.52 ? 1 : roll < 0.82 ? 2 : 3;

    const s = big ? 1.45 : kind === 'heavy' ? 1.22 : foeLvl >= 3 ? 1.12 : foeLvl === 2 ? 1.05 : 1;
    const kneel = !big && rand() < 0.5;
    // Spawn distance adapts to `this.rangeMult` (1x Normal, 1.5x Medium-Far, 2x Sniper Far)!
    const rm: RangeMult = this.demo ? 1 : this.rangeMult;
    let fx = rm === 2 ? 1.42 : rm === 1.5 ? 1.08 : 0.78; let fy = 0.08;
    for (let i = 0; i < 40; i++) {
      fx = this.demo
        ? 0.74 + rand() * 0.2
        : rm === 2
          ? big ? 1.32 + rand() * 0.34 : 1.02 + rand() * 0.62
          : rm === 1.5
            ? big ? 1.02 + rand() * 0.24 : 0.76 + rand() * 0.46
            : big ? 0.68 + rand() * 0.22 : 0.5 + rand() * 0.43;
      fy = big ? -0.15 + rand() * 0.45 : rand() * 2 - 1;
      const x = fx * this.VW; const y = this.cy + fy * this.span;
      const hp = this.hostState === 1 && this.hostage ? this.hostage.plat : null;
      if (hp && Math.abs(hp.fx * this.VW - x) < 115 && y < this.cy + hp.fy * this.span) continue;
      if (!this.plats.some((p) => Math.abs(p.fx * this.VW - x) < 135 && Math.abs(this.cy + p.fy * this.span - y) < 150)) break;
    }
    const plat: Plat = {
      x: 0, y: 0, w: (kneel ? 72 : 64) * s, h: 28 * Math.min(s, 1.25), fx, fy, rise: 0, state: 'rise', phase: rand() * 6.28,
      amp: 5 + Math.min(L, 10) * 1.4, sway: L >= 4 && !big ? rand() * Math.min(L * 3, 26) : 0, sinkT: 0, off: 0, vel: 0,
    };
    this.placePlat(plat);
    this.plats.push(plat);

    // HP scales distinctly with Enemy Level (`foeLvl` 1 = normal, `foeLvl` 3 = ~2.1x thicker!)
    const lvlHpMult = foeLvl === 1 ? 1.0 : foeLvl === 2 ? 1.48 : 2.1 + (foeLvl - 3) * 0.42;
    const baseHp = 38 + 5 * Math.min(L, 14);
    const hp = Math.round(baseHp * lvlHpMult + (big ? 85 + 18 * L : 0));
    const dmg = (8 + 0.6 * Math.min(L, 15)) * (big ? 1.45 : foeLvl >= 3 ? 1.3 : foeLvl === 2 ? 1.15 : 1);

    // Archery skill scales with Enemy Level (`foeLvl` 3 draws faster, aims much tighter & shoots more often!)
    const initSpread = foeLvl === 1 ? 0.22 : foeLvl === 2 ? 0.12 : Math.max(0.032, 0.055 - (foeLvl - 3) * 0.006);
    const minFloor = foeLvl === 1 ? 0.065 : foeLvl === 2 ? 0.038 : 0.018;
    const initWait = kind === 'axer' ? 1.0 + rand() * 0.5 : foeLvl >= 3 ? 1.15 + rand() * 0.65 : foeLvl === 2 ? 1.6 + rand() * 0.9 : 2.1 + rand() * 1.2;

    this.foes.push({
      k: makeStick(v(plat.x, plat.y), -1, s, kneel, big || foeLvl >= 3, kind === 'axer' ? 'thrower' : 'archer'),
      kind, bossKind, team: 1,
      lvl: foeLvl, hp, maxHp: hp, hpLag: hp, hpLagHold: 0, barBump: 0,
      helm: kind === 'helm' || (foeLvl >= 3 && !big && rand() < 0.5), plat, stuck: [],
      vib: 9, hpShow: 0, flash: 0, deadT: 0, dmg, pitch: big ? 0.68 : foeLvl >= 3 ? 0.78 : 0.9 + rand() * 0.2,
      ai: { state: 'wait', t: initWait, aim: Math.PI, pull: foeLvl >= 3 ? 0.92 : 0.8, drawT: foeLvl >= 3 ? 0.5 : 0.72, spread: initSpread, floor: minFloor },
      shockT: 0, burnT: 0, poisonT: 0, dotTick: 0,
    });
    this.spawned++;
    snd.rise(this.pan(plat.x));
    if (big && !this.demo && bossKind) {
      const [bt, bs] = bossTitleOf(bossKind);
      this.banner = 2.4;
      this.bannerText = bt;
      this.bannerSub = bs;
      snd.boss();
    }
  }

  /* ---------------- shooting ---------------- */

  private fire(f: Fighter) {
    const k = f.k; const ang = fireAngle(k);
    const isMaxPwr = f.team === 0 && !this.demo && this.maxPower;
    const pull = isMaxPwr ? 1 : k.pull;
    const sp = f.team === 0 ? (isMaxPwr ? (430 + 800) * MAX_SPEED_MULT : speedOf(pull, this.up.dmg)) : foeSpeedOf(pull, f.lvl);
    const dir = fromAngle(ang);
    const n = f.team === 0 ? 1 + this.up.multi : (f.kind === 'boss' && this.level >= 15) || (f.lvl >= 4 && f.kind !== 'axer' && rand() < 0.35) ? 2 : 1;
    const bowUsed: BowId = f.team === 0 ? this.bow : 'wood';
    const bowDmgMult = bowUsed === 'thunder' || bowUsed === 'fire' ? 1.25 : bowUsed === 'spike' || bowUsed === 'poison' ? 1.18 : 1;
    for (let i = 0; i < n; i++) {
      const a = ang + (i - (n - 1) / 2) * 0.075;
      const tip = add(k.p[4], fromAngle(a, 14 * k.s));
      const dmg = f.team === 0 ? (isMaxPwr ? 9999 : 42 * bowDmgMult * (0.45 + 0.65 * pull) * (1 + 0.18 * this.up.dmg)) : f.dmg * (0.7 + 0.3 * pull);
      this.arrows.push({
        p: tip, prev: { ...tip }, vel: fromAngle(a, sp), ang: a, team: f.team, dmg,
        main: i === Math.floor((n - 1) / 2), near: false, stuckIn: null, ox: 0, oy: 0, life: 0, dead: false, bow: bowUsed,
        maxPower: isMaxPwr, pierced: 0, hitIds: isMaxPwr ? new Set<Fighter>() : undefined,
      });
    }
    // Natural Level-1 release burst aligned with bow angle `ang` and real world gravity
    const releasePt = add(k.p[4], mul(dir, 14 * k.s));
    if (bowUsed === 'thunder') {
      for (let i = 0; i < 6; i++) {
        const sa = ang + (rand() - 0.5) * 0.55; const ssp = 120 + rand() * 220;
        this.parts.push({ p: { ...releasePt }, prev: { ...releasePt }, vel: v(Math.cos(sa) * ssp, Math.sin(sa) * ssp), life: 0, max: 0.14 + rand() * 0.12, r: 1.5, col: i % 2 ? '#00f0ff' : '#ffffff', grav: 640, kind: 'spark', drag: 3.5 });
      }
      snd.thunderRelease(pull, this.pan(k.p[4].x));
    } else if (bowUsed === 'fire') {
      for (let i = 0; i < 6; i++) {
        const sa = ang + (rand() - 0.5) * 0.45; const ssp = 85 + rand() * 140;
        this.parts.push({ p: { ...releasePt }, vel: v(Math.cos(sa) * ssp, Math.sin(sa) * ssp), life: 0, max: 0.22 + rand() * 0.16, r: 4.5 + rand() * 3.5, col: '#ff7b1c', grav: -220, kind: 'fire', drag: 3.8, turb: 7, seed: rand() * 50 });
      }
      snd.fireRelease(pull, this.pan(k.p[4].x));
    } else if (bowUsed === 'poison') {
      for (let i = 0; i < 5; i++) {
        const sa = ang + (rand() - 0.5) * 0.45; const ssp = 90 + rand() * 150;
        this.parts.push({ p: { ...releasePt }, prev: { ...releasePt }, vel: v(Math.cos(sa) * ssp, Math.sin(sa) * ssp), life: 0, max: 0.24 + rand() * 0.18, r: 1.8 + rand() * 1.4, col: i % 2 ? '#d4ff00' : '#6eff00', grav: 720, kind: 'acid', drag: 1.6 });
      }
      snd.acidSpit(this.pan(k.p[4].x));
    } else {
      snd.release(f.team === 0 ? pull : pull * 0.6, this.pan(k.p[4].x));
    }
    // the release: bow hand jumps forward, the string hand swings back, the torso rocks, the muscles go soft a moment
    impulse(k, 4, mul(dir, 100 * pull)); impulse(k, 3, mul(dir, 45 * pull));
    impulse(k, 6, mul(dir, -250 * pull)); impulse(k, 5, mul(dir, -170 * pull));
    impulse(k, 1, mul(dir, -115 * pull)); impulse(k, 0, mul(dir, -160 * pull)); impulse(k, 2, mul(dir, -45 * pull));
    k.muscle = Math.min(k.muscle, 0.58);
    k.exert = Math.min(1, k.exert + 0.3);
    k.pull = 0; k.nock = 0; f.vib = 0;
    f.plat.vel += 26 * pull;
    if (f.team === 0 && !this.demo) { this.hint = false; this.holdAim = 0.55; this.shake = Math.max(this.shake, 1.5 + pull * 3); this.lvShots++; }
    if (this.arrows.length > 60) this.arrows.splice(0, this.arrows.length - 60);
  }

  /** pick an angle and draw for a lobbed shot at the target, with an error that shrinks every shot */
  private aimAt(f: Fighter, tgt: Fighter) {
    const from = f.k.p[1]; const tk = tgt.k;
    const to = lerpV(tk.p[1], tk.p[2], 0.35);
    const dx = to.x - from.x; const dy = to.y - from.y; const X = Math.max(40, Math.abs(dx));
    let pull = clamp(0.5 + X / 1300 + rand() * 0.12 + (f.lvl >= 3 ? 0.15 : 0), 0.55, 1);
    const calcSp = (p: number) => (f.team === 0 ? speedOf(p, this.up.dmg) : foeSpeedOf(p, f.lvl));
    let sp = calcSp(pull);
    let disc = sp ** 4 - AG * (AG * X * X - 2 * dy * sp * sp);
    if (disc < 0) { pull = 1; sp = calcSp(1); disc = sp ** 4 - AG * (AG * X * X - 2 * dy * sp * sp); }
    const th = (disc < 0 ? Math.PI / 4 : Math.atan((sp * sp - Math.sqrt(disc)) / (AG * X))) + gauss() * f.ai.spread;
    f.ai.aim = Math.atan2(-Math.sin(th), Math.sign(dx || -1) * Math.cos(th));
    f.ai.pull = pull;
    f.ai.drawT = f.kind === 'boss' || f.lvl >= 3 ? 0.44 + rand() * 0.18 : f.lvl === 2 ? 0.58 + rand() * 0.22 : 0.74 + rand() * 0.28;
    if (f.kind === 'axer') { f.ai.pull = 1; f.ai.drawT = 0.76; } // dramatic wind-up before hurling
  }

  /** wait → raise and draw → hold a breath → loose. Runs the enemies, and the player on the title screen */
  private think(f: Fighter, tgt: Fighter | null, can: boolean) {
    const k = f.k; const ai = f.ai;
    if (ai.state === 'wait') {
      k.aiming = damp(k.aiming, 0, 4, H); k.pull = damp(k.pull, 0, 12, H);
      if (can) ai.t -= H;
      if (can && tgt && ai.t <= 0 && onString(k) && k.react === 'none' && k.muscle > 0.85 && k.hurt < 0.05) {
        const busy = f.team === 1 ? this.foes.reduce((n, o) => n + (o.k.alive && o.ai.state !== 'wait' ? 1 : 0), 0) : 0;
        if (busy >= (this.level >= 9 ? 3 : 2) && f.kind !== 'axer' && f.lvl < 3) ai.t = 0.35 + rand() * 0.4;
        else { this.aimAt(f, tgt); ai.state = 'draw'; }
      }
    } else if (ai.state === 'draw') {
      k.aim = angLerp(k.aim, ai.aim, 1 - Math.exp(-10 * H));
      k.aiming = damp(k.aiming, 1, 9, H);
      if (k.aiming > 0.6) k.pull = Math.min(ai.pull, k.pull + (H * ai.pull) / ai.drawT);
      if (!can || !tgt) { ai.state = 'wait'; ai.t = 1; }
      else if (k.pull >= ai.pull - 0.001 && k.aiming > 0.97) { ai.state = 'hold'; ai.t = f.lvl >= 3 ? 0.1 + rand() * 0.15 : 0.16 + rand() * 0.25; }
    } else {
      ai.t -= H;
      if (!can || !tgt) { ai.state = 'wait'; ai.t = 1; }
      else if (ai.t <= 0) {
        if (f.kind === 'axer') this.throwAxe(f); else this.fire(f);
        ai.state = 'wait';
        const lvlWaitMult = f.lvl >= 3 ? 0.65 : f.lvl === 2 ? 0.82 : 1.05;
        ai.t = f.team === 0 ? 0.5 + rand() * 0.8 : f.kind === 'axer' ? 1.15 + rand() * 0.6 : Math.max(1.15, (2.6 - this.level * 0.06) * lvlWaitMult) + rand() * 0.9;
        ai.spread = Math.max(ai.floor, ai.spread * (f.lvl >= 3 ? 0.68 : 0.8));
      }
    }
  }

  private hitTest(tip: V, f: Fighter): { stick: number; u: number } | null {
    const P = f.k.p; const s = f.k.s;
    if (Math.abs(tip.x - P[2].x) > 95 * s || Math.abs(tip.y - P[2].y) > 115 * s) return null;
    if (dist(tip, P[0]) < HEAD_R * s + 2.5) return { stick: 0, u: 1 };
    let best: { stick: number; u: number } | null = null; let bd = 1e9;
    for (let i = 1; i < RAG_STICKS.length; i++) {
      const [a, b] = RAG_STICKS[i];
      const r = segDist(tip, P[a], P[b]);
      if (r.d < (i === 1 ? 5.6 : 4.6) * s + 2 && r.d < bd) { bd = r.d; best = { stick: i, u: r.t }; }
    }
    return best;
  }

  private burst(p: V, dir: V, n: number, col: string, speed = 260) {
    for (let i = 0; i < n; i++) {
      const a = Math.atan2(dir.y, dir.x) + (rand() - 0.5) * 1.5;
      const sp = speed * (0.3 + rand() * 0.9);
      this.parts.push({ p: { ...p }, vel: v(Math.cos(a) * sp, Math.sin(a) * sp - 60), life: 0, max: 0.35 + rand() * 0.4, r: 1.6 + rand() * 2.6, col, grav: 900 });
    }
    if (this.parts.length > 520) this.parts.splice(0, this.parts.length - 520);
  }

  /* ---------------- localized Level-1 elemental simulation impacts ---------------- */

  /**
   * Level-1 Localized Electro-Shock Impact:
   * Emits fine, gravity-driven sparks along the arrow's impact/reflection vector `ang`
   * and localizes the plasma discharge ONLY to the specific body part (`hit.stick`) that was struck!
   */
  private triggerThunderHit(at: V, ang: number, victim: Fighter | null, hit: { stick: number; u: number } | null, pan: number) {
    snd.zap(pan, false);
    this.shake = Math.max(this.shake, 7 * (this.demo ? 0.3 : 1));
    this.parts.push({ p: { ...at }, vel: v(0, 0), life: 0, max: 0.22, r: 24, col: '#00f0ff', grav: 0, kind: 'ring' });
    // Fine electric sparks spraying along impact reflection + falling with real gravity
    for (let i = 0; i < 12; i++) {
      const refAng = (i < 7 ? ang + Math.PI : ang) + (rand() - 0.5) * 1.3;
      const sp = 95 + rand() * 250;
      this.parts.push({
        p: { ...at }, prev: { ...at },
        vel: v(Math.cos(refAng) * sp, Math.sin(refAng) * sp - 35),
        life: 0, max: 0.22 + rand() * 0.25, r: 1.4 + rand() * 1.1,
        col: i % 2 === 0 ? '#ffffff' : '#00f0ff',
        grav: 680, kind: 'spark', drag: 2.4,
      });
    }
    if (victim && hit) {
      victim.shockT = Math.max(victim.shockT, 1.8);
      // Localize initial plasma arc strictly to the struck bone (`hit.stick`)
      const [ia, ib] = RAG_STICKS[hit.stick];
      this.arcs.push({ a: { ...at }, b: { ...victim.k.p[ia] }, life: 0, max: 0.2, spread: 5, segs: 5, col: '#00f0ff', lw: 1.35, seed: rand() * 100 });
      this.arcs.push({ a: { ...at }, b: { ...victim.k.p[ib] }, life: 0, max: 0.2, spread: 5, segs: 5, col: '#00f0ff', lw: 1.35, seed: rand() * 100 });
    } else {
      for (let i = 0; i < 2; i++) {
        const a = ang + Math.PI + (rand() - 0.5) * 1.4; const d = 18 + rand() * 20;
        this.arcs.push({ a: { ...at }, b: v(at.x + Math.cos(a) * d, at.y + Math.sin(a) * d), life: 0, max: 0.16, spread: 5, segs: 5, col: '#00f0ff', lw: 1.3, seed: rand() * 100 });
      }
    }
  }

  /**
   * Level-1 Localized Fluid Flame Impact:
   * Launches flame wisps along the arrow's momentum vector `ang` which decelerate via air drag
   * while thermal buoyancy (`grav = -240`) curves them smoothly upward, plus falling gravity embers!
   */
  private triggerFireHit(at: V, ang: number, victim: Fighter | null, _hit: { stick: number; u: number } | null, pan: number) {
    snd.fireball(pan);
    this.shake = Math.max(this.shake, 7 * (this.demo ? 0.3 : 1));
    this.parts.push({ p: { ...at }, vel: v(0, 0), life: 0, max: 0.22, r: 24, col: '#ff881c', grav: 0, kind: 'ring' });
    // Directional fluid flame splash that curves upward with buoyancy
    for (let i = 0; i < 11; i++) {
      const a = ang + (rand() - 0.5) * 1.25;
      const sp = 35 + rand() * 125;
      this.parts.push({
        p: v(at.x + (rand() - 0.5) * 6, at.y + (rand() - 0.5) * 6),
        vel: v(Math.cos(a) * sp, Math.sin(a) * sp - 35),
        life: 0, max: 0.32 + rand() * 0.28, r: 5.5 + rand() * 4.5,
        col: '#ff6a00', grav: -230, kind: 'fire', drag: 3.6, turb: 8 + rand() * 5, seed: rand() * 100,
      });
    }
    // Small glowing embers that fall with real downward gravity and bounce on platforms
    for (let i = 0; i < 10; i++) {
      const a = ang + Math.PI + (rand() - 0.5) * 1.6;
      const sp = 75 + rand() * 210;
      this.parts.push({
        p: { ...at }, prev: { ...at },
        vel: v(Math.cos(a) * sp, Math.sin(a) * sp - 55),
        life: 0, max: 0.38 + rand() * 0.38, r: 1.4 + rand() * 1.2,
        col: i % 2 ? '#ffe552' : '#ff6219', grav: 760, kind: 'ember', drag: 1.0,
      });
    }
    // Subtle thermal smoke wisp rising above the impact
    for (let i = 0; i < 4; i++) {
      this.parts.push({
        p: { ...at }, vel: v((rand() - 0.5) * 35, -55 - rand() * 40),
        life: 0, max: 0.5 + rand() * 0.3, r: 6 + rand() * 5,
        col: '#241c1c', grav: -105, kind: 'smoke', drag: 2.2, turb: 4,
      });
    }
    if (victim) victim.burnT = Math.max(victim.burnT, 2.4);
  }

  /** Spike Fuze: Level-1 Localized Thorn Burst aligned with impact angle & gravity */
  private triggerSpikeHit(at: V, ang: number, victim: Fighter | null, pan: number) {
    snd.snap(pan);
    this.parts.push({ p: { ...at }, vel: v(0, 0), life: 0, max: 0.2, r: 22, col: '#6bff2b', grav: 0, kind: 'ring' });
    for (let i = 0; i < 9; i++) {
      const a = ang + (rand() - 0.5) * 1.8;
      const sp = 110 + rand() * 180;
      this.parts.push({
        p: { ...at }, prev: { ...at },
        vel: v(Math.cos(a) * sp, Math.sin(a) * sp - 40),
        life: 0, max: 0.32 + rand() * 0.2, r: 2.6,
        col: i % 2 ? '#7dff24' : '#1fa62a', grav: 720, kind: 'thorn', rot: a,
      });
    }
    if (victim && victim.k.alive) {
      victim.hpLag = Math.max(victim.hpLag, victim.hp);
      victim.hpLagHold = 0.28;
      victim.barBump = 1;
      victim.hp -= 10;
      this.say(victim.k.p[0].x, victim.k.p[0].y - 46, '🌿 DURI! -10', '#8eff3b', 15, 0.95);
    }
  }

  /**
   * Poisonous Whisper: Level-1 Localized Xenomorph Acid Splatter & Gravity Drip
   * Sprays cohesive molecular acid droplets along the impact vector `ang` that arc downward under real gravity (`grav = 740`).
   */
  private triggerPoisonHit(at: V, ang: number, victim: Fighter | null, _hit: { stick: number; u: number } | null, pan: number) {
    snd.acidSpit(pan);
    this.shake = Math.max(this.shake, 6 * (this.demo ? 0.3 : 1));
    this.parts.push({ p: { ...at }, vel: v(0, 0), life: 0, max: 0.22, r: 22, col: '#cfff04', grav: 0, kind: 'ring' });
    // Directional Xenomorph acid droplets following parabolic gravity arcs
    for (let i = 0; i < 12; i++) {
      const a = (i < 8 ? ang : ang + Math.PI) + (rand() - 0.5) * 1.2;
      const sp = 65 + rand() * 190;
      this.parts.push({
        p: { ...at }, prev: { ...at },
        vel: v(Math.cos(a) * sp, Math.sin(a) * sp - 45),
        life: 0, max: 0.38 + rand() * 0.35, r: 1.8 + rand() * 1.8,
        col: i % 3 === 0 ? '#eaff66' : i % 3 === 1 ? '#a6ff00' : '#3dff14',
        grav: 740, kind: 'acid', drag: 1.4, seed: rand() * 50,
      });
    }
    // Subtle corrosive vapor wisps rising from the splash
    for (let i = 0; i < 4; i++) {
      this.parts.push({
        p: { ...at }, vel: v((rand() - 0.5) * 28, -45 - rand() * 35),
        life: 0, max: 0.45 + rand() * 0.3, r: 5 + rand() * 4,
        col: '#b8ff70', grav: -95, kind: 'acidSmoke', drag: 2.4, turb: 5,
      });
    }
    if (victim) victim.poisonT = Math.max(victim.poisonT, 2.8);
  }

  private say(x: number, y: number, text: string, col: string, size = 18, max = 0.9) {
    if (!this.demo) this.texts.push({ x, y, life: 0, max, text, col, size });
  }

  /**
   * Leave the arrow in the bone it struck.
   * When `halfThrough = false`, the point sits in the middle of that bone so the shaft meets the body with no gap.
   * When `halfThrough = true` (MAX POWER final target), the arrow penetrates HALF OF ITS LENGTH (`ARROW_LEN * 0.5 = 24px`)
   * out the back of the bone with its arrowhead visible on the exit side!
   */
  private lodge(a: Arrow, f: Fighter, hit: { stick: number; u: number }, halfThrough = false): V {
    const k = f.k; const head = hit.stick === 0;
    const [ia, ib] = RAG_STICKS[hit.stick];
    const A = k.p[ia]; const B = k.p[ib];
    let bonePt = a.p; let best = 1e9;
    for (let i = 0; i <= 18; i++) {
      const q = add(a.p, fromAngle(a.ang, i));
      const dd = head ? dist(q, k.p[0]) : segDist(q, A, B).d;
      if (dd < best) { best = dd; bonePt = q; } else if (dd > best + 1) break;
    }
    if (head && !halfThrough) bonePt = add(bonePt, fromAngle(a.ang, -3 * k.s));
    // If `halfThrough`, slide the arrow tip forward by half of ARROW_LEN (24px) past the bone center!
    const tip = halfThrough ? add(bonePt, fromAngle(a.ang, ARROW_LEN * 0.5)) : bonePt;
    const ba = Math.atan2(B.y - A.y, B.x - A.x);
    const rx = tip.x - A.x; const ry = tip.y - A.y; const c = Math.cos(-ba); const sn = Math.sin(-ba);
    const fxDur = a.bow === 'thunder' ? 1.8 : a.bow === 'fire' ? 2.4 : a.bow === 'poison' ? 2.8 : 0;
    f.stuck.push({ stick: hit.stick, u: hit.u, lx: rx * c - ry * sn, ly: rx * sn + ry * c, rel: a.ang - ba, bow: a.bow, fxT: fxDur, halfThrough });
    if (f.stuck.length > 7) f.stuck.shift();
    return bonePt;
  }

  private onHit(a: Arrow, f: Fighter, hit: { stick: number; u: number }) {
    const k = f.k; const head = hit.stick === 0; const torso = hit.stick === 1;
    const isMax = !!a.maxPower && f.team === 1;
    if (isMax) {
      a.hitIds?.add(f);
      a.pierced = (a.pierced ?? 0) + 1;
    }
    // Check if this MAX POWER arrow should keep flying to pierce a 2nd enemy, or stop & lodge half-through in this final enemy!
    const otherAlive = isMax && (a.pierced ?? 0) < 2 && this.foes.some((o) => o !== f && o.k.alive && !a.hitIds?.has(o));
    const shouldPassThrough = isMax && (a.pierced ?? 0) === 1 && otherAlive;

    let tip = a.p;
    if (shouldPassThrough) {
      // Pierces completely through the 1st enemy and keeps flying toward the 2nd enemy!
      a.dead = false;
    } else {
      // Lodges in the enemy; if MAX POWER, penetrates half the arrow's length (`halfThrough = true`)!
      tip = this.lodge(a, f, hit, isMax);
      a.dead = true;
    }

    const back = mul(a.vel, -1); const pan = this.pan(a.p.x);
    // Trigger localized Level-1 elemental simulation on the struck body part!
    if (a.bow === 'thunder') this.triggerThunderHit(tip, a.ang, f, hit, pan);
    else if (a.bow === 'fire') this.triggerFireHit(tip, a.ang, f, hit, pan);
    else if (a.bow === 'spike') this.triggerSpikeHit(tip, a.ang, f, pan);
    else if (a.bow === 'poison') this.triggerPoisonHit(tip, a.ang, f, hit, pan);

    if (!k.alive) {
      punchRag(k as unknown as ArcherRag, hit.stick, hit.u, a.vel, true);
      this.burst(a.p, back, 5, '#b3121b'); snd.hit(pan, false);
      return;
    }
    // the player's headshots are the big reward; an enemy's lucky one hurts but does not end the run
    const heart = torso && hit.u > 0.58 && hit.u < 0.93; // the upper chest
    let helmHit = false;
    let dmg = a.dmg * (f.team === 0 ? (head ? 1.5 : torso ? 1 : 0.6) : head ? (f.kind === 'boss' || f.kind === 'axer' ? 1.8 : 2.6) : heart ? 1.4 : torso ? 1 : 0.55);
    if (this.demo && f.team === 0) dmg *= 0.25;
    if (head && f.helm && !isMax) {
      f.helm = false; dmg *= 0.3; helmHit = true;
      this.parts.push({ p: { ...k.p[0] }, vel: v(a.vel.x * 0.25 + (rand() - 0.5) * 80, -330), life: 0, max: 2.4, r: (HEAD_R + 2) * k.s, col: '#51666f', grav: 1100, kind: 'helm', rot: 0 });
      this.say(k.p[0].x, k.p[0].y - 34, 'HELM LEPAS!', '#cfe3ea', 15);
      snd.clang(pan);
    } else if (head && f.helm && isMax) {
      f.helm = false;
      this.parts.push({ p: { ...k.p[0] }, vel: v(a.vel.x * 0.35, -360), life: 0, max: 2.4, r: (HEAD_R + 2) * k.s, col: '#51666f', grav: 1100, kind: 'helm', rot: 0 });
    }
    // MAX POWER arrows AUTO-KILL (`f.hp = 0`) any enemy they pierce or lodge into!
    dmg = isMax ? Math.max(f.hp, 999) : Math.max(1, Math.round(dmg));
    f.hpLag = Math.max(f.hpLag, f.hp);
    f.hpLagHold = 0.28;
    f.barBump = 1;
    f.hp = isMax ? 0 : f.hp - dmg;
    f.hpShow = 4.5; f.flash = 1;
    if (this.demo && f.team === 0) f.hp = Math.max(f.hp, 20);
    const fatal = f.hp <= 0;
    punchRag(k as unknown as ArcherRag, hit.stick, hit.u, a.vel, fatal);
    k.muscle = Math.min(k.muscle, head ? 0.26 : torso ? 0.44 : 0.6);
    // the pain: flinch away from the blow, a hand to the wound, breath knocked short
    k.hurt = 1; k.hurtDir = Math.sign(a.vel.x) || 1; k.wound = { stick: hit.stick, u: hit.u }; k.exert = Math.min(1, k.exert + 0.45);
    f.plat.vel += head ? 120 : 80;
    this.burst(a.p, back, head ? 14 : 8, '#d3141f', head ? 330 : 240);
    this.parts.push({ p: { ...a.p }, vel: v(0, 0), life: 0, max: 0.22, r: head ? 26 : 18, col: '#ffffff', grav: 0, kind: 'ring' });
    this.hitStop = head ? 0.07 : 0.035;
    this.shake = Math.max(this.shake, (head ? 9 : 5) * (this.demo ? 0.3 : 1));
    snd.hit(pan, head);
    if (!fatal) snd.grunt(pan, f.pitch);
    // every hit shows what it did inside. A head shot gets the full treatment - the world goes dark and the camera
    // closes in on the whole skeleton; anywhere else a bone X-ray renders directly inside the black stickman body!
    if (!this.demo && !helmHit) {
      const full = head;
      this.xray = { f, stick: hit.stick, u: hit.u, pt: { ...tip }, ang: a.ang, t: 0, dur: full ? (f.team === 0 ? 0.42 : fatal ? 0.8 : 0.5) : fatal ? 0.65 : 0.42, full };
      if (full) { this.ts = 0.03; this.hitStop = 0; this.focus = { ...a.p }; snd.crack(pan); snd.xray(); }
      else snd.snap(pan);
    }
    const hx = k.p[0].x; const hy = k.p[0].y - (HEAD_R + 22) * k.s;
    if (f.team === 1) {
      const hitCol = isMax ? '#ffd23f' : a.bow === 'thunder' ? '#5cf4ff' : a.bow === 'fire' ? '#ff942e' : a.bow === 'poison' ? '#d4ff00' : head ? '#ffe14d' : '#ffffff';
      this.say(hx + (rand() - 0.5) * 16, hy, isMax ? 'AUTO DEAD!' : `-${dmg}`, hitCol, isMax || head ? 22 : 18);
      if (isMax) {
        this.say(hx, hy - 22, shouldPassThrough ? '⚡ MAX POWER TEMBUS!' : '⚡ NANCEP SETENGAH PANAH!', '#ffe24a', 16, 1.15);
      } else if (head && !fatal) this.say(hx, hy - 20, 'HEADSHOT!', '#ffe14d', 17, 1.1);
      else if (a.bow === 'thunder' && !fatal) this.say(hx, hy - 20, '⚡ TERSENGAT LISTRIK!', '#5cf4ff', 16, 1.1);
      else if (a.bow === 'fire' && !fatal) this.say(hx, hy - 20, '🔥 TERBAKAR API!', '#ff942e', 16, 1.1);
      else if (a.bow === 'poison' && !fatal) this.say(hx, hy - 20, '🧪 XENOMORPH ACID!', '#d4ff00', 16, 1.1);
      else if (heart && !fatal) this.say(hx, hy - 20, 'JANTUNG!', '#ff9a9a', 16, 1.1);
      if (!this.demo) {
        this.lvHits++; this.combo++;
        if (this.combo >= 2) {
          const bonus = Math.min(this.combo - 1, 5);
          this.spawnCoins(this.player.k.p[0], bonus);
          this.say(this.player.k.p[0].x + 60, this.player.k.p[0].y - 64, `COMBO x${this.combo}  +${bonus}`, '#7fe9f2', 16, 1.2);
          snd.combo(this.combo);
        }
      }
      // a staggered archer loses his draw
      if (f.ai.state !== 'wait' && (head || torso || a.bow === 'thunder')) { f.ai.state = 'wait'; f.ai.t = 0.9 + rand() * 0.5; }
      else f.ai.t = Math.max(f.ai.t, 0.7);
      if (!fatal) {
        const leg = hit.stick >= 2 && hit.stick <= 5;
        const strong = Math.hypot(a.vel.x, a.vel.y) > 900;
        if (head && f.kind !== 'boss' && f.kind !== 'axer') { startReact(k, 'down', 2.1); snd.thud(pan, 0.28); snd.hup(pan, f.pitch, 1.05); }
        else if (leg) { startReact(k, 'knee', 1.35); snd.thud(pan, 0.16); }
        else if ((torso && strong) || head) { startReact(k, 'teeter', 1.05); snd.whoa(pan, f.pitch); }
        if (k.react !== 'none') { f.ai.state = 'wait'; f.ai.t = Math.max(f.ai.t, k.rdur + 0.3); }
      }
    } else {
      this.say(hx, hy, `-${dmg}`, '#ff6b6b', 20);
      if (!this.demo) { this.hurt = 1; this.lvHurt += dmg; }
      if (this.demo) { f.ai.state = 'wait'; f.ai.t = 0.8; }
    }
    if (fatal) this.die(f, head);
  }

  private die(f: Fighter, head: boolean) {
    const k = f.k; const pan = this.pan(k.p[1].x);
    k.alive = false; k.muscle = 0; k.pull = 0; k.hasBow = false; f.hp = 0;
    // a headshot drops him like a cut string; anything else and he folds over the wound first
    k.fade = head ? 0.05 : 0.38; k.hurt = 1;
    snd.cry(pan, f.pitch); snd.fall(pan);
    this.bows.push({
      p: { ...k.p[4] }, vel: v(((k.p[4].x - k.o[4].x) / H) * 0.6 + (rand() - 0.5) * 140, ((k.p[4].y - k.o[4].y) / H) * 0.6 - 190),
      ang: k.bowAng, vr: (rand() - 0.5) * 16, s: k.s, bow: f.team === 0 ? this.bow : 'wood',
    });
    if (f.team === 1) {
      f.plat.sinkT = 1.7;
      this.spawnT = Math.max(this.spawnT, this.demo ? 1.4 : 0.6);
      if (this.demo) return;
      this.kills++; this.totalKills++;
      if (head) this.headshots++;
      const reward = (f.kind === 'boss' || f.kind === 'axer' ? 60 : f.kind === 'heavy' ? 12 : f.kind === 'helm' ? 7 : 5) + (head ? 5 : 0);
      this.spawnCoins(k.p[1], reward);
      const hx = k.p[0].x; const hy = k.p[0].y - (HEAD_R + 44) * k.s;
      this.say(hx, hy, head ? `HEADSHOT! +${reward}` : `+${reward}`, '#ffd23f', head ? 21 : 18, 1.3);
      if (this.up.leech) this.player.hp = Math.min(this.player.maxHp, this.player.hp + 5 * this.up.leech);
      const last = this.kills >= this.total && this.hostState !== 1;
      this.slowT = last ? 1.2 : 0.3; this.slowK = last ? 0.16 : 0.3;
      if (last) this.beginClear(k.p[1]);
      else if (this.kills >= this.total) { this.banner = 2.4; this.bannerText = 'BEBASKAN TAWANAN!'; this.bannerSub = 'PANAH TEPAT DI TALINYA'; }
    } else {
      this.stage = 'dying'; this.deadT = 0; this.drag.on = false;
      this.slowT = 1.4; this.slowK = 0.2;
      this.zoomTo = 1.16; if (!(this.xray && this.xray.full)) this.focus = { ...k.p[1] };
    }
  }

  /* ---------------- simulation ---------------- */

  private step() {
    this.t += H;
    const pl = this.pPlat;
    pl.fy = damp(pl.fy, this.pFyT, 1.4, H);
    const all = [pl, ...this.plats];
    for (const p of all) {
      p.vel += (-p.off * 110 - p.vel * 9) * H; p.off += p.vel * H;
      if (p !== pl) {
        if (p.state === 'rise') { p.rise = Math.min(1, p.rise + H / 1.1); if (p.rise >= 1) p.state = 'on'; }
        else if (p.state === 'on' && p.sinkT > 0) { p.sinkT -= H; if (p.sinkT <= 0) p.state = 'sink'; }
        else if (p.state === 'sink') { p.rise -= H / 1.4; if (p.rise <= 0) p.state = 'off'; }
      }
      this.placePlat(p);
      // crumbs of earth drift off the underside
      if (p.state === 'on' && rand() < 0.005) {
        this.parts.push({ p: v(p.x + (rand() - 0.5) * p.w * 0.8, p.y + p.h), vel: v((rand() - 0.5) * 8, 14), life: 0, max: 0.9 + rand() * 0.6, r: 1 + rand() * 1.4, col: this.theme.platTop, grav: 260 });
      }
    }
    this.plats = this.plats.filter((p) => p.state !== 'off');
    // a ground that is still floating in (or sinking away) only carries its own archer
    const slabs = all.filter((p) => p.state === 'on').map(toSlab);
    const slabsFor = (f: Fighter) => (f.plat.state === 'on' ? slabs : [...slabs, toSlab(f.plat)]);

    const pf = this.player; const pk = pf.k;
    pk.base = v(pl.x, pl.y);
    pk.vigor = clamp(pf.hp / pf.maxHp, 0, 1);
    let nearest: Fighter | null = null; let nd = 1e9;
    for (const f of this.foes) {
      if (!f.k.alive || f.plat.state !== 'on') continue;
      const d = dist(f.k.p[1], pk.p[1]);
      if (d < nd) { nd = d; nearest = f; }
    }
    if (pk.alive) {
      const d = this.drag; let want = 0;
      const wasNock = pk.nock;
      if (pk.nock < 1) pk.nock = Math.min(1, pk.nock + H / 0.46);
      if (!this.demo) {
        if (wasNock < 0.55 && pk.nock >= 0.55) snd.quiver();
        if (wasNock < 1 && pk.nock >= 1) snd.nock();
      }
      if (this.demo && !d.on) {
        this.think(pf, nearest, this.stage === 'play');
        pf.hp = Math.min(pf.maxHp, pf.hp + 5 * H);
      } else {
        // aim follows the drag; the draw follows with a little lag, like real arms taking the load
        this.holdAim -= H;
        if (d.on) {
          const dx = d.sx - d.x; const dy = d.sy - d.y; const L = Math.hypot(dx, dy);
          if (L > 4) {
            pk.aim = angLerp(pk.aim, clamp(Math.atan2(dy, dx), -1.45, 1.15), 1 - Math.exp(-22 * H));
            want = this.maxPower ? 1 : clamp((L - 6) / this.pullPx, 0, 1);
          } else if (this.maxPower) {
            want = 1;
          }
          pk.aiming = damp(pk.aiming, 1, 14, H);
        } else pk.aiming = damp(pk.aiming, this.holdAim > 0 ? 1 : 0, 5, H);
        if (!onString(pk)) want = 0;
        // the last part of the draw is the heaviest: it comes slower
        pk.pull = damp(pk.pull, want, want > pk.pull ? 17 - 7 * pk.pull : 20, H);
        if (pk.pull > this.creakAt) { snd.creak(pk.pull); this.creakAt += 0.14; }
        if (pk.pull < this.creakAt - 0.3) this.creakAt = Math.max(0.14, this.creakAt - 0.14);
      }
      pk.muscle = Math.min(1, pk.muscle + H * 1.1);
      // eyes: down the arrow while aiming, otherwise on the nearest danger
      let threat: V | null = null; let td = 420;
      for (const a of this.arrows) if (a.team === 1 && !a.stuckIn) { const dd = dist(a.p, pk.p[0]); if (dd < td) { td = dd; threat = a.p; } }
      pk.lookAt = (d.on && !this.demo) || pk.aiming > 0.5 ? null : threat ?? (nearest ? nearest.k.p[0] : null);
    } else pf.deadT += H;
    pf.vib += H; pf.flash = Math.max(0, pf.flash - H * 5); pf.barBump = Math.max(0, pf.barBump - H * 6);
    if (pf.hp > pf.hpLag) pf.hpLag = pf.hp;
    if (pf.hpLagHold > 0) pf.hpLagHold = Math.max(0, pf.hpLagHold - H);
    else pf.hpLag = damp(pf.hpLag, Math.max(0, pf.hp), 5.2, H);
    stepStick(pk, slabsFor(pf));

    for (const f of this.foes) {
      const k = f.k;
      f.vib += H; f.flash = Math.max(0, f.flash - H * 5); f.hpShow -= H; f.barBump = Math.max(0, f.barBump - H * 6);
      if (f.hp > f.hpLag) f.hpLag = f.hp;
      if (f.hpLagHold > 0) f.hpLagHold = Math.max(0, f.hpLagHold - H);
      else f.hpLag = damp(f.hpLag, Math.max(0, f.hp), 5.2, H);
      if (k.alive) {
        k.base = v(f.plat.x, f.plat.y);
        k.vigor = clamp(f.hp / f.maxHp, 0, 1);
        k.muscle = Math.min(1, k.muscle + H * (f.shockT > 0 ? 0.25 : 0.9));
        if (k.nock < 1) k.nock = Math.min(1, k.nock + H / (f.kind === 'axer' ? 1 : 0.6));
        this.think(f, pf, this.stage === 'play' && pk.alive && f.plat.state === 'on' && f.shockT <= 0.1);
        // he watches you - and now and then glances away
        k.lookAt = k.aiming > 0.5 ? null : Math.sin(this.t * 0.45 + k.seed * 3) > 0.9 ? v(k.p[0].x + 80 * Math.sin(k.seed * 7), k.p[0].y - 60) : pk.p[0];
      } else f.deadT += H;
      this.stepElementalFighter(f);
      stepStick(k, slabsFor(f));
      // blood drips from a fresh wound
      if (k.hurt > 0.2 && k.alive && rand() < 0.2) {
        const wp = woundPoint(k);
        if (wp) this.parts.push({ p: wp, vel: v((rand() - 0.5) * 40, -10 + rand() * 30), life: 0, max: 0.5 + rand() * 0.3, r: 1.3 + rand() * 1.3, col: '#c4121c', grav: 900 });
      }
    }
    if (pk.hurt > 0.2 && pk.alive && rand() < 0.2) {
      const wp = woundPoint(pk);
      if (wp) this.parts.push({ p: wp, vel: v((rand() - 0.5) * 40, -10 + rand() * 30), life: 0, max: 0.5 + rand() * 0.3, r: 1.3 + rand() * 1.3, col: '#c4121c', grav: 900 });
    }
    this.foes = this.foes.filter((f) => f.k.alive || (f.deadT < 6 && f.k.p[2].y < this.VH + 260));

    // the prisoner: squirming while tied; once free he celebrates, then his ground carries him away
    const hs = this.hostage;
    if (hs) {
      const hk = hs.k;
      hk.base = v(hs.plat.x, hs.plat.y); hk.muscle = Math.min(1, hk.muscle + H); hk.lookAt = pk.p[0];
      hk.happy = damp(hk.happy, this.hostState === 2 ? 1 : 0, 7, H);
      hs.flash = Math.max(0, hs.flash - H * 5);
      stepStick(hk, slabsFor(hs));
      if (this.hostState === 2) {
        this.freeT += H;
        if (this.freeT > 1.9 && hs.plat.state === 'on' && hs.plat.sinkT <= 0) hs.plat.sinkT = 0.01;
      }
      if (hs.plat.state === 'off') this.hostage = null;
    }

    // axes in the air: heavy, slow, spinning - and when they hit a body or platform, they EMBED (`nancep`)!
    for (const ax of this.axes) {
      ax.life += H;
      if (ax.stuckIn) {
        ax.p = v(ax.stuckIn.x + ax.ox, ax.stuckIn.y + ax.oy);
        if (ax.life > 6 || ax.stuckIn.state === 'off') ax.dead = true;
        continue;
      }
      ax.vel.y += 620 * H;
      ax.p = add(ax.p, mul(ax.vel, H));
      if (ax.bossKind === 'thunder_lord') ax.ang = Math.atan2(ax.vel.y, ax.vel.x);
      else ax.ang += ax.vr * H;
      if (!ax.spent) {
        if (Math.floor(ax.life / 0.26) !== Math.floor((ax.life - H) / 0.26)) snd.whup(this.pan(ax.p.x));
        // Check hit on Player ragdoll body -> embed (`nancep`) into the closest bone!
        if (pk.alive && Math.abs(ax.p.x - pk.p[2].x) < 75 && Math.abs(ax.p.y - pk.p[2].y) < 105) {
          let bestStick = 0; let bestU = 1;
          let near = dist(ax.p, pk.p[0]) - HEAD_R;
          for (let si = 1; si < RAG_STICKS.length; si++) {
            const [ia, ib] = RAG_STICKS[si];
            const sd = segDist(ax.p, pk.p[ia], pk.p[ib]);
            if (sd.d < near) { near = sd.d; bestStick = si; bestU = sd.t; }
          }
          if (near < 16) {
            this.axeHit(ax, { stick: bestStick, u: bestU });
            continue;
          }
        }
        // Check hit on any Platform -> embed (`nancep`) into the platform surface!
        const sl = all.find((p) => p.rise > 0.6 && ax.p.x > p.x - p.w / 2 && ax.p.x < p.x + p.w / 2 && ax.p.y >= p.y - 4 && ax.p.y <= p.y + p.h);
        if (sl) {
          const flightAng = Math.atan2(ax.vel.y, ax.vel.x);
          ax.stuckIn = sl;
          ax.spent = true;
          ax.ox = ax.p.x - sl.x;
          ax.oy = 3;
          ax.ang = bossEmbedAng(ax.bossKind, flightAng);
          ax.life = 0;
          sl.vel += 65;
          const bowElem = bossBowOf(ax.bossKind);
          if (bowElem === 'thunder') this.triggerThunderHit(ax.p, flightAng, null, null, this.pan(ax.p.x));
          else if (bowElem === 'fire') this.triggerFireHit(ax.p, flightAng, null, null, this.pan(ax.p.x));
          else if (bowElem === 'poison') this.triggerPoisonHit(ax.p, flightAng, null, null, this.pan(ax.p.x));
          else {
            this.burst(ax.p, v(0, -1), 7, this.theme.platTop, 180);
            snd.wood(this.pan(ax.p.x));
          }
          continue;
        }
      }
      if (ax.p.y > this.VH + 240 || ax.p.x < -300 || ax.p.x > this.VW * 2.2) ax.dead = true;
    }
    this.axes = this.axes.filter((x) => !x.dead);

    // arrows
    for (const a of this.arrows) {
      a.life += H;
      if (a.stuckIn) {
        a.p = v(a.stuckIn.x + a.ox, a.stuckIn.y + a.oy);
        if (a.life > 5 || a.stuckIn.state === 'off') a.dead = true;
        continue;
      }
      a.prev = { ...a.p };
      a.vel.y += AG * H;
      a.p = add(a.p, mul(a.vel, H));
      a.ang = Math.atan2(a.vel.y, a.vel.x);
      const end = { ...a.p };

      // Natural Level-1 in-flight trails aligned with arrow velocity `a.vel`, angle `a.ang`, and world gravity
      if (a.bow === 'thunder' && rand() < 0.45) {
        this.parts.push({
          p: { ...a.p }, prev: { ...a.prev },
          vel: v(-a.vel.x * 0.08 + (rand() - 0.5) * 90, -a.vel.y * 0.08 + (rand() - 0.5) * 90),
          life: 0, max: 0.14 + rand() * 0.1, r: 1.3 + rand() * 0.8,
          col: rand() < 0.5 ? '#ffffff' : '#00f0ff', grav: 640, kind: 'spark', drag: 3.5,
        });
      } else if (a.bow === 'fire') {
        if (rand() < 0.58) {
          this.parts.push({
            p: v(a.p.x + (rand() - 0.5) * 3, a.p.y + (rand() - 0.5) * 3),
            vel: v(-a.vel.x * 0.08 + (rand() - 0.5) * 35, -a.vel.y * 0.08 - 35 + (rand() - 0.5) * 35),
            life: 0, max: 0.22 + rand() * 0.16, r: 4.5 + rand() * 3.5,
            col: '#ff6a00', grav: -210, kind: 'fire', drag: 3.8, turb: 8, seed: rand() * 100,
          });
        }
        if (rand() < 0.28) {
          this.parts.push({
            p: { ...a.p }, prev: { ...a.p },
            vel: v(-a.vel.x * 0.06 + (rand() - 0.5) * 70, -a.vel.y * 0.06 + (rand() - 0.5) * 70),
            life: 0, max: 0.28 + rand() * 0.22, r: 1.3 + rand() * 1.0,
            col: '#ffe552', grav: 680, kind: 'ember', drag: 1.2,
          });
        }
      } else if (a.bow === 'spike' && rand() < 0.28) {
        this.parts.push({
          p: { ...a.p }, vel: v(-a.vel.x * 0.05 + (rand() - 0.5) * 45, (rand() - 0.5) * 45),
          life: 0, max: 0.2, r: 1.9, col: '#7dff24', grav: 640, kind: 'thorn', rot: a.ang,
        });
      } else if (a.bow === 'poison' && rand() < 0.45) {
        // Gravity-driven Xenomorph acid droplets detaching from the flying arrow
        this.parts.push({
          p: { ...a.p }, prev: { ...a.prev },
          vel: v(-a.vel.x * 0.04 + (rand() - 0.5) * 40, -a.vel.y * 0.04 + (rand() - 0.5) * 40),
          life: 0, max: 0.32 + rand() * 0.2, r: 1.6 + rand() * 1.4,
          col: rand() < 0.45 ? '#eaff66' : '#8cff00', grav: 720, kind: 'acid', drag: 1.4, seed: rand() * 50,
        });
      }

      if (a.team === 1 && !a.near && pk.alive && !this.demo && dist(a.p, pk.p[0]) < 80) { a.near = true; snd.whoosh(this.pan(a.p.x)); }
      for (const tt of [0.25, 0.5, 0.75, 1]) {
        const tip = lerpV(a.prev, end, tt);
        if (a.team === 0) {
          // an axe in the air can be shot down (generous hit radius so shooting the Boss's axe feels awesome!)
          const ax = this.axes.find((x) => !x.spent && dist(tip, x.p) < 38 * x.s);
          if (ax) { this.parry(ax, a); break; }
          // the prisoner: the rope is the target, the man is not
          if (hs && this.hostState === 1 && hs.plat.state === 'on') {
            const [top, bot] = this.rope(hs);
            if (segDist(tip, top, bot).d < 7) this.freeHostage(tip);
            else {
              const hh = this.hitTest(tip, hs);
              if (hh) { a.p = tip; this.hostageHit(a, hs, hh); break; }
            }
          }
        }
        for (const f of a.team === 0 ? this.foes : [pf]) {
          if (a.hitIds?.has(f)) continue;
          const hit = this.hitTest(tip, f);
          if (hit) {
            a.p = tip;
            this.onHit(a, f, hit);
            if (a.dead) break;
          }
        }
        if (a.dead) break;
        if (a.team === 0) {
          for (const b of this.balloons) {
            if (dist(tip, v(b.x, b.y)) < 19) { this.popBalloon(b); break; }
          }
        }
        const canPiercePlat =
          a.maxPower &&
          (a.pierced ?? 0) === 1 &&
          this.foes.some((o) => o.k.alive && !a.hitIds?.has(o));
        const sl = canPiercePlat
          ? undefined
          : all.find((p) => p.rise > 0.6 && tip.x > p.x - p.w / 2 && tip.x < p.x + p.w / 2 && tip.y > p.y && tip.y < p.y + p.h);
        if (sl) {
          const in4 = add(tip, fromAngle(a.ang, 9)); // well into the wood: the ground is drawn over the buried end
          a.stuckIn = sl; a.ox = in4.x - sl.x; a.oy = in4.y - sl.y; a.life = 0;
          sl.vel += 30;
          if (a.bow === 'thunder') this.triggerThunderHit(tip, a.ang, null, null, this.pan(tip.x));
          else if (a.bow === 'fire') this.triggerFireHit(tip, a.ang, null, null, this.pan(tip.x));
          else if (a.bow === 'poison') this.triggerPoisonHit(tip, a.ang, null, null, this.pan(tip.x));
          else {
            this.burst(tip, mul(a.vel, -1), 4, this.theme.platTop, 150);
            snd.wood(this.pan(tip.x));
          }
          if (a.team === 0 && a.main) this.combo = 0;
          break;
        }
      }
      if (a.p.y > this.VH + 240 || a.p.x < -360 || a.p.x > this.VW * 2.3) { a.dead = true; if (a.team === 0 && a.main) this.combo = 0; }
    }
    this.arrows = this.arrows.filter((a) => !a.dead);

    for (const p of this.parts) {
      p.life += H;
      if (p.prev) p.prev = { ...p.p };
      if (p.drag) {
        const d = Math.exp(-p.drag * H);
        p.vel.x *= d; p.vel.y *= d;
      }
      if (p.turb) {
        p.vel.x += Math.sin(this.t * p.turb + p.p.y * 0.06) * 260 * H;
      }
      p.vel.y += p.grav * H;
      p.p = add(p.p, mul(p.vel, H));
      // Real physics platform collision bounce for sparks, embers, thorns, and acid droplets!
      if (p.vel.y > 0 && (p.kind === 'spark' || p.kind === 'ember' || p.kind === 'acid' || p.kind === 'thorn')) {
        for (const sl of all) {
          if (sl.rise > 0.6 && p.p.x > sl.x - sl.w * 0.5 && p.p.x < sl.x + sl.w * 0.5 && p.p.y >= sl.y && p.p.y <= sl.y + 10) {
            p.p.y = sl.y - 0.5;
            if (p.kind === 'acid') {
              p.vel.y = -p.vel.y * 0.18; p.vel.x *= 0.35;
              if (rand() < 0.25) {
                this.parts.push({ p: { ...p.p }, vel: v((rand() - 0.5) * 14, -22 - rand() * 18), life: 0, max: 0.28, r: 2.2, col: '#d4ff00', grav: -35, kind: 'acidBubble', drag: 3 });
              }
            } else {
              p.vel.y = -p.vel.y * 0.44; p.vel.x *= 0.72;
            }
            break;
          }
        }
      }
      if (p.rot !== undefined) p.rot += H * 9;
    }
    this.parts = this.parts.filter((p) => p.life < p.max);
    for (const arc of this.arcs) arc.life += H;
    this.arcs = this.arcs.filter((arc) => arc.life < arc.max);
    for (const b of this.bows) { b.vel.y += 1100 * H; b.p = add(b.p, mul(b.vel, H)); b.ang += b.vr * H; }
    this.bows = this.bows.filter((b) => b.p.y < this.VH + 120);
    for (const b of this.balloons) { b.y -= 46 * H; b.x += Math.sin(this.t * 1.4 + b.phase) * 12 * H; }
    this.balloons = this.balloons.filter((b) => b.y > -70);

    if (this.stage === 'play') {
      this.spawnT -= H;
      const alive = this.foes.reduce((n, f) => n + (f.k.alive ? 1 : 0), 0);
      if (alive < this.maxAlive && this.spawned < this.total && this.spawnT <= 0) { this.spawnEnemy(); this.spawnT = this.demo ? 1.2 : 0.55; }
      this.balloonT -= H;
      if (this.balloonT <= 0 && !this.demo) {
        this.balloonT = 12 + rand() * 9;
        this.balloons.push({ x: this.VW * (0.3 + rand() * 0.16), y: this.VH + 40, kind: pf.hp < pf.maxHp * 0.8 ? 'heart' : 'coin', phase: rand() * 6 });
      }
    }
  }

  /**
   * Localized Level-1 120Hz Elemental Simulation on a Fighter:
   * Only affects the specific body parts (`st.stick` at `st.u`) where elemental arrows are embedded!
   */
  private stepElementalFighter(f: Fighter) {
    const k = f.k;
    if (f.shockT > 0) f.shockT = Math.max(0, f.shockT - H);
    if (f.burnT > 0) f.burnT = Math.max(0, f.burnT - H);
    if (f.poisonT > 0) f.poisonT = Math.max(0, f.poisonT - H);

    let hasActiveStuck = false;
    for (const st of f.stuck) {
      if (st.fxT <= 0) continue;
      st.fxT = Math.max(0, st.fxT - H);
      hasActiveStuck = true;
      const [ia, ib] = RAG_STICKS[st.stick];
      const A = k.p[ia]; const B = k.p[ib];
      const wp = lerpV(A, B, st.u);
      const limbVx = ((B.x - k.o[ib].x) / H) * 0.25;
      const limbVy = ((B.y - k.o[ib].y) / H) * 0.25;

      if (st.bow === 'thunder') {
        // Localize micro-spasms strictly to the two joints `[ia, ib]` of the struck limb/part
        if (rand() < 0.28) {
          impulse(k, ia, v((rand() - 0.5) * 130, (rand() - 0.5) * 130));
          impulse(k, ib, v((rand() - 0.5) * 130, (rand() - 0.5) * 130));
        }
        // Subtle gravity spark detaching from the struck point `wp`
        if (rand() < 0.16) {
          const a = rand() * Math.PI * 2; const sp = 60 + rand() * 140;
          this.parts.push({ p: { ...wp }, prev: { ...wp }, vel: v(limbVx + Math.cos(a) * sp, limbVy + Math.sin(a) * sp - 20), life: 0, max: 0.16 + rand() * 0.12, r: 1.3, col: rand() < 0.5 ? '#ffffff' : '#00f0ff', grav: 680, kind: 'spark', drag: 2.8 });
        }
        if (rand() < 0.04) snd.sparkTick(this.pan(wp.x));
      } else if (st.bow === 'fire') {
        // Buoyant flame wisp rising specifically from the wound `wp` on the struck body part
        if (rand() < 0.35) {
          this.parts.push({
            p: v(wp.x + (rand() - 0.5) * 4, wp.y + (rand() - 0.5) * 4),
            vel: v(limbVx + (rand() - 0.5) * 24, limbVy - 42 - rand() * 45),
            life: 0, max: 0.26 + rand() * 0.2, r: (4.2 + rand() * 3.5) * k.s,
            col: '#ff6a00', grav: -210, kind: 'fire', drag: 3.2, turb: 8, seed: rand() * 100,
          });
        }
        if (rand() < 0.1) {
          this.parts.push({
            p: { ...wp }, prev: { ...wp },
            vel: v(limbVx + (rand() - 0.5) * 65, limbVy - 30 - rand() * 50),
            life: 0, max: 0.32 + rand() * 0.25, r: 1.3,
            col: '#ffe552', grav: 720, kind: 'ember', drag: 1.1,
          });
        }
      } else if (st.bow === 'poison') {
        // Gravity-driven Xenomorph acid droplet falling straight DOWN from the struck body part `wp`
        if (rand() < 0.26) {
          this.parts.push({
            p: { ...wp }, prev: { ...wp },
            vel: v(limbVx * 0.4 + (rand() - 0.5) * 18, 10 + rand() * 30),
            life: 0, max: 0.36 + rand() * 0.26, r: 1.6 + rand() * 1.4,
            col: rand() < 0.5 ? '#eaff66' : '#8cff00', grav: 720, kind: 'acid', drag: 1.2,
          });
        }
        if (rand() < 0.1) {
          this.parts.push({
            p: { ...wp }, vel: v((rand() - 0.5) * 16, -35 - rand() * 25),
            life: 0, max: 0.38 + rand() * 0.25, r: 4.2 + rand() * 3.5,
            col: '#c4ff80', grav: -85, kind: 'acidSmoke', drag: 2.5, turb: 5,
          });
        }
      }
    }

    if (!hasActiveStuck && f.shockT <= 0 && f.burnT <= 0 && f.poisonT <= 0) return;
    f.dotTick += H;
    if (k.alive && f.dotTick >= 0.55) {
      f.dotTick = 0;
      let dot = 0;
      let label = '';
      let col = '#ffffff';
      if (f.shockT > 0) { dot += 7; label = '⚡ -7'; col = '#5cf4ff'; }
      if (f.burnT > 0) { dot += 8; label = '🔥 -8'; col = '#ff942e'; snd.sizzle(this.pan(k.p[1].x)); }
      if (f.poisonT > 0) { dot += 7; label = '🧪 -7'; col = '#d4ff00'; snd.sizzle(this.pan(k.p[1].x)); }
      if (dot > 0) {
        f.hp -= dot; f.hpShow = 2.5; f.flash = 0.5;
        this.say(k.p[0].x + (rand() - 0.5) * 18, k.p[0].y - (HEAD_R + 22) * k.s, label, col, 14, 0.7);
        if (f.hp <= 0) this.die(f, false);
      }
    }
  }

  private popBalloon(b: Balloon) {
    this.balloons = this.balloons.filter((x) => x !== b);
    const p = v(b.x, b.y);
    this.burst(p, v(0, -1), 12, b.kind === 'heart' ? '#ff5a5f' : '#ffc933', 220);
    snd.pop(this.pan(b.x));
    if (b.kind === 'heart') {
      const pf = this.player;
      pf.hp = Math.min(pf.maxHp, pf.hp + 30);
      this.say(b.x, b.y - 20, '+30 NYAWA', '#7dffa0', 18, 1.2);
      snd.heal();
    } else {
      this.spawnCoins(p, 10);
      this.say(b.x, b.y - 20, '+10', '#ffd23f', 18, 1.2);
    }
  }

  update(dtReal: number) {
    const dt = Math.min(Math.max(dtReal, 0), 0.05);
    this.rt += dt;
    ambTick(dt, THEMES.indexOf(this.theme));
    // the camera breathes, and leans a little toward where you aim
    const pk = this.player.k;
    this.cam = damp(this.cam, Math.sin(this.rt * 0.11) * 0.55 + (this.drag.on ? Math.cos(pk.aim) * 0.3 * pk.pull : 0), 2, dt);
    if (this.xray) { this.xray.t += dt; if (this.xray.t >= this.xray.dur) this.xray = null; }
    const fullX = !!this.xray && this.xray.full; // only the head shot takes over the camera

    // Dynamic Camera Zoom-Out & Framing:
    // Automatically fits the span from the player's ground on the left to the furthest active enemy ground on the right!
    let minWorldX = Math.max(20, this.pPlat.x - 155);
    let maxWorldX = this.VW;
    if (!this.demo && this.stage === 'play') {
      let furthestRight = this.VW * 0.92;
      for (const f of this.foes) {
        if (!f.k.alive && f.deadT > 1.2) continue;
        const rEdge = f.plat.x + f.plat.w * 0.5 + 150;
        if (rEdge > furthestRight) furthestRight = rEdge;
      }
      if (this.hostage && this.hostState === 1) {
        furthestRight = Math.max(furthestRight, this.hostage.plat.x + 150);
      }
      maxWorldX = Math.max(this.VW, furthestRight);
    }
    const reqSpanX = Math.max(this.VW, maxWorldX - minWorldX);
    const fitZoom = clamp(this.VW / reqSpanX, 0.52, 1);
    const targetZoom = fullX ? 2.3 : this.stage === 'play' ? fitZoom : this.zoomTo;
    const targetCamX = fitZoom < 0.99 ? (minWorldX + maxWorldX) * 0.5 : this.VW * 0.5;
    const targetCamY = this.VH * 0.5 - (1 - fitZoom) * 55;

    this.zoom = damp(this.zoom, targetZoom, fullX ? 16 : 4.2, dt);
    this.camX = damp(this.camX, targetCamX, 4.2, dt);
    this.camY = damp(this.camY, targetCamY, 4.2, dt);
    this.panK = damp(this.panK, fullX ? 0.82 : 0, fullX ? 16 : 6, dt);
    this.stepCoins(dt);
    this.birdT -= dt;
    if (this.birdT <= 0) {
      this.birdT = 11 + rand() * 16;
      const dir = rand() < 0.5 ? 1 : -1;
      this.birds.push({ x: dir > 0 ? -0.08 : 1.08, y: 0.08 + rand() * 0.22, vx: dir * (0.045 + rand() * 0.03), n: 3 + Math.floor(rand() * 3), ph: rand() * 6 });
    }
    for (const b of this.birds) b.x += b.vx * dt;
    this.birds = this.birds.filter((b) => b.x > -0.3 && b.x < 1.3);
    if (!this.paused) {
      if (this.hitStop > 0) this.hitStop -= dt;
      else {
        // an X-ray all but stops the clock; the kill's slow motion picks up after it
        if (!fullX) this.slowT -= dt;
        const pace = this.slowT > 0 ? this.slowK : 1;
        this.ts = fullX ? 0.03 : damp(this.ts, this.xray ? Math.min(0.3, pace) : pace, 14, dt);
        this.acc += dt * this.ts;
        let guard = 0;
        while (this.acc >= H && guard++ < 10) { this.step(); this.acc -= H; }
        if (guard >= 10) this.acc = 0;
      }
      this.shake = Math.max(0, this.shake - dt * 28);
      this.hurt = Math.max(0, this.hurt - dt * 2.2);
      this.banner = Math.max(0, this.banner - dt);
      for (const t of this.texts) t.life += dt;
      this.texts = this.texts.filter((t) => t.life < t.max);
      const pf = this.player;
      if (!this.demo && pf.k.alive && pf.hp < pf.maxHp * 0.3 && this.stage === 'play') {
        this.heartT -= dt;
        if (this.heartT <= 0) { this.heartT = 0.85; snd.heart(); }
      }
      if (fullX) { /* the moment holds */ }
      else if (this.stage === 'clear') {
        this.clearT += dt;
        if (this.clearT > 1.3) this.zoomTo = 1;
        if (this.clearT > 0.95 && !this.rewardPaid) { this.rewardPaid = true; this.spawnCoins(v(this.w / 2, this.h * 0.36 + 44), 10 + 2 * this.level, true); }
        if (this.clearT > 3.2) {
          this.pending = 0; this.coinFx = [];
          pf.hp = Math.min(pf.maxHp, Math.round(pf.hp + pf.maxHp * 0.4));
          this.stage = 'shop'; this.drag.on = false;
          snd.open();
        }
      } else if (this.stage === 'dying') {
        this.deadT += dt;
        if (this.deadT > 1.9) { this.stage = 'dead'; snd.lose(); }
      }
    }
    this.emitUi();
  }

  private emitUi() {
    const pf = this.player;
    const hasBoss = this.foes.some((f) => f.k.alive && (f.kind === 'axer' || f.kind === 'boss'));
    const ui: RUi = {
      stage: this.stage, demo: this.demo, level: this.level, kills: this.kills, total: this.demo ? 1 : this.total, grounds: this.maxAlive, coins: this.coins, shown: this.coins - this.pending, bump: this.bumpN, hostage: this.hostState,
      totalKills: this.totalKills, headshots: this.headshots, hp: Math.max(0, Math.round(pf.hp)), maxHp: pf.maxHp, best: this.best,
      boss: hasBoss || this.level % 5 === 0, hint: this.hint, paused: this.paused, theme: this.theme.name, stars: this.stars, reward: 10 + 2 * this.level, up: { ...this.up },
      cost: { hp: this.costOf('hp'), dmg: this.costOf('dmg'), multi: this.costOf('multi'), leech: this.costOf('leech') },
      bow: this.bow,
      showGuide: this.showGuide,
      rangeMult: this.rangeMult,
      maxPower: this.maxPower,
    };
    const key = JSON.stringify(ui);
    if (key !== this.last) { this.last = key; this.emit(ui); }
  }

  /* ---------------- drawing ---------------- */

  private drawFighter(ctx: Ctx, f: Fighter) {
    const k = f.k;
    const fl = Math.round(f.flash * 215);
    const big = f.kind === 'boss' || f.kind === 'axer';
    const bk = f.bossKind;
    const bossEye =
      bk === 'thunder_lord' ? '#00f0ff'
      : bk === 'inferno_king' ? '#ff9419'
      : bk === 'xeno_queen' ? '#cfff04'
      : bk === 'thorn_warden' ? '#7dff24'
      : big || f.kind === 'heavy' ? '#ff4b4b' : '#ffffff';
    const bossBand =
      bk === 'thunder_lord' ? '#00b4ff'
      : bk === 'inferno_king' ? '#ff4800'
      : bk === 'xeno_queen' ? '#7bff00'
      : bk === 'thorn_warden' ? '#2eb82e'
      : f.kind === 'player' ? '#e5352f'
      : big ? '#c4161c'
      : f.kind === 'hostage' ? '#5ad1ff' : null;
    const look: StickLook = {
      color: fl > 4 ? `rgb(${fl},${Math.round(fl * 0.1)},${Math.round(fl * 0.1)})` : '#000000',
      rim: fl > 4 ? null : this.theme.rim,
      eye: bossEye,
      helm: f.helm, crown: f.kind === 'boss', horns: f.kind === 'axer',
      band: bossBand,
      quiver: f.kind !== 'axer' && f.kind !== 'hostage', bound: f.kind === 'hostage' && this.hostState === 1,
      bossKind: bk,
    };
    const base = ctx.globalAlpha;
    if (f.kind !== 'hostage') ctx.globalAlpha = f.deadT > 5 ? clamp(6 - f.deadT, 0, 1) : 1;

    const activeBow: BowId = f.team === 0 ? this.bow : 'wood';
    drawStick(ctx, k, look, () => {
      if (f.kind === 'axer') {
        drawBossHeldWeapon(ctx, k, bk ?? 'axer', this.rt);
        return;
      }
      if (!k.hasBow) return;
      const hold = onString(k);
      const vib = f.vib < 0.5 ? Math.exp(-f.vib * 12) * Math.cos(f.vib * 85) * 7 : 0;
      drawBow(ctx, k.p[4], k.bowAng, k.s, hold ? dist(k.p[4], k.p[6]) : null, vib, k.nock >= 1, activeBow, this.rt);
      if (k.nock < 1 && k.nock > 0.55) drawArrow(ctx, add(k.p[6], fromAngle(k.bowAng, ARROW_LEN * k.s)), k.bowAng, k.s, false, activeBow, this.rt, false);
    }, () => {
      // arrows & axes embedded (`nancep`) in him go down first: the body then closes over the buried points/blades!
      // When `st.halfThrough === true` (MAX POWER final hit), half of the arrow (`ARROW_LEN * 0.5`) juts out the back with its arrowhead visible!
      for (const st of f.stuck) {
        const [ia, ib] = RAG_STICKS[st.stick];
        const A = k.p[ia]; const B = k.p[ib];
        const ba = Math.atan2(B.y - A.y, B.x - A.x); const c = Math.cos(ba); const sn = Math.sin(ba);
        const wp = v(A.x + st.lx * c - st.ly * sn, A.y + st.lx * sn + st.ly * c);
        if (st.isAxe) {
          drawAxe(ctx, wp, ba + st.rel, st.s ?? 1.25, true, st.bossKind ?? 'axer', this.rt);
        } else {
          drawArrow(ctx, wp, ba + st.rel, 1, !st.halfThrough, st.bow, this.rt, false);
        }
      }
    });

    // LEVEL-1 LOCALIZED ELEMENTAL SIMULATION ON THE STRUCK BODY PART ONLY (`st.stick` at `st.u`):
    for (let si = 0; si < f.stuck.length; si++) {
      const st = f.stuck[si];
      if (st.fxT <= 0) continue;
      const [ia, ib] = RAG_STICKS[st.stick];
      const A = k.p[ia]; const B = k.p[ib];
      const wp = lerpV(A, B, st.u);
      const inten = clamp(st.fxT / 1.2, 0, 1);
      const limbVx = (B.x - k.o[ib].x) / H;

      if (st.bow === 'thunder') {
        // 1. Localized Level-1 Electro-Shock ONLY on `st.stick`:
        if (this.cyanSpr) {
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = inten * 0.42;
          const r = 28 * k.s;
          ctx.drawImage(this.cyanSpr as unknown as CanvasImageSource, wp.x - r, wp.y - r, r * 2, r * 2);
          ctx.restore();
        }
        // Only the bone of the struck body part (`st.stick`) softly illuminates inside the black silhouette
        if (Math.sin(this.rt * 38 + si * 2) > -0.2) {
          ctx.save();
          ctx.shadowColor = 'rgba(0, 235, 255, 0.9)';
          ctx.shadowBlur = 6 * this.dpr;
          ctx.globalAlpha = inten * 0.85;
          drawSkeleton(ctx, k, st.stick, wp, 0, true);
          ctx.restore();
        }
        // Delicate, smooth plasma filament hugging only the struck bone segment (`A` <-> `wp` <-> `B`)
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = inten * 0.9;
        drawBolt(ctx, A, wp, 4.2 * k.s, 5, '#ffffff', '#00e5ff', 1.15, false, this.rt * 18 + si * 7);
        drawBolt(ctx, wp, B, 4.2 * k.s, 5, '#ffffff', '#00e5ff', 1.15, false, this.rt * 18 + si * 7 + 3);
        ctx.restore();
      } else if (st.bow === 'fire') {
        // 2. Localized Level-1 Fluid Simulation Flame ONLY at `wp` on the struck body part:
        // Flame naturally rises straight UP against world gravity (`-Math.PI / 2`), swaying gently with limb motion!
        if (this.fireSpr) {
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = inten * 0.38;
          const r = 26 * k.s;
          ctx.drawImage(this.fireSpr as unknown as CanvasImageSource, wp.x - r, wp.y - r, r * 2, r * 2);
          ctx.restore();
        }
        ctx.save();
        ctx.globalCompositeOperation = 'lighter';
        ctx.globalAlpha = inten * 0.92;
        const sway = clamp(-limbVx * 0.0018, -0.35, 0.35) + Math.sin(this.rt * 9 + si * 2.3) * 0.12;
        drawSimFlame(ctx, wp, -Math.PI / 2 + sway, 19 * k.s, 6.2 * k.s, 0.5, this.rt, si * 3.1 + 1);
        drawSimFlame(ctx, wp, -Math.PI / 2 + sway * 0.6, 13 * k.s, 4.2 * k.s, 0.92, this.rt, si * 5.7 + 2);
        ctx.restore();
      } else if (st.bow === 'poison') {
        // 3. Localized Level-1 Xenomorph Acid ONLY at `wp` on the struck body part:
        // Subtle green acid-etched gleam on the struck bone + gravity-accurate dripping strand straight DOWN (`+y`)!
        if (this.acidSpr) {
          ctx.save();
          ctx.globalCompositeOperation = 'lighter';
          ctx.globalAlpha = inten * 0.35;
          const r = 24 * k.s;
          ctx.drawImage(this.acidSpr as unknown as CanvasImageSource, wp.x - r, wp.y - r, r * 2, r * 2);
          ctx.restore();
        }
        ctx.save();
        ctx.globalAlpha = inten * 0.88;
        const cycle = (this.rt * 1.6 + si * 0.37) % 1;
        const dropLen = (4 + cycle * 14) * k.s;
        const lagX = clamp(-limbVx * 0.015, -4, 4);
        ctx.lineCap = 'round';
        ctx.strokeStyle = '#7bff00'; ctx.lineWidth = 1.9 * (1 - cycle * 0.45) * k.s;
        ctx.beginPath(); ctx.moveTo(wp.x, wp.y); ctx.lineTo(wp.x + lagX, wp.y + dropLen); ctx.stroke();
        ctx.strokeStyle = '#eaff66'; ctx.lineWidth = 0.85 * k.s;
        ctx.beginPath(); ctx.moveTo(wp.x, wp.y); ctx.lineTo(wp.x + lagX, wp.y + dropLen); ctx.stroke();
        ctx.fillStyle = '#d4ff00';
        ctx.beginPath(); ctx.ellipse(wp.x + lagX, wp.y + dropLen, 1.6 * k.s, 2.3 * k.s, 0, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      }
    }

    ctx.globalAlpha = f.kind === 'hostage' ? base : 1;
  }

  /**
   * Draws the thick glossy Health Bar + 3D Circular Level Badge + Delayed White Damage Catch-Up Bar
   * matching Image 1 (`Gambar 1`).
   */
  private drawBar(ctx: Ctx, f: Fighter) {
    const k = f.k;
    const big = f.kind === 'boss' || f.kind === 'axer';
    const sc = clamp(k.s, 0.96, 1.32);
    const bump = f.barBump > 0 ? 1 + 0.13 * Math.sin(f.barBump * Math.PI) : 1;
    const fade = k.alive ? clamp((f.plat.rise - 0.55) * 3, 0, 1) : clamp(1 - f.deadT / 0.55, 0, 1);
    if (fade <= 0.01) return;

    const bw = (big ? 68 : f.lvl >= 3 ? 56 : f.lvl === 2 ? 51 : 46) * sc;
    const bh = 11.5 * sc;
    const rOrb = 11.2 * sc;
    const headX = k.p[0].x;
    const headY = Math.min(k.p[0].y, k.p[1].y - 12 * k.s) - (HEAD_R + 22) * k.s - (big ? 20 : f.helm ? 6 : 0);

    const hpFrac = clamp(f.hp / f.maxHp, 0, 1);
    const lagFrac = clamp(f.hpLag / f.maxHp, hpFrac, 1);
    const isEnemyOrLow = f.team === 1 || hpFrac <= 0.3;

    ctx.save();
    ctx.globalAlpha *= fade;
    ctx.translate(headX, headY);
    if (bump !== 1) ctx.scale(bump, bump);

    // Total width of (Orb + Bar) centered above the head
    const xBar = -bw * 0.42;
    const yBar = -bh * 0.5;
    const cxOrb = xBar - rOrb * 0.32;
    const cyOrb = 0;

    // 1. Rectangular Bar Outer Metallic Frame & Dark Bevel (Image 1 style)
    ctx.fillStyle = '#142b42';
    ctx.fillRect(xBar - 2, yBar - 2, bw + 4, bh + 4);
    ctx.strokeStyle = '#8faabf';
    ctx.lineWidth = 1.5 * sc;
    ctx.strokeRect(xBar - 1.5, yBar - 1.5, bw + 3, bh + 3);

    // 2. Empty Track (Slate-Blue like Image 1's right side)
    ctx.fillStyle = 'rgba(34, 74, 114, 0.88)';
    ctx.fillRect(xBar, yBar, bw, bh);
    ctx.fillStyle = 'rgba(18, 44, 72, 0.65)';
    ctx.fillRect(xBar, yBar + bh * 0.52, bw, bh * 0.48);

    // 3. Delayed White Damage Catch-Up Bar (`hpLag` — the crisp white middle section in Image 1!)
    if (lagFrac > hpFrac + 0.003) {
      const wx = xBar + bw * hpFrac;
      const ww = bw * (lagFrac - hpFrac);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(wx, yBar, ww, bh);
      ctx.fillStyle = '#dceeff';
      ctx.fillRect(wx, yBar + bh * 0.62, ww, bh * 0.38);
    }

    // 4. Glossy Two-Tone Health Fill (Bright top highlight + rich bottom shade like Image 1)
    if (hpFrac > 0.002) {
      const fw = bw * hpFrac;
      const topCol = isEnemyOrLow ? '#ff5e5e' : '#70f588';
      const botCol = isEnemyOrLow ? '#c41c22' : '#1ca339';
      ctx.fillStyle = botCol;
      ctx.fillRect(xBar, yBar, fw, bh);
      ctx.fillStyle = topCol;
      ctx.fillRect(xBar, yBar, fw, bh * 0.44);
      // Thin specular top edge
      ctx.fillStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.fillRect(xBar, yBar + 0.6, fw, 1.3 * sc);
    }

    // Subtle divider ticks for thick HP enemies (Level 2 / Level 3 / Bosses)
    const segs = Math.min(6, Math.max(1, Math.round(f.maxHp / 42)));
    if (segs > 1) {
      ctx.fillStyle = 'rgba(10, 26, 42, 0.38)';
      for (let i = 1; i < segs; i++) {
        ctx.fillRect(xBar + (bw * i) / segs - 0.6, yBar, 1.2, bh);
      }
    }

    // 5. Glossy 3D Circular Level Badge on the Left (Image 1's shiny red orb with level number!)
    const orbRim = isEnemyOrLow ? '#6b0b11' : '#0a471b';
    const orbBody = isEnemyOrLow ? '#de2027' : '#22b845';
    const orbHi = isEnemyOrLow ? '#ff8888' : '#94ffa4';

    // Drop shadow behind orb
    ctx.fillStyle = 'rgba(0, 12, 24, 0.45)';
    ctx.beginPath();
    ctx.arc(cxOrb + 1, cyOrb + 1.5, rOrb + 1.2, 0, Math.PI * 2);
    ctx.fill();

    // Outer dark rim + main orb body
    ctx.fillStyle = orbRim;
    ctx.beginPath();
    ctx.arc(cxOrb, cyOrb, rOrb + 1.2 * sc, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = orbBody;
    ctx.beginPath();
    ctx.arc(cxOrb, cyOrb, rOrb, 0, Math.PI * 2);
    ctx.fill();

    // Inner lower-right shading crescent
    ctx.fillStyle = 'rgba(70, 0, 8, 0.28)';
    ctx.beginPath();
    ctx.arc(cxOrb, cyOrb, rOrb, -0.2, Math.PI * 0.85);
    ctx.fill();

    // Upper-left glossy highlight crescent & specular dot (matching Image 1!)
    ctx.save();
    ctx.translate(cxOrb - rOrb * 0.26, cyOrb - rOrb * 0.3);
    ctx.rotate(-0.55);
    ctx.fillStyle = orbHi;
    ctx.beginPath();
    ctx.ellipse(0, 0, rOrb * 0.52, rOrb * 0.3, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255, 255, 255, 0.72)';
    ctx.beginPath();
    ctx.ellipse(-rOrb * 0.08, -rOrb * 0.06, rOrb * 0.28, rOrb * 0.15, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Bold Italic Level Number inside the Orb (`1`, `2`, `3`, ...)
    const lvlStr = String(f.lvl);
    ctx.font = `italic 900 ${Math.round(13.5 * sc)}px ${FONT}`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#290914';
    ctx.lineWidth = 3.2 * sc;
    ctx.strokeText(lvlStr, cxOrb - 0.5 * sc, cyOrb + 0.8 * sc);
    ctx.fillStyle = '#ffffff';
    ctx.fillText(lvlStr, cxOrb - 0.5 * sc, cyOrb + 0.8 * sc);

    ctx.restore();
  }

  private text(ctx: Ctx, s: string, x: number, y: number, size: number, col: string, alpha = 1) {
    ctx.globalAlpha = alpha;
    ctx.font = `italic 900 ${size}px ${FONT}`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(3, size * 0.2); ctx.strokeStyle = 'rgba(0,18,30,0.6)';
    ctx.strokeText(s, x, y);
    ctx.fillStyle = col; ctx.fillText(s, x, y);
    ctx.globalAlpha = 1;
  }

  /** everything that lives in the forest behind and in front of the fight */
  private ambience(ctx: Ctx, W: number, Hh: number, part: 'sky' | 'mid' | 'front', off: number) {
    const th = this.theme; const dpr = this.dpr; const rt = this.rt;
    const u = Math.max(0.5, Math.min(W, Hh * 1.5) / (1100 * dpr));
    if (part === 'sky') {
      // shafts of light through the canopy
      ctx.globalCompositeOperation = 'lighter';
      const leanX = Math.tan(th.disc[0] > 0.5 ? -0.36 : 0.36) * Hh;
      for (const r of this.rays) {
        const a = 0.05 + 0.04 * Math.sin(rt * 0.35 + r.ph);
        const x = r.x * W + off + Math.sin(rt * 0.12 + r.ph) * 24 * dpr; const w0 = r.w * W;
        const g = ctx.createLinearGradient(x, 0, x + leanX, Hh * 0.95);
        g.addColorStop(0, `rgba(${th.ray},${a})`); g.addColorStop(1, `rgba(${th.ray},0)`);
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.moveTo(x - w0 / 2, -10); ctx.lineTo(x + w0 / 2, -10); ctx.lineTo(x + leanX + w0 * 1.4, Hh * 0.95); ctx.lineTo(x + leanX - w0 * 1.4, Hh * 0.95); ctx.closePath(); ctx.fill();
      }
      ctx.globalCompositeOperation = 'source-over';
      // a flock crossing far away
      ctx.strokeStyle = th.tree; ctx.globalAlpha = 0.55; ctx.lineWidth = 1.8 * dpr * u; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      for (const b of this.birds) {
        const dir = Math.sign(b.vx);
        for (let i = 0; i < b.n; i++) {
          const x = (b.x - dir * i * 0.02) * W; const y = (b.y + (i % 2 ? 1 : -1) * i * 0.012 + Math.sin(rt * 0.9 + i + b.ph) * 0.006) * Hh;
          const s = (6 + (i % 3)) * dpr * u; const flap = Math.sin(rt * 9 + i * 1.3 + b.ph) * 0.7;
          ctx.beginPath(); ctx.moveTo(x - s, y - s * flap); ctx.quadraticCurveTo(x - s * 0.4, y - s * 0.25 * flap - s * 0.2, x, y); ctx.quadraticCurveTo(x + s * 0.4, y - s * 0.25 * flap - s * 0.2, x + s, y - s * flap); ctx.stroke();
        }
      }
      ctx.globalAlpha = 1;
    }
    if (part === 'sky' || part === 'front') {
      // fireflies: small and many among the trees, a few big soft ones close to the lens
      const front = part === 'front'; const spr = this.flySpr;
      if (spr) {
        ctx.globalCompositeOperation = 'lighter';
        for (const fl of this.flies) {
          if (fl.front !== front) continue;
          const t = rt * fl.sp;
          const b = Math.pow(Math.max(0, Math.sin(rt * fl.bl + fl.ph * 3)), 1.6);
          if (b < 0.02) continue;
          const x = (fl.x + Math.sin(t + fl.ph) * 0.035 + Math.sin(t * 0.37 + fl.ph * 2.1) * 0.05) * W;
          const y = (fl.y + Math.cos(t * 0.8 + fl.ph * 1.3) * 0.04 + Math.sin(t * 0.23 + fl.ph) * 0.03) * Hh;
          const r = fl.r * dpr * u;
          ctx.globalAlpha = b * (front ? 0.42 : 0.95);
          ctx.drawImage(spr as unknown as CanvasImageSource, x - r, y - r, r * 2, r * 2);
        }
        ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      }
    }
    if (part === 'mid') {
      // vines swaying from the canopy
      ctx.strokeStyle = th.tree; ctx.fillStyle = th.tree; ctx.globalAlpha = 0.4; ctx.lineWidth = 2.4 * dpr * u; ctx.lineCap = 'round';
      for (const vn of this.vines) {
        const x = vn.x * W + off; const L = vn.len * Hh;
        const sw = Math.sin(rt * 0.8 + vn.ph) * L * 0.09 + Math.sin(rt * 1.9 + vn.ph * 2) * L * 0.02;
        ctx.beginPath(); ctx.moveTo(x, -4); ctx.quadraticCurveTo(x + sw * 0.35, L * 0.55, x + sw, L); ctx.stroke();
        let side = 1;
        for (const t of [0.3, 0.52, 0.72, 0.9, 1]) {
          const m = 1 - t;
          const px = m * m * x + 2 * m * t * (x + sw * 0.35) + t * t * (x + sw); const py = 2 * m * t * L * 0.55 + t * t * L;
          ctx.beginPath(); ctx.ellipse(px + side * 5 * dpr * u, py, 6.5 * dpr * u, 3.2 * dpr * u, side * 0.6, 0, Math.PI * 2); ctx.fill();
          side = -side;
        }
      }
      // low mist drifting between the trunks
      const mist = this.mistSpr;
      if (mist) {
        for (const m of this.mists) {
          const x = ((((m.x + rt * m.sp) % 1.5) + 1.5) % 1.5) - 0.25;
          ctx.globalAlpha = 0.1 + 0.04 * Math.sin(rt * 0.3 + m.y * 20);
          ctx.drawImage(mist as unknown as CanvasImageSource, x * W - W * 0.45, m.y * Hh - Hh * 0.11, W * 0.9, Hh * 0.22);
        }
      }
      // leaves tumbling down
      ctx.fillStyle = th.tree; ctx.globalAlpha = 0.5;
      for (const lf of this.leaves) {
        const y = ((lf.y + rt * lf.sp) % 1.15) - 0.08;
        const x = ((lf.x + Math.sin(rt * 0.9 + lf.ph) * 0.03 + rt * 0.012) % 1.1) - 0.05;
        ctx.save();
        ctx.translate(x * W, y * Hh); ctx.rotate(rt * lf.rs + lf.ph + Math.sin(rt * 1.7 + lf.ph));
        ctx.scale(1, 0.35 + 0.65 * Math.abs(Math.sin(rt * 1.3 + lf.ph)));
        ctx.beginPath(); ctx.ellipse(0, 0, lf.r * dpr * u, lf.r * dpr * u * 0.48, 0, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
      }
      ctx.globalAlpha = 1;
    }
    if (part === 'front') {
      // tall grass right at the lens, moving with the wind
      ctx.fillStyle = th.fg; ctx.globalAlpha = 0.94;
      ctx.beginPath();
      const gust = Math.sin(rt * 0.5) * 0.12;
      for (const b of this.blades) {
        const x = b.x * W; const hh = b.h * dpr * u; const bw = b.w * dpr * u;
        const sw = (Math.sin(rt * 1.5 + b.x * 14 + b.ph) * 0.2 + Math.sin(rt * 0.63 + b.x * 5) * 0.16 + gust) * hh;
        ctx.moveTo(x - bw, Hh + 2);
        ctx.quadraticCurveTo(x + sw * 0.3 - bw * 0.3, Hh - hh * 0.6, x + sw, Hh - hh);
        ctx.quadraticCurveTo(x + sw * 0.3 + bw, Hh - hh * 0.5, x + bw, Hh + 2);
      }
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  /**
   * X-ray. A head shot is the Mortal-Kombat moment: the world goes dark and cold, the camera closes in and you
   * see the whole skeleton with the skull splitting. Any other hit opens a small window over just the bone that
   * was struck - no zoom, the fight carries on around it.
   */
  private drawXray(ctx: Ctx, W: number, Hh: number, shx: number, shy: number) {
    const x = this.xray;
    if (!x) return;
    const { w, h, dpr } = this; const k = x.f.k; const s = k.s;
    const u = x.t / x.dur;
    const e = clamp(x.t / 0.06, 0, 1) * clamp((x.dur - x.t) / 0.12, 0, 1);
    const [ck, cx0, cy0] = this.camTf();
    const world = () => ctx.setTransform(dpr * ck, 0, 0, dpr * ck, dpr * (cx0 + shx), dpr * (cy0 + shy));
    const inside = () => {
      // the flesh is only a dim blue shadow with a cold halo, and inside it, the bones
      ctx.shadowColor = 'rgba(60,180,255,0.95)'; ctx.shadowBlur = 14 * dpr;
      drawStick(ctx, k, { color: '#17588a', rim: null, eye: 'rgba(0,0,0,0)', helm: false, crown: false, band: null, quiver: false });
      ctx.shadowColor = 'rgba(170,240,255,0.95)'; ctx.shadowBlur = 7 * dpr;
      drawSkeleton(ctx, k, x.stick, x.pt, u, !x.full);
      ctx.shadowBlur = 0;
      drawArrow(ctx, add(x.pt, fromAngle(x.ang, 2)), x.ang, 1, false);
    };
    const chips = (n: number, reach: number) => {
      ctx.fillStyle = '#ecfcff';
      for (let i = 0; i < n; i++) {
        const a = x.ang + (i - (n - 1) / 2) * 0.33; const dd = 5 + u * (reach + i * 7);
        ctx.globalAlpha = e * (1 - u * 0.6);
        ctx.save();
        ctx.translate(x.pt.x + Math.cos(a) * dd, x.pt.y + Math.sin(a) * dd + u * u * 26); ctx.rotate(i * 2 + u * 9);
        ctx.beginPath(); ctx.moveTo(-2.4, -1.2); ctx.lineTo(2.6, 0); ctx.lineTo(-1.6, 1.8); ctx.closePath(); ctx.fill();
        ctx.restore();
      }
    };
    if (!x.full) {
      world();
      // Non-head X-ray: DO NOT draw a black panel or capsule border!
      // Because the stickman body is already black (#000000), the glowing cyan-white bones & fracture show right inside the body!
      const [ia, ib] = RAG_STICKS[x.stick];
      let A = k.p[ia]; let B = k.p[ib];
      if (x.stick === 1) { A = lerpV(k.p[2], k.p[1], clamp(x.u - 0.2, 0, 1)); B = lerpV(k.p[2], k.p[1], clamp(x.u + 0.2, 0, 0.97)); }
      const r = (x.stick === 1 ? 17 : 14) * s * (0.55 + 0.45 * ease.out(Math.min(1, x.t / 0.09)));
      ctx.save();
      ctx.globalAlpha = e;
      ctx.shadowColor = 'rgba(110, 235, 255, 0.98)';
      ctx.shadowBlur = 9 * dpr;
      drawSkeleton(ctx, k, x.stick, x.pt, u, true);
      ctx.shadowBlur = 0;
      ctx.restore();
      chips(5, 22);
      const mid = lerpV(A, B, 0.5);
      const label = x.stick === 1 ? 'RUSUK RETAK!' : x.stick <= 5 ? 'TULANG KAKI RETAK!' : 'TULANG LENGAN RETAK!';
      this.text(ctx, label, mid.x, Math.min(A.y, B.y) - r - 11 - u * 8, 12 * (1 + 0.3 * Math.max(0, 1 - u * 5)), '#dffaff', e);
      ctx.globalAlpha = 1;
      return;
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 0.84 * e; ctx.fillStyle = '#020a18'; ctx.fillRect(0, 0, W, Hh);
    world();
    ctx.globalAlpha = e;
    inside();
    // the shock of the impact, a red ring, chips of bone leaving with the arrow
    const pop = Math.max(0, 1 - u * 2.2);
    ctx.strokeStyle = '#ffffff'; ctx.lineCap = 'round';
    for (let i = 0; i < 9; i++) {
      const a = i * 0.7 + 0.3; const r0 = 9 + u * 30; const r1 = r0 + (10 + (i % 3) * 7) * (0.4 + pop);
      ctx.globalAlpha = e * (0.3 + 0.7 * pop); ctx.lineWidth = 2.2 * (0.4 + pop);
      ctx.beginPath(); ctx.moveTo(x.pt.x + Math.cos(a) * r0, x.pt.y + Math.sin(a) * r0); ctx.lineTo(x.pt.x + Math.cos(a) * r1, x.pt.y + Math.sin(a) * r1); ctx.stroke();
    }
    ctx.strokeStyle = '#ff4d4d'; ctx.globalAlpha = e * (1 - u); ctx.lineWidth = 2.4;
    ctx.beginPath(); ctx.arc(x.pt.x, x.pt.y, 6 + u * 30, 0, Math.PI * 2); ctx.stroke();
    chips(7, 34);
    // on the glass: scan lines, a cold vignette, and what just happened
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalAlpha = 0.07 * e; ctx.fillStyle = '#9fe6ff';
    for (let y = (this.rt * 60) % 4; y < h; y += 4) ctx.fillRect(0, y, w, 1);
    ctx.globalAlpha = e;
    const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.72);
    g.addColorStop(0, 'rgba(30,120,200,0)'); g.addColorStop(1, 'rgba(30,120,200,0.4)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    const size = clamp(w * 0.05, 22, 44) * (1 + 0.35 * Math.max(0, 1 - u * 5));
    this.text(ctx, 'TENGKORAK RETAK!', w / 2 + (rand() - 0.5) * 3 * pop, h * 0.84, size, '#eafcff', e);
    ctx.globalAlpha = 1;
  }

  render(ctx: Ctx) {
    const { w, h, dpr } = this;
    const W = Math.round(w * dpr); const Hh = Math.round(h * dpr);
    const th = this.theme;
    const key = `${W}x${Hh}:${th.name}`;
    if (key !== this.sceneKey || !this.scene) {
      this.scene = paintScene(W, Hh, th, THEMES.indexOf(th) + 1, this.make);
      this.flySpr = glowSprite(this.make, th.fly, 64);
      if (!this.mistSpr) this.mistSpr = glowSprite(this.make, '#ffffff', 128);
      if (!this.goldSpr) this.goldSpr = glowSprite(this.make, '#ffc933', 64);
      if (!this.cyanSpr) this.cyanSpr = glowSprite(this.make, '#00e5ff', 96);
      if (!this.fireSpr) this.fireSpr = glowSprite(this.make, '#ff6a00', 96);
      if (!this.acidSpr) this.acidSpr = glowSprite(this.make, '#a6ff00', 96);
      this.sceneKey = key;
    }
    const sn = this.scene; const pad = sn.pad; const cam = clamp(this.cam, -1, 1);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    ctx.drawImage(sn.sky as unknown as CanvasImageSource, -pad - cam * pad * 0.25, 0);
    this.ambience(ctx, W, Hh, 'sky', -cam * pad * 0.3);
    ctx.drawImage(sn.near as unknown as CanvasImageSource, -pad - cam * pad * 0.55, 0);
    this.ambience(ctx, W, Hh, 'mid', -cam * pad * 0.55);
    ctx.drawImage(sn.hills as unknown as CanvasImageSource, -pad - cam * pad * 0.9, 0);

    const shx = (rand() - 0.5) * this.shake; const shy = (rand() - 0.5) * this.shake;
    const [ck, cx0, cy0] = this.camTf();
    ctx.setTransform(dpr * ck, 0, 0, dpr * ck, dpr * (cx0 + shx), dpr * (cy0 + shy));

    for (const b of this.balloons) {
      const col = b.kind === 'heart' ? '#ff5a5f' : '#ffc933';
      ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(b.x, b.y + 17); ctx.quadraticCurveTo(b.x + Math.sin(this.t * 3 + b.phase) * 5, b.y + 30, b.x, b.y + 42); ctx.stroke();
      ctx.fillStyle = col;
      ctx.beginPath(); ctx.ellipse(b.x, b.y, 14, 17, 0, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.moveTo(b.x - 3.5, b.y + 16); ctx.lineTo(b.x + 3.5, b.y + 16); ctx.lineTo(b.x, b.y + 21); ctx.closePath(); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.beginPath(); ctx.ellipse(b.x - 5, b.y - 7, 3, 5, -0.5, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#ffffff';
      ctx.font = `900 14px ${FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(b.kind === 'heart' ? '+' : '$', b.x + 1, b.y + 1);
    }

    // arrows & axes stuck (`nancep`) in a ground go down first, so the ground closes over the buried point/blade
    for (const a of this.arrows) if (a.stuckIn) { ctx.globalAlpha = clamp(5 - a.life, 0, 1); drawArrow(ctx, a.p, a.ang, 1, true, a.bow, this.rt, false); }
    for (const ax of this.axes) if (ax.stuckIn) { ctx.globalAlpha = clamp(6 - ax.life, 0, 1); drawAxe(ctx, ax.p, ax.ang, ax.s, true, ax.bossKind, this.rt); }
    ctx.globalAlpha = 1;
    // the floating grounds, each on its own cushion of light
    for (const p of [this.pPlat, ...this.plats]) {
      const x = p.x - p.w / 2;
      ctx.globalAlpha = (p.state === 'on' ? 1 : clamp(p.rise * 1.6, 0, 1)) * (0.75 + 0.25 * Math.sin(this.rt * 2.2 + p.phase));
      const g = ctx.createLinearGradient(0, p.y + p.h, 0, p.y + p.h + 38);
      g.addColorStop(0, th.glow); g.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = g; ctx.fillRect(x + 5, p.y + p.h, p.w - 10, 38);
      ctx.globalAlpha = p.state === 'on' ? 1 : clamp(p.rise * 1.6, 0, 1);
      ctx.fillStyle = th.plat; ctx.fillRect(x, p.y, p.w, p.h);
      ctx.fillStyle = th.platTop; ctx.fillRect(x, p.y, p.w, 3.5);
    }
    ctx.globalAlpha = 1;

    for (const f of this.foes) if (!f.k.alive) this.drawFighter(ctx, f);
    for (const f of this.foes) if (f.k.alive) this.drawFighter(ctx, f);
    this.drawHostage(ctx);
    this.drawFighter(ctx, this.player);
    for (const b of this.bows) drawBow(ctx, b.p, b.ang, b.s, null, 0, false, b.bow, this.rt);
    for (const ax of this.axes) {
      if (ax.stuckIn) continue;
      const wLabel = bossWeaponLabel(ax.bossKind);
      // Target reticle & callout around the Boss's thrown weapon so the player knows to shoot it out of the air!
      if (!ax.spent && !this.demo) {
        const pulse = 0.5 + 0.5 * Math.sin(this.rt * 18);
        ctx.save();
        ctx.strokeStyle = pulse > 0.5 ? '#ff4d4d' : '#ffd23f';
        ctx.lineWidth = 2.2;
        ctx.globalAlpha = 0.78;
        ctx.setLineDash([6, 5]);
        ctx.beginPath(); ctx.arc(ax.p.x, ax.p.y, 28 + pulse * 5, this.rt * 4, this.rt * 4 + Math.PI * 2); ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
        this.text(ctx, `PANAH ${wLabel}!`, ax.p.x, ax.p.y - 36, 12, '#ffe24a', 0.92);
      }
      // Spinning or javelin weapon with motion-trail ghosts
      for (const [back, al] of [[0.5, 0.18], [0.25, 0.32], [0, 1]]) {
        ctx.globalAlpha = ax.spent ? al * 0.7 : al;
        if (ax.bossKind === 'thunder_lord') {
          const pos = add(ax.p, mul(ax.vel, -0.025 * back));
          drawAxe(ctx, add(pos, fromAngle(ax.ang, -14 * ax.s)), ax.ang, ax.s, false, ax.bossKind, this.rt);
        } else {
          const an = ax.ang - ax.vr * 0.045 * back * 2;
          drawAxe(ctx, add(ax.p, fromAngle(an, -12 * ax.s)), an, ax.s, false, ax.bossKind, this.rt);
        }
      }
      ctx.globalAlpha = 1;
    }
    ctx.lineCap = 'round';
    for (const a of this.arrows) {
      if (a.stuckIn) continue;
      // Elemental ribbon behind every arrow in flight
      const tail = add(a.p, mul(a.vel, a.bow === 'thunder' || a.bow === 'fire' ? -0.068 : -0.048));
      const g = ctx.createLinearGradient(a.p.x, a.p.y, tail.x, tail.y);
      if (a.bow === 'thunder') {
        g.addColorStop(0, 'rgba(180, 255, 255, 0.98)'); g.addColorStop(0.5, 'rgba(0, 220, 255, 0.55)'); g.addColorStop(1, 'rgba(0, 120, 255, 0)');
        ctx.lineWidth = 4.5;
      } else if (a.bow === 'fire') {
        g.addColorStop(0, 'rgba(255, 240, 130, 0.95)'); g.addColorStop(0.45, 'rgba(255, 100, 15, 0.65)'); g.addColorStop(1, 'rgba(200, 20, 0, 0)');
        ctx.lineWidth = 5.2;
      } else if (a.bow === 'spike') {
        g.addColorStop(0, 'rgba(125, 255, 36, 0.85)'); g.addColorStop(1, 'rgba(40, 180, 30, 0)');
        ctx.lineWidth = 3.4;
      } else if (a.bow === 'poison') {
        g.addColorStop(0, 'rgba(230, 255, 80, 0.95)'); g.addColorStop(0.5, 'rgba(130, 255, 0, 0.68)'); g.addColorStop(1, 'rgba(30, 170, 0, 0)');
        ctx.lineWidth = 4.2;
      } else {
        g.addColorStop(0, 'rgba(255,255,255,0.45)'); g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.lineWidth = 2.6;
      }
      ctx.strokeStyle = g;
      ctx.beginPath(); ctx.moveTo(a.p.x, a.p.y); ctx.lineTo(tail.x, tail.y); ctx.stroke();
      drawArrow(ctx, a.p, a.ang, 1, false, a.bow, this.rt);
    }

    // Render simulation particles (smoke, Xenomorph acid globules & normal first, then additive fire/sparks/lightning)
    for (const p of this.parts) {
      const u = p.life / p.max;
      if (p.kind === 'ring') {
        ctx.globalAlpha = (1 - u) * 0.9; ctx.strokeStyle = p.col; ctx.lineWidth = 3.8 * (1 - u) + 0.5;
        ctx.beginPath(); ctx.arc(p.p.x, p.p.y, p.r * (0.25 + 0.75 * ease.out(u)), 0, Math.PI * 2); ctx.stroke();
        continue;
      }
      if (p.kind === 'smoke') {
        ctx.globalAlpha = (1 - u) * 0.38;
        const r = p.r * (0.65 + 1.05 * u);
        const sg = ctx.createRadialGradient(p.p.x, p.p.y, r * 0.1, p.p.x, p.p.y, r);
        sg.addColorStop(0, 'rgba(38, 28, 28, 0.85)');
        sg.addColorStop(0.6, 'rgba(28, 22, 22, 0.45)');
        sg.addColorStop(1, 'rgba(20, 16, 16, 0)');
        ctx.fillStyle = sg;
        ctx.beginPath(); ctx.arc(p.p.x, p.p.y, r, 0, Math.PI * 2); ctx.fill();
        continue;
      }
      if (p.kind === 'acidSmoke') {
        // Xenomorph corrosive greenish-white vapor plume
        ctx.globalAlpha = (1 - u) * 0.45;
        const r = p.r * (0.6 + 1.1 * u);
        const ag = ctx.createRadialGradient(p.p.x, p.p.y, r * 0.1, p.p.x, p.p.y, r);
        ag.addColorStop(0, 'rgba(215, 255, 140, 0.85)');
        ag.addColorStop(0.55, 'rgba(130, 230, 50, 0.42)');
        ag.addColorStop(1, 'rgba(40, 120, 10, 0)');
        ctx.fillStyle = ag;
        ctx.beginPath(); ctx.arc(p.p.x, p.p.y, r, 0, Math.PI * 2); ctx.fill();
        continue;
      }
      if (p.kind === 'acid') {
        // Xenomorph pressurized viscous molecular acid globule + sticky filament tail
        const al = clamp(1 - u, 0, 1);
        ctx.globalAlpha = al;
        const vx = p.vel.x; const vy = p.vel.y;
        const va = Math.atan2(vy, vx);
        const stretch = clamp(Math.hypot(vx, vy) / 140, 1, 2.5);
        if (p.prev) {
          const tail = add(p.p, mul(v(vx, vy), -0.032));
          ctx.strokeStyle = '#7bff00'; ctx.lineWidth = p.r * 1.1;
          ctx.beginPath(); ctx.moveTo(p.p.x, p.p.y); ctx.lineTo(tail.x, tail.y); ctx.stroke();
          ctx.strokeStyle = '#eaff66'; ctx.lineWidth = p.r * 0.45;
          ctx.beginPath(); ctx.moveTo(p.p.x, p.p.y); ctx.lineTo(tail.x, tail.y); ctx.stroke();
        }
        ctx.save();
        ctx.translate(p.p.x, p.p.y); ctx.rotate(va);
        ctx.fillStyle = '#2db300';
        ctx.beginPath(); ctx.ellipse(0, 0, p.r * stretch * 1.15, p.r * 1.05, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#a6ff00';
        ctx.beginPath(); ctx.ellipse(0, 0, p.r * stretch * 0.85, p.r * 0.78, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#f5ff99';
        ctx.beginPath(); ctx.ellipse(p.r * 0.2, -p.r * 0.15, p.r * stretch * 0.42, p.r * 0.35, 0, 0, Math.PI * 2); ctx.fill();
        ctx.restore();
        continue;
      }
      if (p.kind === 'acidBubble') {
        const al = clamp(1 - u, 0, 1);
        const br = p.r * (0.4 + 0.8 * ease.out(u));
        ctx.globalAlpha = al * 0.85;
        ctx.fillStyle = 'rgba(180, 255, 20, 0.35)';
        ctx.strokeStyle = '#eaff66'; ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.arc(p.p.x, p.p.y, br, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(p.p.x - br * 0.32, p.p.y - br * 0.32, br * 0.25, 0, Math.PI * 2); ctx.fill();
        continue;
      }
      if (p.kind === 'fire' || p.kind === 'spark' || p.kind === 'ember') continue; // drawn in additive pass below
      if (p.kind === 'thorn') {
        ctx.save();
        ctx.globalAlpha = clamp(1 - u, 0, 1);
        ctx.translate(p.p.x, p.p.y); ctx.rotate(p.rot ?? 0);
        ctx.fillStyle = p.col;
        ctx.beginPath(); ctx.moveTo(6, 0); ctx.lineTo(-4, -2.5); ctx.lineTo(-4, 2.5); ctx.closePath(); ctx.fill();
        ctx.restore();
        continue;
      }
      ctx.globalAlpha = clamp(1 - u, 0, 1) ** 0.6;
      ctx.fillStyle = p.col;
      ctx.beginPath();
      if (p.kind === 'helm') { ctx.arc(p.p.x, p.p.y, p.r, (p.rot ?? 0) - 1.75 - Math.PI / 2, (p.rot ?? 0) + 1.75 - Math.PI / 2); ctx.closePath(); }
      else ctx.arc(p.p.x, p.p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Additive simulation pass for Fluid-Simulation Flames (`drawSimFlame`), Magma Embers, Plasma Sparks, and Smooth Plasma Arcs
    ctx.save();
    ctx.globalCompositeOperation = 'lighter';
    for (const p of this.parts) {
      const u = p.life / p.max;
      if (p.kind === 'fire') {
        const temp = 1 - u;
        // Align flame tongue with its instantaneous physical velocity vector (which starts at impact angle and curves upward with buoyancy!)
        const fAng = Math.atan2(p.vel.y - 45, p.vel.x);
        const fLen = p.r * (1.55 + 0.85 * Math.sin(u * Math.PI));
        const fWid = p.r * (0.68 - u * 0.32);
        if (this.fireSpr && u < 0.65) {
          const gr = p.r * 1.8;
          ctx.globalAlpha = (1 - u) * 0.24;
          ctx.drawImage(this.fireSpr as unknown as CanvasImageSource, p.p.x - gr, p.p.y - gr, gr * 2, gr * 2);
        }
        ctx.globalAlpha = clamp((1 - u) * 0.95, 0, 1);
        drawSimFlame(ctx, p.p, fAng, Math.max(3.5, fLen), Math.max(1.4, fWid), temp, this.rt, p.seed ?? 0);
      } else if (p.kind === 'ember' || p.kind === 'spark') {
        ctx.globalAlpha = clamp(1 - u, 0, 1);
        ctx.strokeStyle = p.col;
        ctx.lineWidth = p.r * 1.25;
        const tail = p.prev ? add(p.p, mul(v(p.p.x - p.prev.x, p.p.y - p.prev.y), -2.8)) : p.p;
        ctx.beginPath(); ctx.moveTo(p.p.x, p.p.y); ctx.lineTo(tail.x, tail.y); ctx.stroke();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath(); ctx.arc(p.p.x, p.p.y, p.r * 0.65, 0, Math.PI * 2); ctx.fill();
      }
    }
    for (const arc of this.arcs) {
      const u = arc.life / arc.max;
      ctx.globalAlpha = clamp(1 - u, 0, 1);
      drawBolt(ctx, arc.a, arc.b, arc.spread, arc.segs, '#ffffff', arc.col, arc.lw * (1 - u * 0.35), false, arc.seed + this.rt * 16);
    }
    ctx.restore();
    ctx.globalAlpha = 1;

    for (const f of this.foes) {
      if (f.k.alive || f.deadT < 0.55) this.drawBar(ctx, f);
      // the boss winding up his signature weapon: a warning over his head
      if (!this.demo && f.kind === 'axer' && f.k.alive && f.ai.state !== 'wait') {
        this.text(ctx, `AWAS ${bossWeaponLabel(f.bossKind)}!`, f.k.p[0].x, f.k.p[0].y - 68 * f.k.s, 17 + 3.5 * Math.sin(this.rt * 22), '#ff5a4f', 1);
      }
    }
    if (this.player.k.alive) this.drawBar(ctx, this.player);

    for (const t of this.texts) {
      const u = t.life / t.max;
      this.text(ctx, t.text, t.x, t.y - ease.out(u) * 38, t.size * (1 + 0.5 * Math.max(0, 1 - u * 6)), t.col, clamp((1 - u) * 2.5, 0, 1));
    }

    // Image-1 style Parabolic Dotted Trajectory Arc:
    // Clean, evenly spaced circular white dots starting right from the arrow tip, curving to the apex and fading smoothly!
    const pk = this.player.k;
    if (this.showGuide && this.drag.on && pk.alive && onString(pk) && pk.pull > 0.06) {
      const ang = fireAngle(pk);
      const pullUsed = this.maxPower ? 1 : pk.pull;
      const sp = this.maxPower ? (430 + 800) * MAX_SPEED_MULT : speedOf(pullUsed, this.up.dmg);
      const o = add(pk.p[4], fromAngle(ang, 18 * pk.s));
      const vel = fromAngle(ang, sp);
      const N = 24;
      ctx.save();
      ctx.fillStyle = this.maxPower ? '#fff4b8' : '#ffffff';
      ctx.shadowColor = this.maxPower ? 'rgba(255, 200, 40, 0.85)' : 'rgba(255, 255, 255, 0.6)';
      ctx.shadowBlur = 4 * dpr;
      for (let i = 1; i <= N; i++) {
        const tt = i * 0.0175;
        const u = (i - 1) / (N - 1);
        const px = o.x + vel.x * tt;
        const py = o.y + vel.y * tt + 0.5 * AG * tt * tt;
        const rad = Math.max(1.2, (3.2 - u * 1.45) * pk.s);
        ctx.globalAlpha = Math.pow(1 - u, 1.25) * 0.94;
        ctx.beginPath();
        ctx.arc(px, py, rad, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
      ctx.globalAlpha = 1;
    }

    // back to the lens: big fireflies and the grass in front of everything
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    this.ambience(ctx, W, Hh, 'front', 0);
    if (this.xray) this.drawXray(ctx, W, Hh, shx, shy);

    // screen space (NO drag circle or '1.9x MAX!' ring UI from Image 2!)
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.drawCoins(ctx);
    const pf = this.player;
    const lowHp = !this.demo && pf.k.alive && pf.hp < pf.maxHp * 0.3 ? 0.16 + 0.12 * Math.sin(this.rt * 7) : 0;
    const red = Math.max(this.hurt * 0.5, lowHp);
    if (red > 0.01) {
      const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.7);
      g.addColorStop(0, 'rgba(255,0,0,0)'); g.addColorStop(1, `rgba(255,20,30,${red})`);
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
    }
    const title = this.demo ? '' : this.stage === 'clear' ? 'LEVEL SELESAI!' : this.banner > 0 ? this.bannerText : '';
    if (title) {
      const clear = this.stage === 'clear';
      const al = clear ? clamp(this.clearT * 3, 0, 1) : clamp(this.banner * 2, 0, 1) * clamp((2.4 - this.banner) * 5, 0, 1);
      const pop = clear ? 1 + 0.25 * Math.max(0, 1 - this.clearT * 4) : 1 + 0.3 * Math.max(0, 1 - (2.4 - this.banner) * 5);
      const size = clamp(w * 0.075, 30, 66) * pop;
      // a dark band behind the words, like a title card
      ctx.globalAlpha = al * 0.38; ctx.fillStyle = '#00141f';
      ctx.fillRect(0, h * 0.36 - size * 0.75, w, size * 2.05);
      ctx.globalAlpha = 1;
      this.text(ctx, title, w / 2, h * 0.36, size, clear ? '#ffd23f' : '#ffffff', al);
      this.text(ctx, clear ? `+${10 + 2 * this.level} KOIN` : this.bannerSub, w / 2, h * 0.36 + size * 0.85, clamp(size * 0.3, 13, 20), '#dffcff', al);
    }
  }
}

/** binds a RagWorld to a real canvas: sizing, the frame loop and pointer input */
export class RagdollGame {
  world: RagWorld;
  private ctx: Ctx;
  private raf = 0;
  private prev = 0;

  constructor(private canvas: HTMLCanvasElement, emit: (ui: RUi) => void) {
    this.ctx = canvas.getContext('2d') as Ctx;
    this.world = new RagWorld(emit, (w, h) => {
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      return c;
    });
    this.fit();
    ambStart();
    window.addEventListener('resize', this.fit);
    canvas.addEventListener('pointerdown', this.down);
    canvas.addEventListener('pointermove', this.move);
    canvas.addEventListener('pointerup', this.up);
    canvas.addEventListener('pointercancel', this.cancel);
    this.raf = requestAnimationFrame(this.loop);
  }

  private fit = () => {
    const r = this.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(200, r.width); const h = Math.max(200, r.height);
    this.canvas.width = Math.round(w * dpr); this.canvas.height = Math.round(h * dpr);
    this.world.resize(w, h, dpr);
  };
  private pos(e: PointerEvent): [number, number] {
    const r = this.canvas.getBoundingClientRect();
    return [e.clientX - r.left, e.clientY - r.top];
  }
  private down = (e: PointerEvent) => {
    try { this.canvas.setPointerCapture(e.pointerId); } catch { /* fine without capture */ }
    this.world.pointerDown(...this.pos(e));
  };
  private move = (e: PointerEvent) => this.world.pointerMove(...this.pos(e));
  private up = () => this.world.pointerUp();
  private cancel = () => this.world.pointerCancel();
  private loop = (now: number) => {
    const dt = this.prev ? (now - this.prev) / 1000 : 0.016;
    this.prev = now;
    this.world.update(dt);
    this.world.render(this.ctx);
    this.raf = requestAnimationFrame(this.loop);
  };

  destroy() {
    cancelAnimationFrame(this.raf);
    ambStop();
    window.removeEventListener('resize', this.fit);
    this.canvas.removeEventListener('pointerdown', this.down);
    this.canvas.removeEventListener('pointermove', this.move);
    this.canvas.removeEventListener('pointerup', this.up);
    this.canvas.removeEventListener('pointercancel', this.cancel);
  }
}
