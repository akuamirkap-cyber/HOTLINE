import * as THREE from 'three';
import { Terrain } from './terrain';
import { angleDiff, clamp, clamp01, damp, keyLerp, lerp, wrapAngle } from './math';

export const STATES = [
  'IDLE',
  'WALK',
  'JOG',
  'RUN',
  'SPRINT',
  'STOP',
  'RECOVERY',
  'TURN_LEFT',
  'TURN_RIGHT',
  'CROUCH_IDLE',
  'CROUCH_WALK',
  'CROUCH_TURN',
  'JUMP_START',
  'JUMP_AIR',
  'JUMP_LAND',
] as const;
export type LocoState = (typeof STATES)[number];

export const SPEED = { walk: 1.5, jog: 3.2, run: 4.8, sprint: 7.9, crouch: 1.35 };
export const PACE_NAMES = ['WALK', 'JOG', 'RUN'] as const;
const PACE_SPEED = [SPEED.walk, SPEED.jog, SPEED.run];

const GRAVITY = 21;
const JUMP_V = 6.9;

export interface Intent {
  moveX: number; // +right (screen space)
  moveY: number; // +forward
  sprint: boolean;
  jumpPressed: boolean;
  jumpHeld: boolean;
  crouchToggle: boolean;
  strafe: boolean;
  pace: number; // 0 walk, 1 jog, 2 run
  /** Keep the body facing the camera even while sprinting (first-person / weapon aim). */
  lockFacing?: boolean;
  /** Optional speed limit (aiming down sights). */
  speedCap?: number;
}

/**
 * Physics / intent layer. Owns velocity, facing and the locomotion state machine.
 * Nothing here is instantaneous: speed, heading and facing all have their own
 * acceleration limits which change with how fast the character is travelling.
 */
export class CharacterController {
  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  /** Smoothed world-space horizontal acceleration (drives procedural lean). */
  accel = new THREE.Vector3();
  yaw = 0;
  yawRate = 0;
  heading = 0;
  speed = 0;

  grounded = true;
  crouching = false;
  sprinting = false;
  strafing = false;
  hasInput = false;
  inputMag = 0;
  moveYaw = 0;
  pivoting = false;
  pivotDir = 0;

  jumpPrep = false;
  jumpPrepT = 0;
  jumpPrepDur = 0.16;
  airTime = 0;
  landTimer = 0;
  landIntensity = 0;
  recoveryTimer = 0;
  justLanded = false;
  justJumped = false;
  heightAboveGround = 0;
  stopping = false;

  state: LocoState = 'IDLE';
  weights: Record<LocoState, number>;

  private jumpBuffer = 0;
  private coyote = 0;
  private accelLong = 0;
  private takeoffSpeed = 0;
  private peakSpeed = 0;
  private prevVx = 0;
  private prevVz = 0;

  constructor() {
    this.weights = {} as Record<LocoState, number>;
    for (const s of STATES) this.weights[s] = s === 'IDLE' ? 1 : 0;
  }

  reset(x: number, z: number, terrain: Terrain) {
    this.pos.set(x, terrain.height(x, z), z);
    this.vel.set(0, 0, 0);
    this.accel.set(0, 0, 0);
    this.yaw = this.heading = this.yawRate = 0;
    this.grounded = true;
    this.crouching = false;
    this.jumpPrep = false;
    this.accelLong = 0;
  }

  private launch() {
    this.vel.y = JUMP_V;
    this.grounded = false;
    this.jumpPrep = false;
    this.justJumped = true;
    this.airTime = 0;
    this.coyote = 0;
    this.takeoffSpeed = Math.hypot(this.vel.x, this.vel.z);
  }

  update(dt: number, inp: Intent, camYaw: number, terrain: Terrain) {
    this.justLanded = false;
    this.justJumped = false;
    const pos = this.pos;
    const vel = this.vel;

    // ---------------------------------------------------------------- intent
    const mag = Math.min(1, Math.hypot(inp.moveX, inp.moveY));
    this.hasInput = mag > 0.08;
    this.inputMag = this.hasInput ? mag : 0;
    const fx = Math.sin(camYaw);
    const fz = Math.cos(camYaw);
    let dx = fx * inp.moveY - fz * inp.moveX;
    let dz = fz * inp.moveY + fx * inp.moveX;
    const dl = Math.hypot(dx, dz) || 1;
    dx /= dl;
    dz /= dl;
    if (this.hasInput) this.moveYaw = Math.atan2(dx, dz);

    if (inp.crouchToggle && this.grounded && !this.jumpPrep) this.crouching = !this.crouching;
    const wantSprint = inp.sprint && this.hasInput;
    if (wantSprint && this.crouching) this.crouching = false;
    this.sprinting = wantSprint;
    this.strafing = (inp.strafe && !this.sprinting) || !!inp.lockFacing;

    // ------------------------------------------------------------------ jump
    if (inp.jumpPressed) this.jumpBuffer = 0.15;
    else this.jumpBuffer -= dt;
    if (this.grounded) this.coyote = 0.1;
    else this.coyote -= dt;
    if (this.jumpBuffer > 0 && !this.jumpPrep && (this.grounded || this.coyote > 0) && this.landTimer < 0.1) {
      this.jumpBuffer = 0;
      this.crouching = false;
      if (this.grounded) {
        // anticipation: long from standstill, short at speed (stays responsive)
        this.jumpPrep = true;
        this.jumpPrepT = 0;
        this.jumpPrepDur = lerp(0.17, 0.085, clamp01(this.speed / 5));
      } else {
        this.launch();
      }
    }
    if (this.jumpPrep) {
      this.jumpPrepT += dt;
      if (!this.grounded) this.jumpPrep = false;
      else if (this.jumpPrepT >= this.jumpPrepDur) this.launch();
    }

    // ---------------------------------------------------------- target speed
    let maxSpeed = this.sprinting ? SPEED.sprint : PACE_SPEED[clamp(inp.pace | 0, 0, 2)];
    if (this.crouching) maxSpeed = SPEED.crouch;
    let target = this.hasInput ? maxSpeed * (mag < 0.95 ? Math.max(mag, 0.3) : 1) : 0;
    if (inp.speedCap !== undefined) target = Math.min(target, inp.speedCap);
    if (this.landTimer > 0) target *= lerp(1, 0.4, this.landIntensity);
    const speed = Math.hypot(vel.x, vel.z);
    if (this.jumpPrep) target = Math.min(target, speed);

    let yawTarget = this.yaw;
    let yawMax = 8.5;

    if (this.grounded) {
      if (this.strafing) {
        // -------------------------------------------- strafe: face the camera
        this.pivoting = false;
        const rel = this.hasInput ? angleDiff(this.moveYaw, this.yaw) : 0;
        const c = Math.cos(rel);
        const dirF = c > 0 ? lerp(0.8, 1, c) : lerp(0.8, 0.62, -c);
        const cap =
          Math.min(target, this.crouching ? SPEED.crouch : this.sprinting ? SPEED.sprint : SPEED.run * 0.92) * dirF;
        const tvx = this.hasInput ? dx * cap : 0;
        const tvz = this.hasInput ? dz * cap : 0;
        const ex = tvx - vel.x;
        const ez = tvz - vel.z;
        const el = Math.hypot(ex, ez);
        if (el > 1e-5) {
          const step = Math.min(el, Math.min(11, el * 9 + 0.5) * dt);
          vel.x += (ex / el) * step;
          vel.z += (ez / el) * step;
        }
        const ns = Math.hypot(vel.x, vel.z);
        this.heading = ns > 0.3 ? Math.atan2(vel.x, vel.z) : this.yaw;
        this.accelLong = 0;
        yawTarget = camYaw;
        yawMax = this.crouching ? 6 : 8;
      } else {
        // ------------------------------------ free: face the travel direction
        let hd = speed > 0.35 ? Math.atan2(vel.x, vel.z) : this.heading;
        const diff = this.hasInput ? angleDiff(this.moveYaw, hd) : 0;

        // hard reversal at speed → plant & pivot instead of orbiting
        if (!this.pivoting && this.hasInput && speed > 2.6 && Math.abs(diff) > 2.15) {
          this.pivoting = true;
          this.pivotDir = diff >= 0 ? 1 : -1;
        }
        if (this.pivoting && (!this.hasInput || speed < 1.1 || Math.abs(diff) < 1.5)) this.pivoting = false;

        let wanted: number;
        if (this.pivoting) {
          wanted = -(15 + speed * 1.2);
        } else {
          if (this.hasInput) {
            if (speed < 0.45) {
              hd = this.moveYaw;
            } else {
              // travel direction can only bend so fast — tighter when slow, wide arcs at sprint
              const turnRate =
                keyLerp([0, 1.5, 3.2, 4.8, 7.9], [16, 11, 7.5, 5.6, 3.4], speed) * (this.crouching ? 0.8 : 1);
              hd += clamp(diff, -turnRate * dt, turnRate * dt);
            }
          }
          const turnSlow = this.hasInput ? lerp(1, 0.72, clamp01((Math.abs(diff) - 0.3) / 1.4)) : 1;
          // from standstill the body has to rotate toward the goal before it can push off
          const align = Math.cos(angleDiff(this.moveYaw, this.yaw));
          const accelMax =
            lerp(8.5, 4.2, clamp01(speed / SPEED.sprint)) *
            (this.hasInput && speed < 1.5 ? clamp((align + 0.25) / 0.9, 0.1, 1) : 1);
          const decelMax = this.hasInput ? 7.5 : lerp(6.5, 11, clamp01(speed / SPEED.sprint));
          wanted = clamp((target * turnSlow - speed) * 7, -decelMax, accelMax);
        }
        // jerk-limited: acceleration itself eases in and out
        this.accelLong = damp(this.accelLong, wanted, this.pivoting ? 20 : 14, dt);
        let ns = Math.max(0, speed + this.accelLong * dt);
        if (!this.hasInput && ns < 0.06) {
          ns = 0;
          this.accelLong = 0;
        }
        this.heading = hd;
        vel.x = Math.sin(hd) * ns;
        vel.z = Math.cos(hd) * ns;

        if (this.pivoting) yawTarget = ns < 2.4 ? this.moveYaw : this.yaw;
        else if (ns > 0.6) yawTarget = hd;
        else if (this.hasInput) yawTarget = this.moveYaw;
        yawMax = keyLerp([0, 1.5, 4.8, 7.9], [6.5, 7.5, 7.5, 6.8], ns) * (this.crouching ? 0.75 : 1);
      }
    } else {
      // ------------------------------------------------------------ airborne
      this.airTime += dt;
      this.pivoting = false;
      if (this.hasInput) {
        const cap = Math.max(this.takeoffSpeed, 2.6) * mag;
        const ex = dx * cap - vel.x;
        const ez = dz * cap - vel.z;
        const el = Math.hypot(ex, ez);
        if (el > 1e-5) {
          const step = Math.min(el, 6.5 * dt);
          vel.x += (ex / el) * step;
          vel.z += (ez / el) * step;
        }
      } else {
        const k = Math.exp(-0.25 * dt);
        vel.x *= k;
        vel.z *= k;
      }
      // variable height: releasing early shortens the arc, but a tap still gives a committed jump
      const cut = !inp.jumpHeld && this.airTime > 0.12;
      const g = GRAVITY * (vel.y > 0 ? (cut ? 1.6 : 1) : 1.12);
      vel.y = Math.max(vel.y - g * dt, -32);
      yawTarget = this.strafing ? camYaw : this.hasInput ? this.moveYaw : this.yaw;
      yawMax = 4;
    }

    // facing: rate-limited and eased so rotation has anticipation, never a snap
    const yawErr = angleDiff(yawTarget, this.yaw);
    const wantRate = clamp(yawErr * 10, -yawMax, yawMax);
    this.yawRate = damp(this.yawRate, wantRate, 16, dt);
    this.yaw = wrapAngle(this.yaw + this.yawRate * dt);

    // ------------------------------------------------------ integrate + walls
    const stepMax = this.grounded ? 0.34 : 0.22;
    const nx = pos.x + vel.x * dt;
    const nz = pos.z + vel.z * dt;
    const blocked = (x: number, z: number) => terrain.solid(x, z) || terrain.height(x, z) - pos.y > stepMax;
    if (!blocked(nx, nz)) {
      pos.x = nx;
      pos.z = nz;
    } else if (!blocked(nx, pos.z)) {
      pos.x = nx;
      vel.z = 0;
    } else if (!blocked(pos.x, nz)) {
      pos.z = nz;
      vel.x = 0;
    } else {
      vel.x = 0;
      vel.z = 0;
    }

    const gh = terrain.height(pos.x, pos.z);
    if (this.grounded) {
      if (pos.y - gh > 0.4) {
        // walked off a ledge
        this.grounded = false;
        this.airTime = 0;
        this.takeoffSpeed = Math.hypot(vel.x, vel.z);
        vel.y = 0;
      } else {
        pos.y = gh;
        vel.y = 0;
      }
    } else {
      pos.y += vel.y * dt;
      if (pos.y <= gh) {
        if (vel.y <= 0) {
          this.landIntensity = clamp01((-vel.y - 3) / 11);
          pos.y = gh;
          vel.y = 0;
          this.grounded = true;
          this.justLanded = true;
          this.landTimer = 0.14 + 0.34 * this.landIntensity;
          const keep = 1 - 0.4 * this.landIntensity * this.landIntensity;
          vel.x *= keep;
          vel.z *= keep;
          if (this.landIntensity > 0.5) this.recoveryTimer = 0.4;
        } else {
          pos.y = gh;
        }
      }
    }
    this.heightAboveGround = Math.max(0, pos.y - gh);

    // ------------------------------------------------------------ bookkeeping
    this.speed = Math.hypot(vel.x, vel.z);
    const ax = clamp((vel.x - this.prevVx) / Math.max(dt, 1e-4), -26, 26);
    const az = clamp((vel.z - this.prevVz) / Math.max(dt, 1e-4), -26, 26);
    this.accel.x = damp(this.accel.x, ax, 10, dt);
    this.accel.z = damp(this.accel.z, az, 10, dt);
    this.prevVx = vel.x;
    this.prevVz = vel.z;

    if (this.landTimer > 0) this.landTimer -= dt;
    else if (this.recoveryTimer > 0) this.recoveryTimer -= dt;

    if (this.hasInput) this.peakSpeed = this.speed;
    const wasStopping = this.stopping;
    this.stopping = this.grounded && !this.hasInput && this.speed > 0.25;
    if (wasStopping && !this.stopping && this.grounded && this.peakSpeed > 3.4) this.recoveryTimer = 0.45;

    this.state = this.resolveState();
    for (const s of STATES) this.weights[s] = damp(this.weights[s], s === this.state ? 1 : 0, 11, dt);
  }

  /** Transition conditions of the locomotion state machine. */
  private resolveState(): LocoState {
    if (!this.grounded) return 'JUMP_AIR';
    if (this.jumpPrep) return 'JUMP_START';
    if (this.landTimer > 0) return 'JUMP_LAND';
    const sp = this.speed;
    const turnErr = this.hasInput && !this.strafing ? angleDiff(this.moveYaw, this.yaw) : 0;
    const turning = Math.abs(turnErr) > 0.6 || Math.abs(this.yawRate) > 1.6;
    const turnSign = Math.abs(turnErr) > 0.6 ? turnErr : this.yawRate;
    if (this.crouching) {
      if (turning && sp < 0.9) return 'CROUCH_TURN';
      return sp > 0.25 ? 'CROUCH_WALK' : 'CROUCH_IDLE';
    }
    if (this.pivoting) return this.pivotDir > 0 ? 'TURN_LEFT' : 'TURN_RIGHT';
    if (turning && (sp < 0.9 || Math.abs(turnErr) > 0.75)) return turnSign > 0 ? 'TURN_LEFT' : 'TURN_RIGHT';
    if (sp < 0.25) return this.recoveryTimer > 0 ? 'RECOVERY' : 'IDLE';
    if (this.stopping) return 'STOP';
    if (sp < 2.3) return 'WALK';
    if (sp < 4.0) return 'JOG';
    if (sp < 6.0) return 'RUN';
    return 'SPRINT';
  }
}
