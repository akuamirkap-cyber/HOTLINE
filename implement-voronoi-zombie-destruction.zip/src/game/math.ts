export const TAU = Math.PI * 2;

export const clamp = (x: number, a: number, b: number) => (x < a ? a : x > b ? b : x);
export const clamp01 = (x: number) => (x < 0 ? 0 : x > 1 ? 1 : x);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smooth = (t: number) => {
  t = clamp01(t);
  return t * t * (3 - 2 * t);
};
export const smoothstep = (a: number, b: number, x: number) => smooth((x - a) / (b - a));

/** Frame-rate independent exponential approach. */
export const damp = (a: number, b: number, lambda: number, dt: number) =>
  a + (b - a) * (1 - Math.exp(-lambda * dt));

export const wrapAngle = (a: number) => {
  a = (a + Math.PI) % TAU;
  if (a < 0) a += TAU;
  return a - Math.PI;
};
/** Shortest signed difference `to - from`. */
export const angleDiff = (to: number, from: number) => wrapAngle(to - from);
export const lerpAngle = (a: number, b: number, t: number) => a + angleDiff(b, a) * t;
export const dampAngle = (a: number, b: number, lambda: number, dt: number) =>
  a + angleDiff(b, a) * (1 - Math.exp(-lambda * dt));

export const frac = (x: number) => x - Math.floor(x);

/** Piecewise-linear lookup — the 1D blend tree primitive. */
export function keyLerp(keys: number[], vals: number[], x: number): number {
  const n = keys.length;
  if (x <= keys[0]) return vals[0];
  if (x >= keys[n - 1]) return vals[n - 1];
  for (let i = 1; i < n; i++) {
    if (x <= keys[i]) {
      const t = (x - keys[i - 1]) / (keys[i] - keys[i - 1]);
      return vals[i - 1] + (vals[i] - vals[i - 1]) * t;
    }
  }
  return vals[n - 1];
}

/**
 * Unconditionally stable damped spring (implicit integration).
 * omega = angular frequency (stiffness), zeta = damping ratio (<1 overshoots).
 */
export class Spring {
  x: number;
  v = 0;
  omega: number;
  zeta: number;
  constructor(omega = 10, zeta = 1, x0 = 0) {
    this.omega = omega;
    this.zeta = zeta;
    this.x = x0;
  }
  update(target: number, dt: number): number {
    const w = this.omega;
    const f = 1 + 2 * dt * this.zeta * w;
    const hoo = dt * w * w;
    const hhoo = dt * hoo;
    const detInv = 1 / (f + hhoo);
    const detX = f * this.x + dt * this.v + hhoo * target;
    const detV = this.v + hoo * (target - this.x);
    this.x = detX * detInv;
    this.v = detV * detInv;
    return this.x;
  }
  reset(x: number) {
    this.x = x;
    this.v = 0;
  }
}
