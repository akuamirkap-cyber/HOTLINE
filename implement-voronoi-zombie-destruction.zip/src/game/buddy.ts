import * as THREE from 'three';
import { CharacterController, type Intent } from './controller';
import { Rig } from './rig';
import { Animator, type FootStep } from './animator';
import { Arsenal, type ArsenalInput } from './weapons';
import { buildThirdPersonWeapons } from './fpsWeapons';
import type { Terrain } from './terrain';
import type { Range } from './targets';
import type { Foley } from './audio';
import type { Horde, Zombie } from './zombie/zombies';
import { P } from './zombie/skeleton';
import { angleDiff, clamp, wrapAngle } from './math';

/* ---------------------------------------------------------------------------
 * AI TEAMMATE ("BRAVO")
 * A second fully simulated operator: same character controller, procedural
 * locomotion, IK-held weapons and hitscan ballistics as the player — so every
 * round it fires produces the same knockback, Voronoi damage and blood.
 * Brain: threat-prioritised targeting with line of sight, human reaction time,
 * an aim error that converges fast (skilled, not robotic), headshots at range,
 * controlled rifle bursts, sniper for long shots, tactical reloads, callouts,
 * and it never fires through the player.
 * ------------------------------------------------------------------------- */
export type BuddyState = 'FOLLOW' | 'ENGAGE' | 'RELOAD' | 'SWITCH' | 'REGROUP';

export interface BuddyPlayer {
  pos: THREE.Vector3;
  yaw: number;
  alive: boolean;
}

const r = Math.random;
const pick = <T>(a: T[]) => a[(r() * a.length) | 0];
const KILL_LINES = ['Tango down!', 'Got one!', 'Target neutralized.', 'Scratch one.', 'He is down!'];
const HEAD_LINES = ['Headshot!', 'Right between the eyes.', 'Boom — headshot!', 'Clean headshot.'];

/** Olive/desert kit so the teammate never reads as the player. */
const RECOLOR: [string, string][] = [
  ['#c5531c', '#4b6136'],
  ['#8c3913', '#2f3f24'],
  ['#27313f', '#4a463b'],
  ['#2a8f8d', '#b38b3d'],
  ['#59634f', '#6d5c40'],
  ['#a9b3bd', '#a59b7d'],
];

export class Buddy {
  readonly name = 'BRAVO';
  ctrl = new CharacterController();
  rig = new Rig();
  anim: Animator;
  arsenal: Arsenal;
  state: BuddyState = 'FOLLOW';
  target: Zombie | null = null;
  kills = 0;
  headshots = 0;
  callout = '';
  calloutAge = 9;
  aimYaw = 0;
  aimPitch = -0.1;
  onStep: (s: FootStep) => void = () => {};
  private terrain: Terrain;
  private horde: Horde;
  private cam = new THREE.PerspectiveCamera(50, 1, 0.05, 400);
  private inp: ArsenalInput = { fire: false, firePressed: false, aim: false, reloadPressed: false, slot: 1 };
  private intent: Intent = { moveX: 0, moveY: 0, sprint: false, jumpPressed: false, jumpHeld: false, crouchToggle: false, strafe: false, pace: 2, lockFacing: false };
  private time = 0;
  private scanT = 0;
  private reactT = 0;
  private burstLeft = 0;
  private pauseT = 0;
  private errYaw = 0;
  private errPitch = 0;
  private yawVel = 0;
  private pitchVel = 0;
  private side = 1;
  private stuckT = 0;
  private lastGoalD = 0;
  private lastShots = 0;
  private lastKills = 0;
  private lastHeads = 0;
  private noTargetT = 0;
  private sayT = 0;
  private sixT = 0;
  private wasReloading = false;
  private blockT = 0;
  /** most dangerous zombie when none is in line of sight (move to the railing above it) */
  private hidden: Zombie | null = null;
  private prevYawD = 0;
  private prevPitchD = 0;
  private trackT = 0;
  private lastKillT = -9;
  private eye = new THREE.Vector3();
  private aimPt = new THREE.Vector3();
  private v = new THREE.Vector3();
  private w = new THREE.Vector3();

  constructor(scene: THREE.Scene, terrain: Terrain, range: Range, foley: Foley, horde: Horde, x: number, z: number) {
    this.terrain = terrain;
    this.horde = horde;
    const from = RECOLOR.map(([a, b]) => [new THREE.Color(a), new THREE.Color(b)] as const);
    this.rig.root.traverse((o) => {
      const m = (o as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined;
      if (!m || !(m as THREE.MeshStandardMaterial).color) return;
      for (const [a, b] of from) {
        const c = m.color;
        if (Math.abs(c.r - a.r) + Math.abs(c.g - a.g) + Math.abs(c.b - a.b) < 0.02) {
          c.copy(b);
          break;
        }
      }
    });
    scene.add(this.rig.root);
    this.ctrl.reset(x, z, terrain);
    this.anim = new Animator(this.rig);
    this.anim.reset(this.ctrl, terrain);
    this.anim.update(1 / 60, this.ctrl, terrain, 0, 0, 0);
    this.anim.steps.length = 0;
    // its own weapon models (the player's are shared singletons), no extra light, own gun sound
    const quiet = Object.create(foley) as Foley;
    quiet.click = () => {};
    this.arsenal = new Arsenal(scene, this.rig, terrain, range, quiet, { tp: buildThirdPersonWeapons(), light: false, npc: true });
    this.arsenal.zombies = horde;
    this.aimYaw = this.ctrl.yaw;
  }

  reset(x: number, z: number) {
    this.ctrl.reset(x, z, this.terrain);
    this.anim.reset(this.ctrl, this.terrain);
    this.target = null;
    this.state = 'FOLLOW';
    this.kills = this.headshots = 0;
    this.lastKills = this.arsenal.kills;
    this.lastHeads = this.arsenal.heads;
  }

  private say(line: string, force = false) {
    if (!force && this.sayT > 0) return;
    this.callout = line;
    this.calloutAge = 0;
    this.sayT = 2.2;
  }

  /** Aim point on a zombie: head centre when it's upright (skilled shooters go for the head), chest otherwise. */
  private aimPoint(z: Zombie, head: boolean, out: THREE.Vector3) {
    const X = z.pts;
    if (head && !z.severed.has('head')) {
      return out.set(
        X[P.NECK2 * 3] * 0.45 + X[P.HEAD * 3] * 0.55,
        X[P.NECK2 * 3 + 1] * 0.45 + X[P.HEAD * 3 + 1] * 0.55,
        X[P.NECK2 * 3 + 2] * 0.45 + X[P.HEAD * 3 + 2] * 0.55,
      );
    }
    return out.set(
      X[P.SPINE * 3] * 0.4 + X[P.CHEST * 3] * 0.6,
      X[P.SPINE * 3 + 1] * 0.4 + X[P.CHEST * 3 + 1] * 0.6,
      X[P.SPINE * 3 + 2] * 0.4 + X[P.CHEST * 3 + 2] * 0.6,
    );
  }

  private visible(z: Zombie) {
    const p = this.aimPoint(z, false, this.w);
    const dx = p.x - this.eye.x;
    const dy = p.y - this.eye.y;
    const dz = p.z - this.eye.z;
    const d = Math.hypot(dx, dy, dz) || 1;
    return this.terrain.raycast(this.eye.x, this.eye.y, this.eye.z, dx / d, dy / d, dz / d, 0.3, d) >= d - 0.35;
  }

  /** Threat assessment: closeness to the player matters most, then behaviour, speed and distance. */
  private pickTarget(pp: THREE.Vector3) {
    const c = this.ctrl.pos;
    const cands: [number, Zombie][] = [];
    for (const z of this.horde.zombies) {
      if (!z.active || !z.alive) continue;
      const d = Math.hypot(z.pos.x - c.x, z.pos.z - c.z);
      if (d > 62) continue;
      const dp = Math.hypot(z.pos.x - pp.x, z.pos.z - pp.z);
      let s = -d * 0.55 - dp * 1.1;
      if (z.beh === 'ATTACKING') s += 20;
      else if (z.beh === 'APPROACHING') s += 11;
      else if (z.beh === 'CHASING') s += 6;
      if (z.kind === 'runner') s += 5;
      if (!z.upright && z.body !== 'CRAWLING') s -= 9; // downed: finish later
      if (z === this.target) s += 7; // don't flick between targets
      cands.push([s, z]);
    }
    cands.sort((a, b) => b[0] - a[0]);
    let best: Zombie | null = null;
    let bestS = -Infinity;
    let curS = -Infinity;
    for (const [sc, z] of cands) if (z === this.target) curS = sc;
    // threats right under the roof edge are hidden: look further down the list for a clear shot
    for (let i = 0; i < Math.min(22, cands.length); i++) {
      if (this.visible(cands[i][1])) {
        best = cands[i][1];
        bestS = cands[i][0];
        break;
      }
    }
    // stay on the current target unless something clearly more dangerous shows up
    const cur = this.target;
    if (cur && cur.active && cur.alive && curS > -Infinity && best !== cur && bestS < curS + 10 && this.visible(cur)) best = cur;
    this.hidden = best ? null : cands.length ? cands[0][1] : null;
    if (best !== this.target) {
      this.target = best;
      if (best) {
        // human reaction + an initial aim error the shooter corrects quickly (faster right after a kill)
        const chain = this.time - this.lastKillT < 1.5;
        this.reactT = chain ? 0.05 + r() * 0.07 : 0.12 + r() * 0.13;
        this.errYaw = (r() - 0.5) * (chain ? 0.05 : 0.1);
        this.errPitch = (r() - 0.5) * (chain ? 0.03 : 0.06);
        this.burstLeft = 0;
        this.trackT = 0;
      }
    }
  }

  update(dt: number, pl: BuddyPlayer, engaged: boolean) {
    const c = this.ctrl;
    const T = this.terrain;
    const A = this.arsenal;
    this.time += dt;
    this.calloutAge += dt;
    this.sayT -= dt;
    this.sixT -= dt;
    this.eye.set(c.pos.x, c.pos.y + 1.56, c.pos.z);
    this.inp.fire = false;
    this.inp.firePressed = false;
    this.inp.reloadPressed = false;

    // ---------------------------------------------------------------- brain
    if (engaged) {
      this.scanT -= dt;
      if (this.scanT <= 0) {
        this.scanT = 0.18 + r() * 0.1;
        this.pickTarget(pl.pos);
      }
    }
    let t = this.target;
    if (t && (!t.active || !t.alive)) t = this.target = null;
    const fyaw = pl.yaw;
    const fx = Math.sin(fyaw);
    const fz = Math.cos(fyaw);

    let dist = 99;
    let head = false;
    if (t && engaged) {
      this.noTargetT = 0;
      dist = Math.hypot(t.pos.x - c.pos.x, t.pos.z - c.pos.z);
      head = t.upright && dist > 6 && !t.severed.has('head');
      this.aimPoint(t, head, this.aimPt);
      const dx = this.aimPt.x - this.eye.x;
      const dy = this.aimPt.y - this.eye.y;
      const dz = this.aimPt.z - this.eye.z;
      const yawD = Math.atan2(dx, dz);
      const pitchD = Math.atan2(dy, Math.hypot(dx, dz));
      // aim error decays fast (trained shooter), tiny breathing sway
      const k = Math.exp(-7.5 * dt);
      this.errYaw *= k;
      this.errPitch *= k;
      const sway = 0.0022;
      const wantY = yawD + this.errYaw + Math.sin(this.time * 1.9) * sway;
      const wantP = pitchD + this.errPitch + Math.sin(this.time * 1.3 + 1) * sway;
      // critically damped flick-and-settle with feed-forward of the target's angular velocity (no tracking lag)
      let ffY = 0;
      let ffP = 0;
      if (this.trackT > 0 && dt > 0) {
        ffY = clamp(angleDiff(yawD, this.prevYawD) / dt, -6, 6);
        ffP = clamp((pitchD - this.prevPitchD) / dt, -6, 6);
      }
      this.prevYawD = yawD;
      this.prevPitchD = pitchD;
      this.trackT += dt;
      this.yawVel += (angleDiff(wantY, this.aimYaw) * 170 - (this.yawVel - ffY) * 26) * dt;
      this.pitchVel += ((wantP - this.aimPitch) * 170 - (this.pitchVel - ffP) * 26) * dt;
      this.aimYaw = wrapAngle(this.aimYaw + this.yawVel * dt);
      this.aimPitch = clamp(this.aimPitch + this.pitchVel * dt, -1.2, 1.2);
      const err = Math.hypot(angleDiff(yawD, this.aimYaw), pitchD - this.aimPitch);
      const tol = Math.max(0.005, ((head ? 0.095 : 0.16) / Math.max(dist, 1.5)) * 0.9);

      // weapon choice: sniper for long, quiet shots; rifle when they get close
      let near = 99;
      for (const z of this.horde.zombies) {
        if (!z.active || !z.alive) continue;
        near = Math.min(near, Math.hypot(z.pos.x - c.pos.x, z.pos.z - c.pos.z), Math.hypot(z.pos.x - pl.pos.x, z.pos.z - pl.pos.z));
      }
      let want = A.slot;
      if (A.slot === 1 && dist > 27 && near > 12) want = 2;
      else if (A.slot === 2 && (dist < 17 || near < 9)) want = 1;
      if (A.slot >= 0 && want !== A.slot && A.reloadK === 0) {
        this.inp.slot = want;
        this.state = 'SWITCH';
        this.say(want === 2 ? 'Going long — sniper up.' : 'Too close — switching to rifle!');
      }

      // never shoot through the player: hold and sidestep
      const ldx = Math.sin(this.aimYaw) * Math.cos(this.aimPitch);
      const ldy = Math.sin(this.aimPitch);
      const ldz = Math.cos(this.aimYaw) * Math.cos(this.aimPitch);
      const px = pl.pos.x - this.eye.x;
      const py = pl.pos.y + 1.1 - this.eye.y;
      const pz = pl.pos.z - this.eye.z;
      const along = px * ldx + py * ldy + pz * ldz;
      const off = Math.hypot(px - ldx * along, py - ldy * along, pz - ldz * along);
      const tgtAlong = Math.hypot(dx, dy, dz);
      const blocked = along > 0.3 && along < tgtAlong - 0.35 && off < 0.4;
      if (blocked) {
        this.blockT += dt;
        if (this.blockT > 0.4) {
          this.side = -this.side;
          this.blockT = 0;
        }
      } else this.blockT = 0;

      // ---- trigger discipline
      this.reactT -= dt;
      this.pauseT -= dt;
      const ready = this.reactT <= 0 && A.reloadK === 0 && !blocked && A.def !== null && this.inp.slot === null;
      if (A.slot === 2) {
        if (ready && err < tol * 0.8) this.inp.firePressed = true;
      } else if (A.slot >= 0) {
        if (this.burstLeft <= 0 && this.pauseT <= 0 && ready && err < tol) this.burstLeft = dist < 7 ? 6 + ((r() * 4) | 0) : 3 + ((r() * 3) | 0);
        this.inp.fire = this.burstLeft > 0 && err < tol * 2.6 && !blocked;
      }
      this.inp.aim = A.reloadK === 0 && dist > 4;
      if (this.state !== 'SWITCH' || this.inp.slot === null) this.state = A.reloadK > 0 ? 'RELOAD' : 'ENGAGE';

      // warn the player about a zombie right on them
      const dp = Math.hypot(t.pos.x - pl.pos.x, t.pos.z - pl.pos.z);
      if (dp < 3.2 && this.sixT <= 0 && pl.alive) {
        this.say(pick(['On your six!', 'Behind you!', 'Watch out — close!']), true);
        this.sixT = 7;
      }
    } else {
      this.noTargetT += dt;
      this.burstLeft = 0;
      this.inp.aim = false;
      // relax the aim toward where the squad is heading
      const rest = engaged ? (Math.hypot(c.vel.x, c.vel.z) > 0.5 ? Math.atan2(c.vel.x, c.vel.z) : fyaw) : c.yaw;
      this.yawVel += (angleDiff(rest, this.aimYaw) * 30 - this.yawVel * 11) * dt;
      this.pitchVel += ((-0.12 - this.aimPitch) * 30 - this.pitchVel * 11) * dt;
      this.aimYaw = wrapAngle(this.aimYaw + this.yawVel * dt);
      this.aimPitch += this.pitchVel * dt;
      // tactical reload in the lull, rifle back in hand
      if (engaged && A.def && A.reloadK === 0 && this.noTargetT > 0.8 && A.ammo[A.slot] < A.def.mag * 0.6) {
        this.inp.reloadPressed = true;
        this.say(pick(['Reloading!', 'Changing mag!']));
      }
      if (engaged && A.slot === 2 && this.noTargetT > 2.5 && A.reloadK === 0) this.inp.slot = 1;
      if (A.slot < 0 && this.inp.slot === null) this.inp.slot = 1;
      this.state = A.reloadK > 0 ? 'RELOAD' : 'FOLLOW';
    }
    if (A.reloadK > 0 && !this.wasReloading && t) this.say(pick(['Reloading!', 'Covering — reloading!']));
    this.wasReloading = A.reloadK > 0;

    // ------------------------------------------------------------- movement
    const rx = -fz;
    const rz = fx;
    let gx = pl.pos.x + rx * 2.6 * this.side - fx * 1.7;
    let gz = pl.pos.z + rz * 2.6 * this.side - fz * 1.7;
    // keep clear of the nearest zombie (back-pedal while firing)
    let nz: Zombie | null = null;
    let nd = 99;
    for (const z of this.horde.zombies) {
      if (!z.active || !z.alive || !(z.upright || z.body === 'CRAWLING')) continue;
      const d = Math.hypot(z.pos.x - c.pos.x, z.pos.z - c.pos.z);
      if (d < nd) {
        nd = d;
        nz = z;
      }
    }
    if (nz && nd < 3.2) {
      const k = (3.2 - nd) / Math.max(nd, 0.3);
      gx = c.pos.x + (c.pos.x - nz.pos.x) * k * 1.4;
      gz = c.pos.z + (c.pos.z - nz.pos.z) * k * 1.4;
    }
    const okAt = (x: number, z: number) => !T.solid(x, z) && Math.abs(T.height(x, z) - pl.pos.y) < 0.3;
    // threat hidden below the deck edge: step up to the railing on that side for a firing angle
    const hz = this.hidden;
    if (engaged && !t && hz && hz.active && hz.alive && Math.hypot(hz.pos.x - c.pos.x, hz.pos.z - c.pos.z) < 18) {
      const ex = hz.pos.x - c.pos.x;
      const ez = hz.pos.z - c.pos.z;
      const el = Math.hypot(ex, ez) || 1;
      for (let d = 3.2; d > 0.3; d -= 0.2) {
        const tx = c.pos.x + (ex / el) * d;
        const tz = c.pos.z + (ez / el) * d;
        if (okAt(tx, tz) && okAt(c.pos.x + (ex / el) * (d * 0.5), c.pos.z + (ez / el) * (d * 0.5))) {
          gx = tx;
          gz = tz;
          break;
        }
      }
    }
    // never pick a spot off the deck / stair: stay on the player's level, pull in closer if needed
    if (!okAt(gx, gz)) {
      let found = false;
      for (const s of [0.72, 0.5, 0.3]) {
        const tx = pl.pos.x + (gx - pl.pos.x) * s;
        const tz = pl.pos.z + (gz - pl.pos.z) * s;
        if (okAt(tx, tz)) {
          gx = tx;
          gz = tz;
          found = true;
          break;
        }
      }
      if (!found) {
        gx = c.pos.x;
        gz = c.pos.z;
      }
    }
    const dx = gx - c.pos.x;
    const dz = gz - c.pos.z;
    const dd = Math.hypot(dx, dz);
    const engaging = !!t && engaged;
    const moveYaw = engaging ? this.aimYaw : dd > 0.3 ? Math.atan2(dx, dz) : c.yaw;
    let mx = 0;
    let my = 0;
    if (engaged && dd > 0.55) {
      const wx = dx / dd;
      const wz = dz / dd;
      const f = Math.sin(moveYaw);
      const g = Math.cos(moveYaw);
      const k = Math.min(1, dd / 1.6);
      my = (wx * f + wz * g) * k;
      mx = (-wx * g + wz * f) * k;
    }
    const I = this.intent;
    I.moveX = mx;
    I.moveY = my;
    I.sprint = !engaging && dd > 6;
    I.pace = dd > 2.5 ? 2 : 1;
    I.strafe = engaging;
    I.lockFacing = engaging;
    I.speedCap = engaging ? (A.ads ? 2.3 : 3.4) : undefined;
    // regroup if stranded or stuck behind geometry
    const pd = Math.hypot(pl.pos.x - c.pos.x, pl.pos.z - c.pos.z);
    if (engaged && dd > 4 && this.lastGoalD - dd < 0.02 * dt * 60) this.stuckT += dt;
    else this.stuckT = Math.max(0, this.stuckT - dt);
    this.lastGoalD = dd;
    if (engaged && (pd > 32 || this.stuckT > 2.6)) {
      const tx = pl.pos.x - fx * 2.4 + rx * this.side * 1.2;
      const tz = pl.pos.z - fz * 2.4 + rz * this.side * 1.2;
      if (!T.solid(tx, tz) && Math.abs(T.height(tx, tz) - pl.pos.y) < 0.6) {
        this.ctrl.reset(tx, tz, T);
        this.anim.reset(this.ctrl, T);
        this.state = 'REGROUP';
        this.say('Regrouping on you.');
      }
      this.stuckT = 0;
    }

    // ledge guard: steps down a stair are fine, a drop off the tower is not
    if (I.moveX !== 0 || I.moveY !== 0) {
      const f = Math.sin(moveYaw);
      const g = Math.cos(moveYaw);
      let wx = f * I.moveY - g * I.moveX;
      let wz = g * I.moveY + f * I.moveX;
      const wl = Math.hypot(wx, wz) || 1;
      wx /= wl;
      wz /= wl;
      if (c.pos.y - T.height(c.pos.x + wx * 0.55, c.pos.z + wz * 0.55) > 0.45) {
        I.moveX = I.moveY = 0;
        I.sprint = false;
      }
    }
    {
      const vs = Math.hypot(c.vel.x, c.vel.z);
      if (vs > 0.2 && c.grounded && c.pos.y - T.height(c.pos.x + (c.vel.x / vs) * 0.45, c.pos.z + (c.vel.z / vs) * 0.45) > 0.45) {
        c.vel.x = 0;
        c.vel.z = 0;
      }
    }

    // --------------------------------------------- weapon, body, animation
    A.tick(dt, this.inp, c, this.aimYaw, this.aimPitch, false);
    this.inp.slot = null;
    const n = Math.max(1, Math.ceil(dt / (1 / 90)));
    const h = dt / n;
    for (let i = 0; i < n; i++) {
      c.update(h, I, moveYaw, T);
      this.anim.update(h, c, T, this.time, this.aimYaw, this.aimPitch, A.pose);
    }
    this.rig.root.updateMatrixWorld(true);
    for (const s of this.anim.steps) this.onStep(s);
    this.anim.steps.length = 0;

    // ------------------------------------------------------------------ fire
    this.eye.set(c.pos.x, c.pos.y + 1.56, c.pos.z);
    const dir = this.v.set(Math.sin(this.aimYaw) * Math.cos(this.aimPitch), Math.sin(this.aimPitch), Math.cos(this.aimYaw) * Math.cos(this.aimPitch));
    this.cam.position.copy(this.eye);
    this.cam.lookAt(this.w.copy(this.eye).add(dir));
    this.cam.updateMatrixWorld();
    A.shoot(this.cam, 0.35);
    if (A.shots !== this.lastShots) {
      this.burstLeft -= A.shots - this.lastShots;
      this.lastShots = A.shots;
      if (this.burstLeft <= 0) {
        this.pauseT = 0.1 + r() * 0.16;
        // recoil walks the aim off a little; the shooter re-settles before the next burst
        this.errYaw += (r() - 0.5) * 0.012;
        this.errPitch += 0.006 + r() * 0.006;
      }
    }
    A.updateFx(dt);

    // kill confirmation
    if (A.kills !== this.lastKills) {
      this.lastKillT = this.time;
      const k = A.kills - this.lastKills;
      const hh = A.heads - this.lastHeads;
      this.kills += k;
      this.headshots += hh;
      this.lastKills = A.kills;
      this.lastHeads = A.heads;
      if (k >= 2) this.say('Two for one!', true);
      else if (hh > 0) this.say(pick(HEAD_LINES), true);
      else this.say(pick(KILL_LINES));
    }
  }

  /** World position above the head (HUD marker). */
  marker(out: THREE.Vector3) {
    this.rig.head.getWorldPosition(out);
    out.y += 0.42;
    return out;
  }
}
