import { smoothstep } from './math';

export interface Box {
  x0: number;
  x1: number;
  z0: number;
  z1: number;
  h: number;
  /** rendered by the watchtower builder instead of the generic prop boxes */
  style?: 'tower' | 'stair' | 'landing';
}
/** Railing: blocks walking (player, teammate, zombies) but not bullets or flying ragdolls. */
export interface Rail {
  x0: number;
  x1: number;
  z0: number;
  z1: number;
  y: number;
}
export interface Ramp extends Omit<Box, 'h'> {
  h0: number;
  h1: number;
  axis: 'x' | 'z';
}
const GS = 4; // height grid cell (m)
const GN = 44;
const GO = 88;

export interface Pillar {
  x: number;
  z: number;
  r: number;
}

/**
 * Analytic walkable height field. Pure math (no rendering) so the controller,
 * foot IK and camera can all sample it cheaply — and it can run headless.
 */
export class Terrain {
  boxes: Box[] = [];
  ramps: Ramp[] = [];
  pillars: Pillar[] = [];
  /** dynamic round solids (explosive barrels) */
  dyn: Pillar[] = [];
  readonly bound = 78;
  rails: Rail[] = [];
  /** two-storey watchtower: 6×6 m block, floors every 3.24 m, roof deck at 6.48 m */
  readonly tower = { x0: -3, x1: 3, z0: -5, z1: 1, h: 6.48, floor: 3.24 };
  /** player + teammate start on the roof deck */
  readonly spawns = { player: { x: -0.9, z: -2.4 }, buddy: { x: 1.3, z: -3.5 } };
  /** 4 m grid of box / ramp indices (ramps encoded as -(i+1)) for fast exact height queries */
  private grid: number[][] = [];
  /** same grid: tree trunks (index, registered with a 1 m margin) and railings (-(i+1)) */
  private sgrid: number[][] = [];

  constructor() {
    // Staircase → deck → ramp (foot IK on steps and slopes)
    const n = 6;
    const rise = 0.17;
    const run = 0.4;
    const sz = 6;
    for (let i = 0; i < n; i++) {
      this.boxes.push({ x0: 5, x1: 8, z0: sz + i * run, z1: sz + n * run, h: rise * (i + 1) });
    }
    const top = rise * n;
    this.boxes.push({ x0: 4, x1: 9, z0: sz + n * run, z1: sz + n * run + 4.6, h: top });
    this.ramps.push({ x0: -1.5, x1: 4, z0: 9.8, z1: 12.4, h0: 0, h1: top, axis: 'x' });

    // Jump course: ascending crates
    this.boxes.push({ x0: -7, x1: -5, z0: 4, z1: 6.2, h: 0.45 });
    this.boxes.push({ x0: -9.6, x1: -7.4, z0: 4.4, z1: 6.6, h: 0.9 });
    this.boxes.push({ x0: -13, x1: -10, z0: 4, z1: 7.2, h: 1.35 });

    // Low slabs you can simply step onto
    this.boxes.push({ x0: -4.5, x1: -1.2, z0: 14.5, z1: 17.5, h: 0.14 });
    this.boxes.push({ x0: -3.8, x1: -1.9, z0: 15.2, z1: 16.8, h: 0.28 });

    const propStart = this.boxes.length;
    // Ruined compound: tall walls the horde has to path around (gap in the north wall)
    const W = 2.4;
    this.boxes.push({ x0: -26, x1: -17, z0: -3.6, z1: -3.0, h: W });
    this.boxes.push({ x0: -14, x1: -7, z0: -3.6, z1: -3.0, h: W });
    this.boxes.push({ x0: -26, x1: -25.4, z0: -21, z1: -3.0, h: W });
    this.boxes.push({ x0: -26, x1: -11, z0: -21.6, z1: -21, h: W });
    this.boxes.push({ x0: -18, x1: -17.4, z0: -16, z1: -7.5, h: W });
    // South-east L wall
    this.boxes.push({ x0: 18, x1: 34, z0: -22.6, z1: -22, h: W });
    this.boxes.push({ x0: 18, x1: 18.6, z0: -34, z1: -22, h: W });
    // Abandoned cars
    this.boxes.push({ x0: 10, x1: 14.2, z0: -13, z1: -11.2, h: 1.35 });
    this.boxes.push({ x0: -5, x1: -3.2, z0: 21, z1: 25.2, h: 1.35 });
    this.boxes.push({ x0: 14, x1: 15.8, z0: 17, z1: 21.2, h: 1.35 });
    this.boxes.push({ x0: -33, x1: -28.8, z0: 9, z1: 10.8, h: 1.35 });
    this.boxes.push({ x0: 2, x1: 6.2, z0: -19, z1: -17.2, h: 1.35 });
    // Concrete jersey barriers
    this.boxes.push({ x0: -9, x1: -4, z0: -31, z1: -30.4, h: 1.05 });
    this.boxes.push({ x0: 1, x1: 6, z0: -31, z1: -30.4, h: 1.05 });
    this.boxes.push({ x0: 24, x1: 24.6, z0: 12, z1: 19, h: 1.05 });
    // props stand on the rolling ground: heights are relative to the highest corner
    for (let i = propStart; i < this.boxes.length; i++) {
      const b = this.boxes[i];
      let g = -Infinity;
      for (const [x, z] of [[b.x0, b.z0], [b.x1, b.z0], [b.x0, b.z1], [b.x1, b.z1], [(b.x0 + b.x1) / 2, (b.z0 + b.z1) / 2]]) g = Math.max(g, this.base(x, z));
      b.h += g;
    }

    // ---- Two-storey watchtower with a concrete stair wrapping three sides (spawn point).
    // Rise 0.18 m per 0.5 m run: the controller (0.34 m steps), the zombies' body probes
    // (0.36 m over 0.45 m) and the flow field (0.4 m per 1 m cell) can all climb it.
    {
      const T = this.tower;
      const R = 0.18;
      const RUN = 0.5;
      const N = 12;
      this.boxes.push({ x0: T.x0, x1: T.x1, z0: T.z0, z1: T.z1, h: T.h, style: 'tower' });
      this.boxes.push({ x0: 1, x1: 5, z0: 1, z1: 3, h: T.h, style: 'tower' }); // arrival annex
      // flight 1: west side, north → south (ground → 2.16 m)
      for (let k = 0; k < N; k++) this.boxes.push({ x0: -5, x1: -3, z0: 1 - RUN * (k + 1), z1: 1 - RUN * k, h: R * (k + 1), style: 'stair' });
      this.boxes.push({ x0: -5, x1: -3, z0: -7, z1: -5, h: R * N, style: 'landing' });
      // flight 2: south side, west → east (→ 4.32 m)
      for (let k = 0; k < N; k++) this.boxes.push({ x0: -3 + RUN * k, x1: -3 + RUN * (k + 1), z0: -7, z1: -5, h: R * (N + k + 1), style: 'stair' });
      this.boxes.push({ x0: 3, x1: 5, z0: -7, z1: -5, h: R * 2 * N, style: 'landing' });
      // flight 3: east side, south → north (→ 6.48 m, arrives on the annex)
      for (let k = 0; k < N; k++) this.boxes.push({ x0: 3, x1: 5, z0: -5 + RUN * k, z1: -5 + RUN * (k + 1), h: R * (2 * N + k + 1), style: 'stair' });
      const y = T.h;
      const t = 0.06;
      this.rails.push(
        { x0: T.x0, x1: T.x0 + t, z0: T.z0, z1: T.z1, y }, // roof west
        { x0: T.x0, x1: T.x1, z0: T.z0, z1: T.z0 + t, y }, // roof south
        { x0: T.x1 - t, x1: T.x1, z0: T.z0, z1: T.z1 - 0.5, y }, // roof east (stair side; ends short of the arrival corner)
        { x0: T.x0, x1: 1, z0: T.z1 - t, z1: T.z1, y }, // roof north (open toward the annex)
        { x0: 1, x1: 5, z0: 3 - t, z1: 3, y }, // annex north
        { x0: 1, x1: 1 + t, z0: 1, z1: 3, y }, // annex west
        { x0: 5 - t, x1: 5, z0: 1.5, z1: 3, y }, // annex east (stair arrives on its south edge)
      );
    }

    // Tree trunks (solid obstacles, deterministic scatter)
    let seed = 1337;
    const rnd = () => {
      seed = (seed * 16807) % 2147483647;
      return seed / 2147483647;
    };
    for (let i = 0; i < 90; i++) {
      const a = rnd() * Math.PI * 2;
      const r = 24 + rnd() * 80;
      const x = Math.sin(a) * r;
      const z = Math.cos(a) * r;
      const pr = 0.3 + rnd() * 0.15;
      if (x > 4 && Math.abs(z) < 8) continue; // keep the firing lane (+X) clear
      this.pillars.push({ x, z, r: pr });
    }
    for (let i = 0; i < GN * GN; i++) this.grid.push([]);
    const mark = (x0: number, x1: number, z0: number, z1: number, id: number) => {
      for (let gx = Math.max(0, Math.floor((x0 + GO) / GS)); gx <= Math.min(GN - 1, Math.floor((x1 + GO) / GS)); gx++)
        for (let gz = Math.max(0, Math.floor((z0 + GO) / GS)); gz <= Math.min(GN - 1, Math.floor((z1 + GO) / GS)); gz++) this.grid[gx * GN + gz].push(id);
    };
    this.boxes.forEach((b, i) => mark(b.x0, b.x1, b.z0, b.z1, i));
    this.ramps.forEach((r, j) => mark(r.x0, r.x1, r.z0, r.z1, -(j + 1)));
    for (let i = 0; i < GN * GN; i++) this.sgrid.push([]);
    const smark = (x0: number, x1: number, z0: number, z1: number, id: number) => {
      for (let gx = Math.max(0, Math.floor((x0 + GO) / GS)); gx <= Math.min(GN - 1, Math.floor((x1 + GO) / GS)); gx++)
        for (let gz = Math.max(0, Math.floor((z0 + GO) / GS)); gz <= Math.min(GN - 1, Math.floor((z1 + GO) / GS)); gz++) this.sgrid[gx * GN + gz].push(id);
    };
    this.pillars.forEach((p, i) => smark(p.x - p.r - 1, p.x + p.r + 1, p.z - p.r - 1, p.z + p.r + 1, i));
    this.rails.forEach((r, i) => smark(r.x0, r.x1, r.z0, r.z1, -(i + 1)));
  }

  /** Natural snow surface: flat training field, ripple patch, mound, rolling hills. */
  base(x: number, z: number): number {
    const r2 = x * x + z * z;
    let h = 0;
    if (r2 > 361) {
      h =
        (1.5 * Math.sin(x * 0.06 + 0.4) * Math.cos(z * 0.055 + 1.1) +
          0.6 * Math.sin(x * 0.13 + z * 0.11 + 2)) *
        smoothstep(19, 46, Math.sqrt(r2));
    }
    // ripple patch (uneven ground for foot alignment)
    const rx = x + 6;
    const rz = z + 9;
    const rr2 = rx * rx + rz * rz;
    if (rr2 < 36) {
      const rm = 1 - smoothstep(3.2, 6, Math.sqrt(rr2));
      if (rm > 0) h += 0.1 * rm * Math.sin(x * 2.2) * Math.sin(z * 2.0);
    }
    // smooth mound
    const mx = x - 10;
    const mz = z + 7;
    const md = (mx * mx + mz * mz) / 14;
    if (md < 8) h += 0.85 * Math.exp(-md);
    return h;
  }

  height(x: number, z: number): number {
    let h = this.base(x, z);
    const gx = Math.floor((x + GO) / GS);
    const gz = Math.floor((z + GO) / GS);
    if (gx < 0 || gz < 0 || gx >= GN || gz >= GN) return h;
    const cell = this.grid[gx * GN + gz];
    for (let k = 0; k < cell.length; k++) {
      const id = cell[k];
      if (id >= 0) {
        const b = this.boxes[id];
        if (x >= b.x0 && x <= b.x1 && z >= b.z0 && z <= b.z1 && b.h > h) h = b.h;
      } else {
        const r = this.ramps[-id - 1];
        if (x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1) {
          const t = r.axis === 'x' ? (x - r.x0) / (r.x1 - r.x0) : (z - r.z0) / (r.z1 - r.z0);
          const rh = r.h0 + (r.h1 - r.h0) * t;
          if (rh > h) h = rh;
        }
      }
    }
    return h;
  }

  /** Is this point inside a tree trunk (plus margin)? Used by the camera arm. */
  trunk(x: number, z: number, margin: number): boolean {
    if (margin <= 1) {
      const gx = Math.floor((x + GO) / GS);
      const gz = Math.floor((z + GO) / GS);
      if (gx < 0 || gz < 0 || gx >= GN || gz >= GN) return false;
      const cell = this.sgrid[gx * GN + gz];
      for (let k = 0; k < cell.length; k++) {
        const id = cell[k];
        if (id < 0) continue;
        const p = this.pillars[id];
        const dx = x - p.x;
        const dz = z - p.z;
        const rr = p.r + margin;
        if (dx * dx + dz * dz < rr * rr) return true;
      }
      return false;
    }
    for (const p of this.pillars) {
      const dx = x - p.x;
      const dz = z - p.z;
      const rr = p.r + margin;
      if (dx * dx + dz * dz < rr * rr) return true;
    }
    return false;
  }

  /**
   * Bullet ray vs. height field + tree trunks. Marches then bisects.
   * Returns the hit distance or Infinity.
   */
  raycast(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, tMin: number, tMax: number): number {
    const inside = (t: number) => {
      const x = ox + dx * t;
      const y = oy + dy * t;
      const z = oz + dz * t;
      const h = this.height(x, z);
      return y < h || (y < h + 5 && this.trunk(x, z, 0));
    };
    let prev = tMin;
    let t = tMin;
    while (t < tMax) {
      if (inside(t)) {
        let a = prev;
        let b = t;
        for (let i = 0; i < 9; i++) {
          const m = (a + b) / 2;
          if (inside(m)) b = m;
          else a = m;
        }
        return b;
      }
      prev = t;
      t += Math.min(0.5, 0.2 + t * 0.01);
    }
    return Infinity;
  }

  /** Non-walkable solid (tree trunks, world bound). */
  solid(x: number, z: number): boolean {
    if (x * x + z * z > this.bound * this.bound) return true;
    const gx = Math.floor((x + GO) / GS);
    const gz = Math.floor((z + GO) / GS);
    if (gx >= 0 && gz >= 0 && gx < GN && gz < GN) {
      const cell = this.sgrid[gx * GN + gz];
      for (let k = 0; k < cell.length; k++) {
        const id = cell[k];
        if (id >= 0) {
          const p = this.pillars[id];
          const dx = x - p.x;
          const dz = z - p.z;
          const rr = p.r + 0.28;
          if (dx * dx + dz * dz < rr * rr) return true;
        } else {
          const r = this.rails[-id - 1];
          if (x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1) return true;
        }
      }
    }
    for (const p of this.dyn) {
      const dx = x - p.x;
      const dz = z - p.z;
      const rr = p.r + 0.28;
      if (dx * dx + dz * dz < rr * rr) return true;
    }
    return false;
  }
}
