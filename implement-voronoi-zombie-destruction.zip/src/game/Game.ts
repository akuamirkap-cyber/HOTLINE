import * as THREE from 'three';
import { Buddy } from './buddy';
import { Terrain } from './terrain';
import { CharacterController, Intent, LocoState, PACE_NAMES, STATES } from './controller';
import { Animator } from './animator';
import { Rig, Scarf } from './rig';
import { FollowCamera } from './camera';
import { Environment } from './environment';
import { Input } from './input';
import { Foley } from './audio';
import { Arsenal } from './weapons';
import { Range } from './targets';
import { AI_STATES, Horde } from './zombie/zombies';
import { FpsWeapons } from './fpsWeapons';
import { soundEngine } from './ref/audio';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { Barrels } from './barrels';

export interface Hud {
  /** AI teammate */
  buddyState: string;
  buddyWeapon: string;
  buddyAmmo: number;
  buddyMag: number;
  buddyReload: number;
  buddyKills: number;
  buddyHeads: number;
  buddyCallout: string;
  buddyCalloutAge: number;
  buddyX: number;
  buddyY: number;
  buddyOn: boolean;
  buddyDist: number;
  /** player's reload was started automatically */
  autoReload: boolean;
  /** several zombies killed by one round (sniper penetration) */
  multiKill: number;
  /** horde size: bodies on the map (alive + corpses), hard cap, chosen count */
  zTotal: number;
  zCap: number;
  zTarget: number;
  /** Voronoi budget (body parts rendered with fracture geometry) */
  fracMax: number;
  multiAge: number;
  state: LocoState;
  weights: number[];
  speed: number;
  pace: string;
  sprinting: boolean;
  crouching: boolean;
  strafing: boolean;
  grounded: boolean;
  phase: number;
  contactL: number;
  contactR: number;
  cadence: number;
  lean: number;
  bank: number;
  slowmo: boolean;
  debug: boolean;
  muted: boolean;
  fps: number;
  engaged: boolean;
  // weapons / view
  armed: boolean;
  slot: number;
  weapon: string;
  fireMode: string;
  ammo: number;
  mag: number;
  ammoAll: number[];
  reload: number;
  firstPerson: boolean;
  ads: boolean;
  scope: number;
  spread: number;
  hits: number;
  shots: number;
  lastDist: number;
  hitAge: number;
  // survival
  hp: number;
  dead: boolean;
  hurtAge: number;
  hurtAng: number;
  kills: number;
  headshots: number;
  limbs: number;
  zAlive: number;
  zStates: number[];
  killAge: number;
  headAge: number;
  nearest: number;
  aggressive: boolean;
  fpsCam: 'CLASSIC' | 'BODYCAM';
  lens: number;
  blastAge: number;
  /** Voronoi destruction / blood simulation stats */
  fracParts: number;
  debris: number;
  stains: number;
  impactAge: number;
  impactPower: number;
}

const SPAWN = { x: 0, z: -2 };

/** Small sky dome (same palette as the visible sky) used to build the IBL environment map. */
function skyEnvScene() {
  const s = new THREE.Scene();
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    uniforms: {
      top: { value: new THREE.Color('#5f86b8') },
      mid: { value: new THREE.Color('#b9cde3') },
      hor: { value: new THREE.Color('#dfe6ee') },
      gnd: { value: new THREE.Color('#d9e1ea') },
      sunDir: { value: new THREE.Vector3(0.55, 0.42, -0.72).normalize() },
    },
    vertexShader: 'varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
    fragmentShader: `varying vec3 vD; uniform vec3 top; uniform vec3 mid; uniform vec3 hor; uniform vec3 gnd; uniform vec3 sunDir;
      void main(){ float h = vD.y; vec3 c = h < 0.0 ? mix(hor, gnd, smoothstep(0.0, -0.3, h)) : mix(mix(hor, mid, smoothstep(0.0, 0.22, h)), top, smoothstep(0.18, 0.8, h));
        float s = max(dot(normalize(vD), sunDir), 0.0); c += vec3(1.0, 0.9, 0.75) * (pow(s, 32.0) * 0.6 + pow(s, 900.0) * 6.0);
        gl_FragColor = vec4(c, 1.0); }`,
  });
  s.add(new THREE.Mesh(new THREE.SphereGeometry(10, 48, 24), mat));
  return s;
}

export class Game {
  input: Input;
  hud: Hud;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private cam: THREE.PerspectiveCamera;
  private terrain = new Terrain();
  private ctrl = new CharacterController();
  private rig = new Rig();
  private anim: Animator;
  private scarf: Scarf;
  private follow: FollowCamera;
  private env: Environment;
  private foley = new Foley();
  private range: Range;
  private arsenal: Arsenal;
  private horde: Horde;
  private fps: FpsWeapons;
  /** first-person camera: CLASSIC (default, eye-level) or BODYCAM (PIGEON reference chest cam) */
  private fpsCam: 'CLASSIC' | 'BODYCAM' = 'CLASSIC';
  private hitStop = 0;
  private dramaT = 0;
  /** the player's own heavy impacts (screen pulse) */
  private pImpactAge = 9;
  private pImpactPower = 0;
  private buddy: Buddy;
  private tmpB = new THREE.Vector3();
  private barrels: Barrels;
  private blastAge = 9;
  private landed = 0;
  private tmpV = new THREE.Vector3();
  private hp = 100;
  private dead = false;
  private hurtAge = 9;
  private hurtAng = 0;
  private sinceHurt = 9;
  private raf = 0;
  private last = 0;
  private time = 0;
  private timeScale = 1;
  private timeScaleT = 1;
  private fpsAcc = 0;
  private fpsN = 0;
  private gizmo = new THREE.Group();
  private gTargets: THREE.Mesh[] = [];
  private gPlants: THREE.Mesh[] = [];
  private gVel: THREE.ArrowHelper;
  private gIntent: THREE.ArrowHelper;
  private ro: ResizeObserver;
  private host: HTMLElement;
  private v = new THREE.Vector3();

  constructor(canvas: HTMLCanvasElement, host: HTMLElement) {
    this.host = host;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.95;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.cam = new THREE.PerspectiveCamera(52, 1, 0.08, 900);
    this.env = new Environment(this.scene, this.terrain);

    this.ctrl.reset(this.terrain.spawns.player.x, this.terrain.spawns.player.z, this.terrain);
    this.anim = new Animator(this.rig);
    this.anim.reset(this.ctrl, this.terrain);
    this.scene.add(this.rig.root);
    // settle the pose once so the scarf initialises on the real skeleton
    this.anim.update(1 / 60, this.ctrl, this.terrain, 0, 0, 0);
    this.scarf = new Scarf(this.rig);
    this.scene.add(this.scarf.mesh);

    this.follow = new FollowCamera(this.cam);
    this.follow.snap(this.ctrl);

    this.range = new Range(this.scene, this.terrain, SPAWN);
    this.arsenal = new Arsenal(this.scene, this.rig, this.terrain, this.range, this.foley);

    // ---- the horde
    const fog = this.scene.fog as THREE.Fog;
    fog.near = 16;
    fog.far = 150;
    fog.color.set('#c9d0d8');
    this.renderer.toneMappingExposure = 0.88;
    this.horde = new Horde(this.scene, this.terrain, this.foley);
    this.arsenal.zombies = this.horde;
    this.horde.populate(SPAWN.x, SPAWN.z);
    // ---- first-person weapon system (PIGEON reference port)
    this.fps = new FpsWeapons(this.scene, this.terrain);
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.fps.vmScene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    this.fps.vmScene.environmentIntensity = 0.42;
    // image-based lighting for the world: wet blood, glossy fragments and props reflect the winter sky
    this.scene.environment = pmrem.fromScene(skyEnvScene(), 0.02).texture;
    this.scene.environmentIntensity = 0.32;
    this.scene.traverse((o) => {
      const hl = o as THREE.HemisphereLight;
      if (hl.isHemisphereLight) hl.intensity = 0.78;
    });
    pmrem.dispose();
    this.arsenal.onTracer = (s, e, slot) => {
      this.fps.spawnTracer(s, e, slot);
      if (!this.fps.visible) this.fps.spawnMuzzleSmoke(s, slot === 2 ? 4 : 2, slot === 2 ? 1.2 : 0.8, this.cam);
    };
    // ---- explosive barrels
    this.barrels = new Barrels(this.scene, this.terrain, this.horde.blood, this.foley);
    this.arsenal.barrels = this.barrels;
    // ---- AI teammate: a second operator with the same body, weapons and ballistics
    this.buddy = new Buddy(this.scene, this.terrain, this.range, this.foley, this.horde, this.terrain.spawns.buddy.x, this.terrain.spawns.buddy.z);
    this.buddy.arsenal.barrels = this.barrels;
    this.buddy.arsenal.onTracer = (s, e, slot) => {
      this.fps.spawnTracer(s, e, slot);
      this.fps.spawnMuzzleSmoke(s, slot === 2 ? 3 : 1, slot === 2 ? 1 : 0.6, this.cam);
    };
    this.buddy.onStep = (st) => this.env.addFootprint(st);
    this.barrels.onExplode = (p) => {
      this.horde.explode(p, 8.5, 1);
      const d = Math.hypot(this.ctrl.pos.x - p.x, this.ctrl.pos.z - p.z);
      this.foley.explosion(d);
      this.follow.addTrauma(Math.max(0.15, 1.1 - d / 18));
      if (d < 12) this.blastAge = 0;
      if (d < 7 && !this.dead) {
        const f = 1 - d / 7;
        this.hp -= 75 * f * f + 8;
        this.hurtAge = 0;
        this.sinceHurt = 0;
        this.hurtAng = Math.atan2(p.x - this.ctrl.pos.x, p.z - this.ctrl.pos.z);
        const k = (6 * f) / Math.max(d, 0.5);
        this.ctrl.vel.x += (this.ctrl.pos.x - p.x) * k;
        this.ctrl.vel.z += (this.ctrl.pos.z - p.z) * k;
        this.foley.hurt();
        if (this.hp <= 0) {
          this.hp = 0;
          this.dead = true;
          if (document.pointerLockElement) document.exitPointerLock();
        }
      }
    };
    // the player's own body: hidden from the first-person camera but still casting its shadow
    this.rig.root.traverse((o) => o.layers.set(1));
    this.scarf.mesh.layers.set(1);
    this.cam.layers.enable(1);
    this.env.sun.shadow.camera.layers.enable(1);
    this.horde.onPlayerHit = (dmg, fx, fz) => {
      if (this.dead) return;
      this.hp -= dmg;
      this.hurtAge = 0;
      this.sinceHurt = 0;
      this.hurtAng = Math.atan2(fx - this.ctrl.pos.x, fz - this.ctrl.pos.z);
      this.foley.hurt();
      this.follow.kick(0.035);
      this.follow.addTrauma(0.3);
      if (this.hp <= 0) {
        this.hp = 0;
        this.dead = true;
        if (document.pointerLockElement) document.exitPointerLock();
      }
    };

    // ---- debug gizmos
    const tMat = new THREE.MeshBasicMaterial({ color: '#35e0ff', depthTest: false, transparent: true, opacity: 0.9 });
    const pMat = new THREE.MeshBasicMaterial({ color: '#7dff8a', depthTest: false, transparent: true, opacity: 0.9 });
    for (let i = 0; i < 2; i++) {
      const t = new THREE.Mesh(new THREE.SphereGeometry(0.035, 10, 8), tMat);
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.1, 0.125, 24), pMat);
      ring.rotation.x = -Math.PI / 2;
      t.renderOrder = ring.renderOrder = 10;
      this.gTargets.push(t);
      this.gPlants.push(ring);
      this.gizmo.add(t, ring);
    }
    this.gVel = new THREE.ArrowHelper(new THREE.Vector3(0, 0, 1), new THREE.Vector3(), 1, 0x35e0ff, 0.18, 0.1);
    this.gIntent = new THREE.ArrowHelper(new THREE.Vector3(0, 0, 1), new THREE.Vector3(), 1, 0xffa23a, 0.18, 0.1);
    this.gizmo.add(this.gVel, this.gIntent);
    this.gizmo.visible = false;
    this.scene.add(this.gizmo);

    this.input = new Input(canvas);
    this.input.onEngage = () => {
      this.hud.engaged = true;
      this.foley.unlock();
      soundEngine.unlock();
    };
    this.input.onAction = (a) => {
      if (a === 'slowmo') {
        this.timeScaleT = this.timeScaleT < 1 ? 1 : 0.2;
        this.hud.slowmo = this.timeScaleT < 1;
      } else if (a === 'debug') {
        this.gizmo.visible = !this.gizmo.visible;
        this.hud.debug = this.gizmo.visible;
      } else if (a === 'mute') {
        this.foley.muted = !this.foley.muted;
        soundEngine.setMuted(this.foley.muted);
        this.hud.muted = this.foley.muted;
      } else if (a === 'camera') {
        this.follow.toggleMode();
      } else if (a === 'reset') {
        this.restart();
      } else if (a === 'fpscam') {
        this.toggleFpsCam();
      } else if (a === 'inspect') {
        this.fps.triggerInspect();
      } else if (a === 'aggro') {
        this.toggleAggressive();
      }
    };

    this.hud = {
      state: 'IDLE',
      weights: STATES.map(() => 0),
      speed: 0,
      pace: 'RUN',
      sprinting: false,
      crouching: false,
      strafing: false,
      grounded: true,
      phase: 0,
      contactL: 1,
      contactR: 1,
      cadence: 0,
      lean: 0,
      bank: 0,
      slowmo: false,
      debug: false,
      muted: false,
      fps: 60,
      engaged: false,
      armed: false,
      slot: -1,
      weapon: 'UNARMED',
      fireMode: '',
      ammo: 0,
      mag: 0,
      ammoAll: [0, 0, 0],
      reload: 0,
      firstPerson: false,
      ads: false,
      scope: 0,
      spread: 0,
      hits: 0,
      shots: 0,
      lastDist: 0,
      hitAge: 9,
      hp: 100,
      dead: false,
      hurtAge: 9,
      hurtAng: 0,
      kills: 0,
      headshots: 0,
      limbs: 0,
      zAlive: 0,
      zStates: AI_STATES.map(() => 0),
      killAge: 9,
      headAge: 9,
      nearest: 99,
      aggressive: false,
      fpsCam: 'CLASSIC',
      lens: 0,
      blastAge: 9,
      fracParts: 0,
      buddyState: 'FOLLOW',
      buddyWeapon: '',
      buddyAmmo: 0,
      buddyMag: 0,
      buddyReload: 0,
      buddyKills: 0,
      buddyHeads: 0,
      buddyCallout: '',
      buddyCalloutAge: 9,
      buddyX: 0,
      buddyY: 0,
      buddyOn: false,
      buddyDist: 0,
      autoReload: false,
      multiKill: 0,
      zTotal: 0,
      zCap: 1000,
      zTarget: 1000,
      fracMax: 300,
      multiAge: 9,
      debris: 0,
      stains: 0,
      impactAge: 9,
      impactPower: 0,
    };

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(host);
    this.resize();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  toggleFpsCam() {
    this.fpsCam = this.fpsCam === 'CLASSIC' ? 'BODYCAM' : 'CLASSIC';
    this.hud.fpsCam = this.fpsCam;
  }

  /** Settings: how many zombies the horde keeps alive (hard cap 1000). */
  setZombieTarget(n: number) {
    this.horde.target = Math.max(0, Math.min(this.horde.max, Math.round(n)));
    this.hud.zTarget = this.horde.target;
  }
  /** Settings: maximum body parts with Voronoi fracture geometry at once. */
  setVoronoiMax(n: number) {
    this.horde.setVoronoiMax(n);
    this.hud.fracMax = this.horde.voronoiMax;
  }

  toggleAggressive() {
    this.horde.setAggressive(!this.horde.aggressive);
    this.hud.aggressive = this.horde.aggressive;
  }

  restart() {
    this.ctrl.reset(this.terrain.spawns.player.x, this.terrain.spawns.player.z, this.terrain);
    this.anim.reset(this.ctrl, this.terrain);
    this.follow.snap(this.ctrl);
    this.hp = 100;
    this.dead = false;
    this.hurtAge = 9;
    this.horde.populate(SPAWN.x, SPAWN.z);
    this.buddy.reset(this.terrain.spawns.buddy.x, this.terrain.spawns.buddy.z);
  }

  private resize() {
    const w = Math.max(1, this.host.clientWidth);
    const h = Math.max(1, this.host.clientHeight);
    this.renderer.setSize(w, h, false);
    this.cam.aspect = w / h;
    this.cam.updateProjectionMatrix();
    this.fps.setAspect(w / h);
  }

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const raw = Math.min((now - this.last) / 1000, 0.05);
    this.last = now;
    if (raw <= 0) return;
    this.fpsAcc += raw;
    this.fpsN++;
    if (this.fpsAcc > 0.5) {
      this.hud.fps = Math.round(this.fpsN / this.fpsAcc);
      this.fpsAcc = 0;
      this.fpsN = 0;
    }
    this.timeScale += (this.timeScaleT - this.timeScale) * Math.min(1, raw * 8);
    // brief hit-stop on kills (sells the impact)
    const hs = this.hitStop > 0 ? 0.22 : 1;
    this.hitStop = Math.max(0, this.hitStop - raw);
    // sniper kill: a short bullet-time dip that eases back to full speed
    let drama = 1;
    if (this.dramaT > 0) {
      this.dramaT = Math.max(0, this.dramaT - raw);
      const u = this.dramaT / 0.8;
      drama = 1 - 0.66 * u * u;
    }
    const dt = raw * this.timeScale * hs * drama;

    const f = this.input.sample(raw);
    if (this.dead) {
      f.moveX = f.moveY = 0;
      f.fire = f.firePressed = f.sprint = f.jumpPressed = false;
    }
    // look sensitivity scales with zoom so scoped aiming stays controllable
    const sens = Math.min(1, this.cam.fov / 60);
    this.follow.look(f.lookX * sens, f.lookY * sens);

    const ars = this.arsenal;
    const fp = this.follow.firstPerson;
    // aiming or shooting always wins over sprinting; first person only sprints forward
    let sprint = f.sprint && !f.aim && !(ars.armed && f.fire);
    if (fp && f.moveY < 0.5) sprint = false;

    this.follow.steer(raw, this.ctrl, ars.scopeW > 0.35 || (!!ars.def?.scope && ars.ads));
    ars.tick(dt, f, this.ctrl, this.follow.aimYaw, this.follow.aimPitch, fp);

    const intent: Intent = {
      moveX: f.moveX,
      moveY: f.moveY,
      sprint,
      jumpPressed: f.jumpPressed,
      jumpHeld: f.jumpHeld,
      crouchToggle: f.crouchToggle,
      strafe: f.strafeToggle || (!ars.armed && f.aim),
      pace: f.pace,
      // weapon up (or first person) → body squares up to the camera
      lockFacing: fp || (ars.facing && !sprint),
      speedCap: ars.ads ? 2.3 : undefined,
    };

    // fixed-size sub-steps keep springs/gait identical at any frame rate
    const n = Math.max(1, Math.ceil(dt / (1 / 90)));
    const h = dt / n;
    for (let i = 0; i < n; i++) {
      if (i > 0) {
        intent.jumpPressed = false;
        intent.crouchToggle = false;
      }
      this.ctrl.update(h, intent, this.follow.yaw, this.terrain);
      this.time += h;
      this.anim.update(h, this.ctrl, this.terrain, this.time, this.follow.aimYaw, this.follow.aimPitch, ars.pose);
      if (this.ctrl.justLanded) this.landed = Math.max(this.landed, 0.3 + this.ctrl.landIntensity);
    }
    this.horde.pushPlayer(this.ctrl.pos);
    this.rig.root.updateMatrixWorld(true);
    this.scarf.update(Math.max(dt, 1e-4), this.time);

    for (const s of this.anim.steps) {
      this.env.addFootprint(s);
      this.foley.step(s.strength, s.side);
    }
    this.anim.steps.length = 0;

    this.follow.update(raw, this.ctrl, this.anim, this.terrain, {
      ads: ars.armed ? this.anim.adsW : 0,
      zoom: ars.def ? ars.def.zoom : 1,
      scope: this.follow.fpW > 0.6 && ars.armed ? 0 : ars.scopeW,
    });
    // shots resolve after the camera so the ray passes exactly through the crosshair
    this.cam.updateMatrixWorld();
    // ---- first-person: reference weapon system + chest bodycam
    const fpsView = this.follow.fpW > 0.6 && ars.armed;
    if (fpsView) this.cam.layers.disable(1);
    else this.cam.layers.enable(1);
    this.fps.visible = fpsView;
    const right = -Math.cos(this.follow.aimYaw) * this.ctrl.vel.x + Math.sin(this.follow.aimYaw) * this.ctrl.vel.z;
    this.fps.update(dt, raw, {
      slot: ars.slot,
      adsHeld: ars.ads,
      reload: ars.reloadK,
      ammo: ars.slot >= 0 ? ars.ammo[ars.slot] : 0,
      sprinting: this.ctrl.sprinting && this.ctrl.speed > 4,
      speed: this.ctrl.speed,
      grounded: this.ctrl.grounded,
      crouch: this.anim.crouchBlend,
      lookX: f.lookX,
      lookY: f.lookY,
      landed: this.landed,
    }, this.cam);
    this.landed = 0;
    const bodycam = fpsView && this.fpsCam === 'BODYCAM';
    if (bodycam) {
      this.fps.applyCamera(this.cam, this.ctrl.pos.x, this.ctrl.pos.y, this.ctrl.pos.z, this.follow.aimYaw, this.follow.aimPitch, this.ctrl.speed, this.ctrl.grounded, right / 6, this.follow.trauma * 0.6, raw);
    }
    ars.muzzleOverride = fpsView ? this.fps.muzzleWorld(this.cam, this.tmpV) : null;
    this.barrels.update(dt, this.ctrl.pos);
    this.horde.blood.camPos.copy(this.cam.position);
    // ---- zombies: AI, locomotion, ragdoll physics, gore
    this.horde.update(this.hud.engaged ? dt : 0, {
      pos: this.ctrl.pos,
      vel: this.ctrl.vel,
      sprinting: this.ctrl.sprinting,
      crouching: this.ctrl.crouching,
      alive: !this.dead,
    }, this.cam, this.renderer.domElement.height);
    const kills0 = ars.kills;
    const kick = ars.shoot(this.cam, this.follow.camDist);
    if (ars.kills - kills0 >= 2) {
      // one round, several bodies: longer bullet-time + banner
      this.hud.multiKill = ars.kills - kills0;
      this.hud.multiAge = 0;
      this.dramaT = Math.max(this.dramaT, 1.1);
      this.follow.addTrauma(0.2);
    }
    if (kick > 0) {
      // the reference engine owns first-person recoil (viewmodel kick + camera punch + trauma)
      this.fps.fire(ars.slot, ars.ammo[ars.slot], this.cam, this.ctrl.vel);
      if (!bodycam) {
        this.follow.kick(kick);
        this.follow.addTrauma(ars.slot === 2 ? 0.22 : 0.05);
      }
      if (ars.killAge === 0) {
        const head = ars.headAge === 0;
        this.hitStop = Math.max(this.hitStop, ars.slot === 2 ? 0.1 : head ? 0.09 : 0.05);
        this.follow.addTrauma(head ? 0.18 : 0.08);
        if (ars.slot === 2) this.dramaT = 0.8;
      }
      // heavy impacts: freeze-frame + camera punch sell the knockback
      if (ars.zPower > 0) {
        this.pImpactAge = 0;
        this.pImpactPower = ars.zPower;
      }
      if (ars.zPower >= 2.5) {
        this.hitStop = Math.max(this.hitStop, 0.13);
        this.follow.addTrauma(0.24);
      } else if (ars.zPower > 0) this.follow.addTrauma(0.03);
    }
    // ---- teammate: think, move, aim, fire (after the horde so it sees this frame's bodies)
    const B = this.buddy;
    B.update(dt, { pos: this.ctrl.pos, yaw: this.follow.yaw, alive: !this.dead }, this.hud.engaged);
    this.horde.pushPlayer(B.ctrl.pos);
    {
      const dx = B.ctrl.pos.x - this.ctrl.pos.x;
      const dz = B.ctrl.pos.z - this.ctrl.pos.z;
      const d = Math.hypot(dx, dz);
      if (d < 0.62 && d > 1e-4) {
        const nx = B.ctrl.pos.x + (dx / d) * (0.62 - d);
        const nz = B.ctrl.pos.z + (dz / d) * (0.62 - d);
        if (!this.terrain.solid(nx, nz) && Math.abs(this.terrain.height(nx, nz) - B.ctrl.pos.y) < 0.3) {
          B.ctrl.pos.x = nx;
          B.ctrl.pos.z = nz;
        }
      }
    }
    this.fps.updateFx(dt);
    ars.updateFx(dt);
    this.range.update(dt, this.time);

    // first person hides the head; the scope hides the whole body
    const scoped = ars.scopeW > 0.6;
    this.rig.root.visible = !scoped;
    this.scarf.mesh.visible = !scoped;
    this.rig.neck.visible = this.follow.fpW < 0.5;

    this.env.update(dt, this.ctrl.pos, this.time);
    if (this.gizmo.visible) this.updateGizmo();
    this.fps.renderScope(this.renderer, this.scene, this.cam);
    this.renderer.render(this.scene, this.cam);
    this.fps.render(this.renderer);

    // ---- HUD snapshot
    const hud = this.hud;
    const c = this.ctrl;
    hud.state = c.state;
    for (let i = 0; i < STATES.length; i++) hud.weights[i] = c.weights[STATES[i]];
    hud.speed = c.speed;
    hud.pace = PACE_NAMES[f.pace] ?? 'RUN';
    hud.sprinting = c.sprinting;
    hud.crouching = c.crouching;
    hud.strafing = c.strafing;
    hud.grounded = c.grounded;
    hud.phase = this.anim.phase;
    hud.contactL = this.anim.feet[0].contact;
    hud.contactR = this.anim.feet[1].contact;
    hud.cadence = this.anim.cadence;
    hud.lean = this.anim.leanOut;
    hud.bank = this.anim.bankOut;
    const def = ars.def;
    hud.armed = !!def;
    hud.slot = ars.slot;
    hud.weapon = def ? def.name : 'UNARMED';
    hud.fireMode = def ? def.mode : '';
    hud.ammo = def ? ars.ammo[ars.slot] : 0;
    hud.mag = def ? def.mag : 0;
    for (let i = 0; i < 3; i++) hud.ammoAll[i] = ars.ammo[i];
    hud.reload = ars.reloadK;
    hud.firstPerson = this.follow.firstPerson;
    hud.ads = ars.ads;
    // first person aims through the live 3D glass instead of a fullscreen overlay
    hud.scope = fpsView ? 0 : ars.scopeW;
    hud.spread = ars.spread;
    hud.hits = ars.hits;
    hud.shots = ars.shots;
    hud.lastDist = ars.lastDist;
    hud.hitAge = ars.hitAge;
    // survival
    this.hurtAge += raw;
    this.sinceHurt += dt;
    if (!this.dead && this.sinceHurt > 4) this.hp = Math.min(100, this.hp + dt * 5);
    hud.hp = this.hp;
    hud.dead = this.dead;
    hud.hurtAge = this.hurtAge;
    hud.hurtAng = this.hurtAng - this.follow.yaw;
    const H = this.horde;
    hud.kills = H.kills;
    hud.headshots = H.headshots;
    hud.limbs = H.limbs;
    hud.zAlive = H.alive;
    for (let i = 0; i < AI_STATES.length; i++) hud.zStates[i] = H.stateCounts[AI_STATES[i]] ?? 0;
    hud.killAge = ars.killAge;
    hud.headAge = ars.headAge;
    let near = 99;
    for (const z of H.zombies) if (z.active && z.alive) near = Math.min(near, z.pos.distanceTo(c.pos));
    hud.nearest = near;
    hud.aggressive = H.aggressive;
    hud.lens = H.blood.lens;
    hud.fracParts = H.fracturedParts;
    hud.multiAge += raw;
    hud.zTotal = H.bodies;
    hud.zCap = H.max;
    hud.zTarget = H.target;
    hud.fracMax = H.voronoiMax;
    {
      const B = this.buddy;
      const ba = B.arsenal;
      hud.buddyState = B.state;
      hud.buddyWeapon = ba.def ? ba.def.name : '—';
      hud.buddyAmmo = ba.slot >= 0 ? ba.ammo[ba.slot] : 0;
      hud.buddyMag = ba.def ? ba.def.mag : 0;
      hud.buddyReload = ba.reloadK;
      hud.buddyKills = B.kills;
      hud.buddyHeads = B.headshots;
      hud.buddyCallout = B.callout;
      hud.buddyCalloutAge = B.calloutAge;
      hud.buddyDist = B.ctrl.pos.distanceTo(this.ctrl.pos);
      const m = B.marker(this.tmpB).project(this.cam);
      hud.buddyOn = m.z < 1 && Math.abs(m.x) < 1.05 && Math.abs(m.y) < 1.05;
      hud.buddyX = (m.x + 1) * 50;
      hud.buddyY = (1 - m.y) * 50;
      hud.autoReload = ars.autoReloading && ars.reloadK > 0;
    }
    hud.debris = H.debris.active;
    hud.stains = H.blood.stats.stains;
    this.pImpactAge += raw;
    hud.impactAge = this.pImpactAge;
    hud.impactPower = this.pImpactPower;
    this.blastAge += raw;
    hud.blastAge = this.blastAge;
  };

  private updateGizmo() {
    const c = this.ctrl;
    for (let i = 0; i < 2; i++) {
      const f = this.anim.feet[i];
      this.gTargets[i].visible = f.mode === 1;
      this.gTargets[i].position.copy(f.target).y += 0.03;
      this.gPlants[i].visible = f.mode === 0;
      this.gPlants[i].position.set(f.pos.x, f.pos.y + 0.02, f.pos.z);
    }
    const o = this.v.set(c.pos.x, c.pos.y + 0.05, c.pos.z);
    this.gVel.position.copy(o);
    this.gVel.visible = c.speed > 0.1;
    if (c.speed > 0.1) {
      this.gVel.setDirection(new THREE.Vector3(c.vel.x, 0, c.vel.z).normalize());
      this.gVel.setLength(0.4 + c.speed * 0.22, 0.18, 0.1);
    }
    this.gIntent.position.copy(o);
    this.gIntent.visible = c.hasInput;
    if (c.hasInput) {
      this.gIntent.setDirection(new THREE.Vector3(Math.sin(c.moveYaw), 0, Math.cos(c.moveYaw)));
      this.gIntent.setLength(0.9, 0.18, 0.1);
    }
  }

  toggleCamera() {
    this.follow.toggleMode();
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.ro.disconnect();
    this.input.dispose();
    this.renderer.dispose();
  }
}
