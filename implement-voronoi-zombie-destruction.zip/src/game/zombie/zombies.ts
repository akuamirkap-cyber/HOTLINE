import * as THREE from 'three';
import type { Terrain } from '../terrain';
import type { Foley } from '../audio';
import { Spring, angleDiff, clamp, clamp01, damp, lerp, smoothstep, wrapAngle } from '../math';
import { FlowField } from './nav';
import { soundEngine } from '../ref/audio';
import { Blood } from './blood';
import { Debris } from './fragments';
import { Palette, ZombieRenderer, type LostCell } from './zombieMesh';
import {
  GETUP_PRONE,
  GETUP_SUPINE,
  INV_MASS,
  JOINTS,
  Key,
  L,
  NP,
  P,
  PartId,
  Pose,
  RADIUS,
  SEGS,
  SEVER,
  buildConstraints,
  fk,
  ik2,
  makePose,
  sampleKeys,
} from './skeleton';

export const AI_STATES = [
  'IDLE',
  'WANDERING',
  'PLAYER_DETECTED',
  'INVESTIGATING',
  'CHASING',
  'APPROACHING',
  'ATTACKING',
  'STAGGERED',
  'KNOCKED_DOWN',
  'GETTING_UP',
  'DEAD',
] as const;
export type AIState = (typeof AI_STATES)[number];
type Behaviour = 'IDLE' | 'WANDERING' | 'PLAYER_DETECTED' | 'INVESTIGATING' | 'CHASING' | 'APPROACHING' | 'ATTACKING';
export const BODY_STATES = [
  'STANDING',
  'STAGGERED',
  'LOSING_BALANCE',
  'FALLING',
  'GROUND_IMPACT',
  'RAGDOLL_ON_GROUND',
  'RECOVERING',
  'GETTING_UP',
  'STANDING_AGAIN',
  'CRAWLING',
] as const;
export type BodyState = (typeof BODY_STATES)[number];
type Kind = 'shambler' | 'lurcher' | 'runner';

export interface ShotSpec {
  dmg: number;
  power: number;
  impulse: number;
  pen: number;
  explode: number;
  /** whole-body launch speed (m/s) when the round takes a zombie off its feet */
  knock?: number;
  lift?: number;
  spin?: number;
  /** root shove multiplier for living zombies */
  push?: number;
  /** Voronoi fracture radius (m), strength and exit-wound multiplier */
  frag?: number;
  fragK?: number;
  exit?: number;
  /** anti-materiel class: every hit blows the body off its feet */
  heavy?: boolean;
}
export interface ZHit {
  z: Zombie;
  seg: number;
  t: number;
  point: THREE.Vector3;
}
export interface PlayerInfo {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  sprinting: boolean;
  crouching: boolean;
  alive: boolean;
}

const CS = buildConstraints();
const G = 11; // slightly heavy: bodies drop with weight instead of floating
const H = 1 / 120; // physics step
const r = Math.random;
const pick = <T>(a: T[]) => a[(r() * a.length) | 0];

const ARM: number[][] = [
  [P.LSH2, P.LEL, P.LEL2, P.LWR, P.LHA],
  [P.RSH2, P.REL, P.REL2, P.RWR, P.RHA],
];
const LEG: number[][] = [
  [P.LHIP2, P.LKN, P.LKN2, P.LAN, P.LTO],
  [P.RHIP2, P.RKN, P.RKN2, P.RAN, P.RTO],
];
const HEADP: number[] = [P.HEAD, P.NECK2];
const UPPER: number[] = [P.CHEST, P.NECK, P.LSH, P.RSH];
const LOWER: number[] = [P.SPINE, P.PELVIS, P.LHIP, P.RHIP];
const TORSO: number[] = [...UPPER, ...LOWER];

const SKIN = ['#b9bfa6', '#a7b09a', '#c4c2b0', '#9faa9c', '#b8b3a3', '#a9a28f', '#8f9a8c', '#c9c6bd', '#a3a9a8', '#b5ab95'];
const SHIRT = ['#6b4a3a', '#3e4a5c', '#5c5f4a', '#7a7468', '#4a3f3a', '#8a7f6a', '#3d5248', '#6e3b3b', '#b0a99a', '#2f3136', '#5a6b7a', '#7b6d4f', '#8d8a80', '#4d2f2f'];
const PANTS = ['#3b4a63', '#2c3445', '#7a6f55', '#26272b', '#4f5257', '#4a3b2e', '#3a4150'];
const SHOES = ['#2a2420', '#3a3a3a', '#5a4a3a', '#b8b2a5', '#1f1f22'];
const HAIR = ['#2a2420', '#4a3a2a', '#151515', '#6a5a4a', '#8a8070', '#3a2a1a', '#a39a8a'];

class Foot {
  x = 0;
  y = 0;
  z = 0;
  yaw = 0;
  pitch = 0;
  swing = false;
  u = 0;
  dur = 0.3;
  fx = 0;
  fy = 0;
  fz = 0;
  fyaw = 0;
  jx = 0;
  jz = 0;
  lastPh = 0;
}

const _v = new THREE.Vector3();
const _w = new THREE.Vector3();
const _bv = new THREE.Vector3();
const _cf = new THREE.Vector3();
/** max step a zombie body can take (0.36 m stair = 2×0.18; +1 cm so float rounding never blocks a real step) */
const STEP_TOL = 0.37;
const PROBES: [number, number][] = [[0.45, 0], [-0.45, 0], [0, 0.45], [0, -0.45], [0.315, 0.315], [-0.315, 0.315], [0.315, -0.315], [-0.315, -0.315]];
const SEP_N = 210; // separation grid: 0.8 m cells over ±84 m
const SEP_C = 0.8;
const SEP_O = 84;
const COL_N = 84; // body-body broad phase: 2 m cells over ±84 m
const COL_C = 2;
const fx0 = (z: { yaw: number }) => Math.sin(z.yaw);
const fz0 = (z: { yaw: number }) => Math.cos(z.yaw);
const steerPt = { x: 0, z: 0 };

export class Zombie {
  slot: number;
  active = false;
  alive = true;
  kind: Kind = 'shambler';
  s = 1;
  speedMax = 1;
  turnRate = 2;
  lean = 0.3;
  headDroop = 0.2;
  headTilt = 0;
  shAsym = 0;
  armMode = 0;
  reachSide = 0;
  limpSide = -1;
  limp = 0;
  sway = 0.04;
  swayF = 1;
  seed = 0;
  toeOut = [0.2, 0.2];
  armSwing = [0.3, 0.3];
  kneeOut = 0;
  hairStyle = 0;

  pos = new THREE.Vector3();
  rootY = 0;
  yaw = 0;
  speed = 0;
  vel = new THREE.Vector3();
  push = new THREE.Vector3();
  phase = 0;
  feet = [new Foot(), new Foot()];

  beh: Behaviour = 'IDLE';
  behT = 0;
  body: BodyState = 'STANDING';
  bodyT = 0;
  known = new THREE.Vector3();
  hasKnown = false;
  wander = new THREE.Vector3();
  perceiveT = 0;
  canSee = false;
  dist = 99;
  reactDur = 0.5;
  attackT = 0;
  attackHit = false;
  attackCd = 0;
  groanT = 3;
  slowT = 0;
  idleDur = 3;

  hp = 100;
  limbHp = { lArm: 38, rArm: 38, lLeg: 52, rLeg: 52 };
  severed = new Set<PartId>();
  crawler = false;
  hidden = 0;
  balance = 1;
  deadT = 0;
  segDmg = new Float32Array(SEGS.length);

  // reaction layer
  hitLeanX = new Spring(9, 0.45);
  hitLeanZ = new Spring(9, 0.45);
  hitTwist = new Spring(10, 0.4);
  headP = new Spring(7, 0.32);
  headY = new Spring(7, 0.35);
  headR = new Spring(6, 0.3);
  buckle = [new Spring(8, 0.5), new Spring(8, 0.5)];
  lunge = new Spring(14, 0.7);
  reach = [0, 0];
  grabW = 0;
  wallW = 0;
  jerkT = 1;
  style = 0;
  flankSide = 1;
  agg = 0;
  leapT = 0;
  leapCd = 2;
  trailAcc = 0;
  lookYaw = 0;
  fallDir = new THREE.Vector3();
  staggerDur = 0.5;
  wobble = 0;
  launchT = 0; // airborne after a launch: low drag, sliding contact
  hitStack = 0; // rounds landed in quick succession
  craters: number[] = []; // segments with open Voronoi craters (they keep bleeding)
  dripT = 0;
  bleedT = 0; // fresh wound: arterial pumping
  bleedSeg = -1;
  // animation LOD
  animAcc = 1;
  animDt = 1 / 60;
  posed = true;
  poseX = 0;
  poseY = 0;
  poseZ = 0;
  shX = 0;
  shY = 0;
  shZ = 0;
  pinFull = false;
  drawnAsleep = false;
  // World-War-Z frenzy (aggressive mode)
  frenzied = false;
  baseKind: Kind = 'shambler';
  baseSpeed = 1;
  baseTurn = 2;
  baseLean = 0.3;
  // hybrid integrity (Voronoi damage → gameplay)
  armOut = [0, 0];
  dazeT = 0;
  sinkT = 0; // retiring corpse: sinks into the snow, then frees its slot / Voronoi parts
  pathOk = true; // straight line to the player is walkable (no wall / rail / level change)

  // physics
  pts = new Float32Array(NP * 3);
  prev = new Float32Array(NP * 3);
  tgt = new Float32Array(NP * 3);
  lastTgt = new Float32Array(NP * 3);
  tv = new Float32Array(NP * 3);
  pin = new Float32Array(NP).fill(1);
  kick = new Float32Array(NP * 3);
  ghostTo = new Int8Array(NP).fill(-1);
  pinK = new Float32Array(NP);
  wgt = new Float32Array(NP);
  detached = new Uint8Array(NP);
  frozen = new Uint8Array(NP);
  restT = new Float32Array(NP);
  cOn = new Uint8Array(CS.n).fill(1);
  jOn = new Uint8Array(JOINTS.length).fill(1);
  physics = false;
  asleep = false;
  quietT = 0;
  kinetic = 0;
  minY = 0;
  near: number[] = [];
  blendPts = new Float32Array(NP * 3);
  blendW = 0;
  stumps: { at: number; from: number; r: number; spurt: number; drip: number; dripT: number }[] = [];
  bbMin = new THREE.Vector3();
  bbMax = new THREE.Vector3();

  // get-up
  keys: Key[] = GETUP_PRONE;
  getT = 0;
  frameYaw = 0;
  frameX = 0;
  frameZ = 0;
  recoverDur = 1;
  settleT = 1.5;
  impactDone = false;
  crawlPh = 0;

  pose: Pose = makePose();

  constructor(slot: number) {
    this.slot = slot;
  }

  get state(): AIState {
    if (!this.alive) return 'DEAD';
    switch (this.body) {
      case 'STAGGERED':
        return 'STAGGERED';
      case 'LOSING_BALANCE':
      case 'FALLING':
      case 'GROUND_IMPACT':
      case 'RAGDOLL_ON_GROUND':
      case 'RECOVERING':
        return 'KNOCKED_DOWN';
      case 'GETTING_UP':
      case 'STANDING_AGAIN':
        return 'GETTING_UP';
      default:
        return this.beh;
    }
  }
  get upright() {
    return this.alive && (this.body === 'STANDING' || this.body === 'STAGGERED' || this.body === 'STANDING_AGAIN');
  }
}

/**
 * The horde: AI, navigation, procedural undead locomotion, a powered
 * (animation-driven) ragdoll per zombie, hit reactions, dismemberment and
 * knock-down / get-up recovery.
 */
export class Horde {
  /** hard cap: never more than 1000 bodies (alive + corpses) */
  readonly max = 1000;
  target = 1000;
  zombies: Zombie[] = [];
  flow: FlowField;
  blood: Blood;
  debris: Debris;
  private lost: LostCell[] = [];
  private sepHead = new Int32Array(SEP_N * SEP_N);
  private sepNext = new Int32Array(2048);
  private colHead = new Int32Array(COL_N * COL_N);
  private dominoBudget = 8;
  private camX = 0;
  private camZ = 0;
  private camFx = 0;
  private camFz = 1;
  private sepT = 0;
  private sepX = new Float32Array(1024);
  private sepZ = new Float32Array(1024);
  private colNext = new Int32Array(2048);
  /** last zombie impact (read by the camera for hit-stop / shake) */
  impactAge = 9;
  impactPower = 0;
  private render: ZombieRenderer;
  private terrain: Terrain;
  private foley: Foley;
  private acc = 0;
  private time = 0;
  private spawnT = 0;
  private contagionT = 0;
  private groanBudget = 0;
  aggressive = false;
  private collideT = 0;
  kills = 0;
  headshots = 0;
  limbs = 0;
  onPlayerHit: (dmg: number, fromX: number, fromZ: number) => void = () => {};
  stateCounts: Record<string, number> = {};

  constructor(scene: THREE.Scene, terrain: Terrain, foley: Foley) {
    this.terrain = terrain;
    this.foley = foley;
    this.flow = new FlowField(terrain);
    this.blood = new Blood(scene, terrain);
    this.render = new ZombieRenderer(scene, this.max);
    this.debris = new Debris(scene, terrain, this.blood, this.render.parts);
    this.render.onBudget = () => this.budget();
    for (let i = 0; i < this.max; i++) this.zombies.push(new Zombie(i));
    for (const s of AI_STATES) this.stateCounts[s] = 0;
  }

  /** Fill the map with the horde around the player. */
  populate(px: number, pz: number) {
    this.flow.update(0, px, pz, true);
    for (const z of this.zombies) {
      z.active = false;
      this.render.hide(z.slot);
      this.render.resetDamage(z.slot);
    }
    for (let i = 0; i < this.target; i++) {
      const z = this.zombies[i];
      this.spawn(z, px, pz, 16, 68, r() < 0.35);
    }
    this.kills = this.headshots = this.limbs = 0;
    this.debris.clear();
  }

  private spawnPoint(px: number, pz: number, rMin: number, rMax: number, out: THREE.Vector3) {
    for (let tries = 0; tries < 60; tries++) {
      const a = r() * Math.PI * 2;
      const d = rMin + Math.sqrt(r()) * (rMax - rMin);
      const x = px + Math.sin(a) * d;
      const z = pz + Math.cos(a) * d;
      const k = this.flow.idx(x, z);
      if (k < 0 || !this.flow.walk[k] || !isFinite(this.flow.dist[k])) continue;
      if (Math.hypot(x, z) > this.terrain.bound - 3) continue;
      const y = this.terrain.height(x, z);
      if (this.blocked(x, z, y)) continue;
      out.set(x, y, z);
      return true;
    }
    out.set(px + rMin, this.terrain.height(px + rMin, pz), pz);
    return false;
  }

  spawn(z: Zombie, px: number, pz: number, rMin: number, rMax: number, aware: boolean) {
    this.spawnPoint(px, pz, rMin, rMax, z.pos);
    z.active = true;
    z.alive = true;
    const k = r();
    z.kind = k < 0.22 ? 'runner' : k < 0.48 ? 'lurcher' : 'shambler';
    z.s = 0.92 + r() * 0.16;
    if (z.kind === 'runner') {
      z.speedMax = 4.2 + r() * 1.3;
      z.turnRate = 3.4;
      z.lean = 0.5 + r() * 0.22;
    } else if (z.kind === 'lurcher') {
      z.speedMax = 1.9 + r() * 0.9;
      z.turnRate = 2.5;
      z.lean = 0.32 + r() * 0.15;
    } else {
      z.speedMax = 0.7 + r() * 0.55;
      z.turnRate = 1.7;
      z.lean = 0.2 + r() * 0.22;
    }
    z.headDroop = 0.12 + r() * 0.38;
    z.headTilt = (r() - 0.5) * 0.7;
    z.shAsym = (r() - 0.5) * 0.09;
    z.armMode = z.kind === 'runner' ? 3 : r() < 0.45 ? 0 : r() < 0.6 ? 1 : 2;
    z.reachSide = r() < 0.5 ? 0 : 1;
    z.limpSide = r() < 0.38 ? (r() < 0.5 ? 0 : 1) : -1;
    z.limp = 0.4 + r() * 0.6;
    z.sway = 0.025 + r() * 0.05;
    z.swayF = 0.5 + r() * 0.7;
    z.seed = r() * 100;
    z.toeOut = [0.08 + r() * 0.35, 0.08 + r() * 0.35];
    z.armSwing = [0.15 + r() * 0.45, 0.15 + r() * 0.45];
    z.kneeOut = (r() - 0.5) * 0.6;
    z.hairStyle = (r() * 3) | 0;
    z.hp = z.kind === 'runner' ? 85 : 110;
    z.limbHp = { lArm: 38, rArm: 38, lLeg: 52, rLeg: 52 };
    z.severed.clear();
    z.crawler = false;
    z.hidden = 0;
    z.balance = 1;
    z.deadT = 0;
    z.segDmg.fill(0);
    z.stumps.length = 0;
    z.cOn.fill(1);
    z.jOn.fill(1);
    z.detached.fill(0);
    z.frozen.fill(0);
    z.kick.fill(0);
    z.ghostTo.fill(-1);
    z.launchT = 0;
    z.hitStack = 0;
    z.craters.length = 0;
    z.dripT = 0;
    z.bleedT = 0;
    z.bleedSeg = -1;
    z.animAcc = 1;
    z.pinFull = false;
    z.drawnAsleep = false;
    z.armOut[0] = z.armOut[1] = 0;
    z.dazeT = 0;
    z.sinkT = 0;
    z.frenzied = false;
    z.style = z.kind === 'runner' ? (r() < 0.5 ? 0 : 1) : r() < 0.3 ? 0 : r() < 0.55 ? 1 : r() < 0.8 ? 2 : 3;
    z.flankSide = r() < 0.5 ? 1 : -1;
    z.leapT = 0;
    z.leapCd = 1 + r() * 3;
    z.agg = this.aggressive ? 1 : 0;
    z.pin.fill(1);
    z.asleep = false;
    z.physics = false;
    z.blendW = 0;
    z.yaw = r() * Math.PI * 2;
    z.speed = 0;
    z.vel.set(0, 0, 0);
    z.push.set(0, 0, 0);
    z.phase = r();
    z.rootY = z.pos.y;
    z.body = 'STANDING';
    z.bodyT = 0;
    z.beh = aware ? 'INVESTIGATING' : r() < 0.5 ? 'IDLE' : 'WANDERING';
    z.behT = 0;
    z.idleDur = 2 + r() * 5;
    z.hasKnown = aware;
    z.known.set(px, 0, pz);
    z.wander.copy(z.pos);
    z.perceiveT = r() * 0.3;
    z.groanT = 2 + r() * 8;
    z.attackCd = 0;
    z.reach = [0, 0];
    for (const sp of [z.hitLeanX, z.hitLeanZ, z.hitTwist, z.headP, z.headY, z.headR, z.lunge, ...z.buckle]) sp.reset(0);
    const lx = Math.cos(z.yaw);
    const lz = -Math.sin(z.yaw);
    z.feet.forEach((f, i) => {
      const side = i === 0 ? 1 : -1;
      f.x = z.pos.x + lx * side * 0.12 * z.s;
      f.z = z.pos.z + lz * side * 0.12 * z.s;
      f.y = this.terrain.height(f.x, f.z);
      f.yaw = z.yaw + side * z.toeOut[i];
      f.swing = false;
      f.lastPh = 0;
    });
    const pal: Palette = {
      skin: new THREE.Color(pick(SKIN)),
      shirt: new THREE.Color(pick(SHIRT)),
      sleeve: new THREE.Color(),
      pants: new THREE.Color(pick(PANTS)),
      shoes: new THREE.Color(pick(SHOES)),
      hair: new THREE.Color(pick(HAIR)),
      hairStyle: z.hairStyle,
    };
    pal.sleeve.copy(r() < 0.55 ? pal.shirt : pal.skin);
    if (this.aggressive) this.frenzy(z, true);
    this.render.setPalette(z.slot, pal);
    this.render.resetDamage(z.slot);
    this.preDamage(z);
    // settle a first pose so physics starts from a valid skeleton
    this.animate(z, 1 / 60, null);
    z.pts.set(z.tgt);
    z.prev.set(z.tgt);
    z.lastTgt.set(z.tgt);
  }

  // ======================================================================
  update(dt: number, pl: PlayerInfo, cam: THREE.PerspectiveCamera, viewH: number) {
    this.time += dt;
    this.impactAge += dt;
    this.render.setTime(this.time);
    this.flow.update(dt, pl.pos.x, pl.pos.z);
    this.groanBudget = Math.min(2, this.groanBudget + dt * 0.8);

    const cx = cam.position.x;
    const cz = cam.position.z;
    cam.getWorldDirection(_cf);
    this.camX = cx;
    this.camZ = cz;
    this.camFx = _cf.x;
    this.camFz = _cf.z;
    for (const z of this.zombies) {
      if (!z.active) continue;
      if (z.alive) this.think(z, dt, pl);
      this.locomote(z, dt, pl);
      this.bodyLogic(z, dt);
      // animation LOD: distant / off-screen walkers re-pose at 30, 20 or 15 Hz (the posed body still moves every frame)
      const dx = z.pos.x - cx;
      const dz = z.pos.z - cz;
      const d2 = dx * dx + dz * dz;
      let every = d2 > 56 * 56 ? 4 : d2 > 34 * 34 ? 3 : d2 > 15 * 15 ? 2 : 1;
      if (d2 > 10 * 10 && dx * _cf.x + dz * _cf.z < 0) every = 4;
      z.animAcc += dt;
      const throttle = every > 1 && z.alive && z.upright && !z.physics && z.blendW <= 0;
      if (!throttle || z.animAcc >= every / 60 - 1e-4 || z.animAcc > 0.09) {
        this.animate(z, z.animAcc, pl);
        z.animDt = Math.max(z.animAcc, 1e-3);
        z.animAcc = 0;
        z.posed = true;
        z.poseX = z.pos.x;
        z.poseY = z.rootY;
        z.poseZ = z.pos.z;
      } else z.posed = false;
    }
    // crowd separation at 30 Hz (correction scales with the step, so the swarm behaves the same)
    this.sepT += dt;
    if (this.sepT >= 1 / 31) {
      this.separate(this.sepT, pl);
      this.sepT = 0;
    }
    this.contagion(dt);

    // ---- physics (fixed 120 Hz)
    this.acc = Math.min(this.acc + dt, 0.05);
    for (const z of this.zombies) {
      if (!z.active) continue;
      this.prepPhysics(z, dt);
    }
    while (this.acc >= H) {
      this.acc -= H;
      for (const z of this.zombies) if (z.active && z.physics && !z.asleep) this.step(z);
    }
    this.dominoBudget = Math.min(10, this.dominoBudget + dt * 12);
    this.collideT -= dt;
    if (this.collideT <= 0) {
      this.collideT = 1 / 60;
      this.collide();
    }
    for (const z of this.zombies) {
      if (!z.active) continue;
      if (!z.physics || z.asleep) {
        if (!z.asleep) {
          if (z.posed) z.pts.set(z.tgt);
          else {
            // between LOD poses: carry the posed body along with the root
            const sx = z.pos.x - z.poseX;
            const sy = z.rootY - z.poseY;
            const sz = z.pos.z - z.poseZ;
            z.poseX = z.pos.x;
            z.poseY = z.rootY;
            z.poseZ = z.pos.z;
            for (let i = 0; i < NP * 3; i += 3) {
              z.pts[i] += sx;
              z.pts[i + 1] += sy;
              z.pts[i + 2] += sz;
              z.tgt[i] += sx;
              z.tgt[i + 1] += sy;
              z.tgt[i + 2] += sz;
            }
            z.shX = sx;
            z.shY = sy;
            z.shZ = sz;
          }
        }
      }
      this.post(z, dt);
    }
    // retiring corpses sink into the snow, then free their slot
    for (const z of this.zombies) {
      if (!z.active || z.sinkT <= 0) continue;
      z.sinkT -= dt;
      const d = 0.6 * dt;
      for (let i = 1; i < NP * 3; i += 3) {
        z.pts[i] -= d;
        z.prev[i] -= d;
      }
      z.drawnAsleep = false;
      if (z.sinkT <= 0) {
        z.sinkT = 0;
        z.active = false;
        this.render.hide(z.slot);
        this.render.resetDamage(z.slot);
      }
    }
    if (this.render.fracUsed > this.render.maxFrac + 16) this.budget();
    // procedural crumbling: weakened plates give way (cascading), each as its exact chunk
    this.lost.length = 0;
    this.render.crumble(this.time, this.lost);
    if (this.lost.length) this.shed(this.lost, null, 0.9, 12);

    this.respawn(dt, pl);
    this.spurts(dt);
    this.blood.update(dt, cam, viewH);
    this.debris.update(dt);
    this.draw();

    for (const s of AI_STATES) this.stateCounts[s] = 0;
    for (const z of this.zombies) if (z.active && (z.alive || z.deadT < 8)) this.stateCounts[z.state]++;
  }

  /** body parts currently rendered with Voronoi fracture geometry */
  get fracturedParts() {
    return this.render.fracturedParts;
  }

  get alive() {
    let n = 0;
    for (const z of this.zombies) if (z.active && z.alive) n++;
    return n;
  }

  // ============================================================ perception / AI
  private los(z: Zombie, pl: PlayerInfo) {
    const ox = z.pos.x;
    const oy = z.rootY + 1.6 * z.s;
    const oz = z.pos.z;
    const dx = pl.pos.x - ox;
    const dy = pl.pos.y + 1.3 - oy;
    const dz = pl.pos.z - oz;
    const d = Math.hypot(dx, dy, dz);
    if (d < 1.5) return true;
    const t = this.terrain.raycast(ox, oy, oz, dx / d, dy / d, dz / d, 0.3, d);
    return t >= d - 0.4;
  }

  private setBeh(z: Zombie, b: Behaviour) {
    if (z.beh === b) return;
    z.beh = b;
    z.behT = 0;
    if (b === 'PLAYER_DETECTED') {
      z.reactDur = (z.kind === 'runner' ? 0.25 + r() * 0.3 : 0.5 + r() * 0.7) * (this.aggressive ? 0.35 : 1);
      z.headY.v += (r() - 0.5) * 4;
      z.headP.v -= 3; // head snaps up toward the noise
      if (z.dist < 30 && this.groanBudget > 0.5) {
        this.groanBudget -= 0.5;
        if (z.kind === 'runner') this.foley.scream(z.dist);
        else this.foley.groan(z.dist, z.s);
      }
    }
    if (b === 'ATTACKING') {
      z.attackT = 0;
      z.attackHit = false;
    }
  }

  private alert(z: Zombie, x: number, zz: number) {
    z.known.set(x, 0, zz);
    z.hasKnown = true;
    if (z.beh === 'IDLE' || z.beh === 'WANDERING') this.setBeh(z, 'PLAYER_DETECTED');
    else if (z.beh === 'INVESTIGATING') this.setBeh(z, 'CHASING');
  }

  /** Gunshots and loud noises draw the horde. */
  noise(x: number, zz: number, radius: number) {
    for (const z of this.zombies) {
      if (!z.active || !z.alive) continue;
      const d = Math.hypot(z.pos.x - x, z.pos.z - zz);
      if (d < radius) this.alert(z, x, zz);
    }
  }

  private think(z: Zombie, dt: number, pl: PlayerInfo) {
    z.behT += dt;
    const dx = pl.pos.x - z.pos.x;
    const dz = pl.pos.z - z.pos.z;
    z.dist = Math.hypot(dx, dz);
    z.pathOk = true;
    {
      // walls, railings or another level in between (tower roof): what matters is the walking distance
      const k = this.flow.idx(z.pos.x, z.pos.z);
      if (k >= 0 && isFinite(this.flow.dist[k])) {
        const pd = this.flow.dist[k];
        if (pd > z.dist * 1.25 + 1.5 || Math.abs(pl.pos.y - z.rootY) > 1.2) {
          z.dist = Math.max(z.dist, pd);
          z.pathOk = false;
        }
      }
    }
    z.perceiveT -= dt;
    if (z.perceiveT <= 0) {
      z.perceiveT = 0.2 + r() * 0.2;
      const toP = Math.atan2(dx, dz);
      const inFov = Math.abs(angleDiff(toP, z.yaw)) < 1.3;
      z.canSee = pl.alive && z.dist < 34 && (inFov || z.dist < 6) && this.los(z, pl);
      const hear = pl.alive && z.dist < (pl.sprinting ? 15 : pl.crouching ? 2.5 : 7);
      if (z.canSee || hear) {
        z.known.set(pl.pos.x, 0, pl.pos.z);
        z.hasKnown = true;
        if (z.beh === 'IDLE' || z.beh === 'WANDERING') this.setBeh(z, 'PLAYER_DETECTED');
      }
    }
    if (this.aggressive && pl.alive && z.dist < 95) {
      // aggressive horde: they always know where you are
      z.known.set(pl.pos.x, 0, pl.pos.z);
      z.hasKnown = true;
      if (z.beh === 'IDLE' || z.beh === 'WANDERING') this.setBeh(z, 'PLAYER_DETECTED');
      else if (z.beh === 'INVESTIGATING') this.setBeh(z, 'CHASING');
    }
    if (!pl.alive && (z.beh === 'CHASING' || z.beh === 'APPROACHING' || z.beh === 'ATTACKING')) this.setBeh(z, 'WANDERING');

    z.groanT -= dt;
    if (z.groanT <= 0) {
      z.groanT = 4 + r() * 9;
      if (z.dist < 24 && this.groanBudget > 1) {
        this.groanBudget -= 1;
        this.foley.groan(z.dist, z.s);
      }
    }

    const reachD = 0.95 * z.s + 0.1 + (this.aggressive ? 0.12 : 0);
    const atkK = this.aggressive ? 0.72 : 1;
    const dy = Math.abs(pl.pos.y - z.rootY);
    switch (z.beh) {
      case 'IDLE':
        if (z.behT > z.idleDur) {
          const a = r() * Math.PI * 2;
          const d = 3 + r() * 8;
          const wx = z.pos.x + Math.sin(a) * d;
          const wz = z.pos.z + Math.cos(a) * d;
          const k = this.flow.idx(wx, wz);
          if (k >= 0 && this.flow.walk[k]) {
            z.wander.set(wx, 0, wz);
            this.setBeh(z, 'WANDERING');
          } else z.behT = z.idleDur - 0.5;
        }
        break;
      case 'WANDERING':
        if (Math.hypot(z.wander.x - z.pos.x, z.wander.z - z.pos.z) < 0.8 || z.behT > 14) {
          z.idleDur = 2 + r() * 6;
          this.setBeh(z, 'IDLE');
        }
        break;
      case 'PLAYER_DETECTED':
        if (z.behT > z.reactDur) this.setBeh(z, z.kind === 'runner' || z.dist < 16 || z.canSee ? 'CHASING' : 'INVESTIGATING');
        break;
      case 'INVESTIGATING':
        if ((z.canSee && z.dist < 24) || z.behT > 9 || z.dist < 10) this.setBeh(z, 'CHASING');
        break;
      case 'CHASING':
        if (z.dist < 4) this.setBeh(z, 'APPROACHING');
        break;
      case 'APPROACHING':
        if (z.dist > 5.5) this.setBeh(z, 'CHASING');
        else if (z.dist < reachD && dy < 0.9 && z.attackCd <= 0 && z.upright && pl.alive) this.setBeh(z, 'ATTACKING');
        break;
      case 'ATTACKING': {
        z.attackT += dt;
        const hitAt = (z.kind === 'runner' ? 0.38 : 0.55) * atkK;
        if (!z.attackHit && z.attackT > hitAt) {
          z.attackHit = true;
          z.lunge.v += 9;
          if (z.dist < reachD + 0.4 && dy < 1 && z.upright && pl.alive) {
            const armL = !(z.severed.has('lArm') || z.severed.has('lFore')) && !z.armOut[0];
            const armR = !(z.severed.has('rArm') || z.severed.has('rFore')) && !z.armOut[1];
            const arms = (armL ? 1 : 0) + (armR ? 1 : 0);
            this.onPlayerHit((z.kind === 'runner' ? 6 : 9) * (arms === 2 ? 1 : arms === 1 ? 0.65 : 0.3), z.pos.x, z.pos.z);
          }
        }
        if (z.attackT > (z.kind === 'runner' ? 0.85 : 1.2) * atkK) {
          z.attackCd = (0.5 + r() * 0.7) * (this.aggressive ? 0.4 : 1);
          this.setBeh(z, 'APPROACHING');
        }
        break;
      }
    }
    z.attackCd -= dt;
    if (z.crawler && z.beh === 'ATTACKING' && z.body !== 'CRAWLING') this.setBeh(z, 'APPROACHING');
  }

  // ================================================================ locomotion
  /** Body-radius aware: the torso and reaching arms must not clip into walls. */
  private blocked(x: number, zz: number, y: number) {
    const T = this.terrain;
    // fast path: open ground far from props (only the few barrels need a check)
    const k = this.flow.idx(x, zz);
    if (k >= 0 && this.flow.clear[k] && Math.abs(this.flow.h[k] - y) < 0.3) {
      let near = false;
      for (const d of T.dyn) if (Math.abs(d.x - x) < 1.2 && Math.abs(d.z - zz) < 1.2) near = true;
      if (!near) return false;
    }
    if (T.solid(x, zz) || T.height(x, zz) - y > STEP_TOL) return true;
    return this.penetration(x, zz, y) > 0;
  }
  private penetration(x: number, zz: number, y: number) {
    const T = this.terrain;
    const R = 0.45;
    let n = 0;
    for (const [ox, oz] of [[R, 0], [-R, 0], [0, R], [0, -R], [R * 0.7, R * 0.7], [-R * 0.7, R * 0.7], [R * 0.7, -R * 0.7], [-R * 0.7, -R * 0.7]])
      if (T.height(x + ox, zz + oz) - y > STEP_TOL || T.solid(x + ox, zz + oz)) n++;
    return n;
  }
  private moveTo(z: Zombie, nx: number, nz: number) {
    const p = z.pos;
    if (this.blocked(p.x, p.z, p.y)) {
      // already squeezed against geometry: accept any move that doesn't dig deeper
      const T = this.terrain;
      if (!T.solid(nx, nz) && T.height(nx, nz) - p.y <= STEP_TOL && this.penetration(nx, nz, p.y) <= this.penetration(p.x, p.z, p.y)) {
        p.x = nx;
        p.z = nz;
        return true;
      }
    }
    if (!this.blocked(nx, nz, p.y)) {
      p.x = nx;
      p.z = nz;
    } else if (!this.blocked(nx, p.z, p.y)) p.x = nx;
    else if (!this.blocked(p.x, nz, p.y)) p.z = nz;
    else return false;
    return true;
  }

  private locomote(z: Zombie, dt: number, pl: PlayerInfo) {
    const crawling = z.body === 'CRAWLING';
    if (!z.upright && !crawling) {
      z.speed = 0;
      z.vel.set(0, 0, 0);
      return;
    }
    // ---- desired heading
    let want = z.yaw;
    let targetSpeed = 0;
    const chase = z.beh === 'CHASING' || z.beh === 'APPROACHING' || (z.beh === 'INVESTIGATING' && z.hasKnown);
    if (z.alive && chase) {
      const tx = z.beh === 'INVESTIGATING' ? z.known.x : pl.pos.x;
      const tz = z.beh === 'INVESTIGATING' ? z.known.z : pl.pos.z;
      let gx = tx;
      let gz = tz;
      // straight-line chase only on the same level (otherwise follow the flow field up the stair)
      const direct = z.dist < 7 && z.canSee && z.pathOk && Math.abs(pl.pos.y - z.rootY) < 0.6;
      if (!direct && this.flow.steer(z.pos.x, z.pos.z, steerPt, z.kind === 'runner' ? 4 : 3)) {
        gx = steerPt.x;
        gz = steerPt.z;
      }
      want = Math.atan2(gx - z.pos.x, gz - z.pos.z);
      targetSpeed = z.beh === 'INVESTIGATING' ? Math.min(z.speedMax, 1.1) * 0.85 : z.speedMax * (z.beh === 'APPROACHING' ? 0.9 : 1);
      if (z.beh === 'APPROACHING' && z.dist < 0.8) targetSpeed = 0;
    } else if (z.alive && z.beh === 'WANDERING') {
      want = Math.atan2(z.wander.x - z.pos.x, z.wander.z - z.pos.z);
      targetSpeed = Math.min(z.speedMax, 0.9) * 0.6;
    } else if (z.alive && (z.beh === 'PLAYER_DETECTED' || z.beh === 'ATTACKING')) {
      want = Math.atan2(pl.pos.x - z.pos.x, pl.pos.z - z.pos.z);
      targetSpeed = 0;
    }
    // meandering, uncoordinated path (much tighter when enraged)
    z.agg = damp(z.agg, this.aggressive ? 1 : 0, 2, dt);
    const meander = (z.kind === 'runner' ? 0.08 : 0.22) * (1 - 0.6 * z.agg);
    want += Math.sin(this.time * 0.6 + z.seed) * meander + Math.sin(this.time * 1.7 + z.seed * 2) * 0.06 * (1 - 0.5 * z.agg);
    if (z.dazeT > 0) {
      z.dazeT -= dt;
      want += Math.sin(this.time * 3.1 + z.seed) * 0.9;
      targetSpeed *= 0.5;
    }
    if (chase && z.alive) {
      // varied pursuit: flankers swing wide, burst-chargers surge, stalkers hang back then rush
      if (z.style === 1) want += z.flankSide * 0.6 * clamp01((z.dist - 4) / 10) * (0.5 + 0.5 * z.agg);
      if (z.style === 2) targetSpeed *= 1 + (0.4 + 0.5 * z.agg) * Math.pow(Math.max(0, Math.sin(this.time * 1.1 + z.seed)), 6);
      if (z.style === 3) targetSpeed *= z.dist > 7 && z.dist < 15 ? 0.55 : 1.15;
      const mul = z.kind === 'runner' ? 1.22 : z.kind === 'lurcher' ? 1.55 : 1.95;
      targetSpeed *= 1 + (mul - 1) * z.agg;
    }

    if (crawling) {
      targetSpeed = z.alive && chase ? 0.38 : 0;
      if (z.dist < 0.9 && z.alive && pl.alive) {
        targetSpeed = 0;
        if (z.attackCd <= 0) {
          z.attackCd = 1.6;
          if (Math.abs(pl.pos.y - z.rootY) < 0.7) this.onPlayerHit(5, z.pos.x, z.pos.z);
        }
      }
    }
    if (z.body === 'STAGGERED') targetSpeed *= 0.15;
    if (z.body === 'STANDING_AGAIN') targetSpeed *= 0.35;
    if (z.slowT > 0) {
      z.slowT -= dt;
      targetSpeed *= 0.35;
    }

    // ---- turning (slow, rate limited; zombies cannot strafe)
    const err = angleDiff(want, z.yaw);
    const tr = z.turnRate * (crawling ? 0.4 : 1) * (z.body === 'STAGGERED' ? 0.2 : 1) * (1 + 0.8 * z.agg);
    z.yaw = wrapAngle(z.yaw + clamp(err * 3, -tr, tr) * dt);
    targetSpeed *= clamp01(1.25 - Math.abs(err) * 0.7);
    // shuffling lurch: speed surges with every step
    const surge = z.kind === 'runner' ? 1 + 0.12 * Math.sin(4 * Math.PI * z.phase) : 1 + 0.38 * Math.sin(4 * Math.PI * z.phase + 0.6);
    const acc = (z.kind === 'runner' ? 5.5 : 2.4) * (1 + 1.2 * z.agg);
    z.speed += clamp(targetSpeed - z.speed, -acc * 1.6 * dt, acc * dt);
    if (crawling) z.speed = targetSpeed * (0.3 + 1.4 * Math.max(0, Math.sin(2 * Math.PI * z.crawlPh * 2)));
    const sp = Math.max(0, z.speed * (crawling ? 1 : surge));
    const fx = Math.sin(z.yaw);
    const fz = Math.cos(z.yaw);
    // leaping lunge at the player (enraged runners & lurchers)
    z.leapCd -= dt;
    if (z.leapT > 0) z.leapT -= dt;
    else if (
      this.aggressive && z.alive && z.upright && z.body === 'STANDING' && z.kind !== 'shambler' && z.leapCd <= 0 &&
      (z.beh === 'CHASING' || z.beh === 'APPROACHING') && z.dist > 2 && z.dist < 6.5 && Math.abs(err) < 0.4
    ) {
      z.leapT = 0.5;
      z.leapCd = 1.2 + r() * 1.6;
      z.push.x += fx0(z) * 7.2;
      z.push.z += fz0(z) * 7.2;
      z.lunge.v += 16;
      z.headP.v -= 5;
      if (this.groanBudget > 0.3) {
        this.groanBudget -= 0.3;
        this.foley.scream(z.dist);
      }
    }
    z.push.multiplyScalar(Math.exp(-(z.leapT > 0 ? 1.2 : 3.2) * dt));
    z.vel.set(fx * sp + z.push.x, 0, fz * sp + z.push.z);
    // a zombie never walks off a ledge by itself (stair / roof edges): it slides along it.
    // Crowd shoves (separation) still can push it over — that's what the edge falls are.
    let nx = z.pos.x + z.vel.x * dt;
    let nz = z.pos.z + z.vel.z * dt;
    if (z.alive && z.pos.y > 0.4) {
      const vl = Math.hypot(z.vel.x, z.vel.z) || 1;
      const ax = (z.vel.x / vl) * 0.28;
      const az = (z.vel.z / vl) * 0.28;
      const T = this.terrain;
      const drop = (x: number, zz: number) => T.height(x, zz) < z.pos.y - 0.5;
      if (drop(nx + ax, nz + az)) {
        if (!drop(nx + ax, z.pos.z)) nz = z.pos.z;
        else if (!drop(z.pos.x, nz + az)) nx = z.pos.x;
        else {
          nx = z.pos.x;
          nz = z.pos.z;
        }
      }
    }
    const ok = this.moveTo(z, nx, nz);
    if (!ok) {
      // wedged on a corner (wall + stair, car edge): step out of whatever the body probes touch
      const T = this.terrain;
      let ex = 0;
      let ez = 0;
      for (const [ox, oz] of PROBES) {
        const qx = z.pos.x + ox;
        const qz = z.pos.z + oz;
        if (T.height(qx, qz) - z.pos.y > STEP_TOL || T.solid(qx, qz)) {
          ex -= ox;
          ez -= oz;
        }
      }
      const el = Math.hypot(ex, ez);
      if (el > 1e-6) {
        const ux = z.pos.x + (ex / el) * 0.035;
        const uz = z.pos.z + (ez / el) * 0.035;
        if (!T.solid(ux, uz) && T.height(ux, uz) - z.pos.y <= STEP_TOL && T.height(ux, uz) > z.pos.y - 0.5) {
          z.pos.x = ux;
          z.pos.z = uz;
        }
      }
      z.push.set(0, 0, 0);
      z.speed *= 0.5;
    }
    z.pos.y = this.terrain.height(z.pos.x, z.pos.z);
    if (z.alive && z.rootY - z.pos.y > 0.7) {
      // shoved off the stair / roof edge: the body tips over and drops as a ragdoll
      _v.set(z.vel.x || fx, 0, z.vel.z || fz);
      if (_v.lengthSq() < 1e-6) _v.set(fx, 0, fz);
      _v.normalize();
      this.knockDown(z, _v, true);
      z.push.set(0, 0, 0);
      for (let i = 0; i < NP; i++) {
        z.kick[i * 3] += _v.x * 1.4;
        z.kick[i * 3 + 2] += _v.z * 1.4;
      }
    }
    z.rootY = damp(z.rootY, z.pos.y, 12, dt);
  }

  /** Zombies shoulder each other aside instead of overlapping (and block the player). Spatial hash: O(n). */
  private separate(dt: number, pl: PlayerInfo) {
    const Z = this.zombies;
    const head = this.sepHead;
    const next = this.sepNext;
    head.fill(-1);
    const cellOf = (x: number, z: number) => {
      const gx = Math.floor((x + SEP_O) / SEP_C);
      const gz = Math.floor((z + SEP_O) / SEP_C);
      return gx < 0 || gz < 0 || gx >= SEP_N || gz >= SEP_N ? -1 : gx * SEP_N + gz;
    };
    for (let i = 0; i < Z.length; i++) {
      const a = Z[i];
      if (!a.active || !(a.upright || a.body === 'CRAWLING')) continue;
      const k = cellOf(a.pos.x, a.pos.z);
      if (k < 0) continue;
      next[i] = head[k];
      head[k] = i;
    }
    // the frenzied swarm packs tighter and flows like a liquid
    const sepK = this.aggressive ? 0.25 : 0.32;
    const SX = this.sepX;
    const SZ = this.sepZ;
    SX.fill(0);
    SZ.fill(0);
    for (let i = 0; i < Z.length; i++) {
      const a = Z[i];
      if (!a.active || !(a.upright || a.body === 'CRAWLING')) continue;
      const gx = Math.floor((a.pos.x + SEP_O) / SEP_C);
      const gz = Math.floor((a.pos.z + SEP_O) / SEP_C);
      for (let ox = -1; ox <= 1; ox++) {
        for (let oz = -1; oz <= 1; oz++) {
          const cx = gx + ox;
          const cz = gz + oz;
          if (cx < 0 || cz < 0 || cx >= SEP_N || cz >= SEP_N) continue;
          for (let j = head[cx * SEP_N + cz]; j >= 0; j = next[j]) {
            if (j <= i) continue;
            const b = Z[j];
            const dx = b.pos.x - a.pos.x;
            const dz = b.pos.z - a.pos.z;
            const min = sepK * (a.s + b.s);
            const d2 = dx * dx + dz * dz;
            if (d2 > min * min || d2 < 1e-6) continue;
            const d = Math.sqrt(d2);
            const c = ((min - d) / d) * 0.5 * Math.min(1, dt * 12);
            // accumulate (one collision-checked move per zombie instead of two per pair)
            SX[i] -= dx * c;
            SZ[i] -= dz * c;
            SX[j] += dx * c;
            SZ[j] += dz * c;
          }
        }
      }
      const dx = a.pos.x - pl.pos.x;
      const dz = a.pos.z - pl.pos.z;
      const d = Math.hypot(dx, dz);
      const min = 0.5;
      if (d < min && d > 1e-4 && Math.abs(pl.pos.y - a.rootY) < 1) {
        const c = (min - d) / d;
        SX[i] += dx * c * 0.7;
        SZ[i] += dz * c * 0.7;
      }
    }
    for (let i = 0; i < Z.length; i++) {
      let mx = SX[i];
      let mz = SZ[i];
      if (mx === 0 && mz === 0) continue;
      const a = Z[i];
      const l = Math.hypot(mx, mz);
      if (l < 1e-5) continue;
      if (l > 0.22) {
        mx *= 0.22 / l;
        mz *= 0.22 / l;
      }
      this.moveTo(a, a.pos.x + mx, a.pos.z + mz);
    }
  }

  /** Push the player out of zombie bodies (they physically block you). */
  pushPlayer(pos: THREE.Vector3) {
    for (const z of this.zombies) {
      if (!z.active || !z.upright) continue;
      const dx = pos.x - z.pos.x;
      const dz = pos.z - z.pos.z;
      const d = Math.hypot(dx, dz);
      if (d < 0.46 && d > 1e-4 && Math.abs(pos.y - z.rootY) < 1) {
        const c = ((0.46 - d) / d) * 0.3;
        const nx = pos.x + dx * c;
        const nz = pos.z + dz * c;
        // bodies jostle you, but never shove you off the tower / stair edge
        if (!this.blocked(nx, nz, pos.y) && this.terrain.height(nx, nz) > pos.y - 0.45) {
          pos.x = nx;
          pos.z = nz;
        }
      }
    }
  }

  private contagion(dt: number) {
    this.contagionT -= dt;
    if (this.contagionT > 0) return;
    this.contagionT = 0.5;
    if (this.aggressive) return; // everyone already knows where you are
    const buckets = new Map<number, Zombie[]>();
    const key = (x: number, z: number) => Math.floor((x + 100) / 9) * 64 + Math.floor((z + 100) / 9);
    for (const b of this.zombies) {
      if (!b.active || !b.alive || (b.beh !== 'IDLE' && b.beh !== 'WANDERING')) continue;
      const k = key(b.pos.x, b.pos.z);
      const l = buckets.get(k);
      if (l) l.push(b);
      else buckets.set(k, [b]);
    }
    for (const a of this.zombies) {
      if (!a.active || !a.alive || (a.beh !== 'CHASING' && a.beh !== 'APPROACHING')) continue;
      const gx = Math.floor((a.pos.x + 100) / 9);
      const gz = Math.floor((a.pos.z + 100) / 9);
      for (let ox = -1; ox <= 1; ox++) {
        for (let oz = -1; oz <= 1; oz++) {
          const l = buckets.get((gx + ox) * 64 + gz + oz);
          if (!l) continue;
          for (const b of l) {
            if (b.beh !== 'IDLE' && b.beh !== 'WANDERING') continue;
            if (Math.hypot(a.pos.x - b.pos.x, a.pos.z - b.pos.z) < 9) {
              b.known.copy(a.known);
              b.hasKnown = true;
              this.setBeh(b, 'PLAYER_DETECTED');
            }
          }
        }
      }
    }
  }

  // ============================================================== body states
  private setBody(z: Zombie, b: BodyState) {
    z.body = b;
    z.bodyT = 0;
    z.pinFull = false;
  }

  private knockDown(z: Zombie, dir: THREE.Vector3, hard: boolean) {
    if (z.body === 'FALLING' || z.body === 'GROUND_IMPACT' || z.body === 'RAGDOLL_ON_GROUND') return;
    z.fallDir.copy(dir).setY(0).normalize();
    z.impactDone = false;
    z.asleep = false;
    if (hard || !z.upright) this.setBody(z, 'FALLING');
    else this.setBody(z, 'LOSING_BALANCE');
  }

  private die(z: Zombie, dir: THREE.Vector3) {
    if (!z.alive) return;
    z.alive = false;
    z.deadT = 0;
    z.beh = 'IDLE';
    this.kills++;
    if (z.upright || z.body === 'LOSING_BALANCE') {
      z.fallDir.copy(dir).setY(0).normalize();
      z.impactDone = false;
      this.setBody(z, 'FALLING');
      // legs give out first, the torso follows a moment later
      for (const leg of LEG) for (const i of leg) z.pin[i] = 0;
    } else if (z.body !== 'FALLING' && z.body !== 'GROUND_IMPACT') this.setBody(z, 'RAGDOLL_ON_GROUND');
    z.asleep = false;
  }

  private bodyLogic(z: Zombie, dt: number) {
    z.bodyT += dt;
    z.balance = Math.min(1, z.balance + dt * (z.kind === 'runner' ? 0.35 : 0.5) * (1 + 0.6 * z.agg));
    if (!z.alive) z.deadT += dt;
    z.launchT = Math.max(0, z.launchT - dt);
    z.hitStack = Math.max(0, z.hitStack - dt * 2.2);
    switch (z.body) {
      case 'STAGGERED':
        if (z.bodyT > z.staggerDur) this.setBody(z, 'STANDING');
        break;
      case 'LOSING_BALANCE':
        if (z.bodyT > 0.28) this.setBody(z, 'FALLING');
        break;
      case 'FALLING':
        if (z.bodyT > 2.2) this.setBody(z, 'RAGDOLL_ON_GROUND');
        break;
      case 'GROUND_IMPACT':
        if (z.bodyT > 0.35) {
          this.setBody(z, 'RAGDOLL_ON_GROUND');
          z.settleT = (1.1 + r() * 1.6) * (this.aggressive ? 0.45 : 1);
        }
        break;
      case 'RAGDOLL_ON_GROUND':
        if (z.alive && z.bodyT > z.settleT && (z.kinetic < 0.6 || z.bodyT > 4.5)) this.beginRecover(z);
        break;
      case 'RECOVERING':
        if (z.bodyT > z.recoverDur) {
          if (z.crawler) this.setBody(z, 'CRAWLING');
          else {
            this.setBody(z, 'GETTING_UP');
            z.getT = 0;
          }
        }
        break;
      case 'GETTING_UP': {
        const rate = (z.kind === 'runner' ? 1.7 : z.kind === 'lurcher' ? 1.2 : 0.9 + (z.seed % 1) * 0.25) * (1 + 1.3 * z.agg);
        z.getT += dt * rate;
        if (z.getT >= z.keys[z.keys.length - 1].t) this.finishGetUp(z);
        break;
      }
      case 'STANDING_AGAIN':
        if (z.bodyT > 1.1) this.setBody(z, 'STANDING');
        break;
    }
  }

  /** Read the ragdoll: which way is it lying, where is its head? */
  private beginRecover(z: Zombie) {
    const p = z.pts;
    const px = p[P.PELVIS * 3];
    const pz = p[P.PELVIS * 3 + 2];
    let ax = p[P.CHEST * 3] - px;
    let az = p[P.CHEST * 3 + 2] - pz;
    const al = Math.hypot(ax, az) || 1;
    ax /= al;
    az /= al;
    // torso facing normal = side × up
    _v.set(p[P.LSH * 3] - p[P.RSH * 3], p[P.LSH * 3 + 1] - p[P.RSH * 3 + 1], p[P.LSH * 3 + 2] - p[P.RSH * 3 + 2]);
    _w.set(p[P.CHEST * 3] - px, p[P.CHEST * 3 + 1] - p[P.PELVIS * 3 + 1], p[P.CHEST * 3 + 2] - pz);
    _v.cross(_w);
    const prone = _v.y < 0;
    if (prone || z.crawler) {
      z.keys = GETUP_PRONE;
      z.frameYaw = Math.atan2(ax, az);
    } else {
      z.keys = GETUP_SUPINE;
      z.frameYaw = Math.atan2(-ax, -az);
    }
    z.frameX = px;
    z.frameZ = pz;
    z.pos.set(px, this.terrain.height(px, pz), pz);
    z.rootY = z.pos.y;
    z.yaw = z.frameYaw;
    z.recoverDur = (0.8 + r() * 0.8) * (this.aggressive ? 0.5 : 1);
    this.setBody(z, 'RECOVERING');
  }

  private finishGetUp(z: Zombie) {
    const k = z.keys[z.keys.length - 1].p;
    const c = Math.cos(z.frameYaw);
    const sn = Math.sin(z.frameYaw);
    const lx = k.x * z.s;
    const lz = k.z * z.s;
    const nx = z.frameX + lx * c + lz * sn;
    const nz = z.frameZ - lx * sn + lz * c;
    if (!this.blocked(nx, nz, z.pos.y)) z.pos.set(nx, this.terrain.height(nx, nz), nz);
    z.yaw = z.frameYaw;
    z.rootY = z.pos.y;
    z.feet.forEach((f, i) => {
      const an = (i === 0 ? P.LAN : P.RAN) * 3;
      f.x = z.pts[an];
      f.z = z.pts[an + 2];
      f.y = this.terrain.height(f.x, f.z);
      f.yaw = z.yaw + (i === 0 ? 1 : -1) * z.toeOut[i];
      f.swing = false;
    });
    z.blendPts.set(z.pts);
    z.blendW = 1;
    z.speed = 0;
    z.balance = 0.6;
    z.headR.v += (r() - 0.5) * 5;
    this.setBody(z, 'STANDING_AGAIN');
  }

  // ================================================================ animation
  private animate(z: Zombie, dt: number, pl: PlayerInfo | null) {
    z.lastTgt.set(z.tgt);
    const b = z.body;
    if (b === 'RECOVERING' || b === 'GETTING_UP') this.animGetUp(z, dt);
    else if (b === 'CRAWLING') this.animCrawl(z, dt);
    else if (b === 'FALLING' || b === 'GROUND_IMPACT' || b === 'RAGDOLL_ON_GROUND' || !z.alive) {
      // physics owns the body; keep targets on the ragdoll so nothing pulls
      z.tgt.set(z.pts);
    } else this.animWalk(z, dt, pl);
    if (z.blendW > 0) {
      const w = z.blendW * z.blendW * (3 - 2 * z.blendW);
      for (let i = 0; i < NP * 3; i++) z.tgt[i] += (z.blendPts[i] - z.tgt[i]) * w;
      z.blendW = Math.max(0, z.blendW - dt / 0.4);
    }
  }

  private animWalk(z: Zombie, dt: number, pl: PlayerInfo | null) {
    const T = this.terrain;
    const s = z.s;
    const t = this.time;
    const runner = z.kind === 'runner';
    const yaw = z.yaw;
    const fx = Math.sin(yaw);
    const fz = Math.cos(yaw);
    const lx = Math.cos(yaw);
    const lz = -Math.sin(yaw);
    const sp = Math.hypot(z.vel.x, z.vel.z);

    // ---- gait clock: irregular, uneven rhythm
    const stride = runner ? 1.25 + sp * 0.36 : 0.55 + sp * 0.62;
    const freq = (sp / stride) * (1 + 0.16 * Math.sin(t * 1.3 + z.seed) + 0.08 * Math.sin(t * 3.1 + z.seed * 3));
    z.phase += freq * dt;
    const sw = runner ? 0.56 : z.kind === 'lurcher' ? 0.44 : 0.4;
    const offs = [0, 0.5 + (z.limpSide >= 0 ? 0.08 * z.limp : 0)];
    const vdx = sp > 0.25 ? z.vel.x / sp : fx;
    const vdz = sp > 0.25 ? z.vel.z / sp : fz;
    const width = (runner ? 0.085 : 0.13) * s;
    let anySwing = false;
    for (let k = 0; k < 2; k++) if (z.feet[k].swing) anySwing = true;

    for (let k = 0; k < 2; k++) {
      const f = z.feet[k];
      const side = k === 0 ? 1 : -1;
      if (z.severed.has(k === 0 ? 'lLeg' : 'rLeg') || z.severed.has(k === 0 ? 'lShin' : 'rShin')) continue;
      const drag = z.limpSide === k;
      const ph = (z.phase + offs[k]) % 1;
      const restX = z.pos.x + lx * side * width;
      const restZ = z.pos.z + lz * side * width;
      if (!f.swing) {
        if (freq > 0.08 && ph < f.lastPh) {
          this.startSwing(f, clamp((sw * (drag ? 0.85 : 1)) / Math.max(freq, 0.1), 0.14, 0.8), runner);
          anySwing = true;
        } else if (!anySwing && Math.hypot(f.x - restX, f.z - restZ) > (sp < 0.3 ? 0.26 : 0.5) * s) {
          // balance correction step while standing / reaching
          this.startSwing(f, 0.36, false);
          anySwing = true;
        }
      }
      f.lastPh = ph;
      if (f.swing) {
        f.u += dt / f.dur;
        const u = Math.min(1, f.u);
        const tRem = (1 - u) * f.dur;
        const ahead = stride * (runner ? 0.2 : 0.15) * Math.min(1, sp * 2);
        let tx = z.pos.x + z.vel.x * tRem + vdx * ahead + lx * side * width + f.jx * lx + f.jz * fx;
        let tz = z.pos.z + z.vel.z * tRem + vdz * ahead + lz * side * width + f.jx * lz + f.jz * fz;
        let ty = T.height(tx, tz);
        if (Math.abs(ty - z.pos.y) > 0.36) {
          tx = restX;
          tz = restZ;
          ty = T.height(tx, tz);
        }
        const e = u * u * (3 - 2 * u);
        const lift = (drag ? 0.025 : runner ? 0.2 : 0.07 + 0.03 * Math.sin(z.seed + k)) * s;
        f.x = f.fx + (tx - f.fx) * e;
        f.z = f.fz + (tz - f.fz) * e;
        f.y = f.fy + (ty - f.fy) * e + Math.sin(Math.PI * u) * lift;
        f.yaw = f.fyaw + angleDiff(yaw + side * z.toeOut[k], f.fyaw) * e;
        // toe drags / scuffs for the bad leg; heel kicks up on a run
        f.pitch = drag ? 0.35 * Math.sin(Math.PI * u) : runner ? -0.5 * Math.sin(Math.PI * u) + 0.3 * (1 - u) : 0.25 * Math.sin(Math.PI * u * 0.9);
        if (u >= 1) {
          f.swing = false;
          f.pitch = 0;
          if (z.dist < 9 && r() < 0.5) this.foley.zstep(z.dist, runner);
        }
      } else f.pitch = damp(f.pitch, 0, 10, dt);
    }

    // ---- pelvis
    const cyc = 2 * Math.PI * z.phase;
    const limpStance = z.limpSide >= 0 && !z.feet[z.limpSide].swing ? 1 : 0;
    const b0 = z.buckle[0].update(0, dt);
    const b1 = z.buckle[1].update(0, dt);
    const swayL = z.sway * Math.sin(cyc) * Math.min(1, sp * 1.5) + Math.sin(t * z.swayF + z.seed) * 0.025 * (1 + z.wobble);
    let py =
      z.rootY +
      (L.standY - (runner ? 0.11 : 0.045) - (runner ? 0.035 * Math.abs(Math.sin(cyc)) : 0.022 * (1 + Math.cos(2 * cyc)) * Math.min(1, sp))) * s -
      limpStance * 0.035 * z.limp * s -
      (b0 + b1) * 0.14 * s;
    const ppx = z.pos.x + lx * swayL * s;
    const ppz = z.pos.z + lz * swayL * s;
    // keep the legs within reach of the planted feet
    for (let k = 0; k < 2; k++) {
      if (z.severed.has(k === 0 ? 'lLeg' : 'rLeg') || z.severed.has(k === 0 ? 'lShin' : 'rShin')) continue;
      const f = z.feet[k];
      const side = k === 0 ? 1 : -1;
      const hx = ppx + lx * side * L.hipW * s - f.x;
      const hz = ppz + lz * side * L.hipW * s - f.z;
      const reach = (L.thigh + L.shin) * s * 0.995;
      const hd2 = hx * hx + hz * hz;
      const maxY = f.y + L.ankleH * s + 0.02 * s + Math.sqrt(Math.max(0.01, reach * reach - hd2));
      if (py > maxY) py = maxY;
    }
    // never collapse into a crouch to chase a stranded foot (it re-steps instead)
    py = Math.max(py, z.rootY + (L.standY - 0.2) * s - (b0 + b1) * 0.14 * s);

    // ---- reaction springs
    const hlx = z.hitLeanX.update(0, dt);
    const hlz = z.hitLeanZ.update(0, dt);
    const htw = z.hitTwist.update(0, dt);
    const lunge = z.lunge.update(0, dt);
    z.jerkT -= dt;
    if (z.jerkT <= 0) {
      z.jerkT = (0.8 + r() * 3) * (1 - 0.6 * z.agg);
      z.headR.v += (r() - 0.5) * 5;
      z.headP.v += (r() - 0.5) * 3;
      z.headY.v += (r() - 0.5) * 3;
    }
    z.wobble = damp(z.wobble, z.body === 'STANDING_AGAIN' ? 1 : 0, 3, dt);

    // look toward the player when aware
    let lookT = 0;
    if (pl && z.alive && z.beh !== 'IDLE' && z.beh !== 'WANDERING') lookT = clamp(angleDiff(Math.atan2(pl.pos.x - z.pos.x, pl.pos.z - z.pos.z), yaw), -0.9, 0.9);
    z.lookYaw = damp(z.lookYaw, lookT, 4, dt);

    // attack shape
    let grab = 0;
    let windup = 0;
    if (z.beh === 'ATTACKING' && z.alive) {
      const a = z.attackT / ((runner ? 0.85 : 1.2) * (this.aggressive ? 0.72 : 1));
      windup = smoothstep(0, 0.35, a) * (1 - smoothstep(0.35, 0.5, a));
      grab = smoothstep(0.15, 0.4, a) * (1 - smoothstep(0.75, 1, a));
    }
    z.grabW = damp(z.grabW, grab, 10, dt);

    // a wall right in front: arms drop and press against it instead of clipping through
    const wallAhead = T.height(z.pos.x + fx * 0.75 * s, z.pos.z + fz * 0.75 * s) - z.rootY > 0.6 || T.solid(z.pos.x + fx * 0.6, z.pos.z + fz * 0.6);
    z.wallW = damp(z.wallW, wallAhead ? 1 : 0, 6, dt);
    const lean = z.lean + (runner ? 0.12 * Math.min(1, sp / 4) : 0.05 * Math.min(1, sp)) + 0.12 * z.agg + (z.leapT > 0 ? 0.35 : 0);
    const pp = z.pose;
    pp.x = ppx;
    pp.y = py;
    pp.z = ppz;
    pp.yaw = yaw;
    pp.pitch = 0;
    pp.roll = 0;
    pp.pTilt = lean * 0.25 + hlx * 0.3;
    pp.pRoll = limpStance * 0.08 * z.limp * (z.limpSide === 0 ? -1 : 1) + swayL * 0.6 + hlz * 0.3 + (b0 - b1) * 0.25;
    pp.pTwist = 0.13 * Math.sin(cyc) * Math.min(1, sp);
    pp.spBend = lean * 0.35 + hlx * 0.35 + lunge * 0.15 - windup * 0.15;
    pp.chBend = lean * 0.45 + hlx * 0.4 + lunge * 0.25 - windup * 0.1;
    pp.spSide = hlz * 0.35 + 0.05 * Math.sin(cyc + 1) * Math.min(1, sp) + z.shAsym * 0.6;
    pp.chSide = hlz * 0.35 - z.shAsym * 1.2 + Math.sin(t * 0.7 + z.seed) * 0.04 * (1 + z.wobble);
    pp.chTwist = -pp.pTwist * 1.3 + htw + z.lookYaw * 0.25;
    pp.nkBend = -lean * 0.45 + 0.1;
    const hp = z.headP.update(0, dt);
    const hy = z.headY.update(0, dt);
    const hr = z.headR.update(0, dt);
    pp.hdPitch = z.headDroop - lean * 0.35 + hp + 0.06 * Math.sin(cyc * 2 + 0.7) * Math.min(1, sp) - lunge * 0.2 - (z.beh === 'PLAYER_DETECTED' ? 0.25 : 0);
    pp.hdYaw = z.lookYaw * 0.65 + hy + 0.05 * Math.sin(t * 1.1 + z.seed);
    pp.hdRoll = z.headTilt * (1 - 0.5 * Math.min(1, sp / 4)) + hr + Math.sin(t * 0.9 + z.seed * 2) * 0.06;
    pp.shDropL = z.shAsym;
    pp.shDropR = -z.shAsym;

    // ---- arms: hanging / reaching / flailing, never symmetric
    for (let k = 0; k < 2; k++) {
      const side = k === 0 ? 1 : -1;
      const swing = Math.sin(cyc + (k === 0 ? Math.PI : 0)) * Math.min(1, sp * 0.8);
      const n1 = Math.sin(t * (1.3 + k * 0.4) + z.seed + k * 2);
      const n2 = Math.sin(t * (2.1 + k * 0.3) + z.seed * 1.7 + k);
      let fl: number;
      let ab: number;
      let ef: number;
      let wf: number;
      if (z.armMode === 3) {
        fl = 0.45 + 0.85 * swing * (0.6 + z.armSwing[k]) + 0.25 * n1;
        ab = 0.3 + 0.18 * n2;
        ef = 1.0 + 0.45 * Math.sin(cyc * 1 + k) + 0.2 * n1;
        wf = 0.2;
      } else {
        fl = 0.1 + z.armSwing[k] * 0.55 * swing + 0.06 * n1;
        ab = 0.1 + 0.05 * n2 + (k === 0 ? z.shAsym : -z.shAsym);
        ef = 0.25 + 0.12 * (1 + n2);
        wf = 0.3;
      }
      // reaching for the player
      let reachT = z.armMode === 2 ? 0.85 : z.armMode === 1 && z.reachSide === k ? 0.9 : 0;
      if (z.beh === 'APPROACHING' || z.beh === 'ATTACKING' || z.leapT > 0) reachT = 1;
      else if (z.beh === 'CHASING' && z.dist < 9 && z.armMode !== 3) reachT = Math.max(reachT, 0.6);
      if (!z.alive) reachT = 0;
      z.reach[k] = damp(z.reach[k], reachT, 3, dt);
      const rk = z.reach[k] * (1 - z.wallW * (1 - z.grabW));
      fl *= 1 - 0.7 * z.wallW;
      const rfl = 1.45 + 0.12 * n1 + windup * 0.45 - (k === 1 ? 0.12 : 0);
      pp[k === 0 ? 'aFlexL' : 'aFlexR'] = lerp(fl, rfl, rk);
      pp[k === 0 ? 'aAbdL' : 'aAbdR'] = lerp(ab, 0.06 + 0.06 * n2, rk);
      pp[k === 0 ? 'eFlexL' : 'eFlexR'] = lerp(ef, 0.35 + 0.25 * (1 + n2) * 0.5, rk);
      pp[k === 0 ? 'wFlexL' : 'wFlexR'] = lerp(wf, -0.25, rk);
      void side;
    }
    fk(pp, s, z.tgt, false);

    // ---- grabbing: hands IK onto the player
    if (z.grabW > 0.01 && pl) {
      for (let k = 0; k < 2; k++) {
        const side = k === 0 ? 1 : -1;
        const sh = k === 0 ? P.LSH2 : P.RSH2;
        const el = k === 0 ? P.LEL : P.REL;
        const wr = k === 0 ? P.LWR : P.RWR;
        const ha = k === 0 ? P.LHA : P.RHA;
        const pfx = z.pos.x - pl.pos.x;
        const pfz = z.pos.z - pl.pos.z;
        const pd = Math.hypot(pfx, pfz) || 1;
        // target: player's shoulders
        const tx = pl.pos.x + (pfx / pd) * 0.22 + (pfz / pd) * side * 0.18;
        const ty = pl.pos.y + 1.35;
        const tz = pl.pos.z + (pfz / pd) * 0.22 - (pfx / pd) * side * 0.18;
        const w = z.grabW;
        const ox = z.tgt[wr * 3];
        const oy = z.tgt[wr * 3 + 1];
        const oz = z.tgt[wr * 3 + 2];
        const ex = z.tgt[el * 3];
        const ey = z.tgt[el * 3 + 1];
        const ez = z.tgt[el * 3 + 2];
        const hx = z.tgt[ha * 3] - ox;
        const hy2 = z.tgt[ha * 3 + 1] - oy;
        const hz = z.tgt[ha * 3 + 2] - oz;
        ik2(z.tgt, sh, el, wr, tx, ty, tz, L.upper * s, L.fore * s, lx * side * 0.6, -1, lz * side * 0.6);
        for (const [i, x, y, zz] of [
          [el, ex, ey, ez],
          [wr, ox, oy, oz],
        ] as const) {
          z.tgt[i * 3] = x + (z.tgt[i * 3] - x) * w;
          z.tgt[i * 3 + 1] = y + (z.tgt[i * 3 + 1] - y) * w;
          z.tgt[i * 3 + 2] = zz + (z.tgt[i * 3 + 2] - zz) * w;
        }
        z.tgt[ha * 3] = z.tgt[wr * 3] + hx;
        z.tgt[ha * 3 + 1] = z.tgt[wr * 3 + 1] + hy2;
        z.tgt[ha * 3 + 2] = z.tgt[wr * 3 + 2] + hz;
        const e2 = (k === 0 ? P.LEL2 : P.REL2) * 3;
        z.tgt[e2] = z.tgt[el * 3];
        z.tgt[e2 + 1] = z.tgt[el * 3 + 1];
        z.tgt[e2 + 2] = z.tgt[el * 3 + 2];
      }
    }

    // ---- legs: IK onto the world-planted feet (no sliding by construction)
    for (let k = 0; k < 2; k++) {
      const side = k === 0 ? 1 : -1;
      const f = z.feet[k];
      const leg = LEG[k];
      const hip2 = leg[0];
      const kn = leg[1];
      const kn2 = leg[2];
      const an = leg[3];
      const to = leg[4];
      if (z.severed.has(k === 0 ? 'lLeg' : 'rLeg') || z.severed.has(k === 0 ? 'lShin' : 'rShin')) {
        // remaining stump just hangs from the FK pose
        const hip = k === 0 ? P.LHIP : P.RHIP;
        z.tgt[hip2 * 3] = z.tgt[hip * 3];
        z.tgt[hip2 * 3 + 1] = z.tgt[hip * 3 + 1];
        z.tgt[hip2 * 3 + 2] = z.tgt[hip * 3 + 2];
        z.tgt[kn * 3] = z.tgt[hip * 3] + fx * 0.15 * s;
        z.tgt[kn * 3 + 1] = z.tgt[hip * 3 + 1] - L.thigh * s * 0.95;
        z.tgt[kn * 3 + 2] = z.tgt[hip * 3 + 2] + fz * 0.15 * s;
        z.tgt[kn2 * 3] = z.tgt[kn * 3];
        z.tgt[kn2 * 3 + 1] = z.tgt[kn * 3 + 1];
        z.tgt[kn2 * 3 + 2] = z.tgt[kn * 3 + 2];
        continue;
      }
      const bk = k === 0 ? b0 : b1;
      const pole = 1 + bk * 2;
      ik2(
        z.tgt,
        hip2,
        kn,
        an,
        f.x,
        f.y + L.ankleH * s,
        f.z,
        L.thigh * s,
        L.shin * s,
        fx * pole + lx * side * z.kneeOut * 0.4,
        0,
        fz * pole + lz * side * z.kneeOut * 0.4,
      );
      z.tgt[kn2 * 3] = z.tgt[kn * 3];
      z.tgt[kn2 * 3 + 1] = z.tgt[kn * 3 + 1];
      z.tgt[kn2 * 3 + 2] = z.tgt[kn * 3 + 2];
      const c = Math.cos(f.pitch);
      const sn = Math.sin(f.pitch);
      const fl = 0.155 * s;
      const fd = 0.055 * s;
      z.tgt[to * 3] = z.tgt[an * 3] + Math.sin(f.yaw) * (fl * c - fd * sn) * 1;
      z.tgt[to * 3 + 1] = z.tgt[an * 3 + 1] - fd * c - fl * sn;
      z.tgt[to * 3 + 2] = z.tgt[an * 3 + 2] + Math.cos(f.yaw) * (fl * c - fd * sn);
      const tg = T.height(z.tgt[to * 3], z.tgt[to * 3 + 2]) + 0.02 * s;
      if (z.tgt[to * 3 + 1] < tg && tg - z.tgt[to * 3 + 1] < 0.3) z.tgt[to * 3 + 1] = tg;
    }
  }

  private startSwing(f: Foot, dur: number, runner: boolean) {
    f.swing = true;
    f.u = 0;
    f.dur = dur;
    f.fx = f.x;
    f.fy = f.y;
    f.fz = f.z;
    f.fyaw = f.yaw;
    // irregular foot placement
    f.jx = (r() - 0.5) * (runner ? 0.06 : 0.11);
    f.jz = (r() - 0.5) * (runner ? 0.12 : 0.1);
  }

  private frameTarget(z: Zombie, k: Pose) {
    const c = Math.cos(z.frameYaw);
    const sn = Math.sin(z.frameYaw);
    const pp = z.pose;
    Object.assign(pp, k);
    const lx = k.x * z.s;
    const lz = k.z * z.s;
    pp.x = z.frameX + lx * c + lz * sn;
    pp.z = z.frameZ - lx * sn + lz * c;
    pp.y = this.terrain.height(pp.x, pp.z) + k.y * z.s;
    pp.yaw = z.frameYaw + k.yaw;
  }

  private animGetUp(z: Zombie, dt: number) {
    if (z.crawler) {
      this.animCrawl(z, dt);
      return;
    }
    const pp = z.pose;
    if (z.body === 'RECOVERING') {
      // regain body awareness: twitch, then pull the limbs into a supported pose
      sampleKeys(z.keys, 0, pp);
      this.frameTarget(z, pp);
      const tw = Math.max(0, Math.sin(this.time * 7 + z.seed)) * 0.25;
      pp.hdPitch += tw * 0.6;
      pp.aFlexL += tw;
      pp.kFlexR += tw * 0.8;
    } else {
      sampleKeys(z.keys, z.getT, pp);
      this.frameTarget(z, pp);
      // unstable: wobble on the way up
      pp.chSide += Math.sin(this.time * 2.3 + z.seed) * 0.08;
      pp.hdRoll += Math.sin(this.time * 1.7 + z.seed) * 0.15 + z.headTilt * 0.5;
    }
    fk(pp, z.s, z.tgt, true);
  }

  private animCrawl(z: Zombie, dt: number) {
    const pp = z.pose;
    const moving = z.body === 'CRAWLING';
    z.crawlPh += dt * (moving ? 0.55 + z.speed * 0.8 : 0.1);
    const c = 2 * Math.PI * z.crawlPh;
    Object.assign(pp, makePose());
    pp.x = z.pos.x;
    pp.z = z.pos.z;
    pp.y = z.rootY + 0.15 * z.s;
    pp.yaw = z.yaw;
    pp.pitch = Math.PI / 2 - 0.12;
    pp.spBend = -0.12;
    pp.chBend = -0.28 + 0.05 * Math.sin(c * 2);
    pp.chTwist = 0.12 * Math.sin(c);
    pp.pRoll = 0.08 * Math.sin(c);
    pp.nkBend = -0.3;
    pp.hdPitch = -0.55 + 0.1 * Math.sin(c * 2 + 1);
    pp.hdRoll = z.headTilt;
    // alternate arm reach-and-pull
    pp.aFlexL = 2.3 + 0.55 * Math.sin(c);
    pp.eFlexL = 0.7 - 0.55 * Math.sin(c);
    pp.aAbdL = 0.35;
    pp.aFlexR = 2.3 + 0.55 * Math.sin(c + Math.PI);
    pp.eFlexR = 0.7 - 0.55 * Math.sin(c + Math.PI);
    pp.aAbdR = 0.35;
    pp.hFlexL = 0.05;
    pp.hFlexR = 0.1;
    pp.kFlexL = 0.25;
    pp.kFlexR = 0.4;
    pp.ankL = -0.6;
    pp.ankR = -0.6;
    fk(pp, z.s, z.tgt, true);
  }

  // ================================================================== physics
  private pinCap(z: Zombie, i: number): number {
    if (z.detached[i]) return 0;
    if (!z.alive) {
      const leg = LEG[0].includes(i) || LEG[1].includes(i);
      return leg ? 0 : Math.max(0, 1 - z.deadT / 0.14);
    }
    const isLeg = LEG[0].includes(i) || LEG[1].includes(i);
    switch (z.body) {
      case 'LOSING_BALANCE':
        return isLeg ? Math.max(0, 1 - z.bodyT / 0.12) : Math.max(0.05, 1 - z.bodyT / 0.3);
      case 'FALLING':
      case 'GROUND_IMPACT':
      case 'RAGDOLL_ON_GROUND':
        return 0;
      case 'RECOVERING':
        return z.crawler ? 0.5 * smoothstep(0, z.recoverDur, z.bodyT) : 0.32 * smoothstep(0, z.recoverDur, z.bodyT);
      case 'GETTING_UP':
        // physics LOD: far away the get-up is pure animation (identical at range, no solver cost)
        return z.dist > 15 ? 1 : 0.32 + 0.68 * smoothstep(0.2, 2.0, z.getT);
      case 'CRAWLING':
        return z.dist > 18 ? 1 : isLeg ? 0.05 : HEADP.includes(i) ? 0.55 : 0.75;
      default:
        return 1;
    }
  }

  private prepPhysics(z: Zombie, dt: number) {
    // fully animated, fully pinned walker: nothing to prepare
    if (z.pinFull && !z.physics && z.alive && z.upright) return;
    const regain = z.body === 'RECOVERING' || z.body === 'GETTING_UP' ? 3 : 1.7;
    let any = false;
    for (let i = 0; i < NP; i++) {
      const cap = this.pinCap(z, i);
      z.pin[i] = Math.min(cap, z.pin[i] + regain * dt);
      const p = z.pin[i];
      const pe = p * p;
      z.pinK[i] = pe >= 0.995 ? 1 : 1 - Math.pow(1 - pe, H * 60);
      z.wgt[i] = z.frozen[i] || z.pinK[i] >= 1 ? 0 : INV_MASS[i] * (1 - p);
      if (z.pinK[i] < 1 && !z.frozen[i]) any = true;
      const j = i * 3;
      const inv = 1 / Math.max(z.animDt, dt, 1e-4);
      let vx = (z.tgt[j] - z.lastTgt[j]) * inv;
      let vy = (z.tgt[j + 1] - z.lastTgt[j + 1]) * inv;
      let vz = (z.tgt[j + 2] - z.lastTgt[j + 2]) * inv;
      const vl = Math.hypot(vx, vy, vz);
      if (vl > 9) {
        vx *= 9 / vl;
        vy *= 9 / vl;
        vz *= 9 / vl;
      }
      z.tv[j] = vx;
      z.tv[j + 1] = vy;
      z.tv[j + 2] = vz;
    }
    if (any && !z.physics) {
      // waking up from pure animation: start from the animated pose with its velocity
      for (let i = 0; i < NP * 3; i++) z.prev[i] = z.pts[i] - z.tv[i] * H;
    }
    z.physics = any;
    if (!any && z.alive && z.upright) {
      let full = true;
      for (let i = 0; i < NP; i++) if (!z.frozen[i] && z.pin[i] < 0.999) full = false;
      z.pinFull = full;
    } else z.pinFull = false;
    // queued impulses (bullets, blasts) land after the wake-up reset so none are lost
    for (let i = 0; i < NP * 3; i++) {
      if (z.kick[i] !== 0) {
        z.prev[i] -= z.kick[i] * H;
        z.kick[i] = 0;
      }
    }
    if (any && !z.asleep) {
      // nearby tree trunks for collision
      z.near.length = 0;
      const px = z.pts[P.PELVIS * 3];
      const pz = z.pts[P.PELVIS * 3 + 2];
      const pil = this.terrain.pillars;
      for (let k = 0; k < pil.length; k++) if (Math.abs(pil[k].x - px) < 2.6 && Math.abs(pil[k].z - pz) < 2.6) z.near.push(k);
    }
  }

  private step(z: Zombie) {
    const X = z.pts;
    const PV = z.prev;
    const TG = z.tgt;
    const TV = z.tv;
    const W = z.wgt;
    const s = z.s;
    const air = z.launchT > 0;
    const damping = air ? 0.9993 : 0.996;
    const gh2 = G * H * H;
    for (let i = 0; i < NP; i++) {
      if (z.frozen[i]) continue;
      const j = i * 3;
      const k = z.pinK[i];
      if (k >= 1) {
        X[j] = TG[j];
        X[j + 1] = TG[j + 1];
        X[j + 2] = TG[j + 2];
        PV[j] = X[j] - TV[j] * H;
        PV[j + 1] = X[j + 1] - TV[j + 1] * H;
        PV[j + 2] = X[j + 2] - TV[j + 2] * H;
        continue;
      }
      let vx = (X[j] - PV[j]) * damping;
      let vy = (X[j + 1] - PV[j + 1]) * damping;
      let vz = (X[j + 2] - PV[j + 2]) * damping;
      const vm = vx * vx + vy * vy + vz * vz;
      if (vm > (air ? 0.04 : 0.0256)) {
        // cap at ~19 m/s (24 m/s when launched): no explosive tunnelling, no exploding joints
        const k2 = (air ? 0.2 : 0.16) / Math.sqrt(vm);
        vx *= k2;
        vy *= k2;
        vz *= k2;
      }
      PV[j] = X[j];
      PV[j + 1] = X[j + 1];
      PV[j + 2] = X[j + 2];
      X[j] += vx;
      X[j + 1] += vy - gh2;
      X[j + 2] += vz;
      if (k > 0) {
        X[j] += (TG[j] - X[j]) * k;
        X[j + 1] += (TG[j + 1] - X[j + 1]) * k;
        X[j + 2] += (TG[j + 2] - X[j + 2]) * k;
        PV[j] += (X[j] - TV[j] * H - PV[j]) * k;
        PV[j + 1] += (X[j + 1] - TV[j + 1] * H - PV[j + 1]) * k;
        PV[j + 2] += (X[j + 2] - TV[j + 2] * H - PV[j + 2]) * k;
      }
    }

    // ---- constraints
    const iters = (z.dist > 28 && z.launchT <= 0 && z.kinetic < 2.5) || z.body === 'GETTING_UP' || z.body === 'RECOVERING' ? 4 : z.alive ? 7 : 5;
    for (let it = 0; it < iters; it++) {
      for (let c = 0; c < CS.n; c++) {
        if (!z.cOn[c]) continue;
        const a = CS.a[c];
        const b = CS.b[c];
        const wa = W[a];
        const wb = W[b];
        const ws = wa + wb;
        if (ws <= 0) continue;
        const ja = a * 3;
        const jb = b * 3;
        const dx = X[jb] - X[ja];
        const dy = X[jb + 1] - X[ja + 1];
        const dz = X[jb + 2] - X[ja + 2];
        const d = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1e-6;
        const lo = CS.min[c] * s;
        const hi = CS.max[c] >= 99 ? 99 : CS.max[c] * s;
        let goal: number;
        if (d < lo) goal = lo;
        else if (d > hi) goal = hi;
        else continue;
        const f = ((d - goal) / d / ws) * CS.stiff[c];
        X[ja] += dx * f * wa;
        X[ja + 1] += dy * f * wa;
        X[ja + 2] += dz * f * wa;
        X[jb] -= dx * f * wb;
        X[jb + 1] -= dy * f * wb;
        X[jb + 2] -= dz * f * wb;
      }
      // torn-able joints: merge the twin particles
      for (let q = 0; q < JOINTS.length; q++) {
        if (!z.jOn[q]) continue;
        const [a, b] = JOINTS[q];
        const wa = W[a];
        const wb = W[b];
        const ws = wa + wb;
        if (ws <= 0) continue;
        const ja = a * 3;
        const jb = b * 3;
        for (let e = 0; e < 3; e++) {
          const m = (X[ja + e] * wb + X[jb + e] * wa) / ws;
          X[ja + e] = m;
          X[jb + e] = m;
        }
      }
      // hinge limits early in the solve so the distance constraints settle afterwards (no residual stretch)
      if (it === 1 && z.body !== 'CRAWLING') this.hinges(z);
    }

    // ---- world collision: ground, walls, trunks
    const T = this.terrain;
    let minY = 9;
    for (let i = 0; i < NP; i++) {
      if (z.frozen[i] || W[i] <= 0) continue;
      const j = i * 3;
      const rad = RADIUS[i] * s;
      let gh = T.height(X[j], X[j + 2]);
      if (gh - X[j + 1] > 0.3) {
        // pushed into a wall / prop side: don't climb it, stop horizontally
        X[j] = PV[j];
        X[j + 2] = PV[j + 2];
        gh = T.height(X[j], X[j + 2]);
      }
      if (X[j + 1] < gh + rad) {
        X[j + 1] = gh + rad;
        const fr = air ? 0.11 : z.alive ? 0.16 : 0.22;
        PV[j] += (X[j] - PV[j]) * fr;
        PV[j + 2] += (X[j + 2] - PV[j + 2]) * fr;
        if (PV[j + 1] < X[j + 1]) PV[j + 1] = X[j + 1] - (X[j + 1] - PV[j + 1]) * -0.08;
      }
      for (const k of z.near) {
        const pp = T.pillars[k];
        const dx = X[j] - pp.x;
        const dz = X[j + 2] - pp.z;
        const rr = pp.r + rad;
        const d2 = dx * dx + dz * dz;
        if (d2 < rr * rr && d2 > 1e-6) {
          const d = Math.sqrt(d2);
          X[j] = pp.x + (dx / d) * rr;
          X[j + 2] = pp.z + (dz / d) * rr;
        }
      }
      const ry = X[j + 1] - gh - rad;
      if (TORSO.includes(i) && ry < minY) minY = ry;
    }
    z.minY = minY;
  }

  /** Knees bend forward, elbows bend backward: reflect inverted hinges. */
  private hinges(z: Zombie) {
    const X = z.pts;
    const sx = X[P.LHIP * 3] - X[P.RHIP * 3];
    const sy = X[P.LHIP * 3 + 1] - X[P.RHIP * 3 + 1];
    const sz = X[P.LHIP * 3 + 2] - X[P.RHIP * 3 + 2];
    const ux = X[P.SPINE * 3] - X[P.PELVIS * 3];
    const uy = X[P.SPINE * 3 + 1] - X[P.PELVIS * 3 + 1];
    const uz = X[P.SPINE * 3 + 2] - X[P.PELVIS * 3 + 2];
    _v.set(sy * uz - sz * uy, sz * ux - sx * uz, sx * uy - sy * ux).normalize();
    for (let k = 0; k < 2; k++) {
      if (!z.jOn[5 + k] || !z.jOn[7 + k]) continue;
      this.fixHinge(z, LEG[k][0], LEG[k][1], LEG[k][2], LEG[k][3], _v, 1);
    }
    const tx = X[P.LSH * 3] - X[P.RSH * 3];
    const ty = X[P.LSH * 3 + 1] - X[P.RSH * 3 + 1];
    const tz = X[P.LSH * 3 + 2] - X[P.RSH * 3 + 2];
    const vx = X[P.CHEST * 3] - X[P.SPINE * 3];
    const vy = X[P.CHEST * 3 + 1] - X[P.SPINE * 3 + 1];
    const vz = X[P.CHEST * 3 + 2] - X[P.SPINE * 3 + 2];
    _w.set(ty * vz - tz * vy, tz * vx - tx * vz, tx * vy - ty * vx).normalize();
    for (let k = 0; k < 2; k++) {
      if (!z.jOn[1 + k] || !z.jOn[3 + k]) continue;
      this.fixHinge(z, ARM[k][0], ARM[k][1], ARM[k][2], ARM[k][3], _w, -1);
    }
  }
  private fixHinge(z: Zombie, a: number, m: number, m2: number, c: number, fwd: THREE.Vector3, sign: number) {
    const X = z.pts;
    if (z.wgt[m] <= 0) return;
    const ax = X[a * 3];
    const ay = X[a * 3 + 1];
    const az = X[a * 3 + 2];
    let dx = X[c * 3] - ax;
    let dy = X[c * 3 + 1] - ay;
    let dz = X[c * 3 + 2] - az;
    const dl = Math.hypot(dx, dy, dz) || 1;
    dx /= dl;
    dy /= dl;
    dz /= dl;
    let fx = fwd.x;
    let fy = fwd.y;
    let fz = fwd.z;
    const fd = fx * dx + fy * dy + fz * dz;
    fx -= dx * fd;
    fy -= dy * fd;
    fz -= dz * fd;
    const fl = Math.hypot(fx, fy, fz);
    if (fl < 1e-3) return;
    fx /= fl;
    fy /= fl;
    fz /= fl;
    const mx = X[m * 3] - (ax + X[c * 3]) * 0.5;
    const my = X[m * 3 + 1] - (ay + X[c * 3 + 1]) * 0.5;
    const mz = X[m * 3 + 2] - (az + X[c * 3 + 2]) * 0.5;
    const o = (mx * fx + my * fy + mz * fz) * sign;
    if (o >= -0.005) return;
    const k = Math.min(0.04, -o * 1.2) * sign;
    for (const i of [m, m2]) {
      X[i * 3] += fx * k;
      X[i * 3 + 1] += fy * k;
      X[i * 3 + 2] += fz * k;
    }
  }

  private post(z: Zombie, dt: number) {
    const X = z.pts;
    // missing (hidden) parts ride along invisibly at their stump
    for (let i = 0; i < NP; i++) {
      const g = z.ghostTo[i];
      if (g < 0) continue;
      X[i * 3] = X[g * 3];
      X[i * 3 + 1] = X[g * 3 + 1];
      X[i * 3 + 2] = X[g * 3 + 2];
    }
    // smeared blood trail from bodies sliding over the snow
    if (!z.upright && z.physics && !z.asleep && z.minY < 0.12 && (!z.alive || z.stumps.length > 0 || z.segDmg[2] + z.segDmg[3] > 0.3)) {
      const j = P.PELVIS * 3;
      const vx = (X[j] - z.prev[j]) / H;
      const vz = (X[j + 2] - z.prev[j + 2]) / H;
      const sp = Math.hypot(vx, vz);
      if (sp > 0.8) {
        z.trailAcc += sp * dt;
        if (z.trailAcc > 0.3) {
          z.trailAcc = 0;
          this.blood.decal(X[j], X[j + 2], 0.28 + r() * 0.15, 0, undefined, vx * 2, vz * 2, 0.8);
        }
      }
    }
    // kinetic energy proxy (core body)
    let ke = 0;
    if (z.physics && !z.asleep) {
      for (const i of TORSO) {
        const j = i * 3;
        const v = Math.hypot(X[j] - z.prev[j], X[j + 1] - z.prev[j + 1], X[j + 2] - z.prev[j + 2]) / H;
        if (v > ke) ke = v;
      }
    }
    z.kinetic = ke;

    // body hits the ground
    if (z.body === 'FALLING' && z.bodyT > 0.12 && z.minY < 0.05 && !z.impactDone) {
      z.impactDone = true;
      this.setBody(z, 'GROUND_IMPACT');
      _v.set(X[P.SPINE * 3], X[P.SPINE * 3 + 1] - 0.1, X[P.SPINE * 3 + 2]);
      this.blood.snow(_v, 5);
      if (z.segDmg[2] + z.segDmg[3] > 0.2 || !z.alive) this.blood.decal(_v.x, _v.z, 0.8 + r() * 0.6);
      const dd = z.dist;
      if (dd < 30) this.foley.thud(dd);
      // the slam shakes cracked plates loose
      const vy = Math.abs((X[P.SPINE * 3 + 1] - z.prev[P.SPINE * 3 + 1]) / H);
      if (vy > 2.2) {
        this.lost.length = 0;
        this.render.shake(z.slot, Math.min(1, (vy - 1.8) * 0.3), this.time, this.lost);
        if (this.lost.length) this.shed(this.lost, null, 1.2, 10);
      }
    }
    // corpses bleed out into a spreading pool
    if (!z.alive && z.body === 'RAGDOLL_ON_GROUND' && z.bodyT > 0.6 && z.bodyT - dt <= 0.6) {
      this.blood.decal(X[P.SPINE * 3], X[P.SPINE * 3 + 2], 2.0 + r() * 1.3, 0.42);
      if (z.craters.length) this.blood.decal(X[P.CHEST * 3] + (r() - 0.5) * 0.4, X[P.CHEST * 3 + 2] + (r() - 0.5) * 0.4, 1.1 + r() * 0.7, 0.55);
    }

    // follow the ragdoll with the root while it is not animated
    if (!z.upright && z.body !== 'CRAWLING' && z.body !== 'GETTING_UP' && z.body !== 'RECOVERING') {
      z.pos.x = X[P.PELVIS * 3];
      z.pos.z = X[P.PELVIS * 3 + 2];
      z.pos.y = this.terrain.height(z.pos.x, z.pos.z);
      z.rootY = z.pos.y;
    }

    // sleep settled corpses, freeze resting severed pieces
    if (!z.alive && z.physics && !z.asleep) {
      const farC = z.dist > 30;
      if (ke < (farC ? 0.35 : 0.12) && z.deadT > (farC ? 0.8 : 1.2)) z.quietT += dt;
      else z.quietT = 0;
      if (z.quietT > (farC ? 0.3 : 0.8)) {
        z.asleep = true;
        z.prev.set(z.pts);
      }
    }
    if (z.alive) {
      for (let i = 0; i < NP; i++) {
        if (!z.detached[i] || z.frozen[i]) continue;
        const j = i * 3;
        const v = Math.hypot(X[j] - z.prev[j], X[j + 1] - z.prev[j + 1], X[j + 2] - z.prev[j + 2]) / H;
        z.restT[i] = v < 0.1 ? z.restT[i] + dt : 0;
        if (z.restT[i] > 1.2) z.frozen[i] = 1;
      }
    }

    // bounds for hit tests (animated walkers: a box around the root is enough)
    if (!z.physics && z.alive && z.upright) {
      const s = z.s;
      z.bbMin.set(z.pos.x - 1.05 * s, z.rootY - 0.3, z.pos.z - 1.05 * s);
      z.bbMax.set(z.pos.x + 1.05 * s, z.rootY + 2.15 * s, z.pos.z + 1.05 * s);
      return;
    }
    let x0 = 1e9;
    let y0 = 1e9;
    let z0 = 1e9;
    let x1 = -1e9;
    let y1 = -1e9;
    let z1 = -1e9;
    for (let i = 0; i < NP; i++) {
      const j = i * 3;
      if (X[j] < x0) x0 = X[j];
      if (X[j] > x1) x1 = X[j];
      if (X[j + 1] < y0) y0 = X[j + 1];
      if (X[j + 1] > y1) y1 = X[j + 1];
      if (X[j + 2] < z0) z0 = X[j + 2];
      if (X[j + 2] > z1) z1 = X[j + 2];
    }
    z.bbMin.set(x0 - 0.2, y0 - 0.2, z0 - 0.2);
    z.bbMax.set(x1 + 0.2, y1 + 0.2, z1 + 0.2);
  }

  // ===================================================================== hits
  private rayBox(o: THREE.Vector3, d: THREE.Vector3, mn: THREE.Vector3, mx: THREE.Vector3, tMax: number) {
    let t0 = 0;
    let t1 = tMax;
    for (const a of ['x', 'y', 'z'] as const) {
      const inv = 1 / (d[a] || 1e-9);
      let ta = (mn[a] - o[a]) * inv;
      let tb = (mx[a] - o[a]) * inv;
      if (ta > tb) [ta, tb] = [tb, ta];
      t0 = Math.max(t0, ta);
      t1 = Math.min(t1, tb);
      if (t1 < t0) return false;
    }
    return true;
  }

  /** Ray vs every body segment (capsules). Sorted by distance, one hit per zombie. */
  raycast(o: THREE.Vector3, d: THREE.Vector3, tMin: number, tMax: number): ZHit[] {
    const out: ZHit[] = [];
    for (const z of this.zombies) {
      if (!z.active || z.sinkT > 0 || !this.rayBox(o, d, z.bbMin, z.bbMax, tMax)) continue;
      let best = Infinity;
      let bs = -1;
      for (let i = 0; i < SEGS.length; i++) {
        if (z.hidden & (1 << i)) continue;
        const sg = SEGS[i];
        const a = sg.a * 3;
        const b = sg.b * 3;
        const ax = z.pts[a];
        const ay = z.pts[a + 1];
        const az = z.pts[a + 2];
        const ux = z.pts[b] - ax;
        const uy = z.pts[b + 1] - ay;
        const uz = z.pts[b + 2] - az;
        // closest approach between the ray and the segment
        const wx = o.x - ax;
        const wy = o.y - ay;
        const wz = o.z - az;
        const A = d.x * d.x + d.y * d.y + d.z * d.z;
        const B = d.x * ux + d.y * uy + d.z * uz;
        const C = ux * ux + uy * uy + uz * uz;
        const D = d.x * wx + d.y * wy + d.z * wz;
        const E = ux * wx + uy * wy + uz * wz;
        const den = A * C - B * B;
        let sc: number;
        let tc: number;
        if (den < 1e-8) {
          sc = 0;
          tc = C > 0 ? E / C : 0;
        } else {
          sc = (B * E - C * D) / den;
          tc = (A * E - B * D) / den;
        }
        tc = clamp01(tc);
        sc = (B * tc - D) / A;
        if (sc < tMin || sc > tMax) continue;
        const px = o.x + d.x * sc - (ax + ux * tc);
        const py = o.y + d.y * sc - (ay + uy * tc);
        const pz = o.z + d.z * sc - (az + uz * tc);
        const rad = sg.r * z.s;
        const dist2 = px * px + py * py + pz * pz;
        if (dist2 > rad * rad) continue;
        const tHit = sc - Math.sqrt(rad * rad - dist2);
        if (tHit < best) {
          best = tHit;
          bs = i;
        }
      }
      if (bs >= 0) out.push({ z, seg: bs, t: best, point: o.clone().addScaledVector(d, best) });
    }
    out.sort((a, b) => a.t - b.t);
    return out;
  }

  private dropPins(z: Zombie, list: number[], v: number) {
    z.pinFull = false;
    for (const i of list) z.pin[i] = Math.min(z.pin[i], v);
  }

  private impulse(z: Zombie, i: number, dx: number, dy: number, dz: number, J: number) {
    const dv = Math.min(14, J * INV_MASS[i]);
    const j = i * 3;
    z.pinFull = false;
    z.kick[j] += dx * dv;
    z.kick[j + 1] += dy * dv;
    z.kick[j + 2] += dz * dv;
    z.frozen[i] = 0;
    z.restT[i] = 0;
  }

  /** Velocity of a body segment (ragdoll) or of the walking root (animation). */
  private segVel(z: Zombie, seg: number, out: THREE.Vector3) {
    const sg = SEGS[seg];
    if (!z.physics || z.asleep) return out.copy(z.vel);
    const a = sg.a * 3;
    const b = sg.b * 3;
    out.set(
      ((z.pts[a] - z.prev[a] + z.pts[b] - z.prev[b]) * 0.5) / H,
      ((z.pts[a + 1] - z.prev[a + 1] + z.pts[b + 1] - z.prev[b + 1]) * 0.5) / H,
      ((z.pts[a + 2] - z.prev[a + 2] + z.pts[b + 2] - z.prev[b + 2]) * 0.5) / H,
    );
    const l = out.length();
    if (l > 8) out.multiplyScalar(8 / l);
    return out;
  }

  /**
   * Throw the whole ragdoll: linear velocity along the shot (+ lift) plus an
   * angular kick from the lever arm between the impact and the centre of mass.
   * Every attached particle receives a rigid-body-consistent velocity, so the
   * constraints carry the motion instead of absorbing it (no stretching).
   */
  private launch(z: Zombie, dir: THREE.Vector3, at: THREE.Vector3, speed: number, lift: number, spin: number) {
    const X = z.pts;
    let cx = 0;
    let cy = 0;
    let cz = 0;
    let m = 0;
    for (let i = 0; i < NP; i++) {
      if (z.detached[i] || z.ghostTo[i] >= 0) continue;
      const w = 1 / INV_MASS[i];
      cx += X[i * 3] * w;
      cy += X[i * 3 + 1] * w;
      cz += X[i * 3 + 2] * w;
      m += w;
    }
    if (m <= 0) return;
    cx /= m;
    cy /= m;
    cz /= m;
    const hl = Math.hypot(dir.x, dir.z) || 1;
    const vx = (dir.x / hl) * speed;
    const vz = (dir.z / hl) * speed;
    const vy = lift + Math.max(-0.3, dir.y) * speed * 0.35;
    // ω ∝ r × d: high hits flip the body backwards, off-centre hits twist it round
    const rx = at.x - cx;
    const ry = at.y - cy;
    const rz = at.z - cz;
    const rl = Math.hypot(rx, ry, rz) || 1;
    const k = (spin * 3) / Math.max(0.25, rl);
    let wx = (ry * dir.z - rz * dir.y) * k;
    let wy = (rz * dir.x - rx * dir.z) * k;
    let wz = (rx * dir.y - ry * dir.x) * k;
    const wl = Math.hypot(wx, wy, wz);
    if (wl > 7.5) {
      wx *= 7.5 / wl;
      wy *= 7.5 / wl;
      wz *= 7.5 / wl;
    }
    for (let i = 0; i < NP; i++) {
      if (z.detached[i] || z.ghostTo[i] >= 0) continue;
      const j = i * 3;
      const px = X[j] - cx;
      const py = X[j + 1] - cy;
      const pz = X[j + 2] - cz;
      z.kick[j] += vx + (wy * pz - wz * py);
      z.kick[j + 1] += vy + (wz * px - wx * pz);
      z.kick[j + 2] += vz + (wx * py - wy * px);
      z.pin[i] = 0;
      z.frozen[i] = 0;
      z.restT[i] = 0;
    }
    z.launchT = 1.7;
    z.pinFull = false;
    z.asleep = false;
    z.quietT = 0;
    z.push.set(0, 0, 0);
  }

  /** Physical reaction to a bullet, based on exactly which segment it struck. */
  hit(h: ZHit, dir: THREE.Vector3, w: ShotSpec) {
    const z = h.z;
    const sg = SEGS[h.seg];
    const pw = w.power;
    const heavy = !!w.heavy;
    z.asleep = false;
    z.quietT = 0;
    const onPiece = z.detached[sg.a] && z.detached[sg.b];
    const headHit = sg.region === 'head';
    const bv = this.segVel(z, h.seg, _bv);
    this.impactAge = 0;
    this.impactPower = pw;

    // ---- Voronoi fracture of the real body mesh: entry wound + (bigger) exit wound
    const lost = this.lost;
    lost.length = 0;
    const frR = (w.frag ?? 0.045) * (headHit ? 1.35 : 1);
    const frK = w.fragK ?? 0.8;
    this.render.fracture(z.slot, h.seg, h.point, dir, frR, frK, this.time, lost);
    const ex = w.exit ?? 0;
    if (ex > 0) {
      _w.copy(h.point).addScaledVector(dir, sg.r * z.s * 1.7);
      this.render.fracture(z.slot, h.seg, _w, dir, frR * ex, frK * Math.min(1.4, 0.55 + 0.45 * ex), this.time, lost);
    }
    if (lost.length) {
      // blown-off plates leave as the exact Voronoi chunks, from the exact spot on the body
      this.shed(lost, dir, heavy ? 7.5 : 2.6, heavy ? 28 : 10);
      if (!z.craters.includes(h.seg)) {
        if (z.craters.length >= 6) z.craters.shift();
        z.craters.push(h.seg);
      }
      // the fresh crater pumps blood for a few seconds
      z.bleedT = Math.max(z.bleedT, heavy ? 5.5 : 3.2);
      z.bleedSeg = h.seg;
    }

    // ---- blood (inherits the body's own motion so it stays glued to the animation)
    this.blood.impact(h.point, dir, Math.min(3, pw * 1.15), headHit, bv, heavy);
    if (pw >= 2) this.blood.chunks(h.point, dir, headHit ? 8 : 5, 3.5, 0.25);
    else if (headHit || sg.region === 'torso') this.blood.chunks(h.point, dir, 2, 2.4, 0.1);
    soundEngine.playZombieHit(Math.max(2, z.dist), headHit);
    z.segDmg[h.seg] = Math.min(1, z.segDmg[h.seg] + 0.22 * pw);
    this.render.tint(z.slot, h.seg, z.segDmg[h.seg]);
    // the wound stays on that exact spot of the body; cloth rips wider with every hit
    this.render.wound(z.slot, h.seg, h.point, 0.55 + 0.3 * pw);
    this.render.tear(z.slot, h.seg, this.render.tearOf(z.slot, h.seg) + 0.12 + 0.1 * pw);

    // ---- the bullet's momentum, split between the two particles of the segment
    const a = sg.a * 3;
    const ax = z.pts[a];
    const ay = z.pts[a + 1];
    const az = z.pts[a + 2];
    const bx = z.pts[sg.b * 3];
    const by = z.pts[sg.b * 3 + 1];
    const bz = z.pts[sg.b * 3 + 2];
    const L2 = (bx - ax) ** 2 + (by - ay) ** 2 + (bz - az) ** 2 || 1;
    const u = clamp01(((h.point.x - ax) * (bx - ax) + (h.point.y - ay) * (by - ay) + (h.point.z - az) * (bz - az)) / L2);
    // heavy rounds move the whole body through launch(); the local impulse only adds the whip at the wound
    const J = w.impulse * (z.alive ? 1 : 0.75) * (heavy ? 0.4 : 1);
    this.impulse(z, sg.a, dir.x, dir.y, dir.z, J * (1 - u) * 1.6);
    this.impulse(z, sg.b, dir.x, dir.y, dir.z, J * u * 1.6);
    // momentum carries into the rest of the body (heavier parts lag, lighter ones whip)
    const spread = sg.region === 'torso' || sg.region === 'pelvis' || headHit ? 0.55 : 0.25;
    for (const i of TORSO) if (i !== sg.a && i !== sg.b) this.impulse(z, i, dir.x, dir.y * 0.5, dir.z, J * spread);
    if (headHit) this.impulse(z, P.HEAD, dir.x, dir.y + 0.15, dir.z, J * 0.9); // violent head snap
    if (onPiece || !z.alive) {
      for (const i of [sg.a, sg.b]) z.pin[i] = 0;
      // corpses still answer every round; heavy rounds pick them up and throw them again
      if (heavy && !onPiece) {
        this.launch(z, dir, h.point, (w.knock ?? 6) * 0.55, (w.lift ?? 2) * 0.5, (w.spin ?? 1) * 0.6);
        if (z.body === 'RAGDOLL_ON_GROUND' || z.body === 'GROUND_IMPACT') {
          z.impactDone = false;
          this.setBody(z, 'FALLING');
        }
      }
      if (!z.alive && sg.part && (this.render.fracLevel(z.slot, h.seg) > 0.38 || (z.segDmg[h.seg] > 0.6 && (pw >= 2 || r() < 0.35)))) this.sever(z, sg.part, dir, h.point);
      if (!z.alive && headHit && this.render.fracLevel(z.slot, 0) > 0.7) this.popHead(z, dir);
      return;
    }

    // ---- damage
    const dmg = w.dmg * sg.dmg;
    z.hp -= dmg;
    if (lost.length) this.integrity(z, h.seg, dir);
    const fx = Math.sin(z.yaw);
    const fz = Math.cos(z.yaw);
    const lx = Math.cos(z.yaw);
    const lz = -Math.sin(z.yaw);
    const df = dir.x * fx + dir.z * fz; // along facing (-1 = shot from the front)
    const dl = dir.x * lx + dir.z * lz;
    const hl = (h.point.x - z.pos.x) * lx + (h.point.z - z.pos.z) * lz; // lever arm
    const sc = 1 / Math.max(0.7, pw * 0.7);
    const reg = sg.region;
    let bal = 0;
    let push = 0;
    let stag = 0;

    // ---- region specific body reaction (animation layer + powered ragdoll)
    if (reg === 'head') {
      this.dropPins(z, HEADP, 0);
      this.dropPins(z, [P.NECK], 0.3 * sc);
      this.dropPins(z, UPPER, 0.6 * sc);
      z.headP.v += -df * 14 * pw + 4;
      z.headY.v += dl * 8 * pw;
      z.headR.v -= dl * 10 * pw;
      z.hitLeanX.v += df * 4 * pw;
      bal = 0.45;
      push = 1.1;
      stag = 1.1;
    } else if (reg === 'torso') {
      const upper = sg.kind === 'chest';
      this.dropPins(z, upper ? UPPER : LOWER, (upper ? 0.15 : 0.3) * sc);
      this.dropPins(z, HEADP, 0.25 * sc);
      this.dropPins(z, upper ? LOWER : UPPER, 0.5 * sc);
      this.dropPins(z, ARM[0], 0.35);
      this.dropPins(z, ARM[1], 0.35);
      z.hitLeanX.v += df * (upper ? 7 : 5) * pw;
      z.hitLeanZ.v -= dl * 5 * pw;
      z.hitTwist.v += hl * -df * 26 * pw;
      z.headP.v -= df * 6 * pw;
      bal = upper ? 0.34 : 0.38;
      push = 1.6;
      stag = 1.2;
    } else if (reg === 'pelvis') {
      this.dropPins(z, LOWER, 0.3 * sc);
      this.dropPins(z, UPPER, 0.55);
      z.hitLeanX.v -= df * 3 * pw;
      z.buckle[0].v += 2 * pw;
      z.buckle[1].v += 2 * pw;
      bal = 0.5;
      push = 1.2;
      stag = 1.1;
    } else if (reg === 'lArm' || reg === 'rArm') {
      const k = reg === 'lArm' ? 0 : 1;
      const fore = sg.kind !== 'upperArm';
      this.dropPins(z, fore ? ARM[k].slice(2) : ARM[k], 0);
      if (fore) this.dropPins(z, [ARM[k][1]], 0.3);
      this.dropPins(z, [k === 0 ? P.LSH : P.RSH], 0.5);
      z.hitTwist.v += (k === 0 ? 1 : -1) * -df * 9 * pw;
      z.slowT = 0.35;
      bal = 0.08;
      push = 0.25;
      stag = 0.3;
      const key = k === 0 ? 'lArm' : 'rArm';
      z.limbHp[key] -= w.dmg;
    } else {
      const k = reg === 'lLeg' ? 0 : 1;
      this.dropPins(z, LEG[k].slice(1), 0.18 * sc);
      this.dropPins(z, LOWER, 0.7);
      z.buckle[k].v += 7 * pw;
      z.hitLeanZ.v += (k === 0 ? -1 : 1) * 3 * pw;
      bal = 0.6;
      push = 0.6;
      stag = 0.9;
      const key = k === 0 ? 'lLeg' : 'rLeg';
      z.limbHp[key] -= w.dmg;
      // the foot gets knocked out of place
      const f = z.feet[k];
      if (!f.swing && r() < 0.5 * pw) {
        f.x += dir.x * 0.12;
        f.z += dir.z * 0.12;
      }
    }
    const momentum = z.kind === 'runner' ? 1 + z.speed * 0.12 : 1;
    // sustained fire stacks: every extra round in quick succession hits harder
    z.hitStack = Math.min(4, z.hitStack + 1);
    const stack = 1 + 0.18 * z.hitStack;
    z.balance -= bal * pw * momentum * stack * (z.body === 'STANDING_AGAIN' || z.body === 'GETTING_UP' ? 1.6 : 1);
    if (z.upright || z.body === 'CRAWLING') z.push.addScaledVector(_v.set(dir.x, 0, dir.z).normalize(), push * pw * (w.push ?? 1) * stack);
    z.speed *= 0.55; // stopping power: every hit kills the zombie's momentum
    if ((z.body === 'STANDING' || z.body === 'STAGGERED') && stag * pw > 0.45) {
      this.setBody(z, 'STAGGERED');
      z.staggerDur = 0.4 + 0.3 * stag * pw * Math.min(1.6, stack);
    }
    if (z.beh === 'IDLE' || z.beh === 'WANDERING' || z.beh === 'INVESTIGATING') this.setBeh(z, 'CHASING');
    if (z.beh === 'ATTACKING' && pw > 0.9) this.setBeh(z, 'APPROACHING');

    // ---- tearing limbs off (hit points, heavy rounds, or structural failure of a shattered part)
    if (sg.part && sg.part !== 'head') {
      const hpKey = sg.region === 'lArm' ? 'lArm' : sg.region === 'rArm' ? 'rArm' : sg.region === 'lLeg' ? 'lLeg' : 'rLeg';
      if (z.limbHp[hpKey] <= 0 || (pw >= 2 && r() < 0.75) || this.render.fracLevel(z.slot, h.seg) > 0.42) this.sever(z, sg.part, dir, h.point);
    }
    if (sg.region === 'head' && z.hp <= 0) {
      this.headshots++;
      // most headshots leave a blown-open Voronoi crater; only a shattered skull comes apart completely
      if (this.render.fracLevel(z.slot, 0) > 0.62 || r() < w.explode) this.popHead(z, dir);
      else if (sg.kind === 'neck' || r() < 0.15) this.sever(z, 'head', dir, h.point);
    }

    const knock = w.knock ?? 2.5;
    if (z.hp <= 0) {
      // the killing shot throws the whole body; heavy rounds lift it clean off its feet
      if (headHit) soundEngine.playHit('headshot', Math.max(2, z.dist));
      this.die(z, dir);
      this.launch(z, dir, h.point, knock * (headHit && !heavy ? 0.8 : 1), w.lift ?? 0.6, w.spin ?? 0.6);
    } else if (heavy && reg !== 'lArm' && reg !== 'rArm') {
      // anti-materiel round: even survivors are blown off their feet
      this.knockDown(z, dir, true);
      this.launch(z, dir, h.point, knock * 0.8, (w.lift ?? 2) * 0.8, w.spin ?? 1);
    } else if (heavy) {
      // arm shot: the arm goes, the body is spun round and dropped
      this.knockDown(z, dir, true);
      this.launch(z, dir, h.point, knock * 0.4, (w.lift ?? 2) * 0.35, (w.spin ?? 1) * 1.3);
    } else if (z.balance < 0) {
      this.knockDown(z, dir, false);
      // driven off its feet by a sustained burst
      if (z.hitStack >= 3) this.launch(z, dir, h.point, knock * 0.45, 0.4, (w.spin ?? 0.6) * 0.5);
    } else if (!z.upright && z.body !== 'CRAWLING') {
      // hit while getting up: back down
      if (z.body === 'GETTING_UP' && pw > 0.9 && r() < 0.5) this.knockDown(z, dir, true);
    }
  }

  private sever(z: Zombie, part: PartId, dir: THREE.Vector3, at: THREE.Vector3) {
    if (z.severed.has(part)) return;
    if ((part === 'lFore' && z.severed.has('lArm')) || (part === 'rFore' && z.severed.has('rArm'))) return;
    if ((part === 'lShin' && z.severed.has('lLeg')) || (part === 'rShin' && z.severed.has('rLeg'))) return;
    const def = SEVER[part];
    const inD = new Uint8Array(NP);
    for (const i of def.pts) inD[i] = 1;
    // a shoulder tear also releases an already-torn forearm, etc.
    for (const i of def.pts) if (z.detached[i] && !inD[i]) inD[i] = 1;
    for (let c = 0; c < CS.n; c++) if (z.cOn[c] && inD[CS.a[c]] !== inD[CS.b[c]]) z.cOn[c] = 0;
    JOINTS.forEach(([a, b], q) => {
      if (inD[a] !== inD[b]) z.jOn[q] = 0;
    });
    z.severed.add(part);
    for (const i of def.pts) {
      z.detached[i] = 1;
      z.pin[i] = 0;
      this.impulse(z, i, dir.x + (r() - 0.5) * 0.6, dir.y + 0.5, dir.z + (r() - 0.5) * 0.6, 3 + r() * 2);
    }
    z.asleep = false;
    const segR = part === 'head' ? 0.06 : part.endsWith('Leg') ? 0.085 : part.endsWith('Shin') ? 0.065 : part.endsWith('Arm') ? 0.06 : 0.05;
    z.stumps.push({ at: def.stump[0], from: def.stump[1], r: segR, spurt: z.alive ? 3.5 : 1.5, drip: 25, dripT: 0 });
    z.stumps.push({ at: def.piece[0], from: def.piece[1], r: segR * 0.95, spurt: 0.6, drip: 10, dripT: 0 });
    // torn flesh + shredded cloth around the wound on the body side
    for (let i = 0; i < SEGS.length; i++) {
      const sg = SEGS[i];
      if (sg.a === def.stump[0] || sg.b === def.stump[0] || sg.a === def.stump[1]) this.render.tear(z.slot, i, 0.6);
      if (sg.a === def.piece[0]) this.render.tear(z.slot, i, 0.7);
    }
    this.blood.sever(at, dir);
    this.foley.splat(z.dist, true);
    this.limbs++;
    if (part === 'head') {
      if (z.alive) this.die(z, dir);
    } else if (z.alive && (part.endsWith('Leg') || part.endsWith('Shin'))) {
      z.crawler = true;
      this.knockDown(z, dir, true);
    }
  }

  private popHead(z: Zombie, dir: THREE.Vector3) {
    if (z.severed.has('head')) return;
    const hp = P.HEAD * 3;
    _w.set((z.pts[hp] + z.pts[P.NECK * 3]) / 2, (z.pts[hp + 1] + z.pts[P.NECK * 3 + 1]) / 2, (z.pts[hp + 2] + z.pts[P.NECK * 3 + 2]) / 2);
    this.blood.explode(_w, dir);
    this.foley.splat(z.dist, true);
    const def = SEVER.head;
    for (let c = 0; c < CS.n; c++) {
      const ia = def.pts.includes(CS.a[c]);
      const ib = def.pts.includes(CS.b[c]);
      if (ia || ib) z.cOn[c] = 0;
    }
    z.jOn[0] = 0;
    for (const i of def.pts) {
      z.detached[i] = 1;
      z.frozen[i] = 1;
      z.pin[i] = 0;
    }
    z.severed.add('head');
    z.hidden |= 1; // head segment (and hair) gone
    z.stumps.push({ at: P.NECK, from: P.CHEST, r: 0.07, spurt: 4, drip: 30, dripT: 0 });
    for (const i of def.pts) z.ghostTo[i] = P.NECK;
  }


  // ======================================================== pre-existing damage
  /** Some of the dead were already torn up before they rose: rips, old wounds, missing limbs. */
  private preDamage(z: Zombie) {
    const roll = r();
    const level = roll < 0.28 ? 0 : roll < 0.62 ? 1 : 2;
    if (level === 0) return;
    for (let i = 0; i < SEGS.length; i++) {
      if (r() < (level === 1 ? 0.35 : 0.75)) this.render.tear(z.slot, i, (level === 1 ? 0.15 : 0.35) + r() * (level === 1 ? 0.35 : 0.6));
    }
    const nW = level === 1 ? 1 + ((r() * 3) | 0) : 4 + ((r() * 6) | 0);
    for (let k = 0; k < nW; k++) {
      const seg = (r() * SEGS.length) | 0;
      this.render.surfacePoint(seg, _v);
      this.render.woundLocal(z.slot, seg, _v.x, _v.y, _v.z, 0.5 + r() * 0.9);
      z.segDmg[seg] = Math.min(1, z.segDmg[seg] + 0.3);
      this.render.tint(z.slot, seg, z.segDmg[seg]);
    }
    // old broken-open patches: dried Voronoi damage that was there before they rose
    // (rarer than the wounds: with a 1000-strong horde every fractured part costs real GPU time)
    const nF = level === 1 ? (r() < 0.12 ? 1 : 0) : r() < 0.5 ? 1 : 2;
    for (let k = 0; k < nF && this.render.fracUsed < this.render.maxFrac * 0.35; k++) {
      const seg = (r() * SEGS.length) | 0;
      this.render.fracturePre(z.slot, seg, 0.45 + r() * (level === 1 ? 0.6 : 1.1));
      if (!z.craters.includes(seg)) z.craters.push(seg);
    }
    if (level === 2) {
      const q = r();
      // walking amputees and legless crawlers
      if (q < 0.18) this.preSever(z, r() < 0.5 ? 'lFore' : 'rFore');
      else if (q < 0.3) this.preSever(z, r() < 0.5 ? 'lArm' : 'rArm');
      else if (q < 0.44) {
        this.preSever(z, r() < 0.5 ? 'lShin' : 'rLeg');
        z.crawler = true;
        z.body = 'CRAWLING';
        z.speedMax = Math.min(z.speedMax, 0.5);
      }
    }
  }

  /** Limb already missing at spawn: piece hidden, old ragged stump, slow ooze. */
  private preSever(z: Zombie, part: PartId) {
    const def = SEVER[part];
    const inD = new Uint8Array(NP);
    for (const i of def.pts) inD[i] = 1;
    for (let c = 0; c < CS.n; c++) if (inD[CS.a[c]] !== inD[CS.b[c]]) z.cOn[c] = 0;
    JOINTS.forEach(([a, b], q) => {
      if (inD[a] !== inD[b]) z.jOn[q] = 0;
    });
    for (const i of def.pts) {
      z.detached[i] = 1;
      z.frozen[i] = 1;
      z.pin[i] = 0;
      z.ghostTo[i] = def.stump[0];
    }
    SEGS.forEach((sg, i) => {
      if (inD[sg.a] || inD[sg.b]) z.hidden |= 1 << i;
      if (sg.a === def.stump[0] || sg.b === def.stump[0]) this.render.tear(z.slot, i, 0.75);
    });
    z.severed.add(part);
    const segR = part.endsWith('Leg') ? 0.085 : part.endsWith('Shin') ? 0.065 : part.endsWith('Arm') ? 0.06 : 0.05;
    z.stumps.push({ at: def.stump[0], from: def.stump[1], r: segR, spurt: 0, drip: 9999, dripT: r() * 2 });
  }

  // ============================================================ aggression
  /** Start retiring a corpse: it freezes and sinks into the snow, then its slot is reused. */
  private sink(z: Zombie) {
    if (z.sinkT > 0) return;
    z.sinkT = 1.4;
    z.asleep = true;
    z.prev.set(z.pts);
    z.bleedT = 0;
    z.craters.length = 0;
  }

  /** Best corpse to retire: old, far and preferably behind the camera. */
  private oldestCorpse(minAge: number, needFrac = false) {
    let best: Zombie | undefined;
    let bs = -Infinity;
    for (const z of this.zombies) {
      if (!z.active || z.alive || z.sinkT > 0 || z.deadT < minAge) continue;
      if (needFrac && this.render.fracPartsOf(z.slot) === 0) continue;
      const dx = z.pos.x - this.camX;
      const dz = z.pos.z - this.camZ;
      const d = Math.hypot(dx, dz);
      const behind = dx * this.camFx + dz * this.camFz < 0;
      const s = z.deadT + d * 0.4 + (behind ? 30 : 0) + (d > 40 ? 20 : 0);
      if (s > bs) {
        bs = s;
        best = z;
      }
    }
    return best;
  }

  /** Voronoi budget full: retire a fractured corpse, else heal the farthest fractured walker (unnoticeable at range). */
  private budget() {
    const R = this.render;
    let pending = 0;
    for (const z of this.zombies) if (z.active && z.sinkT > 0) pending += R.fracPartsOf(z.slot);
    if (R.fracUsed - pending < R.maxFrac) return;
    const c = this.oldestCorpse(4, true);
    if (c) {
      this.sink(c);
      return;
    }
    let far: Zombie | undefined;
    let fd = 28;
    for (const z of this.zombies) {
      if (!z.active || !z.alive) continue;
      const d = Math.hypot(z.pos.x - this.camX, z.pos.z - this.camZ);
      if (d > fd && R.fracPartsOf(z.slot) > 0) {
        fd = d;
        far = z;
      }
    }
    if (far) {
      R.releaseSlot(far.slot);
      far.craters.length = 0;
      far.bleedT = 0;
    }
  }

  setVoronoiMax(n: number) {
    this.render.maxFrac = Math.max(20, Math.round(n));
  }
  get voronoiMax() {
    return this.render.maxFrac;
  }
  get voronoiUsed() {
    return this.render.fracUsed;
  }
  get bodies() {
    let n = 0;
    for (const z of this.zombies) if (z.active) n++;
    return n;
  }

  /** World War Z frenzy: most of the horde becomes flat-out sprinters (restored when calm). */
  private frenzy(z: Zombie, on: boolean) {
    if (on) {
      if (z.frenzied) return;
      z.frenzied = true;
      z.baseKind = z.kind;
      z.baseSpeed = z.speedMax;
      z.baseTurn = z.turnRate;
      z.baseLean = z.lean;
      if (z.crawler) {
        z.speedMax = Math.max(z.speedMax, 0.8);
        return;
      }
      if (r() < 0.8) {
        z.kind = 'runner';
        z.speedMax = 4.8 + r() * 1.5;
        z.turnRate = 4.6;
        z.lean = 0.55 + r() * 0.25;
        z.armMode = 3;
      } else {
        z.speedMax = Math.max(z.speedMax, 2.6 + r() * 1.2);
        z.turnRate = 3.2;
      }
    } else {
      if (!z.frenzied) return;
      z.frenzied = false;
      z.kind = z.baseKind;
      z.speedMax = z.baseSpeed;
      z.turnRate = z.baseTurn;
      z.lean = z.baseLean;
    }
  }

  /** Blown-off Voronoi plates leave as the exact chunks, with a squirt of blood from each socket and a wet crunch. */
  private shed(lost: LostCell[], dir: THREE.Vector3 | null, speed: number, max: number) {
    const n = Math.min(lost.length, max);
    for (let i = 0; i < lost.length; i++) {
      const c = lost[i];
      const z = this.zombies[c.slot];
      if (i >= n) {
        _v.set(c.x, c.y, c.z);
        _w.set(c.nx, c.ny, c.nz);
        this.blood.chunks(_v, dir ?? _w, 1, speed * 0.6 + 1, 0.15);
        continue;
      }
      this.segVel(z, c.seg, _bv);
      const sp = speed * (0.55 + r() * 0.9);
      const out = 0.7 + r() * 1.8;
      this.debris.spawnCell(
        c.kind, c.cell, c.x, c.y, c.z, c.q, c.s,
        (dir ? dir.x * sp : 0) + c.nx * out + _bv.x + (r() - 0.5) * 0.8,
        (dir ? dir.y * sp : 0) + c.ny * out + _bv.y + 0.6 + r() * 1.4,
        (dir ? dir.z * sp : 0) + c.nz * out + _bv.z + (r() - 0.5) * 0.8,
        this.render.partColor(c.slot, c.seg), z.segDmg[c.seg],
      );
      if (i < 6) {
        _v.set(c.x, c.y, c.z);
        _w.set(c.nx, c.ny, c.nz);
        this.blood.spray(_v, _w, 5, 1.7, 0.5, 1, _bv, 0.5);
      }
    }
    if (lost.length) {
      const z = this.zombies[lost[0].slot];
      this.foley.splat(z.dist, lost.length > 3);
    }
  }

  /**
   * Hybrid limb system: the major regions decide gameplay state from how much
   * of their Voronoi structure is gone, while the cells handle the local shattering.
   */
  private integrity(z: Zombie, seg: number, dir: THREE.Vector3) {
    const lvl = this.render.fracLevel(z.slot, seg);
    const reg = SEGS[seg].region;
    if (reg === 'lLeg' || reg === 'rLeg') {
      const k = reg === 'lLeg' ? 0 : 1;
      if (lvl > 0.18) {
        z.limpSide = k;
        z.limp = Math.min(1, 0.6 + lvl);
        z.speedMax *= 0.85;
      }
      if (lvl > 0.34 && !z.crawler) {
        z.crawler = true; // a shattered leg can't carry the body
        this.knockDown(z, dir, true);
      }
    } else if (reg === 'lArm' || reg === 'rArm') {
      if (lvl > 0.25) z.armOut[reg === 'lArm' ? 0 : 1] = 1;
    } else if (reg === 'head') {
      if (lvl > 0.25) z.dazeT = Math.max(z.dazeT, 2.5);
    } else if (reg === 'torso') {
      if (lvl > 0.55) z.hp = Math.min(z.hp, 0); // the chest is gone
      else if (lvl > 0.3 && !z.crawler) {
        z.crawler = true; // spine shattered: it drags itself on
        this.knockDown(z, dir, true);
      }
    } else if (reg === 'pelvis') {
      if (lvl > 0.32 && !z.crawler) {
        z.crawler = true;
        this.knockDown(z, dir, true);
      }
    }
  }

  setAggressive(on: boolean) {
    this.aggressive = on;
    for (const z of this.zombies) if (z.active && z.alive) this.frenzy(z, on);
    if (!on) return;
    let n = 0;
    for (const z of this.zombies) {
      if (!z.active || !z.alive) continue;
      if (z.beh === 'IDLE' || z.beh === 'WANDERING' || z.beh === 'INVESTIGATING') this.setBeh(z, 'PLAYER_DETECTED');
      if (z.dist < 30 && n++ < 3) (z.kind === 'runner' ? this.foley.scream(z.dist) : this.foley.groan(z.dist, z.s));
    }
  }

  // ============================================================== explosions
  /** Blast: radial momentum into every particle, burns, tears limbs off near the core. */
  explode(c: THREE.Vector3, radius: number, power: number) {
    let hit = 0;
    for (const z of this.zombies) {
      if (!z.active || z.sinkT > 0) continue;
      const sp = P.SPINE * 3;
      const d = Math.hypot(z.pts[sp] - c.x, z.pts[sp + 1] - c.y, z.pts[sp + 2] - c.z);
      if (d > radius) continue;
      hit++;
      const f = 1 - d / radius;
      const ff = f * f;
      z.asleep = false;
      z.quietT = 0;
      const dir = _w.set(z.pts[sp] - c.x, 0, z.pts[sp + 2] - c.z).normalize();
      for (let i = 0; i < NP; i++) {
        if (z.ghostTo[i] >= 0) continue;
        const j = i * 3;
        let dx = z.pts[j] - c.x;
        let dy = z.pts[j + 1] - c.y;
        let dz = z.pts[j + 2] - c.z;
        const l = Math.hypot(dx, dy, dz) || 1;
        dx /= l;
        dy = dy / l + 0.55 + 0.4 * f;
        dz /= l;
        const dl = Math.hypot(dx, dy, dz);
        // heavy torso moves less than flailing hands; all clamped (no physics explosions)
        const v = Math.min(15, power * (3.5 + 11 * ff) * (0.8 + 0.4 * r()) * (0.75 + 0.25 * Math.sqrt(INV_MASS[i] * 4)));
        z.kick[j] += (dx / dl) * v;
        z.kick[j + 1] += (dy / dl) * v;
        z.kick[j + 2] += (dz / dl) * v;
        z.frozen[i] = 0;
        z.restT[i] = 0;
      }
      for (let i = 0; i < SEGS.length; i++) {
        z.segDmg[i] = Math.min(1, z.segDmg[i] + 0.35 * f);
        this.render.tint(z.slot, i, z.segDmg[i]);
        this.render.tear(z.slot, i, this.render.tearOf(z.slot, i) + 0.5 * f, Math.min(1, f * 1.3));
      }
      for (let k = 0; k < 1 + ((f * 4) | 0); k++) {
        const seg = (r() * SEGS.length) | 0;
        this.render.surfacePoint(seg, _v);
        this.render.woundLocal(z.slot, seg, _v.x, _v.y, _v.z, 0.6 + f);
      }
      // the blast shatters plates all over the body (fresh, wet damage)
      for (let k = 0; k < 1 + ((f * 5) | 0); k++) {
        const seg = (r() * SEGS.length) | 0;
        if (z.hidden & (1 << seg)) continue;
        this.lost.length = 0;
        this.render.fracturePre(z.slot, seg, 0.5 + f * 1.5, 1, this.lost);
        if (this.lost.length) this.shed(this.lost, dir, 6 * f, 4);
        if (!z.craters.includes(seg)) z.craters.push(seg);
      }
      if (f > 0.45) {
        for (const part of ['lArm', 'rArm', 'lLeg', 'rLeg', 'lFore', 'rShin'] as PartId[]) {
          if (r() < f * 0.42) {
            const a = SEVER[part].pts[0] * 3;
            _v.set(z.pts[a], z.pts[a + 1], z.pts[a + 2]);
            this.sever(z, part, dir, _v);
          }
        }
        if (f > 0.78 && r() < 0.45) this.popHead(z, dir);
      }
      if (z.alive) {
        z.hp -= 280 * ff + 25 * f;
        z.balance = -1;
        if (z.hp <= 0 || z.severed.has('head')) {
          if (z.alive) {
            z.alive = false;
            z.deadT = 0;
            this.kills++;
            z.fallDir.copy(dir);
            z.impactDone = false;
            this.setBody(z, 'FALLING');
          }
        } else this.knockDown(z, dir, true);
        if (z.beh === 'IDLE' || z.beh === 'WANDERING') this.setBeh(z, 'CHASING');
      } else if (z.body === 'RAGDOLL_ON_GROUND') {
        z.impactDone = false;
        this.setBody(z, 'FALLING');
      }
    }
    // the blast is heard everywhere
    this.noise(c.x, c.z, 80);
    return hit;
  }

  // ====================================================== body-body collisions
  /** Flying ragdolls collide with other bodies (and bowl standing zombies over). Spatial broad phase. */
  private collide() {
    const core = [P.CHEST, P.SPINE, P.PELVIS, P.HEAD, P.LKN, P.RKN];
    const solid = [P.CHEST, P.SPINE, P.PELVIS, P.HEAD];
    const R = 0.26;
    const Z = this.zombies;
    const head = this.colHead;
    const next = this.colNext;
    head.fill(-1);
    const cellOf = (x: number, z: number) => {
      const gx = Math.floor((x + SEP_O) / COL_C);
      const gz = Math.floor((z + SEP_O) / COL_C);
      return gx < 0 || gz < 0 || gx >= COL_N || gz >= COL_N ? -1 : gx * COL_N + gz;
    };
    for (let i = 0; i < Z.length; i++) {
      const b = Z[i];
      if (!b.active) continue;
      const k = cellOf((b.bbMin.x + b.bbMax.x) * 0.5, (b.bbMin.z + b.bbMax.z) * 0.5);
      if (k < 0) continue;
      next[i] = head[k];
      head[k] = i;
    }
    for (const a of Z) {
      if (!a.active || !a.physics || a.asleep || a.upright || a.body === 'CRAWLING' || a.kinetic < 0.4) continue;
      const gx = Math.floor(((a.bbMin.x + a.bbMax.x) * 0.5 + SEP_O) / COL_C);
      const gz = Math.floor(((a.bbMin.z + a.bbMax.z) * 0.5 + SEP_O) / COL_C);
      for (let ox = -1; ox <= 1; ox++) {
        for (let oz = -1; oz <= 1; oz++) {
          const cx = gx + ox;
          const cz = gz + oz;
          if (cx < 0 || cz < 0 || cx >= COL_N || cz >= COL_N) continue;
          for (let j = head[cx * COL_N + cz]; j >= 0; j = next[j]) {
            const b = Z[j];
            if (b === a) continue;
            if (a.bbMax.x < b.bbMin.x || a.bbMin.x > b.bbMax.x || a.bbMax.z < b.bbMin.z || a.bbMin.z > b.bbMax.z || a.bbMax.y < b.bbMin.y || a.bbMin.y > b.bbMax.y) continue;
            this.collidePair(a, b, core, solid, R);
          }
        }
      }
    }
  }

  private collidePair(a: Zombie, b: Zombie, core: number[], solid: number[], R: number) {
        const bStatic = b.upright || b.asleep || !b.physics;
        for (const i of core) {
          const ja = i * 3;
          for (const k of solid) {
            const jb = k * 3;
            const dx = a.pts[ja] - b.pts[jb];
            const dy = a.pts[ja + 1] - b.pts[jb + 1];
            const dz = a.pts[ja + 2] - b.pts[jb + 2];
            const d2 = dx * dx + dy * dy + dz * dz;
            if (d2 > R * R || d2 < 1e-8) continue;
            const d = Math.sqrt(d2);
            const pen = (R - d) / d;
            const wa = bStatic ? 1 : 0.5;
            a.pts[ja] += dx * pen * wa;
            a.pts[ja + 1] += dy * pen * wa;
            a.pts[ja + 2] += dz * pen * wa;
            if (!bStatic) {
              b.pts[jb] -= dx * pen * 0.5;
              b.pts[jb + 1] -= dy * pen * 0.5;
              b.pts[jb + 2] -= dz * pen * 0.5;
            }
            const vx = (a.pts[ja] - a.prev[ja]) / H;
            const vz = (a.pts[ja + 2] - a.prev[ja + 2]) / H;
            const sp = Math.hypot(vx, vz);
            if (b.upright && sp > 3.5) {
              // domino: a body slamming into a standing zombie can take it down
              b.balance -= 0.25 * sp * 0.25;
              b.hitLeanX.v -= 3;
              b.push.x += (vx / sp) * 1.2;
              b.push.z += (vz / sp) * 1.2;
              // domino budget: a flying body bowls a few over, it doesn't flatten the whole crowd in one frame
              if (b.balance < 0 && this.dominoBudget >= 1) {
                this.dominoBudget--;
                this.knockDown(b, _v.set(vx, 0, vz), false);
              } else if (b.balance < 0) b.balance = 0.05;
              else if (b.body === 'STANDING') {
                this.setBody(b, 'STAGGERED');
                b.staggerDur = 0.5;
              }
            }
          }
        }
  }

  // ============================================================ blood spurts
  private spurts(dt: number) {
    for (const z of this.zombies) {
      if (!z.active) continue;
      // open Voronoi craters keep dripping from the exact spot on the moving body
      // arterial jets: pulsing streams out of the freshest crater, riding the body's own motion
      if (z.bleedT > 0 && z.bleedSeg >= 0) {
        z.bleedT -= dt;
        const pulse = Math.max(0, Math.sin(this.time * 8.5 + z.slot * 1.7));
        const n = Math.round(pulse * pulse * 5 * Math.min(1, z.bleedT / 1.5) * Math.min(2, dt * 60));
        if (n > 0 && !(z.hidden & (1 << z.bleedSeg)) && this.render.craterJet(z.slot, z.bleedSeg, _v, _w)) {
          _w.y += 0.3;
          _w.normalize();
          this.segVel(z, z.bleedSeg, _bv);
          this.blood.stream(_v, _w, n, (1.1 + pulse * 2.8) * (z.alive ? 1 : 0.7), _bv);
        }
      }
      // wounded walkers leave a trail of drops and smears
      if (z.alive && z.upright && z.speed > 0.3 && (z.stumps.length > 0 || z.segDmg[0] + z.segDmg[2] + z.segDmg[3] + z.segDmg[4] > 0.5)) {
        z.trailAcc += z.speed * dt;
        if (z.trailAcc > 0.6) {
          z.trailAcc = 0;
          this.blood.decal(z.pos.x + (r() - 0.5) * 0.25, z.pos.z + (r() - 0.5) * 0.25, 0.1 + r() * 0.16, 0, undefined, z.vel.x * 1.6, z.vel.z * 1.6, 0.85);
        }
      }
      if (z.craters.length && (z.alive || z.deadT < 25)) {
        z.dripT -= dt;
        if (z.dripT <= 0) {
          z.dripT = (z.alive ? 0.2 : 0.4) + r() * 0.6;
          const seg = z.craters[(r() * z.craters.length) | 0];
          if (!(z.hidden & (1 << seg)) && this.render.craterPoint(z.slot, seg, _v) && this.render.localToWorld(z.slot, seg, _v.x, _v.y, _v.z, _v)) this.blood.drip(_v, 1);
        }
      }
      for (const st of z.stumps) {
        if (st.spurt <= 0) {
          if (st.drip > 0) {
            st.drip -= dt;
            st.dripT -= dt;
            if (st.dripT <= 0) {
              st.dripT = 0.25 + r() * 0.5;
              const a = st.at * 3;
              _v.set(z.pts[a], z.pts[a + 1] - 0.02, z.pts[a + 2]);
              _w.set(0, -1, 0);
              this.blood.spray(_v, _w, 1, 0.3, 0.15, 1.4);
            }
          }
          continue;
        }
        st.spurt -= dt;
        const pulse = 0.5 + 0.5 * Math.sin(this.time * 8 + st.at);
        const n = Math.round(st.spurt * 9 * pulse * dt * 60 * 0.25);
        if (n <= 0) continue;
        const a = st.at * 3;
        const f = st.from * 3;
        _v.set(z.pts[a], z.pts[a + 1], z.pts[a + 2]);
        _w.set(z.pts[a] - z.pts[f], z.pts[a + 1] - z.pts[f + 1], z.pts[a + 2] - z.pts[f + 2]).normalize();
        this.blood.stream(_v, _w, n, 1.2 + pulse * 1.8);
      }
    }
  }

  // ============================================================== population
  private respawn(dt: number, pl: PlayerInfo) {
    this.spawnT -= dt;
    // retire old corpses far from the player (they sink into the snow)
    for (const z of this.zombies) {
      if (z.active && !z.alive && z.sinkT <= 0 && z.deadT > 75 && Math.hypot(z.pos.x - pl.pos.x, z.pos.z - pl.pos.z) > 25) this.sink(z);
    }
    const alive = this.alive;
    // zombie count lowered in the settings: quietly remove the farthest walkers (out of sight)
    if (alive > this.target + 2) {
      let far: Zombie | undefined;
      let fd = 30;
      for (const z of this.zombies) {
        if (!z.active || !z.alive) continue;
        const d = Math.hypot(z.pos.x - pl.pos.x, z.pos.z - pl.pos.z);
        if (d > fd) {
          fd = d;
          far = z;
        }
      }
      for (let k = 0; far && k < 4; k++) {
        far.active = false;
        this.render.hide(far.slot);
        this.render.resetDamage(far.slot);
        far = undefined;
      }
    }
    if (this.spawnT > 0 || alive >= this.target) return;
    this.spawnT = this.aggressive ? 0.03 : 0.12;
    const slot = this.zombies.find((z) => !z.active);
    if (!slot) {
      // hard cap of 1000 bodies reached: the oldest corpse (preferably out of sight) sinks away and frees its slot
      let sinking = 0;
      for (const z of this.zombies) if (z.active && z.sinkT > 0) sinking++;
      if (sinking < 6) {
        const c = this.oldestCorpse(10);
        if (c) this.sink(c);
      }
      return;
    }
    // reinforcements stream in from out of sight, already hunting
    this.spawn(slot, pl.pos.x, pl.pos.z, 38, 66, true);
  }

  // ================================================================== render
  private draw() {
    const R = this.render;
    R.beginStumps();
    for (const z of this.zombies) {
      if (!z.active) continue;
      if (z.asleep) {
        // settled corpse: matrices don't change any more
        if (!z.drawnAsleep) {
          R.write(z.slot, z.pts, z.s, z.hidden, z.hairStyle);
          z.drawnAsleep = true;
        } else R.touch(z.slot);
      } else {
        z.drawnAsleep = false;
        if (z.posed || z.physics) R.write(z.slot, z.pts, z.s, z.hidden, z.hairStyle);
        else R.shift(z.slot, z.shX, z.shY, z.shZ);
      }
      for (const st of z.stumps) R.stump(z.pts, st.at, st.from, st.r * z.s);
    }
    R.commit();
  }
}
