import * as THREE from 'three';
import type { Terrain } from '../terrain';
import type { Blood } from './blood';
import type { FracInfo } from './voronoi';

/* ---------------------------------------------------------------------------
 * VORONOI CELL DEBRIS
 * Every Voronoi cell of every body part is registered once in a BatchedMesh as
 * its own little solid: the outer skin / cloth patch, the cut walls and the
 * inner face — the exact piece that breaks out of the zombie. When a plate is
 * destroyed, that very chunk leaves from the spot (and orientation) where it
 * sat on the animated body, so the hole and the flying piece match perfectly.
 * Cheap rigid particles (no constraints): gravity, terrain + wall bounce,
 * friction, sleep. One draw call for all fragments in the world.
 * ------------------------------------------------------------------------- */
const N = 720;
const LIFE = 40;
const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _p = new THREE.Vector3();
const _s = new THREE.Vector3();
const _c = new THREE.Color();

/** Split a fractured part into one geometry per Voronoi cell (positions relative to the cell centre). */
function cellGeometries(info: FracInfo): THREE.BufferGeometry[] {
  const pos = info.geo.getAttribute('position') as THREE.BufferAttribute;
  const nor = info.geo.getAttribute('normal') as THREE.BufferAttribute;
  const col = info.geo.getAttribute('color') as THREE.BufferAttribute;
  const inn = info.geo.getAttribute('aInner') as THREE.BufferAttribute;
  const P: number[][] = [];
  const Nn: number[][] = [];
  const C: number[][] = [];
  const Ly: number[][] = [];
  for (let c = 0; c < info.cells; c++) {
    P.push([]);
    Nn.push([]);
    C.push([]);
    Ly.push([]);
  }
  const index = info.geo.getIndex();
  const total = index ? index.count : pos.count;
  for (let t = 0; t < total; t++) {
    const i = index ? index.getX(t) : t;
    const code = inn.getW(i);
    const cell = code % 64;
    const layer = Math.floor(code / 64) % 4;
    if (cell >= info.cells) continue;
    P[cell].push(pos.getX(i) - info.center[cell * 3], pos.getY(i) - info.center[cell * 3 + 1], pos.getZ(i) - info.center[cell * 3 + 2]);
    Nn[cell].push(nor.getX(i), nor.getY(i), nor.getZ(i));
    C[cell].push(col.getX(i), col.getY(i), col.getZ(i));
    Ly[cell].push(layer);
  }
  return P.map((p, c) => {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(Nn[c], 3));
    g.setAttribute('color', new THREE.Float32BufferAttribute(C[c], 3));
    g.setAttribute('aLayer', new THREE.Float32BufferAttribute(Ly[c], 1));
    return g;
  });
}

export class Debris {
  private mesh: THREE.BatchedMesh;
  private geoId: Record<string, number[]> = {};
  private size: Record<string, Float32Array> = {};
  private inst = new Int32Array(N);
  private pos = new Float32Array(N * 3);
  private vel = new Float32Array(N * 3);
  private rot = new Float32Array(N * 4);
  private spin = new Float32Array(N * 3);
  private scl = new Float32Array(N);
  private rad = new Float32Array(N);
  private life = new Float32Array(N);
  private rest = new Uint8Array(N);
  private bled = new Uint8Array(N);
  private cursor = 0;
  private terrain: Terrain;
  private blood: Blood;
  active = 0;

  constructor(scene: THREE.Scene, terrain: Terrain, blood: Blood, parts: Record<string, FracInfo>) {
    this.terrain = terrain;
    this.blood = blood;
    const all: { kind: string; geos: THREE.BufferGeometry[] }[] = [];
    let verts = 0;
    for (const kind of Object.keys(parts)) {
      const geos = cellGeometries(parts[kind]);
      for (const g of geos) verts += g.attributes.position.count;
      all.push({ kind, geos });
      this.size[kind] = parts[kind].size;
    }
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.62, metalness: 0 });
    mat.onBeforeCompile = (sh) => {
      sh.vertexShader = sh.vertexShader
        .replace('#include <common>', '#include <common>\nattribute float aLayer; varying float vLayer; varying vec3 vLp;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\nvLayer = aLayer; vLp = position;');
      sh.fragmentShader = sh.fragmentShader
        .replace(
          '#include <common>',
          `#include <common>
          varying float vLayer; varying vec3 vLp;
          float dh(vec3 p){ p = fract(p*0.3183099+0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
          float dn(vec3 x){ vec3 i = floor(x); vec3 f = fract(x); f = f*f*(3.0-2.0*f);
            return mix(mix(mix(dh(i), dh(i+vec3(1,0,0)), f.x), mix(dh(i+vec3(0,1,0)), dh(i+vec3(1,1,0)), f.x), f.y),
                       mix(mix(dh(i+vec3(0,0,1)), dh(i+vec3(1,0,1)), f.x), mix(dh(i+vec3(0,1,1)), dh(i+vec3(1,1,1)), f.x), f.y), f.z); }
          float zWetD;`,
        )
        .replace(
          '#include <color_fragment>',
          `#include <color_fragment>
          zWetD = 0.0;
          if (vLayer < 0.5) {
            // outer skin / cloth of the zombie it came from, splashed with blood
            float b = smoothstep(0.35, 0.75, dn(vLp * 60.0));
            diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.5, 0.13, 0.12), 0.25 + 0.45 * b);
            zWetD = 0.4 * b;
          } else {
            // broken faces: cloth/skin band -> fat -> fibrous muscle -> dark core
            float dk = vLayer > 2.5 ? 1.0 : clamp(vLayer - 1.0, 0.0, 1.0);
            float fib = dn(vLp * vec3(120.0, 30.0, 120.0));
            vec3 muscle = mix(vec3(0.36, 0.035, 0.03), vec3(0.68, 0.13, 0.1), fib);
            vec3 fat = vec3(0.8, 0.64, 0.44) * (0.85 + 0.3 * dn(vLp * 150.0));
            vec3 cs = mix(diffuseColor.rgb * 0.8, fat, smoothstep(0.04, 0.12, dk));
            cs = mix(cs, muscle, smoothstep(0.15, 0.32, dk));
            cs *= mix(1.0, 0.55, smoothstep(0.5, 1.0, dk));
            diffuseColor.rgb = cs;
            zWetD = 0.75;
          }`,
        )
        .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\nroughnessFactor = mix(roughnessFactor, 0.2, zWetD);');
    };
    this.mesh = new THREE.BatchedMesh(N, verts + 64, (verts + 64) * 2, mat);
    this.mesh.sortObjects = false;
    this.mesh.castShadow = true;
    this.mesh.receiveShadow = true;
    for (const { kind, geos } of all) this.geoId[kind] = geos.map((g) => this.mesh.addGeometry(g));
    const first = all[0].kind;
    for (let i = 0; i < N; i++) {
      this.inst[i] = this.mesh.addInstance(this.geoId[first][0]);
      this.mesh.setVisibleAt(this.inst[i], false);
      this.mesh.setColorAt(this.inst[i], _c.setRGB(1, 1, 1));
    }
    scene.add(this.mesh);
  }

  /**
   * Launch the exact Voronoi piece `cell` of a `kind` body part.
   * (x,y,z) = cell centre, q = the part's world rotation, s = zombie scale.
   */
  spawnCell(kind: string, cell: number, x: number, y: number, z: number, q: THREE.Quaternion, s: number, vx: number, vy: number, vz: number, color: THREE.Color, darken = 0) {
    const ids = this.geoId[kind];
    if (!ids || cell >= ids.length) return;
    const i = this.cursor;
    this.cursor = (i + 1) % N;
    const id = this.inst[i];
    this.mesh.setGeometryIdAt(id, ids[cell]);
    this.mesh.setColorAt(id, _c.copy(color).multiplyScalar(1 - darken * 0.5));
    this.mesh.setVisibleAt(id, true);
    this.pos.set([x, y, z], i * 3);
    this.vel.set([vx, vy, vz], i * 3);
    this.rot.set([q.x, q.y, q.z, q.w], i * 4);
    const w = 7 + Math.random() * 16;
    this.spin.set([(Math.random() - 0.5) * w, (Math.random() - 0.5) * w, (Math.random() - 0.5) * w], i * 3);
    this.scl[i] = s;
    this.rad[i] = Math.max(0.01, this.size[kind][cell] * s * 0.45);
    this.life[i] = LIFE * (0.8 + Math.random() * 0.4);
    this.rest[i] = 0;
    this.bled[i] = 0;
    this.place(i);
  }

  private place(i: number) {
    const j = i * 3;
    const o = i * 4;
    const fade = this.life[i] < 1.5 ? Math.max(0, this.life[i] / 1.5) : 1;
    _q.set(this.rot[o], this.rot[o + 1], this.rot[o + 2], this.rot[o + 3]);
    const sc = this.scl[i] * fade;
    _m.compose(_p.set(this.pos[j], this.pos[j + 1] - (1 - fade) * 0.03, this.pos[j + 2]), _q, _s.set(sc, sc, sc));
    this.mesh.setMatrixAt(this.inst[i], _m);
  }

  update(dt: number) {
    const T = this.terrain;
    const P = this.pos;
    const V = this.vel;
    let act = 0;
    for (let i = 0; i < N; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      if (this.life[i] <= 0) {
        this.mesh.setVisibleAt(this.inst[i], false);
        continue;
      }
      act++;
      const j = i * 3;
      if (!this.rest[i]) {
        const px = P[j];
        const pz = P[j + 2];
        const drag = Math.exp(-0.35 * dt);
        V[j] *= drag;
        V[j + 2] *= drag;
        V[j + 1] = V[j + 1] * drag - 9.8 * dt;
        P[j] += V[j] * dt;
        P[j + 1] += V[j + 1] * dt;
        P[j + 2] += V[j + 2] * dt;
        const q = this.rot;
        const o = i * 4;
        const wx = this.spin[j] * dt * 0.5;
        const wy = this.spin[j + 1] * dt * 0.5;
        const wz = this.spin[j + 2] * dt * 0.5;
        const qx = q[o], qy = q[o + 1], qz = q[o + 2], qw = q[o + 3];
        let nx = qx + (wx * qw + wy * qz - wz * qy);
        let ny = qy + (wy * qw + wz * qx - wx * qz);
        let nz = qz + (wz * qw + wx * qy - wy * qx);
        let nw = qw + (-wx * qx - wy * qy - wz * qz);
        const l = Math.hypot(nx, ny, nz, nw) || 1;
        nx /= l; ny /= l; nz /= l; nw /= l;
        q[o] = nx; q[o + 1] = ny; q[o + 2] = nz; q[o + 3] = nw;
        const r = this.rad[i];
        let gh = T.height(P[j], P[j + 2]);
        if (gh - (P[j + 1] - V[j + 1] * dt) > 0.2) {
          // bounced off the side of a wall / car
          P[j] = px;
          P[j + 2] = pz;
          V[j] *= -0.35;
          V[j + 2] *= -0.35;
          gh = T.height(px, pz);
          if (!this.bled[i]) {
            this.blood.wallSplat(P[j], P[j + 1], P[j + 2], -V[j], -V[j + 2], r * 5);
            this.bled[i] = 1;
          }
        }
        if (P[j + 1] - r < gh) {
          P[j + 1] = gh + r;
          if (V[j + 1] < -1.1 && !this.bled[i]) {
            this.blood.decal(P[j], P[j + 2], r * (6 + Math.random() * 5), 0, gh, V[j], V[j + 2], 0.9);
            this.bled[i] = 1;
          }
          V[j + 1] *= -0.28;
          V[j] *= 0.55;
          V[j + 2] *= 0.55;
          this.spin[j] *= 0.5;
          this.spin[j + 1] *= 0.5;
          this.spin[j + 2] *= 0.5;
          if (Math.abs(V[j + 1]) < 0.45 && Math.hypot(V[j], V[j + 2]) < 0.3) this.rest[i] = 1;
        }
        this.place(i);
      } else if (this.life[i] < 1.5) this.place(i);
    }
    this.active = act;
  }

  clear() {
    for (let i = 0; i < N; i++) {
      this.life[i] = 0;
      this.mesh.setVisibleAt(this.inst[i], false);
    }
  }
}
