import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { L, P, SEGS } from './skeleton';
import { MAX_CELLS, fractureGeometry, transformFrac, type FracInfo, type Prim } from './voronoi';

type RGB = [number, number, number];
type ColorFn = (x: number, y: number, z: number) => RGB;
type Inside = (x: number, y: number, z: number) => boolean;

const hash = (x: number, y: number, z: number) => {
  const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return s - Math.floor(s);
};
/** Cheap smooth-ish 3D noise for grime / stains. */
function noise(x: number, y: number, z: number) {
  const f = 9;
  return (
    0.5 * Math.sin(x * f + Math.sin(z * f * 0.7) * 2) * Math.cos(y * f * 0.8 + x * 3) +
    0.35 * Math.sin(z * f * 1.9 + y * 5.1) * Math.sin(x * f * 2.3 - 1.3) +
    0.15 * (hash(x, y, z) * 2 - 1)
  );
}
let stainSeed = 0;
/** Clothing: grime, dark blood stains, worn patches. */
const cloth = (stain = 0.25): ColorFn => {
  const sd = (stainSeed += 1.37);
  return (x, y, z) => {
    const n = noise(x + sd, y, z - sd);
    const g = 0.78 + 0.22 * n;
    const st = noise(x * 1.7 - sd, y * 1.3, z * 1.9 + sd * 0.5);
    if (st > 1 - stain) return [0.55 * g, 0.12 * g, 0.1 * g]; // dried blood
    if (n < -0.55) return [0.45, 0.42, 0.38]; // torn / filthy patch
    return [g, g * 0.98, g * 0.94];
  };
};
const skin: ColorFn = (x, y, z) => {
  const n = noise(x * 1.3, y * 1.3, z * 1.3);
  const g = 0.86 + 0.16 * n;
  if (n > 0.62) return [0.72 * g, 0.62 * g, 0.7 * g]; // bruising
  return [g, g, g * 0.98];
};
const flat =
  (r: number, g: number, b: number): ColorFn =>
  () => [r, g, b];

function prim(geo: THREE.BufferGeometry, col: ColorFn, m?: THREE.Matrix4, inside?: Inside) {
  if (m) geo.applyMatrix4(m);
  if (inside) geo.userData.inside = inside;
  geo.deleteAttribute('uv');
  const p = geo.attributes.position;
  const c = new Float32Array(p.count * 3);
  for (let i = 0; i < p.count; i++) {
    const [r, g, b] = col(p.getX(i), p.getY(i), p.getZ(i));
    c[i * 3] = r;
    c[i * 3 + 1] = g;
    c[i * 3 + 2] = b;
  }
  geo.setAttribute('color', new THREE.BufferAttribute(c, 3));
  if (!geo.index) {
    const idx: number[] = [];
    for (let i = 0; i < p.count; i++) idx.push(i);
    geo.setIndex(idx);
  }
  return geo;
}
const M = (x = 0, y = 0, z = 0, sx = 1, sy = 1, sz = 1, rx = 0, ry = 0, rz = 0) =>
  new THREE.Matrix4().compose(
    new THREE.Vector3(x, y, z),
    new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz)),
    new THREE.Vector3(sx, sy, sz),
  );
const sph = (col: ColorFn, x: number, y: number, z: number, rx: number, ry: number, rz: number, seg = 12) =>
  prim(new THREE.SphereGeometry(1, seg, Math.max(6, (seg * 2) / 3)), col, M(x, y, z, rx, ry, rz), (px, py, pz) =>
    ((px - x) / rx) ** 2 + ((py - y) / ry) ** 2 + ((pz - z) / rz) ** 2 < 0.96);
/** Axis-aligned box occupancy (rounded boxes, slightly conservative). */
const boxIn = (cx: number, cy: number, cz: number, hx: number, hy: number, hz: number): Inside => (px, py, pz) =>
  Math.abs(px - cx) < hx * 0.94 && Math.abs(py - cy) < hy * 0.94 && Math.abs(pz - cz) < hz * 0.94;
/** Limb along +Y from 0 to len (hanging limbs: +Y points down the limb). */
const limb = (col: ColorFn, r0: number, r1: number, len: number, wob = 0) => {
  const g = new THREE.CylinderGeometry(r1, r0, len, 10, 3, true);
  g.translate(0, len / 2, 0);
  if (wob > 0) {
    // lumpy, uneven silhouette (worn baggy cloth / wasted flesh)
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const k = 1 + wob * noise(p.getX(i) * 3, p.getY(i) * 3, p.getZ(i) * 3);
      p.setX(i, p.getX(i) * k);
      p.setZ(i, p.getZ(i) * k);
    }
  }
  const k = (1 - wob) * 0.95;
  const inCyl: Inside = (px, py, pz) => py > 0.003 && py < len - 0.003 && px * px + pz * pz < ((r0 + ((r1 - r0) * py) / len) * k) ** 2;
  return [prim(g, col, undefined, inCyl), sph(col, 0, 0, 0, r0, r0, r0, 10), sph(col, 0, len, 0, r1, r1, r1, 10)];
};
const merge = (parts: THREE.BufferGeometry[]) => {
  const g = mergeGeometries(parts)!;
  g.computeBoundingSphere();
  // remember which triangles came from which primitive (Voronoi fracture drops buried surfaces)
  const prims: Prim[] = [];
  let t = 0;
  for (const p of parts) {
    const n = p.index!.count / 3;
    const inside = p.userData.inside as Inside | undefined;
    let box: THREE.Box3 | undefined;
    if (inside) {
      p.computeBoundingBox();
      box = p.boundingBox!.clone().expandByScalar(0.003);
    }
    prims.push({ triStart: t, triCount: n, box, inside });
    t += n;
  }
  g.userData.prims = prims;
  return g;
};

function buildGeometries() {
  const G: Record<string, THREE.BufferGeometry> = {};
  const POST: Record<string, THREE.Matrix4> = {};
  // ---- head: hollow cheeks, open jaw, sunken milky eyes, bloody mouth
  const face: ColorFn = (x, y, z) => {
    const s = skin(x, y, z);
    if (z > 0.04 && y < 0.075 && Math.abs(x) < 0.06) return [0.62, 0.16, 0.14]; // blood round the mouth
    if (z > 0.06 && y > 0.105 && y < 0.145 && Math.abs(Math.abs(x) - 0.036) < 0.026) return [s[0] * 0.55, s[1] * 0.5, s[2] * 0.58]; // dark eye bags
    return s;
  };
  G.head = merge([
    sph(face, 0, 0.125, -0.005, 0.094, 0.114, 0.104, 16),
    sph(face, 0, 0.05, 0.03, 0.066, 0.042, 0.06, 12), // jaw (hanging open)
    sph(flat(0.18, 0.03, 0.03), 0, 0.068, 0.078, 0.036, 0.02, 0.02, 8), // mouth cavity
    sph(flat(0.85, 0.8, 0.68), 0, 0.08, 0.085, 0.03, 0.006, 0.012, 8), // teeth
    sph(face, 0, 0.11, 0.1, 0.014, 0.022, 0.02, 8), // nose
    sph(flat(0.25, 0.18, 0.2), 0.036, 0.128, 0.086, 0.022, 0.016, 0.012, 8),
    sph(flat(0.25, 0.18, 0.2), -0.036, 0.128, 0.086, 0.022, 0.016, 0.012, 8),
    sph(flat(1.45, 1.42, 1.25), 0.036, 0.127, 0.09, 0.0105, 0.009, 0.008, 8), // milky eyes
    sph(flat(1.45, 1.42, 1.25), -0.036, 0.127, 0.09, 0.0105, 0.009, 0.008, 8),
    sph(face, 0.094, 0.115, 0, 0.012, 0.024, 0.016, 8),
    sph(face, -0.094, 0.115, 0, 0.012, 0.024, 0.016, 8),
  ]);
  const neckCol: ColorFn = (x, y, z) => (x > 0.02 && z > -0.01 && y > 0.02 && y < 0.07 ? [0.55, 0.12, 0.1] : skin(x, y, z));
  G.neck = merge([prim(new THREE.CylinderGeometry(0.046, 0.054, 0.13, 10, 2, true).translate(0, 0.05, 0.005), neckCol)]);
  // ---- torso: hunched back, dirty shirt with a collar
  const shirt = cloth(0.28);
  G.chest = merge([
    sph(shirt, 0, 0.165, 0.005, 0.172, 0.2, 0.118, 14),
    sph(shirt, 0, 0.245, -0.045, 0.14, 0.1, 0.085, 10), // hunch
    sph(shirt, 0.158, 0.29, -0.005, 0.074, 0.07, 0.074, 10),
    sph(shirt, -0.158, 0.29, -0.005, 0.074, 0.07, 0.074, 10),
    prim(new THREE.TorusGeometry(0.062, 0.02, 6, 16), shirt, M(0, 0.318, 0.012, 1.1, 1, 0.9, Math.PI / 2 + 0.2)),
  ]);
  const shirt2 = cloth(0.3);
  const hem = new THREE.CylinderGeometry(0.155, 0.165, 0.09, 14, 2, true);
  {
    // ragged untucked hem
    const p = hem.attributes.position;
    for (let i = 0; i < p.count; i++) if (p.getY(i) < 0) p.setY(i, p.getY(i) - Math.max(0, noise(p.getX(i) * 4, 0, p.getZ(i) * 4)) * 0.05);
  }
  G.abdomen = merge([sph(shirt2, 0, 0.1, 0.005, 0.152, 0.125, 0.108, 12), prim(hem, shirt2, M(0, 0.02, 0.003, 1, 1, 0.74))]);
  const pants = cloth(0.18);
  G.pelvis = merge([
    sph(pants, 0, 0.0, 0, 0.158, 0.112, 0.112, 12),
    prim(new THREE.TorusGeometry(0.15, 0.014, 6, 20), flat(0.25, 0.2, 0.18), M(0, 0.072, 0, 1, 1, 0.75, Math.PI / 2)),
  ]);
  // ---- arms (hanging: local +Y runs down the limb)
  G.upperArm = merge(limb(cloth(0.22), 0.058, 0.047, L.upper, 0.08));
  G.forearm = merge([
    ...limb(cloth(0.2), 0.046, 0.036, L.fore, 0.06),
    prim(new THREE.CylinderGeometry(0.04, 0.04, 0.03, 10, 1, true), flat(0.7, 0.68, 0.65), M(0, 0.02, 0)),
  ]);
  const handCol: ColorFn = (x, y, z) => (y > 0.135 ? [0.35, 0.28, 0.27] : skin(x, y, z));
  G.hand = merge([
    sph(handCol, 0, 0.055, 0, 0.04, 0.058, 0.022, 10),
    sph(handCol, 0, 0.12, -0.012, 0.037, 0.045, 0.017, 10), // clawed fingers
    sph(handCol, 0.03, 0.05, -0.018, 0.014, 0.032, 0.016, 8),
  ]);
  // ---- legs
  G.thigh = merge(limb(cloth(0.2), 0.086, 0.064, L.thigh, 0.07));
  G.shin = merge([
    ...limb(cloth(0.22), 0.064, 0.05, L.shin, 0.06),
    prim(new THREE.CylinderGeometry(0.058, 0.066, 0.06, 10, 1, true), cloth(0.1), M(0, L.shin - 0.05, 0)),
  ]);
  // foot: local +Y runs from ankle to toe, local +Z points DOWN
  const shoe = cloth(0.1);
  G.foot = merge([
    prim(new RoundedBoxGeometry(0.1, 0.26, 0.085, 2, 0.03), shoe, M(0, 0.05, 0.035), boxIn(0, 0.05, 0.035, 0.05, 0.13, 0.0425)),
    prim(new RoundedBoxGeometry(0.104, 0.27, 0.02, 1, 0.008), flat(0.35, 0.33, 0.3), M(0, 0.05, 0.075), boxIn(0, 0.05, 0.075, 0.052, 0.135, 0.01)),
    sph(shoe, 0, 0, 0, 0.05, 0.05, 0.05, 8),
  ]);
  // the ankle→toe axis slopes down ~20°: tilt the shoe back so the sole sits flat
  // (applied after fracturing so the primitive occupancy tests stay axis aligned)
  POST.foot = new THREE.Matrix4().makeRotationX(-0.34);
  // ---- hair variants (head local)
  const hair: ColorFn = (x, y, z) => {
    const n = 0.8 + 0.25 * noise(x * 3, y * 3, z * 3);
    return [n, n, n];
  };
  const tufts = (n: number, seed: number, yMin: number) => {
    const out: THREE.BufferGeometry[] = [];
    for (let i = 0; i < n; i++) {
      const a = hash(i, seed, 1) * Math.PI * 2;
      const e = yMin + hash(i, seed, 2) * (1.35 - yMin);
      const x = Math.cos(a) * Math.cos(e) * 0.1;
      const z = Math.sin(a) * Math.cos(e) * 0.1 - 0.01;
      const y = 0.13 + Math.sin(e) * 0.105;
      out.push(sph(hair, x, y, z, 0.03 + hash(i, seed, 3) * 0.025, 0.018, 0.03, 6));
    }
    return out;
  };
  const cap = (open: number) =>
    prim(new THREE.SphereGeometry(0.11, 14, 8, 0, Math.PI * 2, 0, Math.PI * open), hair, M(0, 0.128, -0.012, 0.97, 1.02, 1.02, -0.45));
  G.hair0 = merge([cap(0.52), ...tufts(14, 1, 0.3)]); // messy short
  G.hair1 = merge([
    cap(0.55),
    sph(hair, 0, 0.06, -0.075, 0.098, 0.13, 0.055, 10), // long, matted, hanging
    sph(hair, 0.08, 0.06, -0.02, 0.03, 0.11, 0.05, 8),
    sph(hair, -0.08, 0.05, -0.02, 0.03, 0.12, 0.05, 8),
    ...tufts(8, 2, 0.5),
  ]);
  G.hair2 = merge([
    prim(new THREE.TorusGeometry(0.095, 0.03, 6, 16, Math.PI * 1.3), hair, M(0, 0.12, -0.01, 1, 1, 1.05, Math.PI / 2, 0, Math.PI * 0.85)),
    ...tufts(6, 3, 0.9), // balding with stringy patches
  ]);
  // ---- stump: ragged raw flesh, protruding splintered bone, tendons and a torn cloth fringe
  const stumpCol: ColorFn = (x, y, z) => {
    const n = noise(x * 2, y * 2, z * 2);
    return y > 0.1 ? [0.5 + 0.15 * n, 0.05, 0.05] : [0.3, 0.02, 0.02];
  };
  const sg = new THREE.SphereGeometry(1, 12, 8);
  {
    const p = sg.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const k = 1 + 0.32 * noise(p.getX(i) * 2.3, p.getY(i) * 2.3, p.getZ(i) * 2.3);
      p.setXYZ(i, p.getX(i) * k, p.getY(i) * 0.42 * k, p.getZ(i) * k);
    }
  }
  const bone = new THREE.CylinderGeometry(0.22, 0.3, 1.1, 7, 2);
  {
    const p = bone.attributes.position;
    for (let i = 0; i < p.count; i++) if (p.getY(i) > 0.5) p.setY(i, p.getY(i) + (hash(i, 1, 2) - 0.5) * 0.5); // splintered end
  }
  bone.translate(0.08, 0.45, 0.05);
  const strips: THREE.BufferGeometry[] = [];
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2 + 0.4;
    const t = new THREE.CylinderGeometry(0.06, 0.1, 0.55 + hash(i, 3, 1) * 0.4, 5);
    strips.push(prim(t, i % 2 ? flat(0.55, 0.08, 0.07) : flat(0.72, 0.6, 0.55), M(Math.cos(a) * 0.62, 0.25, Math.sin(a) * 0.62, 1, 1, 1, Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5)));
  }
  const fringe = new THREE.CylinderGeometry(1.15, 1.25, 0.5, 14, 2, true);
  {
    const p = fringe.attributes.position;
    for (let i = 0; i < p.count; i++) if (p.getY(i) > 0) p.setY(i, p.getY(i) + (hash(i, 7, 3) - 0.3) * 0.6);
  }
  fringe.translate(0, -0.25, 0);
  G.stump = merge([prim(sg, stumpCol), prim(bone, flat(0.92, 0.87, 0.76)), ...strips, prim(fringe, flat(0.3, 0.27, 0.25))]);
  return { G, POST };
}



/* ---------------------------------------------------------------- shaders */
const NOISE_GLSL = `
float zhash(vec3 p){ p = fract(p*0.3183099+0.1); p *= 17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float znoise(vec3 x){ vec3 i = floor(x); vec3 f = fract(x); f = f*f*(3.0-2.0*f);
  return mix(mix(mix(zhash(i), zhash(i+vec3(1,0,0)), f.x), mix(zhash(i+vec3(0,1,0)), zhash(i+vec3(1,1,0)), f.x), f.y),
             mix(mix(zhash(i+vec3(0,0,1)), zhash(i+vec3(1,0,1)), f.x), mix(zhash(i+vec3(0,1,1)), zhash(i+vec3(1,1,1)), f.x), f.y), f.z); }
varying vec3 vLoc; varying vec4 vW0; varying vec4 vW1; varying vec4 vW2; varying vec4 vTear;
#ifdef Z_FRAC
varying vec4 vFr; varying vec4 vFr2;
#endif
`;
const WOUND_GLSL = `
uniform vec3 uDown;
void zWound(vec4 W, float n1, inout float wound, inout float rim, inout float core){
  float d = distance(vLoc, W.xyz);
  float rr = (0.016 + 0.028 * W.w) * (0.65 + 0.7 * n1);
  float on = step(0.001, W.w);
  wound = max(wound, on * (1.0 - smoothstep(rr * 0.7, rr, d)));
  rim = max(rim, on * (1.0 - smoothstep(rr, rr * 2.1, d)));
  core = max(core, on * (1.0 - smoothstep(0.0, rr * 0.42, d)));
}
/* blood that ran down from the wound while the zombie stood (rest-pose down, so it stays put on the ragdoll) */
void zDrip(vec4 W, inout float drip){
  vec3 q = vLoc - W.xyz;
  float along = dot(q, uDown);
  vec3 lat = q - uDown * along;
  float len = 0.05 + 0.11 * min(W.w, 1.6);
  float rr = 0.012 + 0.018 * min(W.w, 1.6);
  float streak = smoothstep(0.52, 0.78, znoise(lat * 90.0 + W.xyz * 37.0 + vTear.y));
  float m = step(0.0, along) * (1.0 - smoothstep(len * 0.35, len, along + znoise(lat * 50.0) * 0.025))
          * (1.0 - smoothstep(rr * 0.5, rr * 1.7, length(lat))) * streak;
  drip = max(drip, step(0.001, W.w) * m);
}
`;
const FRAC_VERT = `
#ifdef Z_FRAC
attribute vec4 aInner;
uniform sampler2D uFrac; uniform sampler2D uCells; uniform float uTime;
vec3 zP; float zLayer;
vec3 zRot(vec3 v, vec3 k, float a){ float c = cos(a), s = sin(a); return v*c + cross(k, v)*s + k*dot(k, v)*(1.0 - c); }
#endif
`;
/** Per-cell plate motion: cracks open, plates tilt and sink, destroyed plates vanish and expose the crater. */
const FRAC_NORMAL = `
#ifdef Z_FRAC
{
  float code = aInner.w;
  float cell = mod(code, 64.0);
  zLayer = mod(floor(code / 64.0), 4.0);
  float nb = floor(code / 256.0);
  vec4 st = texelFetch(uFrac, ivec2(int(cell + 0.5), gl_InstanceID), 0);
  vec4 c0 = texelFetch(uCells, ivec2(int(cell + 0.5), 0), 0);
  vec4 c1 = texelFetch(uCells, ivec2(int(cell + 0.5), 1), 0);
  float dmg = st.x;
  float rnd = fract(sin(cell * 12.9898 + 4.1) * 43758.5453);
  float rnd2 = fract(sin(cell * 78.233 + 1.7) * 24634.6345);
  vec3 C = c0.xyz; vec3 Nc = normalize(c1.xyz); float dep = c1.w;
  float crack = smoothstep(0.03, 0.32, dmg);
  float sink = smoothstep(0.32, 0.88, dmg);
  float gone = step(0.9, dmg);
  float age = max(0.0, uTime - st.y);
  float jolt = exp(-age * 6.0) * cos(age * 31.0) * crack;
  zP = position;
  if (zLayer < 1.5) {
    vec3 ax = normalize(cross(Nc, normalize(vec3(rnd - 0.5, rnd2 - 0.5, 0.37))) + vec3(1e-4));
    float ang = (crack * 0.22 + sink * 0.34) * (rnd2 * 2.0 - 1.0) + jolt * 0.16;
    vec3 q = zRot(zP - C, ax, ang);
    q *= 1.0 - (crack * (0.05 + 0.09 * rnd) + sink * 0.14);
    zP = C + q - Nc * dep * (crack * (0.1 + 0.25 * rnd) + sink * 0.55 + jolt * 0.22);
    objectNormal = zRot(objectNormal, ax, ang);
    if (gone > 0.5) zP = zLayer < 0.5 ? C : aInner.xyz;
  } else if (zLayer > 2.5) {
    if (dmg < 0.015) zP = C;
  }
  if (zLayer > 0.5 && zLayer < 2.5) {
    float dn = texelFetch(uFrac, ivec2(int(nb + 0.5), gl_InstanceID), 0).x;
    if (dmg < 0.015 && dn < 0.015) zP = aInner.xyz;
  }
  vFr = vec4(zLayer, zLayer < 1.5 ? 0.0 : 1.0, dmg, rnd);
  vFr2 = vec4(st.z * exp(-age / 45.0), age, st.w, gone);
}
#endif
`;
/** Cross-section shading: cloth/skin band → fat → fibrous muscle → dark crater floor / skull. */
const FRAC_FRAG = `
#ifdef Z_FRAC
  float fWet = vFr2.x;
  if (vFr.x < 0.5) {
    float plate = smoothstep(0.03, 0.4, vFr.z);
    diffuseColor.rgb *= mix(1.0, 0.74 + 0.34 * vFr.w, plate);
    diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.5, 0.13, 0.12), plate * (0.28 + 0.5 * fWet));
    zWet = max(zWet, plate * fWet * 0.8);
  } else {
    float dk = vFr.y;
    float fib = znoise(vLoc * vec3(110.0, 26.0, 110.0));
    vec3 muscle = mix(vec3(0.36, 0.035, 0.03), vec3(0.66, 0.13, 0.1), fib);
    vec3 fat = vec3(0.8, 0.64, 0.44) * (0.85 + 0.3 * znoise(vLoc * 140.0));
    vec3 cs = mix(diffuseColor.rgb * 0.8, fat, smoothstep(0.05, 0.12, dk));
    cs = mix(cs, muscle, smoothstep(0.16, 0.32, dk));
    cs *= mix(1.0, 0.5, smoothstep(0.45, 1.0, dk));
    if (vFr.x > 2.5) {
      float n3 = znoise(vLoc * 75.0);
      cs = mix(vec3(0.2, 0.018, 0.016), vec3(0.48, 0.07, 0.05), n3);
      float bone = smoothstep(0.6, 0.72, znoise(vLoc * 38.0 + 3.0));
      cs = mix(cs, vec3(0.8, 0.74, 0.62), bone * 0.55);
      #ifdef Z_SKULL
        float sk = smoothstep(0.35, 0.5, znoise(vLoc * 22.0));
        cs = mix(cs, vec3(0.82, 0.76, 0.64) * (0.8 + 0.3 * n3), 0.45 + 0.4 * sk);
        cs = mix(cs, vec3(0.25, 0.03, 0.03), smoothstep(0.62, 0.66, znoise(vLoc * 60.0)) * 0.8);
      #endif
    }
    diffuseColor.rgb = cs;
    zWet = max(zWet, 0.55 + 0.45 * fWet);
  }
#endif
`;

const U_TIME = { value: 0 };
interface DmgOpts {
  cloth: boolean;
  rough: number;
  down: THREE.Vector3;
  frac?: { state: THREE.DataTexture; cells: THREE.DataTexture };
  skull?: boolean;
}

/**
 * Per-instance damage on the real animated mesh: wounds live in the body part's
 * local space (so they follow every animation and ragdoll pose), rips tear
 * through clothing to rotten skin, craters dent the surface, blasts char it,
 * blood runs down from wounds, and (fractured variant) Voronoi plates crack,
 * sink and break away exposing layered flesh.
 */
function damageMaterial(o: DmgOpts) {
  const m = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: o.rough, metalness: 0 });
  const defines: Record<string, string> = { STANDARD: '' };
  if (o.cloth) defines.Z_CLOTH = '';
  if (o.frac) defines.Z_FRAC = '';
  if (o.skull) defines.Z_SKULL = '';
  m.defines = defines;
  m.onBeforeCompile = (sh) => {
    sh.uniforms.uDown = { value: o.down };
    if (o.frac) {
      sh.uniforms.uFrac = { value: o.frac.state };
      sh.uniforms.uCells = { value: o.frac.cells };
      sh.uniforms.uTime = U_TIME;
    }
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nattribute vec4 aW0; attribute vec4 aW1; attribute vec4 aW2; attribute vec4 aTear;' + NOISE_GLSL + FRAC_VERT)
      .replace('#include <beginnormal_vertex>', '#include <beginnormal_vertex>\n' + FRAC_NORMAL)
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        #ifdef Z_FRAC
          transformed = zP;
        #endif
        vLoc = position; vW0 = aW0; vW1 = aW1; vW2 = aW2; vTear = aTear;
        float cr = aW0.w * (1.0 - smoothstep(0.0, 0.03 + 0.03*aW0.w, distance(position, aW0.xyz)))
                 + aW1.w * (1.0 - smoothstep(0.0, 0.03 + 0.03*aW1.w, distance(position, aW1.xyz)))
                 + aW2.w * (1.0 - smoothstep(0.0, 0.03 + 0.03*aW2.w, distance(position, aW2.xyz)));
        float tn = znoise(position * 34.0 + aTear.y * 5.0);
        float zDent = min(cr, 1.6) * 0.013 + aTear.x * max(0.0, tn - 0.55) * 0.014;
        #ifdef Z_FRAC
          if (zLayer > 0.5) zDent = 0.0;
        #endif
        transformed -= objectNormal * zDent;`,
      );
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\n' + NOISE_GLSL + WOUND_GLSL)
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        float n1 = znoise(vLoc * 60.0 + vTear.y * 7.0);
        float n2 = znoise(vLoc * vec3(16.0, 34.0, 16.0) + vTear.y * 3.0) * 0.7 + znoise(vLoc * 70.0 + vTear.y) * 0.3;
        float wound = 0.0; float rim = 0.0; float core = 0.0; float drip = 0.0;
        zWound(vW0, n1, wound, rim, core); zWound(vW1, n1, wound, rim, core); zWound(vW2, n1, wound, rim, core);
        zDrip(vW0, drip); zDrip(vW1, drip); zDrip(vW2, drip);
        float th = 1.0 - vTear.x * 0.52;
        float tear = smoothstep(0.0, 0.035, n2 - th);
        float fray = (1.0 - smoothstep(0.0, 0.05, th - n2)) * (1.0 - tear) * step(0.001, vTear.x);
        vec3 rotten = vec3(0.4, 0.43, 0.35) * (0.7 + 0.35 * n1);
        vec3 flesh = mix(vec3(0.33, 0.03, 0.03), vec3(0.62, 0.17, 0.13), n1);
        #ifdef Z_CLOTH
          diffuseColor.rgb = mix(diffuseColor.rgb, min(diffuseColor.rgb * 1.7 + 0.08, vec3(1.0)), fray * 0.55);
          diffuseColor.rgb = mix(diffuseColor.rgb, rotten, tear);
          diffuseColor.rgb = mix(diffuseColor.rgb, flesh * 0.8, tear * smoothstep(0.07, 0.14, n2 - th));
        #else
          diffuseColor.rgb = mix(diffuseColor.rgb, mix(flesh, vec3(0.22, 0.16, 0.18), 0.45), tear * 0.9);
          diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.7, 0.55, 0.62), fray * 0.6);
        #endif
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.28, 0.018, 0.02) * (0.8 + 0.4 * n1), drip * 0.8);
        diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * vec3(0.5, 0.16, 0.15), rim * 0.85);
        diffuseColor.rgb = mix(diffuseColor.rgb, flesh, wound);
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.05, 0.0, 0.0), core);
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.035, 0.03, 0.025) * (0.5 + n1), clamp(vTear.z * (0.6 + 0.6 * n2), 0.0, 1.0));
        float zWet = max(max(wound, rim * 0.55), drip * 0.7);
        ${FRAC_FRAG}`,
      )
      .replace('#include <roughnessmap_fragment>', '#include <roughnessmap_fragment>\nroughnessFactor = mix(roughnessFactor, 0.16, zWet);');
  };
  m.customProgramCacheKey = () => 'zdmg|' + Object.keys(defines).join(',');
  return m;
}

export interface Palette {
  skin: THREE.Color;
  shirt: THREE.Color;
  sleeve: THREE.Color;
  pants: THREE.Color;
  shoes: THREE.Color;
  hair: THREE.Color;
  hairStyle: number;
}

/** A Voronoi cell that was just blown off the body (world space). */
export interface LostCell {
  x: number;
  y: number;
  z: number;
  nx: number;
  ny: number;
  nz: number;
  size: number;
  /** which piece: body-part kind + Voronoi cell, the zombie slot / segment it left */
  kind: string;
  cell: number;
  slot: number;
  seg: number;
  /** the part's world rotation and scale at the moment it broke off */
  q: THREE.Quaternion;
  s: number;
}

/** Low-poly stand-in that only renders into the shadow map (capsule for limbs, ellipsoid otherwise). */
function shadowProxy(g: THREE.BufferGeometry) {
  const bb = new THREE.Box3().setFromBufferAttribute(g.getAttribute('position') as THREE.BufferAttribute);
  const c = bb.getCenter(new THREE.Vector3());
  const d = bb.getSize(new THREE.Vector3());
  const w = Math.max(d.x, d.z);
  let geo: THREE.BufferGeometry;
  if (d.y > 1.6 * w) {
    const r = w * 0.46;
    geo = new THREE.CapsuleGeometry(r, Math.max(0.01, d.y - 2 * r), 3, 8);
  } else {
    geo = new THREE.SphereGeometry(1, 10, 7);
    geo.scale(d.x * 0.48, d.y * 0.48, d.z * 0.48);
  }
  geo.translate(c.x, c.y, c.z);
  return geo;
}

const KINDS = ['head', 'neck', 'chest', 'abdomen', 'pelvis', 'upperArm', 'forearm', 'hand', 'thigh', 'shin', 'foot'];
const NSEG = SEGS.length;
const BLOOD = new THREE.Color(0.32, 0.02, 0.02);
const ATTRS = ['aW0', 'aW1', 'aW2', 'aTear'];
const UP = new THREE.Vector3(0, -1, 0);
const HANG = new THREE.Vector3(0, 1, 0);
/** Rest-pose "down" in each part's local frame (hanging limbs run +Y down the limb, the foot's +Z points down). */
const DOWN: Record<string, THREE.Vector3> = {
  head: UP, neck: UP, chest: UP, abdomen: UP, pelvis: UP,
  upperArm: HANG, forearm: HANG, hand: HANG, thigh: HANG, shin: HANG,
  foot: new THREE.Vector3(0, 0, 1),
};
const FRAC_CFG: Record<string, { cells: number; maxDepth: number; depth: number; core: 'axis' | 'point'; point?: [number, number, number] }> = {
  head: { cells: 46, maxDepth: 0.034, depth: 0.34, core: 'point', point: [0, 0.112, 0.012] },
  neck: { cells: 12, maxDepth: 0.02, depth: 0.36, core: 'axis' },
  chest: { cells: 58, maxDepth: 0.05, depth: 0.3, core: 'axis' },
  abdomen: { cells: 40, maxDepth: 0.046, depth: 0.32, core: 'axis' },
  pelvis: { cells: 34, maxDepth: 0.044, depth: 0.32, core: 'axis' },
  upperArm: { cells: 26, maxDepth: 0.026, depth: 0.38, core: 'axis' },
  forearm: { cells: 24, maxDepth: 0.022, depth: 0.38, core: 'axis' },
  hand: { cells: 12, maxDepth: 0.014, depth: 0.36, core: 'axis' },
  thigh: { cells: 32, maxDepth: 0.034, depth: 0.36, core: 'axis' },
  shin: { cells: 28, maxDepth: 0.028, depth: 0.36, core: 'axis' },
  foot: { cells: 16, maxDepth: 0.026, depth: 0.34, core: 'axis' },
};
const _c = new THREE.Color();
const hash1 = (a: number, b: number) => {
  const s = Math.sin(a * 91.3458 + b * 47.123) * 43758.5453;
  return s - Math.floor(s);
};

/** One body-part kind: an intact instanced mesh for undamaged parts and a packed fractured one for damaged parts. */
interface KindSet {
  kind: string;
  intact: THREE.InstancedMesh;
  frac: THREE.InstancedMesh;
  info: FracInfo;
  cap: number;
  per: number;
  fracCap: number;
  packOf: Int32Array;
  identOf: Int32Array;
  n: number;
  state: Float32Array; // MAX_CELLS × cap × (damage, hit time, wetness, burn)
  stateTex: THREE.DataTexture;
  dirty: boolean;
}

/**
 * All zombies share ~two instanced meshes per body-part type. Intact parts use
 * the cheap original mesh; as soon as a part is fractured it moves into a
 * packed instanced Voronoi mesh whose plates are driven per cell from a small
 * float texture (one row per damaged part) — a localized, GPU-side mesh update.
 */
export class ZombieRenderer {
  private sets: Record<string, KindSet> = {};
  private segSet: KindSet[] = [];
  private segSub: number[] = [];
  private segPer: number[] = [];
  private hair: THREE.InstancedMesh[] = [];
  private stumps: THREE.InstancedMesh;
  private base: THREE.Color[][] = [];
  readonly maxStumps: number;
  private stumpN = 0;
  private geos: Record<string, THREE.BufferGeometry> = {};
  private woundI: Uint8Array = new Uint8Array(0);
  private mats: Float32Array;
  private hi = 0;
  private frameHi = 0;
  /** global Voronoi budget: max body parts rendered with fracture geometry at the same time */
  maxFrac = 300;
  private fracTotal = 0;
  /** called when the budget is full: the horde retires corpses / heals distant walkers to make room */
  onBudget: () => void = () => {};
  /** bumped on every respawn of a slot: stale crumble events are ignored */
  private gen: Uint32Array;
  private crumbleQ: { slot: number; seg: number; cell: number; t: number; gen: number }[] = [];
  /** scalp blown open: hair hidden so it never hovers over a crater */
  private bald: Uint8Array;
  readonly max: number;
  readonly stats = { intactTris: 0, fracTris: 0, cells: 0, buildMs: 0 };

  constructor(scene: THREE.Scene, max: number) {
    const t0 = performance.now();
    this.max = max;
    const { G, POST } = buildGeometries();
    this.geos = G;
    const hairMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, metalness: 0 });
    const plainMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.4, metalness: 0 });
    const count: Record<string, number> = {};
    for (const s of SEGS) count[s.kind] = (count[s.kind] ?? 0) + 1;
    let seed = 3;
    for (const k of KINDS) {
      const info = fractureGeometry(G[k], G[k].userData.prims as Prim[], { ...FRAC_CFG[k], seed: seed++ });
      if (POST[k]) {
        G[k].applyMatrix4(POST[k]);
        transformFrac(info, POST[k]);
      }
      const skinKind = k === 'head' || k === 'hand' || k === 'neck';
      const cap = max * count[k];
      // damaged parts are a minority: cap the packed set (keeps the damage texture ≤ 2048 rows on any WebGL2 GPU)
      const fracCap = Math.min(cap, 1536);
      const state = new Float32Array(MAX_CELLS * fracCap * 4);
      const stateTex = new THREE.DataTexture(state, MAX_CELLS, fracCap, THREE.RGBAFormat, THREE.FloatType);
      stateTex.needsUpdate = true;
      const rough = skinKind ? 0.55 : 0.86;
      const intact = new THREE.InstancedMesh(G[k], damageMaterial({ cloth: !skinKind, rough, down: DOWN[k] }), cap);
      const frac = new THREE.InstancedMesh(
        info.geo,
        damageMaterial({ cloth: !skinKind, rough, down: DOWN[k], frac: { state: stateTex, cells: info.cellTex }, skull: k === 'head' }),
        fracCap,
      );
      const proxyGeo = shadowProxy(G[k]);
      for (const im of [intact, frac]) {
        const n = im === intact ? cap : fracCap;
        im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        // the detailed mesh doesn't cast: a low-poly proxy sharing its instance matrices does (shadow pass only)
        im.castShadow = false;
        im.receiveShadow = true;
        im.frustumCulled = false;
        for (let i = 0; i < n; i++) im.setColorAt(i, _c.setRGB(1, 1, 1));
        const px = new THREE.InstancedMesh(proxyGeo, PROXY_MAT, n);
        px.instanceMatrix = im.instanceMatrix;
        px.frustumCulled = false;
        px.castShadow = true;
        px.count = 0;
        px.onBeforeShadow = () => {
          px.count = im.count;
        };
        px.onAfterShadow = () => {
          px.count = 0;
        };
        scene.add(px);
        for (const a of ATTRS) {
          const at = new THREE.InstancedBufferAttribute(new Float32Array(n * 4), 4);
          at.setUsage(THREE.DynamicDrawUsage);
          im.geometry.setAttribute(a, at);
        }
        (im.instanceMatrix.array as Float32Array).fill(0);
        scene.add(im);
      }
      intact.count = cap;
      frac.count = 0;
      this.sets[k] = { kind: k, intact, frac, info, cap, per: count[k], fracCap, packOf: new Int32Array(cap).fill(-1), identOf: new Int32Array(fracCap), n: 0, state, stateTex, dirty: false };
      const idx = G[k].index;
      this.stats.intactTris += (idx ? idx.count : G[k].attributes.position.count) / 3;
      this.stats.fracTris += info.tris;
      this.stats.cells += info.cells;
    }
    for (let h = 0; h < 3; h++) {
      const im = new THREE.InstancedMesh(G['hair' + h], hairMat, max);
      im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      im.castShadow = false;
      im.frustumCulled = false;
      for (let i = 0; i < max; i++) im.setColorAt(i, _c.setRGB(1, 1, 1));
      (im.instanceMatrix.array as Float32Array).fill(0);
      this.hair.push(im);
      scene.add(im);
    }
    this.maxStumps = max * 4;
    this.stumps = new THREE.InstancedMesh(G.stump, plainMat, this.maxStumps);
    this.stumps.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.stumps.frustumCulled = false;
    this.stumps.castShadow = true;
    this.stumps.count = 0;
    scene.add(this.stumps);

    const seen: Record<string, number> = {};
    for (const s of SEGS) {
      const sub = seen[s.kind] ?? 0;
      seen[s.kind] = sub + 1;
      this.segSet.push(this.sets[s.kind]);
      this.segSub.push(sub);
      this.segPer.push(count[s.kind]);
    }
    for (let z = 0; z < max; z++) this.base.push(SEGS.map(() => new THREE.Color()));
    this.woundI = new Uint8Array(max * NSEG);
    this.mats = new Float32Array(max * NSEG * 16);
    this.bald = new Uint8Array(max);
    this.gen = new Uint32Array(max);
    this.stats.buildMs = performance.now() - t0;
  }

  setTime(t: number) {
    U_TIME.value = t;
  }

  private ident(slot: number, seg: number) {
    return slot * this.segPer[seg] + this.segSub[seg];
  }

  /** Move a body part into the fractured mesh (allocating its damage row). */
  private pack(slot: number, seg: number) {
    const S = this.segSet[seg];
    const k = this.ident(slot, seg);
    let p = S.packOf[k];
    if (p >= 0) return p;
    if (S.n >= S.fracCap) return -1;
    if (this.fracTotal >= this.maxFrac) {
      this.onBudget();
      // soft cap: a little headroom while retiring bodies sink away, then a hard stop
      if (this.fracTotal >= this.maxFrac + 24) return -1;
    }
    p = S.n++;
    this.fracTotal++;
    S.packOf[k] = p;
    S.identOf[p] = k;
    for (const a of ATTRS) {
      const src = S.intact.geometry.getAttribute(a) as THREE.InstancedBufferAttribute;
      const dst = S.frac.geometry.getAttribute(a) as THREE.InstancedBufferAttribute;
      dst.setXYZW(p, src.getX(k), src.getY(k), src.getZ(k), src.getW(k));
      dst.needsUpdate = true;
    }
    const ci = S.intact.instanceColor!.array as Float32Array;
    const cf = S.frac.instanceColor!.array as Float32Array;
    for (let q = 0; q < 3; q++) cf[p * 3 + q] = ci[k * 3 + q];
    S.frac.instanceColor!.needsUpdate = true;
    const mi = S.intact.instanceMatrix.array as Float32Array;
    const mf = S.frac.instanceMatrix.array as Float32Array;
    for (let q = 0; q < 16; q++) {
      mf[p * 16 + q] = mi[k * 16 + q];
      mi[k * 16 + q] = 0;
    }
    S.state.fill(0, p * MAX_CELLS * 4, (p + 1) * MAX_CELLS * 4);
    S.dirty = true;
    return p;
  }

  /** Return all fractured parts of a slot to the intact mesh (swap-remove keeps the packed range dense). */
  private release(slot: number) {
    const R = MAX_CELLS * 4;
    for (let seg = 0; seg < NSEG; seg++) {
      const S = this.segSet[seg];
      const k = this.ident(slot, seg);
      const p = S.packOf[k];
      if (p < 0) continue;
      const last = S.n - 1;
      if (p !== last) {
        const kl = S.identOf[last];
        for (const a of ATTRS) {
          const at = S.frac.geometry.getAttribute(a) as THREE.InstancedBufferAttribute;
          at.setXYZW(p, at.getX(last), at.getY(last), at.getZ(last), at.getW(last));
          at.needsUpdate = true;
        }
        const cf = S.frac.instanceColor!.array as Float32Array;
        for (let q = 0; q < 3; q++) cf[p * 3 + q] = cf[last * 3 + q];
        S.frac.instanceColor!.needsUpdate = true;
        const mf = S.frac.instanceMatrix.array as Float32Array;
        for (let q = 0; q < 16; q++) mf[p * 16 + q] = mf[last * 16 + q];
        S.state.copyWithin(p * R, last * R, (last + 1) * R);
        S.packOf[kl] = p;
        S.identOf[p] = kl;
      }
      S.packOf[k] = -1;
      S.n--;
      this.fracTotal--;
      S.dirty = true;
    }
  }

  /** Write a per-instance vec4 to the intact mesh and its fractured mirror. */
  private setA(seg: number, slot: number, name: string, x: number, y: number, z: number, w: number) {
    const S = this.segSet[seg];
    const k = this.ident(slot, seg);
    const a = S.intact.geometry.getAttribute(name) as THREE.InstancedBufferAttribute;
    a.setXYZW(k, x, y, z, w);
    a.needsUpdate = true;
    const p = S.packOf[k];
    if (p >= 0) {
      const b = S.frac.geometry.getAttribute(name) as THREE.InstancedBufferAttribute;
      b.setXYZW(p, x, y, z, w);
      b.needsUpdate = true;
    }
  }
  private getA(seg: number, name: string) {
    return this.segSet[seg].intact.geometry.getAttribute(name) as THREE.InstancedBufferAttribute;
  }
  private setCol(seg: number, slot: number, c: THREE.Color) {
    const S = this.segSet[seg];
    const k = this.ident(slot, seg);
    S.intact.setColorAt(k, c);
    S.intact.instanceColor!.needsUpdate = true;
    const p = S.packOf[k];
    if (p >= 0) {
      S.frac.setColorAt(p, c);
      S.frac.instanceColor!.needsUpdate = true;
    }
  }

  /** Clear all wounds / tears / fractures of a slot (new zombie). */
  resetDamage(slot: number) {
    this.release(slot);
    this.bald[slot] = 0;
    this.gen[slot]++;
    for (let i = 0; i < NSEG; i++) {
      for (const a of ['aW0', 'aW1', 'aW2']) this.setA(i, slot, a, 0, 0, 0, 0);
      this.setA(i, slot, 'aTear', 0, Math.random() * 50, 0, 0);
      this.woundI[slot * NSEG + i] = 0;
    }
  }

  /** Wound at a body-part local point (cycles through 3 slots per part). */
  woundLocal(slot: number, seg: number, x: number, y: number, z: number, strength: number) {
    const wi = slot * NSEG + seg;
    const w = this.woundI[wi] % 3;
    this.woundI[wi]++;
    this.setA(seg, slot, 'aW' + w, x, y, z, Math.min(1.6, strength));
  }

  /** Last rendered matrix of a part (null if hidden). */
  private matrixOf(slot: number, seg: number, out: THREE.Matrix4) {
    const o = (slot * NSEG + seg) * 16;
    if (this.mats[o + 15] === 0) return null;
    return out.fromArray(this.mats, o);
  }

  /** Wound where a bullet struck in world space: converted into the part's local frame. */
  wound(slot: number, seg: number, p: THREE.Vector3, strength: number) {
    if (!this.matrixOf(slot, seg, _m)) return;
    _v.copy(p).applyMatrix4(_m.invert());
    this.woundLocal(slot, seg, _v.x, _v.y, _v.z, strength);
  }

  /** Part-local point → world (follows the animated / ragdolled mesh). */
  localToWorld(slot: number, seg: number, x: number, y: number, z: number, out: THREE.Vector3) {
    if (!this.matrixOf(slot, seg, _m)) return null;
    return out.set(x, y, z).applyMatrix4(_m);
  }

  /** Rips through clothing (x), char (z). Values only grow. */
  tear(slot: number, seg: number, amount: number, burn = 0) {
    const at = this.getA(seg, 'aTear');
    const k = this.ident(slot, seg);
    this.setA(seg, slot, 'aTear', Math.min(1, Math.max(at.getX(k), amount)), at.getY(k), Math.min(1, Math.max(at.getZ(k), burn)), at.getW(k));
  }
  tearOf(slot: number, seg: number) {
    return this.getA(seg, 'aTear').getX(this.ident(slot, seg));
  }

  /** A random point on the surface of a body part (for pre-existing damage). */
  surfacePoint(seg: number, out: THREE.Vector3) {
    const p = this.geos[SEGS[seg].kind].attributes.position;
    const i = (Math.random() * p.count) | 0;
    return out.set(p.getX(i), p.getY(i), p.getZ(i));
  }

  setPalette(slot: number, p: Palette) {
    SEGS.forEach((s, i) => {
      const c =
        s.kind === 'head' || s.kind === 'neck' || s.kind === 'hand'
          ? p.skin
          : s.kind === 'chest' || s.kind === 'abdomen' || s.kind === 'upperArm'
            ? p.shirt
            : s.kind === 'forearm'
              ? p.sleeve
              : s.kind === 'foot'
                ? p.shoes
                : p.pants;
      this.base[slot][i].copy(c);
      this.setCol(i, slot, c);
    });
    for (let h = 0; h < 3; h++) this.hair[h].setColorAt(slot, p.hair);
    for (const m of this.hair) if (m.instanceColor) m.instanceColor.needsUpdate = true;
  }
  partColor(slot: number, seg: number) {
    return this.base[slot][seg];
  }

  /** Blood soaks into a body part as it takes damage. */
  tint(slot: number, seg: number, amount: number) {
    _c.copy(this.base[slot][seg]).lerp(BLOOD, Math.min(0.45, amount * 0.6));
    this.setCol(seg, slot, _c);
  }

  /* ------------------------------------------------------- Voronoi damage */
  /**
   * Impact in world space: cells around the hit (stretched along the shot into
   * the body) crack, sink or break away. Newly destroyed cells are appended to
   * `lost` (world space) so the caller can launch matching debris.
   */
  fracture(slot: number, seg: number, p: THREE.Vector3, dir: THREE.Vector3, radius: number, strength: number, time: number, lost?: LostCell[]) {
    if (!this.matrixOf(slot, seg, _m)) return 0;
    const s = Math.hypot(_m.elements[0], _m.elements[1], _m.elements[2]) || 1;
    _mi.copy(_m).invert();
    _v.copy(p).applyMatrix4(_mi);
    _d.copy(dir).transformDirection(_mi);
    return this.fractureLocal(slot, seg, _v.x, _v.y, _v.z, radius / s, strength, time, 1, lost, _d);
  }

  fractureLocal(slot: number, seg: number, x: number, y: number, z: number, R: number, S: number, time: number, wet: number, lost?: LostCell[], dir?: THREE.Vector3) {
    const set = this.segSet[seg];
    const info = set.info;
    const pi = this.pack(slot, seg);
    if (pi < 0) return 0;
    const st = set.state;
    const row = pi * MAX_CELLS * 4;
    const salt = Math.random() * 1000;
    let gone = 0;
    for (let c = 0; c < info.cells; c++) {
      const dx = info.center[c * 3] - x;
      const dy = info.center[c * 3 + 1] - y;
      const dz = info.center[c * 3 + 2] - z;
      let dd = Math.hypot(dx, dy, dz);
      if (dir) {
        const along = dx * dir.x + dy * dir.y + dz * dir.z;
        if (along > 0) dd -= along * 0.3; // the wound channel reaches into the body
      }
      const reach = R * (0.6 + 0.8 * hash1(c, salt)) + info.size[c] * 0.45;
      if (dd >= reach) continue;
      const u = Math.max(0, dd) / reach;
      const add = S * (1 - u * u) * (0.65 + 0.7 * Math.random());
      if (add < 0.01) continue;
      const j = row + c * 4;
      const before = st[j];
      st[j] = Math.min(1, before + add);
      st[j + 1] = wet > 0.5 ? time : time - 300; // old wounds: no pop animation, dried
      st[j + 2] = Math.min(1, Math.max(st[j + 2] * 0.6, wet * Math.min(1, add * 2.5)));
      if (before < 0.9 && st[j] >= 0.9) {
        gone++;
        // the rim of a broken-out plate always cracks
        for (const nb of info.neighbors[c]) {
          const q = row + nb * 4;
          if (st[q] < 0.12) {
            st[q] = 0.12 + Math.random() * 0.16;
            st[q + 1] = st[j + 1];
            st[q + 2] = Math.max(st[q + 2], st[j + 2] * 0.7);
          }
        }
        if (lost) this.pushLost(slot, seg, c, lost);
        // procedural crumbling: plates left hanging between broken neighbours give way a moment later
        if (wet > 0.5) this.queueCrumble(slot, seg, row, c, time);
      }
    }
    set.dirty = true;
    if (seg === 0 && gone > 0 && this.fracLevel(slot, 0) > 0.28) this.bald[slot] = 1;
    return gone;
  }

  private pushLost(slot: number, seg: number, c: number, lost: LostCell[]) {
    if (!this.matrixOf(slot, seg, _m)) return;
    const info = this.segSet[seg].info;
    const q = new THREE.Quaternion();
    _m.decompose(_dp, q, _ds);
    _v.fromArray(info.center, c * 3).applyMatrix4(_m);
    _n.fromArray(info.normal, c * 3).transformDirection(_m);
    lost.push({ x: _v.x, y: _v.y, z: _v.z, nx: _n.x, ny: _n.y, nz: _n.z, size: info.size[c] * _ds.x, kind: this.segSet[seg].kind, cell: c, slot, seg, q, s: _ds.x });
  }

  private queueCrumble(slot: number, seg: number, row: number, c: number, time: number) {
    const set = this.segSet[seg];
    const st = set.state;
    for (const nb of set.info.neighbors[c]) {
      const d = st[row + nb * 4];
      if (d < 0.42 || d >= 0.9) continue;
      let broken = 0;
      for (const m of set.info.neighbors[nb]) if (st[row + m * 4] >= 0.9) broken++;
      if (broken >= 2 && this.crumbleQ.length < 600) this.crumbleQ.push({ slot, seg, cell: nb, t: time + 0.05 + Math.random() * 0.32, gen: this.gen[slot] });
    }
  }

  /** Due crumble events: weakened plates break away (cascading). Newly lost cells are appended to `lost`. */
  crumble(time: number, lost: LostCell[]) {
    const Q = this.crumbleQ;
    for (let i = Q.length - 1; i >= 0; i--) {
      const e = Q[i];
      if (e.t > time) continue;
      Q[i] = Q[Q.length - 1];
      Q.pop();
      if (e.gen !== this.gen[e.slot]) continue;
      const set = this.segSet[e.seg];
      const p = set.packOf[this.ident(e.slot, e.seg)];
      if (p < 0) continue;
      const row = p * MAX_CELLS * 4;
      const j = row + e.cell * 4;
      if (set.state[j] >= 0.9) continue;
      set.state[j] = 1;
      set.state[j + 1] = time;
      set.state[j + 2] = Math.max(set.state[j + 2], 0.8);
      set.dirty = true;
      this.pushLost(e.slot, e.seg, e.cell, lost);
      this.queueCrumble(e.slot, e.seg, row, e.cell, time);
    }
  }

  /** A hard knock (body slamming into the ground): cracked, sunken plates shake loose. */
  shake(slot: number, strength: number, time: number, lost: LostCell[]) {
    for (let seg = 0; seg < NSEG; seg++) {
      const set = this.segSet[seg];
      const p = set.packOf[this.ident(slot, seg)];
      if (p < 0) continue;
      const row = p * MAX_CELLS * 4;
      for (let c = 0; c < set.info.cells; c++) {
        const j = row + c * 4;
        const d = set.state[j];
        if (d >= 0.5 && d < 0.9 && Math.random() < strength * (d - 0.35)) {
          set.state[j] = 1;
          set.state[j + 1] = time;
          set.dirty = true;
          this.pushLost(slot, seg, c, lost);
        }
      }
    }
  }

  /** Fractured geometry of every body-part kind (debris registers each cell once). */
  get parts(): Record<string, FracInfo> {
    const o: Record<string, FracInfo> = {};
    for (const k of KINDS) o[k] = this.sets[k].info;
    return o;
  }

  /** Keep a zombie's instances in the drawn range without touching its matrices (settled corpses). */
  touch(slot: number) {
    if (slot + 1 > this.frameHi) this.frameHi = slot + 1;
  }

  /** Translate an already-posed zombie (animation LOD frames: limbs keep their pose, the body keeps moving). */
  shift(slot: number, dx: number, dy: number, dz: number) {
    if (slot + 1 > this.frameHi) this.frameHi = slot + 1;
    const M = this.mats;
    for (let i = 0; i < NSEG; i++) {
      const co = (slot * NSEG + i) * 16;
      if (M[co + 15] === 0) continue;
      M[co + 12] += dx;
      M[co + 13] += dy;
      M[co + 14] += dz;
      const S = this.segSet[i];
      const k = this.ident(slot, i);
      const pk = S.packOf[k];
      const arr = (pk >= 0 ? S.frac.instanceMatrix.array : S.intact.instanceMatrix.array) as Float32Array;
      const o = (pk >= 0 ? pk : k) * 16;
      arr[o + 12] = M[co + 12];
      arr[o + 13] = M[co + 13];
      arr[o + 14] = M[co + 14];
    }
    for (let h = 0; h < 3; h++) {
      const ha = this.hair[h].instanceMatrix.array as Float32Array;
      const o = slot * 16;
      if (ha[o + 15] === 0) continue;
      ha[o + 12] += dx;
      ha[o + 13] += dy;
      ha[o + 14] += dz;
    }
  }

  /** Old, dried damage for zombies that rose already broken. */
  fracturePre(slot: number, seg: number, strength: number, wet = 0, lost?: LostCell[]) {
    const info = this.segSet[seg].info;
    const c = (Math.random() * info.cells) | 0;
    const R = 0.025 + Math.random() * 0.05;
    return this.fractureLocal(slot, seg, info.center[c * 3], info.center[c * 3 + 1], info.center[c * 3 + 2], R, strength, U_TIME.value, wet, lost);
  }

  /** Fraction of the part's plates that are gone (0..1). */
  fracLevel(slot: number, seg: number) {
    const set = this.segSet[seg];
    const p = set.packOf[this.ident(slot, seg)];
    if (p < 0) return 0;
    let n = 0;
    const row = p * MAX_CELLS * 4;
    for (let c = 0; c < set.info.cells; c++) if (set.state[row + c * 4] >= 0.9) n++;
    return n / set.info.cells;
  }

  /** Visual damage state of a body region: 0 intact, 1 cracked, 2 fractured, 3 shattered, 4 destroyed. */
  damageState(slot: number, seg: number) {
    const set = this.segSet[seg];
    const p = set.packOf[this.ident(slot, seg)];
    if (p < 0) return 0;
    let cracked = 0;
    let gone = 0;
    const row = p * MAX_CELLS * 4;
    for (let c = 0; c < set.info.cells; c++) {
      const d = set.state[row + c * 4];
      if (d >= 0.9) gone++;
      else if (d > 0.05) cracked++;
    }
    const g = gone / set.info.cells;
    if (g > 0.55) return 4;
    if (g > 0.25) return 3;
    if (gone > 0) return 2;
    return cracked > 0 ? 1 : 0;
  }

  /** A random destroyed cell of the part, local space (for drips out of open craters). */
  craterPoint(slot: number, seg: number, out: THREE.Vector3) {
    const set = this.segSet[seg];
    const p = set.packOf[this.ident(slot, seg)];
    if (p < 0) return null;
    const row = p * MAX_CELLS * 4;
    const n = set.info.cells;
    const o = (Math.random() * n) | 0;
    for (let k = 0; k < n; k++) {
      const c = (o + k) % n;
      if (set.state[row + c * 4] >= 0.5) return out.fromArray(set.info.center, c * 3);
    }
    return null;
  }

  /** World position + outward normal of an open crater cell (arterial jets follow the moving body). */
  craterJet(slot: number, seg: number, outP: THREE.Vector3, outN: THREE.Vector3) {
    const set = this.segSet[seg];
    const p = set.packOf[this.ident(slot, seg)];
    if (p < 0 || !this.matrixOf(slot, seg, _m)) return false;
    const row = p * MAX_CELLS * 4;
    const n = set.info.cells;
    const o = (Math.random() * n) | 0;
    for (let k = 0; k < n; k++) {
      const c = (o + k) % n;
      if (set.state[row + c * 4] >= 0.6) {
        outP.fromArray(set.info.center, c * 3).applyMatrix4(_m);
        outN.fromArray(set.info.normal, c * 3).transformDirection(_m);
        return true;
      }
    }
    return false;
  }

  private static write(arr: ArrayLike<number> & { [i: number]: number }, o: number, X: number[], Y: number[], Z: number[], a: number[], s: number) {
    arr[o] = X[0] * s;
    arr[o + 1] = X[1] * s;
    arr[o + 2] = X[2] * s;
    arr[o + 3] = 0;
    arr[o + 4] = Y[0] * s;
    arr[o + 5] = Y[1] * s;
    arr[o + 6] = Y[2] * s;
    arr[o + 7] = 0;
    arr[o + 8] = Z[0] * s;
    arr[o + 9] = Z[1] * s;
    arr[o + 10] = Z[2] * s;
    arr[o + 11] = 0;
    arr[o + 12] = a[0];
    arr[o + 13] = a[1];
    arr[o + 14] = a[2];
    arr[o + 15] = 1;
  }

  /** Orient every segment from its two particles + a lateral reference. */
  write(slot: number, pts: Float32Array, s: number, hidden: number, hairStyle: number) {
    if (slot + 1 > this.frameHi) this.frameHi = slot + 1;
    const sx = pts[P.LSH * 3] - pts[P.RSH * 3];
    const sy = pts[P.LSH * 3 + 1] - pts[P.RSH * 3 + 1];
    const sz = pts[P.LSH * 3 + 2] - pts[P.RSH * 3 + 2];
    const hx = pts[P.LHIP * 3] - pts[P.RHIP * 3];
    const hy = pts[P.LHIP * 3 + 1] - pts[P.RHIP * 3 + 1];
    const hz = pts[P.LHIP * 3 + 2] - pts[P.RHIP * 3 + 2];
    const M = this.mats;
    for (let i = 0; i < NSEG; i++) {
      const sg = SEGS[i];
      const S = this.segSet[i];
      const k = this.ident(slot, i);
      const pk = S.packOf[k];
      const ia = S.intact.instanceMatrix.array as Float32Array;
      const fa = S.frac.instanceMatrix.array as Float32Array;
      const co = (slot * NSEG + i) * 16;
      if (hidden & (1 << i)) {
        for (let q = 0; q < 16; q++) {
          M[co + q] = 0;
          ia[k * 16 + q] = 0;
          if (pk >= 0) fa[pk * 16 + q] = 0;
        }
        continue;
      }
      const a = sg.a * 3;
      const b = sg.b * 3;
      _A[0] = pts[a];
      _A[1] = pts[a + 1];
      _A[2] = pts[a + 2];
      let yx = pts[b] - pts[a];
      let yy = pts[b + 1] - pts[a + 1];
      let yz = pts[b + 2] - pts[a + 2];
      const yl = Math.hypot(yx, yy, yz) || 1e-5;
      yx /= yl;
      yy /= yl;
      yz /= yl;
      let rx = sg.ref === 'sh' ? sx : hx;
      let ry = sg.ref === 'sh' ? sy : hy;
      let rz = sg.ref === 'sh' ? sz : hz;
      let d = rx * yx + ry * yy + rz * yz;
      rx -= yx * d;
      ry -= yy * d;
      rz -= yz * d;
      let rl = Math.hypot(rx, ry, rz);
      if (rl < 1e-3) {
        // limb parallel to the shoulder line: fall back to the other reference
        rx = sg.ref === 'sh' ? hx : sx;
        ry = sg.ref === 'sh' ? hy : sy;
        rz = sg.ref === 'sh' ? hz : sz;
        d = rx * yx + ry * yy + rz * yz;
        rx -= yx * d;
        ry -= yy * d;
        rz -= yz * d;
        rl = Math.hypot(rx, ry, rz) || 1;
      }
      _X[0] = rx / rl;
      _X[1] = ry / rl;
      _X[2] = rz / rl;
      _Y[0] = yx;
      _Y[1] = yy;
      _Y[2] = yz;
      _Z[0] = _X[1] * yz - _X[2] * yy;
      _Z[1] = _X[2] * yx - _X[0] * yz;
      _Z[2] = _X[0] * yy - _X[1] * yx;
      ZombieRenderer.write(M, co, _X, _Y, _Z, _A, s);
      if (pk >= 0) {
        for (let q = 0; q < 16; q++) {
          fa[pk * 16 + q] = M[co + q];
          ia[k * 16 + q] = 0;
        }
      } else for (let q = 0; q < 16; q++) ia[k * 16 + q] = M[co + q];
      if (i === 0) {
        for (let h = 0; h < 3; h++) {
          const ha = this.hair[h].instanceMatrix.array as Float32Array;
          if (h === hairStyle) ZombieRenderer.write(ha, slot * 16, _X, _Y, _Z, _A, s);
          else for (let q = 0; q < 16; q++) ha[slot * 16 + q] = 0;
        }
      }
    }
    if (hidden & 1 || this.bald[slot]) {
      for (let h = 0; h < 3; h++) {
        const ha = this.hair[h].instanceMatrix.array as Float32Array;
        for (let q = 0; q < 16; q++) ha[slot * 16 + q] = 0;
      }
    }
  }

  hide(slot: number) {
    for (let i = 0; i < NSEG; i++) {
      const S = this.segSet[i];
      const k = this.ident(slot, i);
      const pk = S.packOf[k];
      const ia = S.intact.instanceMatrix.array as Float32Array;
      const fa = S.frac.instanceMatrix.array as Float32Array;
      const co = (slot * NSEG + i) * 16;
      for (let q = 0; q < 16; q++) {
        ia[k * 16 + q] = 0;
        this.mats[co + q] = 0;
        if (pk >= 0) fa[pk * 16 + q] = 0;
      }
    }
    for (let h = 0; h < 3; h++) {
      const ha = this.hair[h].instanceMatrix.array as Float32Array;
      for (let q = 0; q < 16; q++) ha[slot * 16 + q] = 0;
    }
  }

  beginStumps() {
    this.stumpN = 0;
  }
  /** Raw wound cap at particle `at`, facing away from particle `from`. */
  stump(pts: Float32Array, at: number, from: number, r: number) {
    if (this.stumpN >= this.maxStumps) return;
    const ax = pts[at * 3];
    const ay = pts[at * 3 + 1];
    const az = pts[at * 3 + 2];
    _v.set(ax - pts[from * 3], ay - pts[from * 3 + 1], az - pts[from * 3 + 2]);
    if (_v.lengthSq() < 1e-8) _v.set(0, 1, 0);
    _v.normalize();
    _q.setFromUnitVectors(_up, _v);
    _m.compose(_p.set(ax, ay, az), _q, _s.set(r, r, r));
    this.stumps.setMatrixAt(this.stumpN++, _m);
  }

  get fracUsed() {
    return this.fracTotal;
  }
  /** Fractured parts held by one zombie. */
  fracPartsOf(slot: number) {
    let n = 0;
    for (let seg = 0; seg < NSEG; seg++) if (this.segSet[seg].packOf[this.ident(slot, seg)] >= 0) n++;
    return n;
  }
  /** Hand a zombie's fractured parts back to the intact mesh (wounds and blood stay). */
  releaseSlot(slot: number) {
    this.release(slot);
    this.gen[slot]++;
  }

  /** Number of body parts currently rendered with the fractured mesh. */
  get fracturedParts() {
    let n = 0;
    for (const k of KINDS) n += this.sets[k].n;
    return n;
  }

  commit() {
    this.hi = this.frameHi;
    this.frameHi = 0;
    for (const m of this.hair) m.count = this.hi;
    for (const k of KINDS) {
      const S = this.sets[k];
      S.intact.count = Math.min(S.cap, this.hi * S.per);
      S.intact.instanceMatrix.needsUpdate = true;
      S.frac.instanceMatrix.needsUpdate = true;
      S.frac.count = S.n;
      if (S.dirty) {
        S.stateTex.needsUpdate = true;
        S.dirty = false;
      }
    }
    for (const m of this.hair) m.instanceMatrix.needsUpdate = true;
    this.stumps.count = this.stumpN;
    this.stumps.instanceMatrix.needsUpdate = true;
  }
}

const _X = [0, 0, 0];
const _Y = [0, 0, 0];
const _Z = [0, 0, 0];
const _A = [0, 0, 0];
const _v = new THREE.Vector3();
const _n = new THREE.Vector3();
const _dp = new THREE.Vector3();
const _ds = new THREE.Vector3();
const PROXY_MAT = new THREE.MeshBasicMaterial();
const _d = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _q = new THREE.Quaternion();
const _m = new THREE.Matrix4();
const _mi = new THREE.Matrix4();
const _p = new THREE.Vector3();
const _s = new THREE.Vector3();
void L;
