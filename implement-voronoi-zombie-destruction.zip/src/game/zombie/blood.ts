import * as THREE from 'three';
import type { Box, Ramp, Terrain } from '../terrain';

/* ---------------------------------------------------------------------------
 * BLOOD SIMULATION
 *  • GPU droplets: each droplet is spawned once (origin, velocity, drag, size)
 *    and its ballistic flight with drag is solved analytically in the vertex
 *    shader — thousands of glossy, velocity-stretched drops for zero per-frame
 *    CPU cost. Their landing is solved exactly on the CPU at spawn time against
 *    the real scene (ground, box tops, ramps, wall faces, tree trunks).
 *  • Surface stains: one instanced, GPU-conforming decal layer. Ground stains
 *    follow the analytic terrain in the vertex shader, top/ramp stains are
 *    clipped to their surface, wall stains sit on the exact face and run down,
 *    trunk stains wrap the octagonal bark. They react to the surface material
 *    (soak into snow, glossy on metal/concrete, absorbed by bark) and dry
 *    from wet glossy red to matte brown over time. Pools spread on the GPU.
 *  • Soft mist, gore bits, lens splatter. Everything pooled: no allocations.
 * ------------------------------------------------------------------------- */
const rnd = (a: number, b: number) => a + Math.random() * (b - a);
const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) * 1.15;
const _d = new THREE.Vector3();
const _a = new THREE.Vector3();
const _b = new THREE.Vector3();
const _m = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _s = new THREE.Vector3();
const _p = new THREE.Vector3();
const _e = new THREE.Euler();
const _c = new THREE.Color();
const ZERO = new THREE.Vector3();
const GS = 4; // height-grid cell size (m)
const GN = 44; // cells per side
const GO = 88; // grid origin offset (covers ±88 m)
const DOWN = new THREE.Vector3(0, -1, 0);
// dedicated emit directions: never alias the scratch vectors used by cone() / trace()
const _back = new THREE.Vector3();
const _tp = new THREE.Vector3();
const _ex = new THREE.Vector3();
const _up2 = new THREE.Vector3();

function cone(dir: THREE.Vector3, spread: number, out: THREE.Vector3) {
  _a.set(1, 0, 0);
  if (Math.abs(dir.x) > 0.8) _a.set(0, 1, 0);
  _a.cross(dir).normalize();
  _b.crossVectors(dir, _a);
  const ang = Math.random() * Math.PI * 2;
  const r = Math.tan(spread) * Math.sqrt(Math.random());
  return out.copy(dir).addScaledVector(_a, Math.cos(ang) * r).addScaledVector(_b, Math.sin(ang) * r).normalize();
}

/* --------------------------------------------------------------- atlas */
/** 4×4 atlas of white-on-transparent masks: spots, streaks, pools, wall runs, smear. */
function stainAtlas(): THREE.Texture {
  const S = 512;
  const C = 128;
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const g = cv.getContext('2d')!;
  let k = 1234;
  const r = () => {
    k = (k * 9301 + 49297) % 233280;
    return k / 233280;
  };
  const blob = (x: number, y: number, rx: number, ry: number, a: number) => {
    g.save();
    g.translate(x, y);
    g.scale(1, ry / rx);
    const gr = g.createRadialGradient(0, 0, 0, 0, 0, rx);
    gr.addColorStop(0, `rgba(255,255,255,${a})`);
    gr.addColorStop(0.78, `rgba(240,240,240,${a})`);
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.beginPath();
    g.arc(0, 0, rx, 0, Math.PI * 2);
    g.fill();
    g.restore();
  };
  for (let cell = 0; cell < 16; cell++) {
    const ox = (cell % 4) * C;
    const oy = Math.floor(cell / 4) * C;
    g.save();
    g.beginPath();
    g.rect(ox + 2, oy + 2, C - 4, C - 4);
    g.clip();
    const cx = ox + C / 2;
    const cy = oy + C / 2;
    if (cell < 6) {
      // splat: irregular core, radiating spines, satellite droplets
      const core = 5 + ((r() * 4) | 0);
      for (let i = 0; i < core; i++) blob(cx + (r() - 0.5) * 30, cy + (r() - 0.5) * 30, 9 + r() * 15, 9 + r() * 15, 1);
      const spines = 6 + ((r() * 10) | 0);
      for (let i = 0; i < spines; i++) {
        const a = r() * Math.PI * 2;
        const d0 = 14 + r() * 10;
        const d1 = d0 + 8 + r() * 30;
        for (let t = 0; t < 1; t += 0.08) {
          const d = d0 + (d1 - d0) * t;
          blob(cx + Math.cos(a) * d, cy + Math.sin(a) * d, (1 - t) * 4 + 1.1, (1 - t) * 4 + 1.1, 0.95);
        }
      }
      for (let i = 0; i < 16 + cell * 4; i++) {
        const a = r() * Math.PI * 2;
        const d = 26 + r() * 32;
        blob(cx + Math.cos(a) * d, cy + Math.sin(a) * d, 1 + r() * 3, 1 + r() * 3, 0.9);
      }
    } else if (cell < 10) {
      // streak: fat head near the top, tapering tail toward the bottom (= flight direction)
      const hx = cx + (r() - 0.5) * 8;
      const hy = oy + 26;
      blob(hx, hy, 15, 13, 1);
      let x = hx;
      for (let t = 0; t < 1; t += 0.03) {
        x += (r() - 0.5) * 1.6;
        blob(x, hy + t * 92, 13 * (1 - t) + 1.6, 13 * (1 - t) + 1.6, 0.95);
      }
      for (let i = 0; i < 14; i++) blob(cx + (r() - 0.5) * 46, oy + 20 + r() * 100, 1 + r() * 2.6, 1.4 + r() * 4, 0.9);
    } else if (cell < 13) {
      // pool: lobed blob
      for (let i = 0; i < 16; i++) blob(cx + (r() - 0.5) * 44, cy + (r() - 0.5) * 44, 14 + r() * 22, 14 + r() * 22, 1);
    } else if (cell < 15) {
      // wall run: splat on top, rivulets running down
      blob(cx, oy + 22, 18, 14, 1);
      for (let i = 0; i < 5; i++) blob(cx + (r() - 0.5) * 30, oy + 22 + (r() - 0.5) * 10, 6 + r() * 6, 6 + r() * 6, 1);
      const runs = 3 + ((r() * 4) | 0);
      for (let i = 0; i < runs; i++) {
        let x = cx + (r() - 0.5) * 34;
        const len = 40 + r() * 60;
        const w0 = 2.2 + r() * 2.5;
        for (let t = 0; t < len; t += 2) {
          x += (r() - 0.5) * 0.8;
          blob(x, oy + 26 + t, w0 * (1 - (t / len) * 0.45), w0 * (1 - (t / len) * 0.45), 0.96);
        }
        blob(x, oy + 26 + len, w0 * 1.15, w0 * 1.5, 1); // bead at the end of the run
      }
    } else {
      // smear (bodies sliding through the snow)
      for (let i = 0; i < 26; i++) blob(cx + (r() - 0.5) * 34, oy + 12 + r() * 104, 8 + r() * 10, 12 + r() * 16, 0.55 + r() * 0.4);
    }
    g.restore();
  }
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.NoColorSpace;
  t.generateMipmaps = true;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.anisotropy = 4;
  return t;
}


/** Airborne splat sprites: 12 irregular blobs with satellites + 4 burst splats (for hit bursts). */
function splatAtlas(): THREE.Texture {
  const S = 512;
  const C = 128;
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const g = cv.getContext('2d')!;
  let k = 777;
  const r = () => {
    k = (k * 9301 + 49297) % 233280;
    return k / 233280;
  };
  const blob = (x: number, y: number, rx: number, ry: number) => {
    g.save();
    g.translate(x, y);
    g.scale(1, ry / rx);
    g.fillStyle = '#ffffff';
    g.beginPath();
    g.arc(0, 0, rx, 0, Math.PI * 2);
    g.fill();
    g.restore();
  };
  for (let cell = 0; cell < 16; cell++) {
    const ox = (cell % 4) * C;
    const oy = Math.floor(cell / 4) * C;
    g.save();
    g.beginPath();
    g.rect(ox + 1, oy + 1, C - 2, C - 2);
    g.clip();
    const cx = ox + C / 2;
    const cy = oy + C / 2;
    if (cell < 12) {
      // irregular wet blob + a few satellite drops
      const lobes = 4 + ((r() * 4) | 0);
      for (let i = 0; i < lobes; i++) blob(cx + (r() - 0.5) * 26, cy + (r() - 0.5) * 26, 13 + r() * 13, 13 + r() * 13);
      for (let i = 0; i < 3 + ((r() * 6) | 0); i++) {
        const a = r() * Math.PI * 2;
        const d = 30 + r() * 22;
        blob(cx + Math.cos(a) * d, cy + Math.sin(a) * d, 2 + r() * 5, 2 + r() * 5);
      }
    } else {
      // burst: dense core, long radiating spikes ending in beads
      for (let i = 0; i < 7; i++) blob(cx + (r() - 0.5) * 22, cy + (r() - 0.5) * 22, 12 + r() * 12, 12 + r() * 12);
      const spikes = 12 + ((r() * 10) | 0);
      for (let i = 0; i < spikes; i++) {
        const a = r() * Math.PI * 2;
        const len = 26 + r() * 32;
        for (let t = 0; t <= 1; t += 0.06) blob(cx + Math.cos(a) * (12 + len * t), cy + Math.sin(a) * (12 + len * t), 5.5 * (1 - t) + 1.4, 5.5 * (1 - t) + 1.4);
        blob(cx + Math.cos(a) * (14 + len), cy + Math.sin(a) * (14 + len), 2.6 + r() * 2.5, 2.6 + r() * 2.5);
      }
      for (let i = 0; i < 18; i++) {
        const a = r() * Math.PI * 2;
        const d = 22 + r() * 40;
        blob(cx + Math.cos(a) * d, cy + Math.sin(a) * d, 1.2 + r() * 2.6, 1.2 + r() * 2.6);
      }
    }
    g.restore();
  }
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.NoColorSpace;
  t.generateMipmaps = true;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  return t;
}

function cloudTexture(): THREE.Texture {
  const s = 64;
  const cv = document.createElement('canvas');
  cv.width = cv.height = s;
  const g = cv.getContext('2d')!;
  for (let i = 0; i < 26; i++) {
    const x = 32 + (Math.random() - 0.5) * 30;
    const y = 32 + (Math.random() - 0.5) * 30;
    const r = 6 + Math.random() * 12;
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, 'rgba(255,255,255,0.22)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, s, s);
  }
  return new THREE.CanvasTexture(cv);
}

/* ------------------------------------------------------------- GLSL */
const BASE_H = `
float bsm(float a, float b, float x){ float t = clamp((x - a) / (b - a), 0.0, 1.0); return t * t * (3.0 - 2.0 * t); }
float baseH(vec2 p){
  float h = (1.5 * sin(p.x * 0.06 + 0.4) * cos(p.y * 0.055 + 1.1) + 0.6 * sin(p.x * 0.13 + p.y * 0.11 + 2.0)) * bsm(19.0, 46.0, length(p));
  float rm = 1.0 - bsm(3.2, 6.0, length(p + vec2(6.0, 9.0)));
  h += 0.1 * rm * sin(p.x * 2.2) * sin(p.y * 2.0);
  vec2 m = p - vec2(10.0, -7.0);
  float md = dot(m, m) / 14.0;
  if (md < 8.0) h += 0.85 * exp(-md);
  return h;
}
`;

/** Surface kinds for stains. */
const GROUND = 0;
const TOP = 1;
const RAMP = 2;
const WALL = 3;
const TRUNK = 4;
/** Surface materials. */
const SNOW = 0;
const HARD = 1;
const BARK = 2;

interface Tree {
  x: number;
  z: number;
  yb: number;
  top: number;
  r0: number;
  taper: number;
  rot: number;
}
interface Landing {
  t: number;
  type: number;
  x: number;
  y: number;
  z: number;
  nx: number;
  nz: number;
  vx: number;
  vy: number;
  vz: number;
  size: number;
  shade: number;
  ref: number;
}

export class Blood {
  private terrain: Terrain;
  /** blood on the camera lens (0..1), read by the HUD */
  lens = 0;
  camPos = new THREE.Vector3();
  time = 0;
  private uTime = { value: 0 };
  // ---- GPU droplets
  private readonly ND = 16384;
  private dA: Float32Array; // x y z t0
  private dB: Float32Array; // vx vy vz ±tEnd
  private dC: Float32Array; // size shade drag stretch
  private dI = 0;
  private lastDrop = -9;
  /** droplet traces allowed this frame; overflow is queued and traced over the next frames */
  private traceBudget = 450;
  private deferred: number[] = [];
  private dq = 0;
  private nearX = 1e9;
  private nearZ = 1e9;
  private dLo = Infinity;
  private dHi = -1;
  private dropGeo: THREE.InstancedBufferGeometry;
  // ---- hit bursts
  private readonly NB = 384;
  private bA!: Float32Array; // x y z t0
  private bB!: Float32Array; // dir xyz, size
  private bC!: Float32Array; // seed life shade -
  private bI = 0;
  private bLo = Infinity;
  private bHi = -1;
  private burstGeo!: THREE.InstancedBufferGeometry;
  // ---- mist
  private readonly NM = 900;
  private mPos: Float32Array;
  private mVel: Float32Array;
  private mLife: Float32Array;
  private mLife0: Float32Array;
  private mSize: Float32Array;
  private mSize0: Float32Array;
  private mAlpha: Float32Array;
  private mA0: Float32Array;
  private mCol: Float32Array;
  private mI = 0;
  private mist: THREE.Points;
  private mMat: THREE.ShaderMaterial;
  // ---- stains
  private readonly NS = 6144;
  private sA: Float32Array;
  private sB: Float32Array;
  private sC: Float32Array;
  private sD: Float32Array;
  private sE: Float32Array;
  private sI = 0;
  private sLo = Infinity;
  private sHi = -1;
  private stainGeo: THREE.InstancedBufferGeometry;
  private budget = 60;
  private pending: Landing[] = [];
  private trees: Tree[] = [];
  private near: number[] = [];
  private hit: Landing = { t: 0, type: 0, x: 0, y: 0, z: 0, nx: 0, nz: 0, vx: 0, vy: 0, vz: 0, size: 0, shade: 1, ref: -1 };
  // ---- gore
  private readonly NG = 320;
  private gore: THREE.InstancedMesh;
  private gPos: Float32Array;
  private gVel: Float32Array;
  private gRot: Float32Array;
  private gSpin: Float32Array;
  private gScale: Float32Array;
  private gLife: Float32Array;
  private gRest: Uint8Array;
  private gI = 0;
  private gDirty = false;
  stats = { drops: 0, stains: 0 };
  /** 4 m grid of the boxes / ramps overlapping each cell (fast exact height queries for droplet traces) */
  private grid: number[][] = [];

  constructor(scene: THREE.Scene, terrain: Terrain) {
    this.terrain = terrain;
    for (let i = 0; i < GN * GN; i++) this.grid.push([]);
    const mark = (x0: number, x1: number, z0: number, z1: number, id: number) => {
      for (let gx = Math.max(0, Math.floor((x0 + GO) / GS)); gx <= Math.min(GN - 1, Math.floor((x1 + GO) / GS)); gx++)
        for (let gz = Math.max(0, Math.floor((z0 + GO) / GS)); gz <= Math.min(GN - 1, Math.floor((z1 + GO) / GS)); gz++) this.grid[gx * GN + gz].push(id);
    };
    terrain.boxes.forEach((b, i) => mark(b.x0, b.x1, b.z0, b.z1, i));
    terrain.ramps.forEach((r, j) => mark(r.x0, r.x1, r.z0, r.z1, -(j + 1)));
    // trunk shapes exactly as the environment builds them (octagonal, tapered, rotated)
    terrain.pillars.forEach((p, i) => {
      const s = (p.r / 0.34) * (0.95 + ((i * 37) % 10) * 0.04);
      const sy = s * (0.9 + ((i * 13) % 7) * 0.05);
      const yb = terrain.base(p.x, p.z) - 0.1;
      this.trees.push({ x: p.x, z: p.z, yb, top: yb + 4.6 * sy, r0: 0.34 * s, taper: (0.14 * s) / (5 * sy), rot: i * 1.7 });
    });

    // ------------------------------------------------------------ droplets
    this.dA = new Float32Array(this.ND * 4);
    this.dB = new Float32Array(this.ND * 4);
    this.dC = new Float32Array(this.ND * 4);
    for (let i = 0; i < this.ND; i++) this.dA[i * 4 + 3] = -1e6; // dead
    // billboard quad (splat sprite) — positions solved analytically on the GPU
    const quad = new THREE.BufferGeometry();
    quad.setAttribute('position', new THREE.Float32BufferAttribute([-0.5, -0.5, 0, 0.5, -0.5, 0, 0.5, 0.5, 0, -0.5, 0.5, 0], 3));
    quad.setAttribute('normal', new THREE.Float32BufferAttribute([0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1], 3));
    quad.setIndex([0, 1, 2, 0, 2, 3]);
    const satlas = splatAtlas();
    const dg = new THREE.InstancedBufferGeometry();
    dg.index = quad.index;
    dg.setAttribute('position', quad.attributes.position);
    dg.setAttribute('normal', quad.attributes.normal);
    dg.setAttribute('aDA', new THREE.InstancedBufferAttribute(this.dA, 4).setUsage(THREE.DynamicDrawUsage));
    dg.setAttribute('aDB', new THREE.InstancedBufferAttribute(this.dB, 4).setUsage(THREE.DynamicDrawUsage));
    dg.setAttribute('aDC', new THREE.InstancedBufferAttribute(this.dC, 4).setUsage(THREE.DynamicDrawUsage));
    dg.instanceCount = 0; // grows with use: idle pools cost nothing
    this.dropGeo = dg;
    const BILL = `
      vec3 toCam = normalize(cameraPosition - bP);
      vec3 refU = abs(toCam.y) > 0.98 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
      vec3 camR = normalize(cross(refU, toCam));
      vec3 camU = cross(toCam, camR);
      vec3 ax1 = camR * cos(bAng) + camU * sin(bAng);
      float st = 1.0;
      vec3 vs = bVel - toCam * dot(bVel, toCam);
      float vl = length(vs);
      if (vl > 0.5) { float w = smoothstep(0.5, 3.5, vl); ax1 = normalize(mix(ax1, vs / vl, w)); st = 1.0 + min(2.4, vl * 0.14) * w; }
      vec3 ax2 = normalize(cross(toCam, ax1));
      bA1 = ax1 * bSize * st; bA2 = ax2 * bSize;
      objectNormal = normalize(toCam + (ax1 * position.x + ax2 * position.y) * 0.9);`;
    const dm = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.28, metalness: 0, alphaTest: 0.5, side: THREE.DoubleSide });
    dm.alphaToCoverage = true;
    dm.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = this.uTime;
      sh.uniforms.uSplat = { value: satlas };
      sh.vertexShader = sh.vertexShader
        .replace('#include <common>', '#include <common>\nattribute vec4 aDA; attribute vec4 aDB; attribute vec4 aDC; uniform float uTime; varying vec2 vDUv; varying float vDS; varying float vDCell;\nvec3 bP; vec3 bVel; vec3 bA1; vec3 bA2; float bAng; float bSize;')
        .replace(
          '#include <beginnormal_vertex>',
          `#include <beginnormal_vertex>
          {
            float t = uTime - aDA.w;
            float tEnd = abs(aDB.w);
            float alive = step(0.0, t) * step(t, tEnd);
            t = clamp(t, 0.0, tEnd);
            float k = aDC.z;
            float e = exp(-k * t);
            float f1 = (1.0 - e) / k;
            bP = aDA.xyz + aDB.xyz * f1 - vec3(0.0, 9.8, 0.0) * (t - f1) / k;
            bVel = aDB.xyz * e - vec3(0.0, 9.8, 0.0) * f1;
            float fade = aDB.w < 0.0 ? clamp((tEnd - t) / 0.18, 0.0, 1.0) : 1.0;
            bSize = aDC.x * 4.6 * alive * fade;
            bAng = aDC.w * 6.2831853;
            ${BILL}
            vDUv = position.xy + 0.5;
            vDS = aDC.y;
            vDCell = floor(fract(aDC.w * 7.13) * 11.99);
          }`,
        )
        .replace('#include <begin_vertex>', 'vec3 transformed = bP + bA1 * position.x + bA2 * position.y;');
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', '#include <common>\nuniform sampler2D uSplat; varying vec2 vDUv; varying float vDS; varying float vDCell;')
        .replace(
          '#include <color_fragment>',
          `#include <color_fragment>
          vec2 cuv = (vec2(mod(vDCell, 4.0), 3.0 - floor(vDCell / 4.0)) + clamp(vDUv, 0.01, 0.99)) * 0.25;
          diffuseColor.rgb = vec3(0.52, 0.012, 0.02) * vDS;
          diffuseColor.a = texture2D(uSplat, cuv).a;`,
        )
        .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\nif (dot(normal, vViewPosition) < 0.0) normal = -normal;');
    };
    const drops = new THREE.Mesh(dg, dm);
    drops.frustumCulled = false;
    drops.castShadow = false;
    drops.renderOrder = 3;
    scene.add(drops);

    // hit bursts: a splat that blooms open at the wound and erodes into droplets
    this.bA = new Float32Array(this.NB * 4);
    this.bB = new Float32Array(this.NB * 4);
    this.bC = new Float32Array(this.NB * 4);
    for (let i = 0; i < this.NB; i++) this.bA[i * 4 + 3] = -1e6;
    const bg = new THREE.InstancedBufferGeometry();
    bg.index = quad.index;
    bg.setAttribute('position', quad.attributes.position);
    bg.setAttribute('normal', quad.attributes.normal);
    bg.setAttribute('aBA', new THREE.InstancedBufferAttribute(this.bA, 4).setUsage(THREE.DynamicDrawUsage));
    bg.setAttribute('aBB', new THREE.InstancedBufferAttribute(this.bB, 4).setUsage(THREE.DynamicDrawUsage));
    bg.setAttribute('aBC', new THREE.InstancedBufferAttribute(this.bC, 4).setUsage(THREE.DynamicDrawUsage));
    bg.instanceCount = 0;
    this.burstGeo = bg;
    const bm = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.3, metalness: 0, alphaTest: 0.5, side: THREE.DoubleSide });
    bm.alphaToCoverage = true;
    bm.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = this.uTime;
      sh.uniforms.uSplat = { value: satlas };
      sh.vertexShader = sh.vertexShader
        .replace('#include <common>', '#include <common>\nattribute vec4 aBA; attribute vec4 aBB; attribute vec4 aBC; uniform float uTime; varying vec2 vDUv; varying float vBK; varying float vBCell; varying float vBS;\nvec3 bP; vec3 bVel; vec3 bA1; vec3 bA2; float bAng; float bSize;')
        .replace(
          '#include <beginnormal_vertex>',
          `#include <beginnormal_vertex>
          {
            float age = uTime - aBA.w;
            float life = aBC.y;
            float alive = step(0.0, age) * step(age, life);
            age = clamp(age, 0.0, life);
            float grow = 1.0 - exp(-age * 24.0);
            bP = aBA.xyz + aBB.xyz * (0.12 * grow + age * 0.9) - vec3(0.0, 2.2, 0.0) * age * age;
            bVel = vec3(0.0);
            bSize = aBB.w * (0.3 + 0.7 * grow) * (1.0 + 0.4 * age / life) * alive;
            bAng = aBC.x * 6.2831853;
            ${BILL}
            vDUv = position.xy + 0.5;
            vBK = age / life;
            vBCell = 12.0 + floor(fract(aBC.x * 5.37) * 3.99);
            vBS = aBC.z;
          }`,
        )
        .replace('#include <begin_vertex>', 'vec3 transformed = bP + bA1 * position.x + bA2 * position.y;');
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', '#include <common>\nuniform sampler2D uSplat; varying vec2 vDUv; varying float vBK; varying float vBCell; varying float vBS;')
        .replace(
          '#include <color_fragment>',
          `#include <color_fragment>
          vec2 cuv = (vec2(mod(vBCell, 4.0), 3.0 - floor(vBCell / 4.0)) + clamp(vDUv, 0.01, 0.99)) * 0.25;
          float a = texture2D(uSplat, cuv).a;
          float thr = mix(0.5, 0.985, pow(vBK, 1.35));
          diffuseColor.rgb = mix(vec3(0.66, 0.02, 0.03), vec3(0.34, 0.01, 0.015), vBK) * vBS;
          diffuseColor.a = 0.5 + (a - thr);`,
        )
        .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\nif (dot(normal, vViewPosition) < 0.0) normal = -normal;');
    };
    const bursts = new THREE.Mesh(bg, bm);
    bursts.frustumCulled = false;
    bursts.renderOrder = 3;
    scene.add(bursts);

    // ---------------------------------------------------------------- mist
    this.mPos = new Float32Array(this.NM * 3).fill(-9999);
    this.mVel = new Float32Array(this.NM * 3);
    this.mLife = new Float32Array(this.NM);
    this.mLife0 = new Float32Array(this.NM).fill(1);
    this.mSize = new Float32Array(this.NM);
    this.mSize0 = new Float32Array(this.NM);
    this.mAlpha = new Float32Array(this.NM);
    this.mA0 = new Float32Array(this.NM);
    this.mCol = new Float32Array(this.NM * 3);
    const mg = new THREE.BufferGeometry();
    mg.setAttribute('position', new THREE.BufferAttribute(this.mPos, 3).setUsage(THREE.DynamicDrawUsage));
    mg.setAttribute('aSize', new THREE.BufferAttribute(this.mSize, 1).setUsage(THREE.DynamicDrawUsage));
    mg.setAttribute('aAlpha', new THREE.BufferAttribute(this.mAlpha, 1).setUsage(THREE.DynamicDrawUsage));
    mg.setAttribute('color', new THREE.BufferAttribute(this.mCol, 3).setUsage(THREE.DynamicDrawUsage));
    this.mMat = new THREE.ShaderMaterial({
      uniforms: { uScale: { value: 600 }, map: { value: cloudTexture() } },
      transparent: true,
      depthWrite: false,
      vertexShader: `attribute float aSize; attribute float aAlpha; attribute vec3 color; uniform float uScale;
        varying float vA; varying vec3 vC; varying float vR;
        void main(){ vec4 mv = modelViewMatrix*vec4(position,1.0); gl_Position = projectionMatrix*mv;
          gl_PointSize = aSize*uScale/max(0.05,-mv.z); vA=aAlpha; vC=color; vR = fract(position.x*13.7+position.z*7.1)*6.283; }`,
      fragmentShader: `uniform sampler2D map; varying float vA; varying vec3 vC; varying float vR;
        void main(){ vec2 c = gl_PointCoord-0.5; float s=sin(vR), co=cos(vR); c = vec2(c.x*co-c.y*s, c.x*s+c.y*co)+0.5;
          float a = texture2D(map, c).a; gl_FragColor = vec4(vC, a*vA*2.2); }`,
    });
    this.mist = new THREE.Points(mg, this.mMat);
    this.mist.frustumCulled = false;
    this.mist.renderOrder = 4;
    scene.add(this.mist);

    // -------------------------------------------------------------- stains
    this.sA = new Float32Array(this.NS * 4);
    this.sB = new Float32Array(this.NS * 4);
    this.sC = new Float32Array(this.NS * 4);
    this.sD = new Float32Array(this.NS * 4);
    this.sE = new Float32Array(this.NS * 4);
    const plane = new THREE.PlaneGeometry(1, 1, 8, 8);
    plane.rotateX(-Math.PI / 2);
    const sg = new THREE.InstancedBufferGeometry();
    sg.index = plane.index;
    sg.setAttribute('position', plane.attributes.position);
    sg.setAttribute('normal', plane.attributes.normal);
    for (const [n, arr] of [['sA', this.sA], ['sB', this.sB], ['sC', this.sC], ['sD', this.sD], ['sE', this.sE]] as const)
      sg.setAttribute(n, new THREE.InstancedBufferAttribute(arr, 4).setUsage(THREE.DynamicDrawUsage));
    sg.instanceCount = 0;
    this.stainGeo = sg;
    const atlas = stainAtlas();
    const sm = new THREE.MeshStandardMaterial({
      color: '#ffffff',
      roughness: 0.3,
      metalness: 0,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
      envMapIntensity: 0.45,
    });
    sm.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = this.uTime;
      sh.uniforms.uAtlas = { value: atlas };
      sh.vertexShader = sh.vertexShader
        .replace(
          '#include <common>',
          `#include <common>
          attribute vec4 sA; attribute vec4 sB; attribute vec4 sC; attribute vec4 sD; attribute vec4 sE;
          uniform float uTime;
          varying vec2 vSUv; varying vec4 vSClip; varying vec3 vSW; varying vec4 vSE; varying vec2 vSK; varying float vSTc;
          vec3 sPos;
          ${BASE_H}`,
        )
        .replace(
          '#include <beginnormal_vertex>',
          `#include <beginnormal_vertex>
          {
            vec2 l = position.xz;
            float age = max(0.0, uTime - sE.y);
            float g = sE.z > 0.0 ? (0.1 + 0.9 * (1.0 - exp(-age * sE.z))) : 1.0;
            float type = sB.z;
            vec2 sz = sB.xy * g;
            float cr = cos(sA.w), sr = sin(sA.w);
            vec2 lr = l * sz;
            vec2 rl = vec2(lr.x * cr - lr.y * sr, lr.x * sr + lr.y * cr);
            vec3 nrm = vec3(0.0, 1.0, 0.0);
            vSTc = 0.0;
            if (type < 0.5) {
              vec2 w = sA.xz + rl;
              sPos = vec3(w.x, baseH(w) + 0.013, w.y);
              float e = 0.06;
              float hx = baseH(w + vec2(e, 0.0)) - baseH(w - vec2(e, 0.0));
              float hz = baseH(w + vec2(0.0, e)) - baseH(w - vec2(0.0, e));
              nrm = normalize(vec3(-hx, 2.0 * e, -hz));
            } else if (type < 1.5) {
              sPos = vec3(sA.x + rl.x, sA.y, sA.z + rl.y);
            } else if (type < 2.5) {
              vec2 w = sA.xz + rl;
              sPos = vec3(w.x, sC.x * w.x + sC.y * w.y + sC.z + 0.01, w.y);
              nrm = normalize(vec3(-sC.x, 1.0, -sC.y));
            } else if (type < 3.5) {
              vec3 n = vec3(sC.x, 0.0, sC.y);
              vec3 tg = vec3(-n.z, 0.0, n.x);
              sPos = sA.xyz + n * 0.005 + tg * rl.x + vec3(0.0, rl.y, 0.0);
              nrm = n;
              vSTc = abs(n.x) > 0.5 ? sPos.z : sPos.x;
            } else {
              float ang0 = atan(sA.x - sC.x, sA.z - sC.y);
              float y = sA.y + rl.y;
              float R = max(0.04, sC.z - sC.w * (y - sD.x));
              float th = ang0 - rl.x / R;
              float seg = 0.7853982;
              float ph = th - sD.y;
              float fc = (floor(ph / seg) + 0.5) * seg;
              float rr = R * 0.9238795 / cos(ph - fc) + 0.006;
              sPos = vec3(sC.x + sin(th) * rr, y, sC.y + cos(th) * rr);
              nrm = vec3(sin(fc + sD.y), 0.0, cos(fc + sD.y));
            }
            // view-dependent depth bias: slide toward the camera along the view ray (no screen shift),
            // more with distance where depth precision drops — no z-fighting flicker on snow, tops or walls
            vec3 toCam = cameraPosition - sPos;
            float dc = length(toCam);
            sPos += toCam / max(dc, 1e-3) * min(0.08, 0.002 + dc * 0.0011);
            objectNormal = nrm;
            vSUv = l + 0.5;
            vSW = sPos;
            vSClip = sD;
            vSE = vec4(sE.x, age, sE.w, sB.w);
            vSK = vec2(type, fract(sA.w * 3.17 + sB.x * 11.3));
          }`,
        )
        .replace('#include <begin_vertex>', 'vec3 transformed = sPos;');
      sh.fragmentShader = sh.fragmentShader
        .replace(
          '#include <common>',
          `#include <common>
          uniform sampler2D uAtlas;
          varying vec2 vSUv; varying vec4 vSClip; varying vec3 vSW; varying vec4 vSE; varying vec2 vSK; varying float vSTc;
          float sMask; float sWet; float sMat;
          float sh2(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
          float sn(vec2 p){ vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
            return mix(mix(sh2(i), sh2(i + vec2(1.0, 0.0)), f.x), mix(sh2(i + vec2(0.0, 1.0)), sh2(i + vec2(1.0, 1.0)), f.x), f.y); }`,
        )
        .replace(
          '#include <color_fragment>',
          `#include <color_fragment>
          {
            float type = vSK.x;
            if (type > 0.5 && type < 2.5 && (vSW.x < vSClip.x || vSW.x > vSClip.y || vSW.z < vSClip.z || vSW.z > vSClip.w)) discard;
            if (type > 2.5 && type < 3.5 && (vSTc < vSClip.x || vSTc > vSClip.y || vSW.y > vSClip.w)) discard;
            float cell = vSE.w;
            vec2 cuv = (vec2(mod(cell, 4.0), 3.0 - floor(cell / 4.0)) + clamp(vSUv, 0.004, 0.996)) * 0.25;
            float a = texture2D(uAtlas, cuv).a;
            float vd = length(vSW - cameraPosition);
            float nk = 1.0 - smoothstep(12.0, 38.0, vd); // edge noise fades out before it can alias
            float n = sn(vSW.xz * 16.0 + vSW.y * 11.0 + vSK.y * 91.0);
            float n2 = 0.5;
            float e = a + (n - 0.5) * 0.26 * nk;
            float aa = fwidth(e) * 1.2 + 0.015;
            float m = smoothstep(0.42 - aa, 0.42 + aa, e);
            if (cell > 12.5 && cell < 14.5) {
              float reveal = clamp(vSE.y * 0.3 + 0.18, 0.0, 1.0);
              m *= smoothstep(1.0 - reveal - 0.06, 1.0 - reveal, vSUv.y);
            }
            float wet = exp(-vSE.y / 70.0);
            sMat = vSE.z;
            vec3 fresh = vec3(0.36, 0.012, 0.017);
            vec3 dried = vec3(0.12, 0.028, 0.022);
            vec3 col = mix(dried, fresh, wet) * abs(vSE.x) * (0.85 + 0.3 * n2);
            float alpha = m;
            if (sMat < 0.5) {
              // snow wicks the blood outward: soft pink halo around a darker soaked core
              float halo = smoothstep(0.06, 0.34, a + (n - 0.5) * 0.22 * nk) * (1.0 - m);
              col = mix(col, mix(vec3(0.5, 0.11, 0.12), vec3(0.6, 0.3, 0.3), 1.0 - wet), halo);
              alpha = max(m * 0.97, halo * (0.4 + 0.25 * wet));
            } else if (sMat > 1.5) {
              col *= 0.62;
              alpha *= 0.9;
            }
            if (vSE.x < 0.0) { col = vec3(0.028, 0.026, 0.024); alpha = m * 0.92; }
            diffuseColor.rgb = col;
            diffuseColor.a = alpha;
            sMask = m;
            sWet = vSE.x < 0.0 ? 0.0 : wet * m;
          }`,
        )
        .replace(
          '#include <roughnessmap_fragment>',
          `#include <roughnessmap_fragment>
          roughnessFactor = sMat < 0.5 ? mix(0.9, 0.5, sWet) : sMat < 1.5 ? mix(0.66, 0.16, sWet) : mix(0.94, 0.62, sWet);`,
        )
        .replace(
          '#include <normal_fragment_maps>',
          `#include <normal_fragment_maps>
          if (dot(normal, vViewPosition) < 0.0) normal = -normal;`,
        );
    };
    const stains = new THREE.Mesh(sg, sm);
    stains.frustumCulled = false;
    stains.receiveShadow = true;
    stains.renderOrder = 1;
    scene.add(stains);

    // ---------------------------------------------------------------- gore
    this.gPos = new Float32Array(this.NG * 3);
    this.gVel = new Float32Array(this.NG * 3);
    this.gRot = new Float32Array(this.NG * 3);
    this.gSpin = new Float32Array(this.NG * 3);
    this.gScale = new Float32Array(this.NG);
    this.gLife = new Float32Array(this.NG);
    this.gRest = new Uint8Array(this.NG);
    const gg = new THREE.IcosahedronGeometry(1, 1);
    {
      const p = gg.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const k = 0.75 + 0.35 * Math.sin(p.getX(i) * 7 + p.getY(i) * 5) * Math.cos(p.getZ(i) * 6);
        p.setXYZ(i, p.getX(i) * k, p.getY(i) * k * 0.7, p.getZ(i) * k * 0.85);
      }
      gg.computeVertexNormals();
    }
    this.gore = new THREE.InstancedMesh(gg, new THREE.MeshStandardMaterial({ roughness: 0.3, metalness: 0.05 }), this.NG);
    _m.makeScale(0, 0, 0);
    for (let i = 0; i < this.NG; i++) {
      this.gore.setMatrixAt(i, _m);
      this.gore.setColorAt(i, _c.setRGB(0.4, 0.02, 0.02));
    }
    this.gore.frustumCulled = false;
    this.gore.castShadow = true;
    scene.add(this.gore);
  }

  // =================================================================== trace
  private nearTrees(o: THREE.Vector3) {
    this.nearX = o.x;
    this.nearZ = o.z;
    this.near.length = 0;
    for (let i = 0; i < this.trees.length; i++) {
      const t = this.trees[i];
      if (Math.abs(t.x - o.x) < 9 && Math.abs(t.z - o.z) < 9) this.near.push(i);
    }
  }
  /** Exact same surface as Terrain.height (analytic snow + boxes + ramps), ~10× faster for traces. */
  private height(x: number, z: number) {
    let h = 0;
    const r2 = x * x + z * z;
    if (r2 > 361) {
      const t = Math.min(1, (Math.sqrt(r2) - 19) / 27);
      h = (1.5 * Math.sin(x * 0.06 + 0.4) * Math.cos(z * 0.055 + 1.1) + 0.6 * Math.sin(x * 0.13 + z * 0.11 + 2)) * (t * t * (3 - 2 * t));
    }
    const rx = x + 6;
    const rz = z + 9;
    const rr2 = rx * rx + rz * rz;
    if (rr2 < 36) {
      const t = Math.min(1, Math.max(0, (Math.sqrt(rr2) - 3.2) / 2.8));
      h += 0.1 * (1 - t * t * (3 - 2 * t)) * Math.sin(x * 2.2) * Math.sin(z * 2.0);
    }
    const mx = x - 10;
    const mz = z + 7;
    const md = (mx * mx + mz * mz) / 14;
    if (md < 8) h += 0.85 * Math.exp(-md);
    const gx = Math.floor((x + GO) / GS);
    const gz = Math.floor((z + GO) / GS);
    if (gx < 0 || gz < 0 || gx >= GN || gz >= GN) return h;
    const cell = this.grid[gx * GN + gz];
    for (let k = 0; k < cell.length; k++) {
      const id = cell[k];
      if (id >= 0) {
        const b = this.terrain.boxes[id];
        if (x >= b.x0 && x <= b.x1 && z >= b.z0 && z <= b.z1 && b.h > h) h = b.h;
      } else {
        const r = this.terrain.ramps[-id - 1];
        if (x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1) {
          const t = r.axis === 'x' ? (x - r.x0) / (r.x1 - r.x0) : (z - r.z0) / (r.z1 - r.z0);
          const rh = r.h0 + (r.h1 - r.h0) * t;
          if (rh > h) h = rh;
        }
      }
    }
    return h;
  }
  /** test hook: compare against Terrain.height */
  heightCheck(x: number, z: number) {
    return this.height(x, z) - this.terrain.height(x, z);
  }

  private boxAt(x: number, z: number, h: number): Box | null {
    for (const b of this.terrain.boxes) if (x >= b.x0 && x <= b.x1 && z >= b.z0 && z <= b.z1 && Math.abs(b.h - h) < 1e-5) return b;
    return null;
  }
  private rampAt(x: number, z: number, h: number): Ramp | null {
    for (const r of this.terrain.ramps) {
      if (x < r.x0 || x > r.x1 || z < r.z0 || z > r.z1) continue;
      const t = r.axis === 'x' ? (x - r.x0) / (r.x1 - r.x0) : (z - r.z0) / (r.z1 - r.z0);
      if (Math.abs(r.h0 + (r.h1 - r.h0) * t - h) < 1e-4) return r;
    }
    return null;
  }

  /**
   * Exact landing of a droplet launched from (p, v) with linear drag k:
   * marches the analytic trajectory against the scene, bisects the contact.
   * Fills this.hit (time relative to launch). Returns false if it never lands.
   */
  private trace(px: number, py: number, pz: number, vx: number, vy: number, vz: number, k: number, life: number, coarse: boolean) {
    const T = this.terrain;
    const H = this.hit;
    const dt = coarse ? 0.05 : 0.022;
    let x0 = px;
    let y0 = py;
    let z0 = pz;
    let h0 = this.height(px, pz);
    const at = (t: number) => {
      const e = Math.exp(-k * t);
      const f1 = (1 - e) / k;
      _p.set(px + vx * f1, py + vy * f1 - (9.8 * (t - f1)) / k, pz + vz * f1);
      return e;
    };
    if (py < h0 + 0.005) {
      H.t = 0.0001;
      H.type = GROUND;
      H.x = px;
      H.y = h0;
      H.z = pz;
      H.vx = vx;
      H.vy = vy;
      H.vz = vz;
      return true;
    }
    let t = 0;
    for (let s = 0; s < 140; s++) {
      t += dt;
      if (t > life) return false;
      at(t);
      const x = _p.x;
      const y = _p.y;
      const z = _p.z;
      // tree trunks
      for (const ti of this.near) {
        const tr = this.trees[ti];
        if (y < tr.yb || y > tr.top) continue;
        const R = tr.r0 - tr.taper * (y - tr.yb);
        const dx = x - tr.x;
        const dz = z - tr.z;
        if (dx * dx + dz * dz < R * R) {
          let a = t - dt;
          let b = t;
          for (let i = 0; i < 5; i++) {
            const mm = (a + b) * 0.5;
            at(mm);
            const rr = tr.r0 - tr.taper * (_p.y - tr.yb);
            if ((_p.x - tr.x) ** 2 + (_p.z - tr.z) ** 2 < rr * rr) b = mm;
            else a = mm;
          }
          const e = at(b);
          H.t = b;
          H.type = TRUNK;
          H.x = _p.x;
          H.y = _p.y;
          H.z = _p.z;
          H.ref = ti;
          H.vx = vx * e;
          H.vz = vz * e;
          H.vy = vy * e - (9.8 * (1 - e)) / k;
          return true;
        }
      }
      const h = this.height(x, z);
      if (y <= h) {
        if (h - h0 > 0.1 && y0 < h - 0.01) {
          const bx = this.boxAt(x, z, h);
          if (bx) {
            // entered the box through a side face: slab test on the last step
            let best = -1;
            let nx = 0;
            let nz = 0;
            const ddx = x - x0;
            const ddz = z - z0;
            if (x0 < bx.x0 && ddx > 0) {
              const s1 = (bx.x0 - x0) / ddx;
              if (s1 > best) { best = s1; nx = -1; nz = 0; }
            }
            if (x0 > bx.x1 && ddx < 0) {
              const s1 = (bx.x1 - x0) / ddx;
              if (s1 > best) { best = s1; nx = 1; nz = 0; }
            }
            if (z0 < bx.z0 && ddz > 0) {
              const s1 = (bx.z0 - z0) / ddz;
              if (s1 > best) { best = s1; nx = 0; nz = -1; }
            }
            if (z0 > bx.z1 && ddz < 0) {
              const s1 = (bx.z1 - z0) / ddz;
              if (s1 > best) { best = s1; nx = 0; nz = 1; }
            }
            if (best >= 0) {
              const tt = t - dt + dt * best;
              const e = at(tt);
              if (_p.y < bx.h - 0.01) {
                H.t = tt;
                H.type = WALL;
                H.x = nx !== 0 ? (nx < 0 ? bx.x0 : bx.x1) : _p.x;
                H.y = _p.y;
                H.z = nz !== 0 ? (nz < 0 ? bx.z0 : bx.z1) : _p.z;
                H.nx = nx;
                H.nz = nz;
                H.vx = vx * e;
                H.vz = vz * e;
                H.vy = vy * e - (9.8 * (1 - e)) / k;
                H.ref = T.boxes.indexOf(bx);
                return true;
              }
            }
          }
        }
        // top / ground contact: bisect height crossing
        let a = t - dt;
        let b = t;
        for (let i = 0; i < (coarse ? 2 : 5); i++) {
          const mm = (a + b) * 0.5;
          at(mm);
          if (_p.y <= this.height(_p.x, _p.z)) b = mm;
          else a = mm;
        }
        const e = at(b);
        H.t = b;
        H.type = GROUND;
        H.x = _p.x;
        H.y = this.height(_p.x, _p.z);
        H.z = _p.z;
        H.vx = vx * e;
        H.vz = vz * e;
        H.vy = vy * e - (9.8 * (1 - e)) / k;
        return true;
      }
      x0 = x;
      y0 = y;
      z0 = z;
      h0 = h;
    }
    return false;
  }

  // ================================================================ droplets
  private drop(x: number, y: number, z: number, vx: number, vy: number, vz: number, size: number, shade: number, stain: number) {
    if (this.traceBudget <= 0) {
      if (this.deferred.length < 120000) this.deferred.push(x, y, z, vx, vy, vz, size, shade, stain, this.time);
      return;
    }
    this.traceBudget--;
    this.emitDrop(x, y, z, vx, vy, vz, size, shade, stain, this.time);
  }

  /** Trace a droplet's landing and hand it to the GPU (t0 = original launch time, so queued drops stay in sync). */
  private emitDrop(x: number, y: number, z: number, vx: number, vy: number, vz: number, size: number, shade: number, stain: number, t0: number) {
    if (Math.abs(x - this.nearX) + Math.abs(z - this.nearZ) > 3) this.nearTrees(_tp.set(x, y, z));
    const i = this.dI;
    this.dI = (this.dI + 1) % this.ND;
    if (i + 1 > this.dropGeo.instanceCount) this.dropGeo.instanceCount = i + 1;
    this.lastDrop = this.time;
    if (i < this.dLo) this.dLo = i;
    if (i > this.dHi) this.dHi = i;
    if (this.dI === 0) {
      this.dLo = 0;
      this.dHi = this.ND - 1;
    }
    // small drops brake hard (mist-like), big drops fly true
    const k = Math.min(2.6, Math.max(0.35, 0.0075 / Math.max(size, 0.003)));
    const life = 2.6;
    const decal = Math.random() < stain;
    const landed = this.trace(x, y, z, vx, vy, vz, k, life, !decal);
    const tEnd = landed ? this.hit.t : life;
    const j = i * 4;
    this.dA[j] = x;
    this.dA[j + 1] = y;
    this.dA[j + 2] = z;
    this.dA[j + 3] = t0;
    this.dB[j] = vx;
    this.dB[j + 1] = vy;
    this.dB[j + 2] = vz;
    this.dB[j + 3] = landed ? tEnd : -tEnd;
    this.dC[j] = size;
    this.dC[j + 1] = shade;
    this.dC[j + 2] = k;
    this.dC[j + 3] = Math.random();
    if (landed && decal && this.pending.length < 6000) {
      const H = this.hit;
      this.pending.push({ ...H, t: t0 + H.t, size: size * rnd(11, 22), shade });
    }
  }

  private lensHit(o: THREE.Vector3, amount: number) {
    const d = o.distanceTo(this.camPos);
    if (d < 4.5) this.lens = Math.min(1, this.lens + amount * (1 - d / 4.5));
  }

  /** Cone of liquid droplets (log-normal sizes, optional emitter velocity). */
  spray(o: THREE.Vector3, dir: THREE.Vector3, n: number, speed: number, spread: number, size = 1, inherit: THREE.Vector3 = ZERO, stain = 0.42) {
    this.nearTrees(o);
    for (let k = 0; k < n; k++) {
      cone(dir, spread, _d);
      const v = speed * rnd(0.3, 1.15);
      const sz = size * 0.0095 * Math.exp(gauss() * 0.42) * (Math.random() < 0.07 ? 2 : 1);
      this.drop(
        o.x + rnd(-0.015, 0.015), o.y + rnd(-0.015, 0.015), o.z + rnd(-0.015, 0.015),
        _d.x * v + inherit.x, _d.y * v + inherit.y, _d.z * v + inherit.z,
        sz, rnd(0.55, 1), stain,
      );
    }
  }

  /** Filaments: droplets released in tight chains along a few sub-directions (organic, never a uniform cone). */
  tendrils(o: THREE.Vector3, dir: THREE.Vector3, count: number, per: number, speed: number, spread: number, inherit: THREE.Vector3 = ZERO) {
    this.nearTrees(o);
    const sub = new THREE.Vector3();
    for (let c = 0; c < count; c++) {
      cone(dir, spread, sub);
      const base = speed * rnd(0.6, 1.1);
      for (let k = 0; k < per; k++) {
        cone(sub, 0.035, _d);
        const v = base * (1 - (k / per) * 0.55) * rnd(0.95, 1.05);
        this.drop(o.x, o.y, o.z, _d.x * v + inherit.x, _d.y * v + inherit.y, _d.z * v + inherit.z, rnd(0.005, 0.011) * (k === 0 ? 1.7 : 1), rnd(0.5, 0.85), 0.3);
      }
    }
  }

  /** A coherent jet (arterial spurt / pouring stump). */
  stream(o: THREE.Vector3, dir: THREE.Vector3, n: number, speed: number, inherit: THREE.Vector3 = ZERO) {
    this.nearTrees(o);
    for (let k = 0; k < n; k++) {
      cone(dir, 0.07, _d);
      const v = speed * rnd(0.85, 1.05);
      const back = rnd(0, 0.03);
      this.drop(o.x - _d.x * back, o.y - _d.y * back, o.z - _d.z * back, _d.x * v + inherit.x, _d.y * v + inherit.y, _d.z * v + inherit.z, rnd(0.007, 0.012), rnd(0.5, 0.75), 0.34);
    }
  }

  /** Slow drips from an open wound (follows the moving body via `o`). */
  drip(o: THREE.Vector3, n = 1, inherit: THREE.Vector3 = ZERO) {
    this.nearTrees(o);
    for (let k = 0; k < n; k++) this.drop(o.x, o.y - 0.01, o.z, rnd(-0.15, 0.15) + inherit.x * 0.5, rnd(-0.3, 0) + inherit.y * 0.5, rnd(-0.15, 0.15) + inherit.z * 0.5, rnd(0.008, 0.016), rnd(0.5, 0.8), 0.7);
  }

  /** Splat that blooms open at a wound and erodes into droplets (classic hit splat). */
  burst(o: THREE.Vector3, dir: THREE.Vector3, size: number, life = 0.42, shade = 1) {
    const i = this.bI;
    this.bI = (this.bI + 1) % this.NB;
    if (i < this.bLo) this.bLo = i;
    if (i > this.bHi) this.bHi = i;
    if (this.bI === 0) {
      this.bLo = 0;
      this.bHi = this.NB - 1;
    }
    if (i + 1 > this.burstGeo.instanceCount) this.burstGeo.instanceCount = i + 1;
    const j = i * 4;
    this.bA[j] = o.x;
    this.bA[j + 1] = o.y;
    this.bA[j + 2] = o.z;
    this.bA[j + 3] = this.time;
    this.bB[j] = dir.x;
    this.bB[j + 1] = dir.y;
    this.bB[j + 2] = dir.z;
    this.bB[j + 3] = size * rnd(0.85, 1.2);
    this.bC[j] = Math.random();
    this.bC[j + 1] = life * rnd(0.85, 1.15);
    this.bC[j + 2] = shade * rnd(0.8, 1.05);
  }

  puffs(o: THREE.Vector3, n: number, size: number, r = 0.35, g = 0.02, b = 0.02, alpha = 0.55, life = 0.6, vel?: THREE.Vector3) {
    for (let k = 0; k < n; k++) {
      const i = this.mI;
      this.mI = (this.mI + 1) % this.NM;
      this.mPos[i * 3] = o.x + rnd(-0.05, 0.05);
      this.mPos[i * 3 + 1] = o.y + rnd(-0.05, 0.05);
      this.mPos[i * 3 + 2] = o.z + rnd(-0.05, 0.05);
      this.mVel[i * 3] = (vel ? vel.x : 0) + rnd(-0.4, 0.4);
      this.mVel[i * 3 + 1] = (vel ? vel.y : 0) + rnd(-0.1, 0.5);
      this.mVel[i * 3 + 2] = (vel ? vel.z : 0) + rnd(-0.4, 0.4);
      this.mLife[i] = this.mLife0[i] = life * rnd(0.7, 1.3);
      this.mSize0[i] = size * rnd(0.6, 1.3);
      this.mSize[i] = this.mSize0[i];
      this.mA0[i] = alpha * rnd(0.6, 1);
      this.mAlpha[i] = this.mA0[i];
      this.mCol[i * 3] = r;
      this.mCol[i * 3 + 1] = g;
      this.mCol[i * 3 + 2] = b;
    }
  }

  // ================================================================== stains
  private stain(type: number, x: number, y: number, z: number, rot: number, sx: number, sz: number, cell: number, shade: number, grow: number, mat: number, c: number[], clip: number[]) {
    const i = this.sI;
    this.sI = (this.sI + 1) % this.NS;
    if (i < this.sLo) this.sLo = i;
    if (i > this.sHi) this.sHi = i;
    if (this.sI === 0) {
      this.sLo = 0;
      this.sHi = this.NS - 1;
    }
    const j = i * 4;
    this.sA.set([x, y, z, rot], j);
    this.sB.set([sx, sz, type, cell], j);
    this.sC.set(c, j);
    this.sD.set(clip, j);
    this.sE.set([shade, this.time, grow, mat], j);
    this.stainGeo.instanceCount = Math.max(this.stainGeo.instanceCount, i + 1);
  }

  /** Place a stain at a surface contact (ground / top / ramp / wall / trunk). */
  private place(L: Landing, size: number, shade: number, grow = 0, cellHint = -1) {
    const T = this.terrain;
    const hs = Math.hypot(L.vx, L.vz);
    const fast = hs > 1.6 && grow === 0;
    if (L.type === WALL) {
      const runs = Math.random() < 0.45;
      const cell = runs ? 13 + ((Math.random() * 2) | 0) : fast ? 6 + ((Math.random() * 4) | 0) : (Math.random() * 6) | 0;
      // streak along the tangential + vertical travel on the wall
      const tv = L.nx !== 0 ? L.vz * -L.nx : L.vx * L.nz;
      const rot = runs ? 0 : fast ? Math.atan2(tv, -L.vy) : Math.random() * 6.28;
      const b = T.boxes[L.ref];
      const clip = L.nx !== 0 ? [b.z0, b.z1, -50, b.h] : [b.x0, b.x1, -50, b.h];
      const len = runs ? size * rnd(1.6, 2.6) : fast ? size * (1 + Math.min(2.5, hs * 0.3)) : size;
      const yc = runs ? L.y - len * 0.32 : L.y;
      this.stain(WALL, L.x, yc, L.z, rot, size * (runs ? 0.9 : fast ? 0.6 : 1), len, cell, shade, 0, HARD, [L.nx, L.nz, 0, 0], clip);
      return;
    }
    if (L.type === TRUNK) {
      const tr = this.trees[L.ref];
      const runs = Math.random() < 0.35;
      const s = Math.min(size, tr.r0 * 1.6);
      this.stain(TRUNK, L.x, L.y - (runs ? s * 0.5 : 0), L.z, 0, s * 0.8, runs ? s * 2.2 : s, runs ? 13 + ((Math.random() * 2) | 0) : (Math.random() * 6) | 0, shade * 0.9, 0, BARK, [tr.x, tr.z, tr.r0, tr.taper], [tr.yb, tr.rot, 0, 0]);
      return;
    }
    // horizontal-ish contact: classify the surface at the point
    const h = T.height(L.x, L.z);
    const cell = cellHint >= 0 ? cellHint : grow > 0 ? 10 + ((Math.random() * 3) | 0) : fast ? 6 + ((Math.random() * 4) | 0) : (Math.random() * 6) | 0;
    let rot = Math.random() * Math.PI * 2;
    let len = size * rnd(0.85, 1.15);
    let wid = size;
    let cx = L.x;
    let cz = L.z;
    if (fast) {
      const dx = L.vx / hs;
      const dz = L.vz / hs;
      rot = Math.atan2(dx, -dz);
      len = size * (1 + Math.min(3, hs * 0.35));
      wid = size * 0.6;
      cx += dx * len * 0.3;
      cz += dz * len * 0.3;
    }
    const base = T.base(L.x, L.z);
    if (h - base > 0.004) {
      const b = this.boxAt(L.x, L.z, h);
      if (b) {
        this.stain(TOP, cx, h + 0.006, cz, rot, wid, len, cell, shade, grow, SNOW, [0, 0, 0, 0], [b.x0, b.x1, b.z0, b.z1]);
        return;
      }
      const r = this.rampAt(L.x, L.z, h);
      if (r) {
        const a = r.axis === 'x' ? (r.h1 - r.h0) / (r.x1 - r.x0) : 0;
        const bb = r.axis === 'z' ? (r.h1 - r.h0) / (r.z1 - r.z0) : 0;
        const c = r.h0 - a * r.x0 - bb * r.z0;
        this.stain(RAMP, cx, h, cz, rot, wid, len, cell, shade, grow, SNOW, [a, bb, c, 0], [r.x0, r.x1, r.z0, r.z1]);
        return;
      }
    }
    this.stain(GROUND, cx, h, cz, rot, wid, len, cell, shade, grow, SNOW, [0, 0, 0, 0], [-1e4, 1e4, -1e4, 1e4]);
  }

  /** Splat on the ground (legacy API). Elongated along (vx,vz) when moving fast; grow > 0 spreads a pool. */
  decal(x: number, z: number, size: number, grow = 0, y?: number, vx = 0, vz = 0, shade = 1) {
    if (grow <= 0) {
      if (this.budget <= 0) return;
      this.budget--;
    }
    const L = this.hit;
    L.type = GROUND;
    L.x = x;
    L.z = z;
    L.y = y ?? this.terrain.height(x, z);
    L.vx = vx;
    L.vz = vz;
    L.vy = -1;
    this.place(L, grow > 0 ? size : size, shade, grow, grow <= 0 && Math.hypot(vx, vz) > 1.6 && shade < 0.85 ? 15 : -1);
  }

  /** Spatter against the nearest wall face (used by bouncing debris). */
  wallSplat(x: number, y: number, z: number, dx: number, dz: number, size: number) {
    const T = this.terrain;
    const l = Math.hypot(dx, dz) || 1;
    const px = x - (dx / l) * 0.25;
    const pz = z - (dz / l) * 0.25;
    const h = T.height(px, pz);
    const b = this.boxAt(px, pz, h);
    if (!b || y > b.h) return;
    const L = this.hit;
    const dl = [Math.abs(x - b.x0), Math.abs(x - b.x1), Math.abs(z - b.z0), Math.abs(z - b.z1)];
    const k = dl.indexOf(Math.min(...dl));
    L.type = WALL;
    L.nx = k === 0 ? -1 : k === 1 ? 1 : 0;
    L.nz = k === 2 ? -1 : k === 3 ? 1 : 0;
    L.x = k === 0 ? b.x0 : k === 1 ? b.x1 : x;
    L.z = k === 2 ? b.z0 : k === 3 ? b.z1 : z;
    L.y = y;
    L.vx = 0;
    L.vz = 0;
    L.vy = 0;
    L.ref = T.boxes.indexOf(b);
    this.place(L, size, 0.9);
  }

  /** Charred blast mark. */
  scorch(x: number, z: number, size: number) {
    const L = this.hit;
    L.type = GROUND;
    L.x = x;
    L.z = z;
    L.y = this.terrain.height(x, z);
    L.vx = L.vz = 0;
    L.vy = -1;
    this.place(L, size, -1, 0, 10 + ((Math.random() * 3) | 0));
  }

  chunks(o: THREE.Vector3, dir: THREE.Vector3, n: number, speed: number, bone = 0.2, burnt = false) {
    for (let k = 0; k < n; k++) {
      const i = this.gI;
      this.gI = (this.gI + 1) % this.NG;
      cone(dir, 0.9, _d);
      const v = speed * rnd(0.3, 1.1);
      this.gPos.set([o.x, o.y, o.z], i * 3);
      this.gVel.set([_d.x * v, _d.y * v + rnd(0.5, 2.5), _d.z * v], i * 3);
      this.gRot.set([rnd(0, 6), rnd(0, 6), rnd(0, 6)], i * 3);
      this.gSpin.set([rnd(-14, 14), rnd(-14, 14), rnd(-14, 14)], i * 3);
      this.gScale[i] = rnd(0.012, 0.04);
      this.gLife[i] = 40;
      this.gRest[i] = 0;
      if (Math.random() < bone) this.gore.setColorAt(i, _c.setRGB(0.85, 0.8, 0.68));
      else if (burnt) this.gore.setColorAt(i, _c.setRGB(rnd(0.05, 0.15), 0.03, 0.02));
      else this.gore.setColorAt(i, _c.setRGB(rnd(0.3, 0.55), rnd(0.01, 0.05), rnd(0.02, 0.05)));
    }
    if (this.gore.instanceColor) this.gore.instanceColor.needsUpdate = true;
    this.gDirty = true;
  }

  /**
   * Bullet wound. Light rounds: heavy back-spatter, a dense exit cone torn into
   * filaments, a pumping jet and a red mist puff. Heavy rounds: a violent
   * through-and-through plume that paints ground and walls metres behind the
   * target, a lingering blood haze, and a big splash on the lens up close.
   */
  impact(p: THREE.Vector3, dir: THREE.Vector3, power: number, head = false, inherit: THREE.Vector3 = ZERO, heavy = false) {
    this.budget = Math.min(this.budget + 30 + power * 18, heavy ? 340 : 230);
    _back.copy(dir).negate();
    this.spray(p, _back, 10 + power * 6, 1.9 + power * 0.7, 0.65, 0.95, inherit, 0.42);
    this.burst(p, _back, 0.13 + power * 0.03, 0.3, 0.9);
    if (heavy) {
      _ex.copy(dir).setY(dir.y * 0.6 + 0.08).normalize();
      // the exit wound blooms into a huge splat, a second one tears off along the plume
      this.burst(p, _ex, head ? 0.78 : 0.62, 0.55);
      _tp.copy(p).addScaledVector(_ex, 0.35);
      this.burst(_tp, _ex, 0.46, 0.5, 0.9);
      this.spray(p, _ex, head ? 240 : 200, 11, 0.28, 1.3, inherit, 0.56);
      this.spray(p, _ex, 100, 5.2, 0.72, 1.12, inherit, 0.5);
      this.tendrils(p, _ex, head ? 12 : 9, 14, 9.5, 0.34, inherit);
      this.stream(p, _ex, 36, 7.2, inherit);
      _d.copy(_ex).multiplyScalar(3.2);
      this.puffs(p, 14, head ? 0.9 : 0.72, 0.36, 0.012, 0.014, 0.6, 1.6, _d);
      _d.copy(_ex).multiplyScalar(0.7);
      this.puffs(p, 6, 0.5, 0.42, 0.02, 0.02, 0.45, 2.4, _d); // haze that hangs in the air
      this.lensHit(p, 0.75);
    } else {
      this.burst(p, dir, (head ? 0.34 : 0.24) + power * 0.04, 0.42);
      this.spray(p, dir, (head ? 60 : 38) + power * 22, 3.6 + power * 2, head ? 0.5 : 0.36, 1.2, inherit, 0.52);
      this.tendrils(p, dir, 4 + ((power * 2) | 0), 8, 3.9 + power * 1.2, 0.45, inherit);
      this.stream(p, dir, 8 + power * 4, 2.8 + power, inherit);
      _d.copy(dir).multiplyScalar(0.8 + power * 0.5);
      this.puffs(p, 3 + power, head ? 0.42 : 0.3, 0.36, 0.014, 0.014, 0.55, 0.9, _d);
      if (head) {
        // the skull vents upward
        _up2.set(dir.x * 0.3, 1, dir.z * 0.3).normalize();
        this.spray(p, _up2, 46, 2.8, 0.85, 1.12, inherit, 0.5);
      }
      this.lensHit(p, 0.34 * power);
    }
    this.spray(p, DOWN, 10, 0.6, 0.3, 1.5, inherit, 0.85);
  }

  explode(p: THREE.Vector3, dir: THREE.Vector3, inherit: THREE.Vector3 = ZERO) {
    this.budget = 340;
    _up2.copy(dir).multiplyScalar(0.6).add(_b.set(0, 0.6, 0)).normalize();
    const up = _up2.clone();
    this.burst(p, up, 0.95, 0.6);
    this.burst(p, dir, 0.6, 0.5, 0.9);
    this.spray(p, up, 260, 5.5, 1.1, 1.35, inherit, 0.45);
    this.spray(p, dir, 160, 8.5, 0.42, 1.25, inherit, 0.55);
    this.tendrils(p, up, 16, 12, 6.5, 0.9, inherit);
    this.puffs(p, 20, 0.7, 0.32, 0.014, 0.014, 0.66, 1.5, up.multiplyScalar(1.4));
    this.chunks(p, dir, 30, 4.8, 0.4);
    this.lensHit(p, 1);
  }

  sever(p: THREE.Vector3, dir: THREE.Vector3, inherit: THREE.Vector3 = ZERO) {
    this.budget = Math.min(this.budget + 70, 280);
    this.burst(p, dir, 0.5, 0.5);
    this.spray(p, dir, 110, 3.8, 0.8, 1.25, inherit, 0.5);
    this.tendrils(p, dir, 7, 10, 3.8, 0.7, inherit);
    this.stream(p, dir, 40, 3.2, inherit);
    this.puffs(p, 9, 0.4, 0.34, 0.02, 0.02, 0.58, 1.0);
    this.chunks(p, dir, 10, 3.2, 0.3);
    this.lensHit(p, 0.6);
  }

  snow(p: THREE.Vector3, n: number) {
    this.puffs(p, n, 0.5, 0.92, 0.94, 0.97, 0.45, 0.9);
  }

  clear() {
    for (let i = 0; i < this.ND; i++) this.dA[i * 4 + 3] = -1e6;
    this.dLo = 0;
    this.dHi = this.ND - 1;
    this.stainGeo.instanceCount = 0;
    this.sI = 0;
    this.pending.length = 0;
  }

  // ================================================================== update
  update(dt: number, cam: THREE.PerspectiveCamera, viewH: number) {
    this.time += dt;
    this.uTime.value = this.time;
    // big bursts: trace the queued droplets a slice per frame
    this.traceBudget = 450;
    const D = this.deferred;
    while (this.dq < D.length && this.traceBudget > 0) {
      const i = this.dq;
      this.dq += 10;
      if (this.time - D[i + 9] > 2.2) continue;
      this.traceBudget--;
      this.emitDrop(D[i], D[i + 1], D[i + 2], D[i + 3], D[i + 4], D[i + 5], D[i + 6], D[i + 7], D[i + 8], D[i + 9]);
    }
    if (this.dq >= D.length) {
      D.length = 0;
      this.dq = 0;
    }
    const scale = viewH / (2 * Math.tan(THREE.MathUtils.degToRad(cam.fov) / 2));
    this.mMat.uniforms.uScale.value = scale;
    const T = this.terrain;
    this.lens = Math.max(0, this.lens - dt * 0.35);

    // ---- landings due → stains (droplets already vanished on the GPU at that instant)
    for (let i = this.pending.length - 1; i >= 0; i--) {
      const L = this.pending[i];
      if (L.t > this.time) continue;
      this.pending[i] = this.pending[this.pending.length - 1];
      this.pending.pop();
      if (this.budget <= 0) continue;
      this.budget--;
      this.place(L, L.size, L.shade);
    }
    this.budget = Math.min(this.budget + dt * 110, 320);
    // every droplet is dead 2.6 s after the last spawn: rewind the pool so idle frames draw nothing
    if (this.time - this.lastDrop > 2.8 && this.dropGeo.instanceCount > 0) {
      this.dropGeo.instanceCount = 0;
      this.dI = 0;
    }

    // ---- upload only the dirty ranges of the GPU pools
    if (this.dHi >= 0) {
      for (const n of ['aDA', 'aDB', 'aDC']) {
        const a = this.dropGeo.getAttribute(n) as THREE.InstancedBufferAttribute;
        a.clearUpdateRanges();
        a.addUpdateRange(this.dLo * 4, (this.dHi - this.dLo + 1) * 4);
        a.needsUpdate = true;
      }
      this.dLo = Infinity;
      this.dHi = -1;
    }
    if (this.sHi >= 0) {
      for (const n of ['sA', 'sB', 'sC', 'sD', 'sE']) {
        const a = this.stainGeo.getAttribute(n) as THREE.InstancedBufferAttribute;
        a.clearUpdateRanges();
        a.addUpdateRange(this.sLo * 4, (this.sHi - this.sLo + 1) * 4);
        a.needsUpdate = true;
      }
      this.sLo = Infinity;
      this.sHi = -1;
    }
    if (this.bHi >= 0) {
      for (const n of ['aBA', 'aBB', 'aBC']) {
        const a = this.burstGeo.getAttribute(n) as THREE.InstancedBufferAttribute;
        a.clearUpdateRanges();
        a.addUpdateRange(this.bLo * 4, (this.bHi - this.bLo + 1) * 4);
        a.needsUpdate = true;
      }
      this.bLo = Infinity;
      this.bHi = -1;
    }
    this.stats.stains = this.stainGeo.instanceCount;

    // ---- mist
    const MP = this.mPos;
    const MV = this.mVel;
    for (let i = 0; i < this.NM; i++) {
      if (this.mLife[i] <= 0) continue;
      this.mLife[i] -= dt;
      const j = i * 3;
      if (this.mLife[i] <= 0) {
        MP[j + 1] = -9999;
        this.mAlpha[i] = 0;
        continue;
      }
      const k = 1 - this.mLife[i] / this.mLife0[i];
      MV[j] *= Math.exp(-3 * dt);
      MV[j + 1] = MV[j + 1] * Math.exp(-3 * dt) - 0.25 * dt;
      MV[j + 2] *= Math.exp(-3 * dt);
      MP[j] += MV[j] * dt;
      MP[j + 1] += MV[j + 1] * dt;
      MP[j + 2] += MV[j + 2] * dt;
      this.mSize[i] = this.mSize0[i] * (1 + k * 2);
      this.mAlpha[i] = this.mA0[i] * (1 - k) * (1 - k);
    }
    const mg = this.mist.geometry;
    mg.attributes.position.needsUpdate = true;
    mg.attributes.aSize.needsUpdate = true;
    mg.attributes.aAlpha.needsUpdate = true;
    mg.attributes.color.needsUpdate = true;

    // ---- gore bits
    let any = this.gDirty;
    this.gDirty = false;
    for (let i = 0; i < this.NG; i++) {
      if (this.gLife[i] <= 0 || this.gRest[i]) continue;
      any = true;
      const j = i * 3;
      const GP = this.gPos;
      const GV = this.gVel;
      GV[j + 1] -= 9.8 * dt;
      GP[j] += GV[j] * dt;
      GP[j + 1] += GV[j + 1] * dt;
      GP[j + 2] += GV[j + 2] * dt;
      this.gRot[j] += this.gSpin[j] * dt;
      this.gRot[j + 1] += this.gSpin[j + 1] * dt;
      this.gRot[j + 2] += this.gSpin[j + 2] * dt;
      const gh = T.height(GP[j], GP[j + 2]) + this.gScale[i] * 0.6;
      if (GP[j + 1] < gh) {
        GP[j + 1] = gh;
        if (GV[j + 1] < -1.5 && Math.random() < 0.6) this.decal(GP[j], GP[j + 2], rnd(0.08, 0.2), 0, undefined, GV[j], GV[j + 2]);
        GV[j + 1] *= -0.25;
        GV[j] *= 0.55;
        GV[j + 2] *= 0.55;
        this.gSpin[j] *= 0.5;
        this.gSpin[j + 1] *= 0.5;
        this.gSpin[j + 2] *= 0.5;
        if (Math.abs(GV[j + 1]) < 0.4 && Math.hypot(GV[j], GV[j + 2]) < 0.2) this.gRest[i] = 1;
      }
      _q.setFromEuler(_e.set(this.gRot[j], this.gRot[j + 1], this.gRot[j + 2]));
      const sc = this.gScale[i];
      _m.compose(_p.set(GP[j], GP[j + 1], GP[j + 2]), _q, _s.set(sc, sc, sc));
      this.gore.setMatrixAt(i, _m);
    }
    if (any) this.gore.instanceMatrix.needsUpdate = true;
  }
}
