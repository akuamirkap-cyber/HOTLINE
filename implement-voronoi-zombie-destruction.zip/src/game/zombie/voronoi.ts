import * as THREE from 'three';
import { mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

/* ---------------------------------------------------------------------------
 * PROCEDURAL VORONOI BODY FRACTURE
 *
 * Every body-part mesh of the zombie is cut into irregular 3D Voronoi cells:
 *   • seeds are scattered over the real surface with a varying exclusion radius
 *     (Poisson-like, so cell sizes vary and nothing looks like a grid)
 *   • every surface triangle is clipped against the bisector planes of its
 *     nearest seeds (Sutherland–Hodgman) → exact, straight polygon borders
 *   • each cell becomes a solid chunk: the outer skin/cloth patch, side walls
 *     along every cut edge and an inner "crater floor" offset toward the core
 *   • surfaces buried inside other primitives are dropped so craters never
 *     reveal overlapping geometry
 *
 * Vertex layout (non-indexed):
 *   position  rest position          normal / color   from the source mesh
 *   aInner    xyz = inner counterpart (where the vertex collapses when the cell
 *             is destroyed), w = cell + 64*layer + 256*neighbour
 *   layer: 0 outer skin, 1 wall (outer edge, moves with the plate),
 *          2 wall (inner edge, fixed), 3 inner floor (fixed)
 * ------------------------------------------------------------------------- */
export const MAX_CELLS = 64;

export interface Prim {
  triStart: number;
  triCount: number;
  box?: THREE.Box3;
  inside?: (x: number, y: number, z: number) => boolean;
}

export interface FracOptions {
  cells: number;
  seed: number;
  depth: number; // inner floor = this fraction of the way to the core
  maxDepth: number; // absolute cap (metres, scale 1)
  core: 'axis' | 'point';
  point?: [number, number, number];
}

export interface FracInfo {
  geo: THREE.BufferGeometry;
  cells: number;
  center: Float32Array;
  normal: Float32Array;
  size: Float32Array;
  depth: Float32Array;
  neighbors: number[][];
  cellTex: THREE.DataTexture;
  tris: number;
}

export function rng(seed: number) {
  let s = (seed * 2654435761) >>> 0 || 1;
  return () => {
    s ^= s << 13;
    s >>>= 0;
    s ^= s >>> 17;
    s ^= s << 5;
    s >>>= 0;
    return s / 4294967296;
  };
}

type V = number[]; // x y z nx ny nz r g b

function lerpV(a: V, b: V, t: number): V {
  const o = new Array(9);
  for (let i = 0; i < 9; i++) o[i] = a[i] + (b[i] - a[i]) * t;
  return o;
}

/** Keep the part of the polygon where dot(n,p) - d <= 0. */
function clip(poly: V[], nx: number, ny: number, nz: number, d: number): V[] {
  const out: V[] = [];
  const n = poly.length;
  for (let i = 0; i < n; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % n];
    const da = nx * a[0] + ny * a[1] + nz * a[2] - d;
    const db = nx * b[0] + ny * b[1] + nz * b[2] - d;
    if (da <= 0) out.push(a);
    if (da <= 0 !== db <= 0) out.push(lerpV(a, b, da / (da - db)));
  }
  return out;
}

export function fractureGeometry(src: THREE.BufferGeometry, prims: Prim[] | undefined, opt: FracOptions): FracInfo {
  const rand = rng(opt.seed * 7919 + 17);
  const pos = src.getAttribute('position') as THREE.BufferAttribute;
  const nor = src.getAttribute('normal') as THREE.BufferAttribute;
  const col = src.getAttribute('color') as THREE.BufferAttribute;
  const index = src.getIndex();
  const triN = (index ? index.count : pos.count) / 3;
  const vi = (t: number, k: number) => (index ? index.getX(t * 3 + k) : t * 3 + k);
  const vert = (i: number): V => [pos.getX(i), pos.getY(i), pos.getZ(i), nor.getX(i), nor.getY(i), nor.getZ(i), col.getX(i), col.getY(i), col.getZ(i)];

  // ---- core (inner floor target): principal axis through the centroid, or a point
  let cx = 0;
  let cy = 0;
  let cz = 0;
  for (let i = 0; i < pos.count; i++) {
    cx += pos.getX(i);
    cy += pos.getY(i);
    cz += pos.getZ(i);
  }
  cx /= pos.count;
  cy /= pos.count;
  cz /= pos.count;
  let ax = 0;
  let ay = 1;
  let az = 0;
  {
    let xx = 0, xy = 0, xz = 0, yy = 0, yz = 0, zz = 0;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i) - cx;
      const y = pos.getY(i) - cy;
      const z = pos.getZ(i) - cz;
      xx += x * x; xy += x * y; xz += x * z; yy += y * y; yz += y * z; zz += z * z;
    }
    for (let k = 0; k < 40; k++) {
      const nx = xx * ax + xy * ay + xz * az;
      const ny = xy * ax + yy * ay + yz * az;
      const nz = xz * ax + yz * ay + zz * az;
      const l = Math.hypot(nx, ny, nz) || 1;
      ax = nx / l;
      ay = ny / l;
      az = nz / l;
    }
  }
  let tmin = Infinity;
  let tmax = -Infinity;
  for (let i = 0; i < pos.count; i++) {
    const t = (pos.getX(i) - cx) * ax + (pos.getY(i) - cy) * ay + (pos.getZ(i) - cz) * az;
    if (t < tmin) tmin = t;
    if (t > tmax) tmax = t;
  }
  const pt = opt.point;
  const inner = (x: number, y: number, z: number): [number, number, number] => {
    let qx: number, qy: number, qz: number;
    if (opt.core === 'point' && pt) {
      qx = pt[0];
      qy = pt[1];
      qz = pt[2];
    } else {
      const t = Math.min(tmax * 0.72, Math.max(tmin * 0.72, (x - cx) * ax + (y - cy) * ay + (z - cz) * az));
      qx = cx + ax * t;
      qy = cy + ay * t;
      qz = cz + az * t;
    }
    const dx = qx - x;
    const dy = qy - y;
    const dz = qz - z;
    const L = Math.hypot(dx, dy, dz) || 1e-6;
    const f = Math.min(opt.depth, opt.maxDepth / L);
    return [x + dx * f, y + dy * f, z + dz * f];
  };

  // ---- drop surfaces buried inside other primitives (they would poke out of craters)
  const keep = new Uint8Array(triN).fill(1);
  if (prims) {
    const owner = new Int16Array(triN).fill(-1);
    prims.forEach((p, k) => {
      for (let t = p.triStart; t < p.triStart + p.triCount && t < triN; t++) owner[t] = k;
    });
    const buriedPt = (x: number, y: number, z: number, self: number) => {
      for (let m = 0; m < prims.length; m++) {
        if (m === self) continue;
        const p = prims[m];
        if (!p.inside) continue;
        if (p.box && (x < p.box.min.x || x > p.box.max.x || y < p.box.min.y || y > p.box.max.y || z < p.box.min.z || z > p.box.max.z)) continue;
        if (p.inside(x, y, z)) return true;
      }
      return false;
    };
    for (let t = 0; t < triN; t++) {
      const self = owner[t];
      let all = true;
      let mx = 0, my = 0, mz = 0;
      for (let k = 0; k < 3 && all; k++) {
        const i = vi(t, k);
        mx += pos.getX(i) / 3;
        my += pos.getY(i) / 3;
        mz += pos.getZ(i) / 3;
        if (!buriedPt(pos.getX(i), pos.getY(i), pos.getZ(i), self)) all = false;
      }
      if (all && buriedPt(mx, my, mz, self)) keep[t] = 0;
    }
  }

  // ---- seeds: area-weighted darts with a varying exclusion radius
  const area = new Float64Array(triN);
  let total = 0;
  const tmpA = new THREE.Vector3();
  const tmpB = new THREE.Vector3();
  const tmpC = new THREE.Vector3();
  for (let t = 0; t < triN; t++) {
    if (!keep[t]) continue;
    tmpA.fromBufferAttribute(pos, vi(t, 0));
    tmpB.fromBufferAttribute(pos, vi(t, 1)).sub(tmpA);
    tmpC.fromBufferAttribute(pos, vi(t, 2)).sub(tmpA);
    area[t] = tmpB.cross(tmpC).length() * 0.5;
    total += area[t];
  }
  const cum = new Float64Array(triN);
  let acc = 0;
  for (let t = 0; t < triN; t++) cum[t] = acc += area[t];
  const want = Math.min(opt.cells, MAX_CELLS);
  const spacing = Math.sqrt(total / want);
  const seeds: number[] = [];
  const srad: number[] = [];
  for (let a = 0; a < want * 80 && srad.length < want; a++) {
    const u = rand() * total;
    let lo = 0;
    let hi = triN - 1;
    while (lo < hi) {
      const m = (lo + hi) >> 1;
      if (cum[m] < u) lo = m + 1;
      else hi = m;
    }
    let b1 = rand();
    let b2 = rand();
    if (b1 + b2 > 1) {
      b1 = 1 - b1;
      b2 = 1 - b2;
    }
    const i0 = vi(lo, 0);
    const i1 = vi(lo, 1);
    const i2 = vi(lo, 2);
    const x = pos.getX(i0) + (pos.getX(i1) - pos.getX(i0)) * b1 + (pos.getX(i2) - pos.getX(i0)) * b2;
    const y = pos.getY(i0) + (pos.getY(i1) - pos.getY(i0)) * b1 + (pos.getY(i2) - pos.getY(i0)) * b2;
    const z = pos.getZ(i0) + (pos.getZ(i1) - pos.getZ(i0)) * b1 + (pos.getZ(i2) - pos.getZ(i0)) * b2;
    const r = spacing * (0.5 + 0.8 * rand());
    let ok = true;
    for (let j = 0; j < srad.length && ok; j++) {
      const d = Math.hypot(x - seeds[j * 3], y - seeds[j * 3 + 1], z - seeds[j * 3 + 2]);
      if (d < 0.5 * (r + srad[j]) * 0.9) ok = false;
    }
    if (!ok) continue;
    seeds.push(x, y, z);
    srad.push(r);
  }
  const S = srad.length;

  // ---- clip every surface triangle into its Voronoi cells
  const P: number[] = [];
  const N: number[] = [];
  const C: number[] = [];
  const I: number[] = [];
  const cArea = new Float64Array(S);
  const cCen = new Float64Array(S * 3);
  const cNor = new Float64Array(S * 3);
  const nbr: Set<number>[] = Array.from({ length: S }, () => new Set<number>());
  const push = (v: V, inn: [number, number, number], code: number, px = v[0], py = v[1], pz = v[2], nx = v[3], ny = v[4], nz = v[5]) => {
    P.push(px, py, pz);
    N.push(nx, ny, nz);
    C.push(v[6], v[7], v[8]);
    I.push(inn[0], inn[1], inn[2], code);
  };
  const K = Math.min(S, 9);
  const cand: number[] = [];
  const dist: number[] = new Array(S);
  const nearestOf = (x: number, y: number, z: number) => {
    let best = -1;
    let bd = Infinity;
    for (const j of cand) {
      const d = (x - seeds[j * 3]) ** 2 + (y - seeds[j * 3 + 1]) ** 2 + (z - seeds[j * 3 + 2]) ** 2;
      if (d < bd) {
        bd = d;
        best = j;
      }
    }
    return best;
  };
  const emit = (cell: number, poly: V[], cut: boolean) => {
    const n = poly.length;
    const inn = poly.map((v) => inner(v[0], v[1], v[2]));
    for (let k = 1; k < n - 1; k++) {
      const a = poly[0];
      const b = poly[k];
      const c = poly[k + 1];
      tmpB.set(b[0] - a[0], b[1] - a[1], b[2] - a[2]);
      tmpC.set(c[0] - a[0], c[1] - a[1], c[2] - a[2]);
      const ar = tmpB.cross(tmpC).length() * 0.5;
      cArea[cell] += ar;
      cCen[cell * 3] += ((a[0] + b[0] + c[0]) / 3) * ar;
      cCen[cell * 3 + 1] += ((a[1] + b[1] + c[1]) / 3) * ar;
      cCen[cell * 3 + 2] += ((a[2] + b[2] + c[2]) / 3) * ar;
      cNor[cell * 3] += (a[3] + b[3] + c[3]) * ar;
      cNor[cell * 3 + 1] += (a[4] + b[4] + c[4]) * ar;
      cNor[cell * 3 + 2] += (a[5] + b[5] + c[5]) * ar;
      // outer skin + inner crater floor (same winding: both face outward)
      for (const q of [0, k, k + 1]) push(poly[q], inn[q], cell + 64 * 0 + 256 * cell);
      for (const q of [0, k, k + 1]) push(poly[q], inn[q], cell + 64 * 3 + 256 * cell, inn[q][0], inn[q][1], inn[q][2]);
    }
    if (!cut) return;
    // side walls along every edge that lies on a bisector plane
    for (let k = 0; k < n; k++) {
      const a = poly[k];
      const b = poly[(k + 1) % n];
      for (const j of cand) {
        if (j === cell) continue;
        const nx = seeds[j * 3] - seeds[cell * 3];
        const ny = seeds[j * 3 + 1] - seeds[cell * 3 + 1];
        const nz = seeds[j * 3 + 2] - seeds[cell * 3 + 2];
        const nl = Math.hypot(nx, ny, nz) || 1;
        const d = (nx * (seeds[j * 3] + seeds[cell * 3]) + ny * (seeds[j * 3 + 1] + seeds[cell * 3 + 1]) + nz * (seeds[j * 3 + 2] + seeds[cell * 3 + 2])) * 0.5;
        const da = Math.abs(nx * a[0] + ny * a[1] + nz * a[2] - d) / nl;
        const db = Math.abs(nx * b[0] + ny * b[1] + nz * b[2] - d) / nl;
        if (da > 2e-6 || db > 2e-6) continue;
        const ia = inn[k];
        const ib = inn[(k + 1) % n];
        // wall normal must face the neighbour (out of this cell)
        const ex = b[0] - a[0], ey = b[1] - a[1], ez = b[2] - a[2];
        const fx = ia[0] - a[0], fy = ia[1] - a[1], fz = ia[2] - a[2];
        let wx = ey * fz - ez * fy;
        let wy = ez * fx - ex * fz;
        let wz = ex * fy - ey * fx;
        const flip = wx * nx + wy * ny + wz * nz < 0;
        const wl = Math.hypot(wx, wy, wz) || 1;
        wx /= wl;
        wy /= wl;
        wz /= wl;
        if (flip) {
          wx = -wx;
          wy = -wy;
          wz = -wz;
        }
        const A = flip ? b : a;
        const B = flip ? a : b;
        const IA = flip ? ib : ia;
        const IB = flip ? ia : ib;
        const code1 = cell + 64 * 1 + 256 * j;
        const code2 = cell + 64 * 2 + 256 * j;
        push(A, IA, code1, A[0], A[1], A[2], wx, wy, wz);
        push(B, IB, code1, B[0], B[1], B[2], wx, wy, wz);
        push(B, IB, code2, IB[0], IB[1], IB[2], wx, wy, wz);
        push(A, IA, code1, A[0], A[1], A[2], wx, wy, wz);
        push(B, IB, code2, IB[0], IB[1], IB[2], wx, wy, wz);
        push(A, IA, code2, IA[0], IA[1], IA[2], wx, wy, wz);
        nbr[cell].add(j);
        break;
      }
    }
  };

  for (let t = 0; t < triN; t++) {
    if (!keep[t] || area[t] < 1e-12) continue;
    const tri = [vert(vi(t, 0)), vert(vi(t, 1)), vert(vi(t, 2))];
    const mx = (tri[0][0] + tri[1][0] + tri[2][0]) / 3;
    const my = (tri[0][1] + tri[1][1] + tri[2][1]) / 3;
    const mz = (tri[0][2] + tri[1][2] + tri[2][2]) / 3;
    for (let j = 0; j < S; j++) dist[j] = (mx - seeds[j * 3]) ** 2 + (my - seeds[j * 3 + 1]) ** 2 + (mz - seeds[j * 3 + 2]) ** 2;
    cand.length = 0;
    for (let k = 0; k < K; k++) {
      let best = -1;
      let bd = Infinity;
      for (let j = 0; j < S; j++) if (dist[j] < bd && !cand.includes(j)) {
        bd = dist[j];
        best = j;
      }
      cand.push(best);
    }
    const o0 = nearestOf(tri[0][0], tri[0][1], tri[0][2]);
    const o1 = nearestOf(tri[1][0], tri[1][1], tri[1][2]);
    const o2 = nearestOf(tri[2][0], tri[2][1], tri[2][2]);
    if (o0 === o1 && o1 === o2 && o0 === cand[0]) {
      emit(o0, tri, false);
      continue;
    }
    for (const i of cand) {
      let poly: V[] = tri;
      for (const j of cand) {
        if (j === i) continue;
        const nx = seeds[j * 3] - seeds[i * 3];
        const ny = seeds[j * 3 + 1] - seeds[i * 3 + 1];
        const nz = seeds[j * 3 + 2] - seeds[i * 3 + 2];
        const d = (nx * (seeds[j * 3] + seeds[i * 3]) + ny * (seeds[j * 3 + 1] + seeds[i * 3 + 1]) + nz * (seeds[j * 3 + 2] + seeds[i * 3 + 2])) * 0.5;
        poly = clip(poly, nx, ny, nz, d);
        if (poly.length < 3) break;
      }
      if (poly.length >= 3) emit(i, poly, true);
    }
  }

  // ---- per-cell data
  const center = new Float32Array(MAX_CELLS * 3);
  const normal = new Float32Array(MAX_CELLS * 3);
  const size = new Float32Array(MAX_CELLS);
  const depth = new Float32Array(MAX_CELLS);
  const tex = new Float32Array(MAX_CELLS * 2 * 4);
  for (let c = 0; c < S; c++) {
    const a = cArea[c] || 1e-9;
    const x = cCen[c * 3] / a;
    const y = cCen[c * 3 + 1] / a;
    const z = cCen[c * 3 + 2] / a;
    tmpA.set(cNor[c * 3], cNor[c * 3 + 1], cNor[c * 3 + 2]);
    if (tmpA.lengthSq() < 1e-12) tmpA.set(x - cx, y - cy, z - cz);
    tmpA.normalize();
    const inn = inner(x, y, z);
    center.set([x, y, z], c * 3);
    normal.set([tmpA.x, tmpA.y, tmpA.z], c * 3);
    size[c] = Math.sqrt(a / Math.PI);
    depth[c] = Math.max(0.004, Math.hypot(inn[0] - x, inn[1] - y, inn[2] - z));
    tex.set([x, y, z, size[c]], c * 4);
    tex.set([tmpA.x, tmpA.y, tmpA.z, depth[c]], (MAX_CELLS + c) * 4);
  }
  const cellTex = new THREE.DataTexture(tex, MAX_CELLS, 2, THREE.RGBAFormat, THREE.FloatType);
  cellTex.needsUpdate = true;

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(P, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(N, 3));
  geo.setAttribute('color', new THREE.Float32BufferAttribute(C, 3));
  geo.setAttribute('aInner', new THREE.Float32BufferAttribute(I, 4));
  // share identical vertices (polygon fans, wall strips): ~2-3x fewer vertex-shader runs per fractured part
  const indexed = mergeVertices(geo, 1e-6);
  indexed.computeBoundingSphere();
  return {
    geo: indexed,
    cells: S,
    center,
    normal,
    size,
    depth,
    neighbors: nbr.map((s) => [...s]),
    cellTex,
    tris: P.length / 9,
  };
}

/** Apply a rigid transform to a fractured part (geometry, cell data and texture). */
export function transformFrac(f: FracInfo, m: THREE.Matrix4) {
  f.geo.applyMatrix4(m); // position + normal
  const inn = f.geo.getAttribute('aInner') as THREE.BufferAttribute;
  const v = new THREE.Vector3();
  for (let i = 0; i < inn.count; i++) {
    v.set(inn.getX(i), inn.getY(i), inn.getZ(i)).applyMatrix4(m);
    inn.setXYZ(i, v.x, v.y, v.z);
  }
  const nm = new THREE.Matrix3().getNormalMatrix(m);
  const tex = f.cellTex.image.data as unknown as Float32Array;
  for (let c = 0; c < f.cells; c++) {
    v.fromArray(f.center, c * 3).applyMatrix4(m);
    v.toArray(f.center, c * 3);
    tex.set([v.x, v.y, v.z], c * 4);
    v.fromArray(f.normal, c * 3).applyMatrix3(nm).normalize();
    v.toArray(f.normal, c * 3);
    tex.set([v.x, v.y, v.z], (MAX_CELLS + c) * 4);
  }
  f.cellTex.needsUpdate = true;
}

/* ------------------------------------------------------------ debris chunks
 * Convex Voronoi-like fragments (a cube cut by random planes). The face that
 * points most toward +Y is the skin/cloth side (tinted with the body part's
 * colour), every broken face is raw flesh — so a chunk reads as a piece of
 * the zombie it came from. */
export function chunkGeometry(seed: number): THREE.BufferGeometry {
  const rand = rng(seed * 131 + 7);
  type P3 = [number, number, number];
  const c: P3[] = [
    [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
    [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1],
  ];
  let faces: P3[][] = [
    [c[0], c[3], c[2], c[1]], [c[4], c[5], c[6], c[7]], [c[0], c[1], c[5], c[4]],
    [c[2], c[3], c[7], c[6]], [c[1], c[2], c[6], c[5]], [c[0], c[4], c[7], c[3]],
  ];
  const planes = 7 + ((rand() * 5) | 0);
  for (let k = 0; k < planes; k++) {
    // random direction, avoid shaving the +Y skin side too much
    let nx = rand() * 2 - 1;
    let ny = (rand() * 2 - 1) * 0.8 - 0.15;
    let nz = rand() * 2 - 1;
    const l = Math.hypot(nx, ny, nz) || 1;
    nx /= l;
    ny /= l;
    nz /= l;
    const d = 0.42 + rand() * 0.45;
    const out: P3[][] = [];
    const cap: P3[] = [];
    for (const f of faces) {
      const res: P3[] = [];
      for (let i = 0; i < f.length; i++) {
        const a = f[i];
        const b = f[(i + 1) % f.length];
        const da = nx * a[0] + ny * a[1] + nz * a[2] - d;
        const db = nx * b[0] + ny * b[1] + nz * b[2] - d;
        if (da <= 0) res.push(a);
        if (da <= 0 !== db <= 0) {
          const t = da / (da - db);
          const p: P3 = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
          res.push(p);
          cap.push(p);
        }
      }
      if (res.length >= 3) out.push(res);
    }
    if (cap.length >= 3) {
      let mx = 0, my = 0, mz = 0;
      for (const p of cap) {
        mx += p[0] / cap.length;
        my += p[1] / cap.length;
        mz += p[2] / cap.length;
      }
      // basis in the cut plane, sort CCW around +n
      const ux = Math.abs(nx) < 0.9 ? 1 : 0;
      const uy = Math.abs(nx) < 0.9 ? 0 : 1;
      let e1x = uy * nz - 0 * ny, e1y = 0 * nx - ux * nz, e1z = ux * ny - uy * nx;
      const el = Math.hypot(e1x, e1y, e1z) || 1;
      e1x /= el; e1y /= el; e1z /= el;
      const e2x = ny * e1z - nz * e1y, e2y = nz * e1x - nx * e1z, e2z = nx * e1y - ny * e1x;
      const uniq: P3[] = [];
      for (const p of cap) if (!uniq.some((q) => Math.hypot(q[0] - p[0], q[1] - p[1], q[2] - p[2]) < 1e-6)) uniq.push(p);
      uniq.sort((p, q) => {
        const ap = Math.atan2((p[0] - mx) * e2x + (p[1] - my) * e2y + (p[2] - mz) * e2z, (p[0] - mx) * e1x + (p[1] - my) * e1y + (p[2] - mz) * e1z);
        const aq = Math.atan2((q[0] - mx) * e2x + (q[1] - my) * e2y + (q[2] - mz) * e2z, (q[0] - mx) * e1x + (q[1] - my) * e1y + (q[2] - mz) * e1z);
        return ap - aq;
      });
      if (uniq.length >= 3) out.push(uniq);
    }
    faces = out;
  }
  // find the skin face (most +Y facing)
  const fn = (f: P3[]) => {
    const a = new THREE.Vector3(...f[0]);
    const b = new THREE.Vector3(...f[1]).sub(a);
    const cc = new THREE.Vector3(...f[2]).sub(a);
    return b.cross(cc).normalize();
  };
  let skin = 0;
  let best = -2;
  faces.forEach((f, i) => {
    const n = fn(f);
    if (n.y > best) {
      best = n.y;
      skin = i;
    }
  });
  const P: number[] = [];
  const N: number[] = [];
  const Sk: number[] = [];
  const sy = 0.55 + rand() * 0.2; // plate-like: skin on top, flesh underneath
  faces.forEach((f, i) => {
    const sf = f.map((p) => [p[0], p[1] * sy, p[2]] as P3);
    const n = fn(sf);
    for (let k = 1; k < sf.length - 1; k++) {
      for (const q of [sf[0], sf[k], sf[k + 1]]) {
        P.push(q[0], q[1], q[2]);
        N.push(n.x, n.y, n.z);
        Sk.push(i === skin ? 1 : 0);
      }
    }
  });
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(N, 3));
  g.setAttribute('aSkin', new THREE.Float32BufferAttribute(Sk, 1));
  g.computeBoundingSphere();
  return g;
}
