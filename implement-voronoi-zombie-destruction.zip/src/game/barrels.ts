import * as THREE from 'three';
import type { Terrain } from './terrain';
import type { Blood } from './zombie/blood';
import type { Foley } from './audio';

/* ---------------------------------------------------------------------------
 * EXPLOSIVE BARRELS
 * Shoot one → sparks + short fuse → fireball, ground shock ring, blast sphere,
 * light flash, debris, embers, smoke column, scorch mark, chain reactions.
 * The physical response (zombie ragdolls, player damage, camera shake) is
 * delegated through `onExplode` so it reuses the existing systems.
 * ------------------------------------------------------------------------- */
interface Barrel {
  x: number;
  z: number;
  y: number;
  obj: THREE.Group;
  alive: boolean;
  fuse: number;
  respawn: number;
  solid: { x: number; z: number; r: number };
}
interface Fx {
  t: number;
  active: boolean;
  pos: THREE.Vector3;
  balls: THREE.Mesh[];
  ballDir: THREE.Vector3[];
  ring: THREE.Mesh;
  shock: THREE.Mesh;
  light: THREE.PointLight;
}
const SPOTS: [number, number][] = [
  [-7.4, -8.2],
  [2.6, -9.6],
  [-8.4, -12],
  [9.4, -15.2],
  [-12, 9.5],
  [-1.6, 19.8],
  [12.6, 14.6],
  [-19.5, -1.4],
  [20.5, -18.8],
  [-14.5, -18.5],
  [6.5, 24],
  [-24, 6.5],
  [1.2, -26],
  [-6.2, -4.8],
];
const R = 0.3;
const HGT = 0.9;

function labelTexture() {
  const cv = document.createElement('canvas');
  cv.width = 256;
  cv.height = 64;
  const g = cv.getContext('2d')!;
  g.fillStyle = '#e8b10f';
  g.fillRect(0, 0, 256, 64);
  g.fillStyle = '#151515';
  for (let i = -2; i < 20; i++) {
    g.beginPath();
    g.moveTo(i * 16, 0);
    g.lineTo(i * 16 + 8, 0);
    g.lineTo(i * 16 - 8, 14);
    g.lineTo(i * 16 - 16, 14);
    g.fill();
    g.beginPath();
    g.moveTo(i * 16, 50);
    g.lineTo(i * 16 + 8, 50);
    g.lineTo(i * 16 - 8, 64);
    g.lineTo(i * 16 - 16, 64);
    g.fill();
  }
  g.font = 'bold 26px sans-serif';
  g.textAlign = 'center';
  g.fillText('▲ FLAMMABLE ▲', 128, 41);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = THREE.RepeatWrapping;
  t.repeat.x = 2;
  return t;
}

export class Barrels {
  list: Barrel[] = [];
  onExplode: (p: THREE.Vector3) => void = () => {};
  private fx: Fx[] = [];
  private terrain: Terrain;
  private blood: Blood;
  private foley: Foley;
  private scene: THREE.Scene;
  private shards: THREE.InstancedMesh;
  private sP = new Float32Array(80 * 3);
  private sV = new Float32Array(80 * 3);
  private sR = new Float32Array(80 * 3);
  private sW = new Float32Array(80 * 3);
  private sLife = new Float32Array(80);
  private sI = 0;
  private fireGeo: THREE.BufferGeometry;
  private _m = new THREE.Matrix4();
  private _q = new THREE.Quaternion();
  private _e = new THREE.Euler();
  private _v = new THREE.Vector3();
  private _s = new THREE.Vector3();

  constructor(scene: THREE.Scene, terrain: Terrain, blood: Blood, foley: Foley) {
    this.scene = scene;
    this.terrain = terrain;
    this.blood = blood;
    this.foley = foley;
    const red = new THREE.MeshStandardMaterial({ color: '#a8231b', roughness: 0.45, metalness: 0.55 });
    const dark = new THREE.MeshStandardMaterial({ color: '#4a1410', roughness: 0.5, metalness: 0.6 });
    const label = new THREE.MeshStandardMaterial({ map: labelTexture(), roughness: 0.6, metalness: 0.2 });
    const snow = new THREE.MeshStandardMaterial({ color: '#eef3f8', roughness: 0.95 });
    for (const [x, z] of SPOTS) {
      const y = terrain.height(x, z);
      const g = new THREE.Group();
      const body = new THREE.Mesh(new THREE.CylinderGeometry(R, R, HGT, 24), red);
      body.position.y = HGT / 2;
      const band = new THREE.Mesh(new THREE.CylinderGeometry(R + 0.004, R + 0.004, 0.2, 24, 1, true), label);
      band.position.y = HGT * 0.55;
      g.add(body, band);
      for (const yy of [0.02, 0.3, 0.6, 0.88]) {
        const rib = new THREE.Mesh(new THREE.TorusGeometry(R + 0.006, 0.012, 6, 28), dark);
        rib.rotation.x = Math.PI / 2;
        rib.position.y = yy;
        g.add(rib);
      }
      const cap = new THREE.Mesh(new THREE.CylinderGeometry(R * 0.93, R * 0.93, 0.02, 24), snow);
      cap.position.y = HGT + 0.008;
      const bung = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.03, 10), dark);
      bung.position.set(0.15, HGT + 0.02, 0.05);
      g.add(cap, bung);
      g.position.set(x, y, z);
      g.rotation.y = Math.random() * 6.28;
      g.traverse((o) => {
        o.castShadow = true;
        o.receiveShadow = true;
      });
      scene.add(g);
      const solid = { x, z, r: R + 0.02 };
      terrain.dyn.push(solid);
      this.list.push({ x, z, y, obj: g, alive: true, fuse: -1, respawn: 0, solid });
    }
    // lumpy fireball geometry
    const fg = new THREE.IcosahedronGeometry(1, 3);
    {
      const p = fg.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const x = p.getX(i);
        const y = p.getY(i);
        const z = p.getZ(i);
        const k = 1 + 0.22 * Math.sin(x * 5 + y * 3) * Math.cos(z * 4 - x * 2) + 0.1 * Math.sin(y * 11 + z * 7);
        p.setXYZ(i, x * k, y * k, z * k);
      }
      fg.computeVertexNormals();
    }
    this.fireGeo = fg;
    for (let i = 0; i < 3; i++) this.fx.push(this.makeFx());
    const sg = new THREE.BoxGeometry(1, 0.1, 0.6);
    sg.translate(0, 0, 0);
    this.shards = new THREE.InstancedMesh(sg, red, 80);
    this._m.makeScale(0, 0, 0);
    for (let i = 0; i < 80; i++) this.shards.setMatrixAt(i, this._m);
    this.shards.frustumCulled = false;
    this.shards.castShadow = true;
    scene.add(this.shards);
  }

  private makeFx(): Fx {
    const balls: THREE.Mesh[] = [];
    const ballDir: THREE.Vector3[] = [];
    for (let i = 0; i < 6; i++) {
      const m = new THREE.Mesh(
        this.fireGeo,
        new THREE.MeshBasicMaterial({ color: '#ffb347', transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }),
      );
      m.visible = false;
      m.renderOrder = 6;
      this.scene.add(m);
      balls.push(m);
      ballDir.push(new THREE.Vector3());
    }
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.82, 1, 64),
      new THREE.MeshBasicMaterial({ color: '#ffd9a0', transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }),
    );
    ring.rotation.x = -Math.PI / 2;
    ring.visible = false;
    this.scene.add(ring);
    const shock = new THREE.Mesh(
      new THREE.SphereGeometry(1, 32, 16),
      new THREE.ShaderMaterial({
        uniforms: { uA: { value: 0 } },
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        vertexShader: `varying vec3 vN; varying vec3 vV; void main(){ vec4 mv = modelViewMatrix*vec4(position,1.0); vN = normalize(normalMatrix*normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }`,
        fragmentShader: `uniform float uA; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0 - abs(dot(vN, vV)), 3.0); gl_FragColor = vec4(vec3(1.0,0.85,0.65)*f*uA, f*uA); }`,
      }),
    );
    shock.visible = false;
    this.scene.add(shock);
    const light = new THREE.PointLight('#ff9a40', 0, 38, 1.6);
    this.scene.add(light);
    return { t: 0, active: false, pos: new THREE.Vector3(), balls, ballDir, ring, shock, light };
  }

  /** Ray vs upright barrel cylinders. */
  raycast(o: THREE.Vector3, d: THREE.Vector3, tMin: number, tMax: number): { i: number; t: number } | null {
    let best: { i: number; t: number } | null = null;
    for (let i = 0; i < this.list.length; i++) {
      const b = this.list[i];
      if (!b.alive) continue;
      const ox = o.x - b.x;
      const oz = o.z - b.z;
      const A = d.x * d.x + d.z * d.z;
      const B = 2 * (ox * d.x + oz * d.z);
      const C = ox * ox + oz * oz - R * R;
      const disc = B * B - 4 * A * C;
      if (disc < 0 || A < 1e-8) continue;
      const t = (-B - Math.sqrt(disc)) / (2 * A);
      if (t < tMin || t > tMax || (best && t > best.t)) continue;
      const y = o.y + d.y * t;
      if (y < b.y || y > b.y + HGT) continue;
      best = { i, t };
    }
    return best;
  }

  hit(i: number, p: THREE.Vector3) {
    const b = this.list[i];
    if (!b.alive) return;
    this.foley.clang();
    this.blood.puffs(p, 3, 0.18, 1, 0.75, 0.3, 0.9, 0.25);
    if (b.fuse < 0) b.fuse = 0.14 + Math.random() * 0.08;
  }

  private explode(b: Barrel) {
    b.alive = false;
    b.fuse = -1;
    b.respawn = 45;
    b.obj.visible = false;
    const idx = this.terrain.dyn.indexOf(b.solid);
    if (idx >= 0) this.terrain.dyn.splice(idx, 1);
    const p = new THREE.Vector3(b.x, b.y + 0.5, b.z);
    // ---- visual
    const fx = this.fx.find((f) => !f.active) ?? this.fx[0];
    fx.active = true;
    fx.t = 0;
    fx.pos.copy(p);
    fx.balls.forEach((m, k) => {
      fx.ballDir[k].set(Math.random() - 0.5, 0.35 + Math.random() * 0.8, Math.random() - 0.5).normalize().multiplyScalar(k === 0 ? 0 : 0.9 + Math.random() * 0.8);
      m.visible = true;
      m.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
    });
    fx.ring.visible = true;
    fx.ring.position.set(b.x, b.y + 0.06, b.z);
    fx.shock.visible = true;
    fx.shock.position.copy(p);
    fx.light.position.set(b.x, b.y + 1.4, b.z);
    fx.light.intensity = 160;
    // debris
    for (let k = 0; k < 14; k++) {
      const i = this.sI;
      this.sI = (this.sI + 1) % 80;
      const a = Math.random() * 6.28;
      const sp = 6 + Math.random() * 9;
      this.sP.set([b.x, b.y + 0.4 + Math.random() * 0.4, b.z], i * 3);
      this.sV.set([Math.cos(a) * sp * 0.7, 4 + Math.random() * 9, Math.sin(a) * sp * 0.7], i * 3);
      this.sR.set([Math.random() * 6, Math.random() * 6, Math.random() * 6], i * 3);
      this.sW.set([(Math.random() - 0.5) * 22, (Math.random() - 0.5) * 22, (Math.random() - 0.5) * 22], i * 3);
      this.sLife[i] = 30;
    }
    // embers + smoke column
    this.blood.puffs(p, 16, 0.6, 1, 0.55, 0.15, 0.95, 0.5, this._v.set(0, 3, 0));
    this.blood.puffs(p, 22, 1.6, 0.12, 0.11, 0.1, 0.65, 3.8, this._v.set(0, 2.2, 0));
    this.blood.puffs(p, 10, 1.2, 0.85, 0.87, 0.9, 0.4, 1.6, this._v.set(0, 0.5, 0)); // snow kicked up
    this.blood.scorch(b.x, b.z, 3.6);
    // ---- chain reaction
    for (const o of this.list) {
      if (!o.alive || o === b || o.fuse >= 0) continue;
      const d = Math.hypot(o.x - b.x, o.z - b.z);
      if (d < 6) o.fuse = 0.15 + d * 0.06;
    }
    this.onExplode(p);
  }

  update(dt: number, playerPos: THREE.Vector3) {
    for (const b of this.list) {
      if (b.alive && b.fuse >= 0) {
        // burning fuse: sparks + flame jet out of the hole
        b.fuse -= dt;
        this._v.set(b.x, b.y + HGT * 0.7, b.z);
        this.blood.puffs(this._v, 1, 0.25, 1, 0.6, 0.15, 0.9, 0.3, this._s.set(0, 1.5, 0));
        if (b.fuse <= 0) this.explode(b);
      } else if (!b.alive) {
        b.respawn -= dt;
        if (b.respawn <= 0 && Math.hypot(playerPos.x - b.x, playerPos.z - b.z) > 18) {
          b.alive = true;
          b.obj.visible = true;
          this.terrain.dyn.push(b.solid);
        }
      }
    }
    // ---- fireball / shock FX
    for (const f of this.fx) {
      if (!f.active) continue;
      f.t += dt;
      const t = f.t;
      f.balls.forEach((m, k) => {
        const grow = 1 - Math.exp(-t * 9);
        const s = (k === 0 ? 2.4 : 1.4 + k * 0.1) * grow * (1 + t * 0.6);
        m.scale.setScalar(Math.max(0.01, s));
        m.position.copy(f.pos).addScaledVector(f.ballDir[k], grow * 1.6 + t * 1.2);
        m.position.y += t * 1.5;
        const mat = m.material as THREE.MeshBasicMaterial;
        const life = Math.max(0, 1 - t / (0.75 + k * 0.05));
        mat.opacity = life * life * 0.95;
        mat.color.setRGB(1, 0.45 + 0.5 * life, 0.12 + 0.6 * life * life);
        m.rotation.y += dt * 0.8;
        if (life <= 0) m.visible = false;
      });
      const rs = 0.5 + t * 26;
      f.ring.scale.setScalar(rs);
      (f.ring.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 1 - t / 0.55) * 0.9;
      f.shock.scale.setScalar(0.5 + t * 30);
      (f.shock.material as THREE.ShaderMaterial).uniforms.uA.value = Math.max(0, 1 - t / 0.3) * 1.3;
      f.light.intensity = 160 * Math.exp(-t * 6) * (0.85 + 0.15 * Math.sin(t * 60));
      if (t > 0.6) f.ring.visible = false;
      if (t > 0.32) f.shock.visible = false;
      if (t > 1.4) {
        f.active = false;
        f.light.intensity = 0;
      }
    }
    // ---- debris
    let any = false;
    for (let i = 0; i < 80; i++) {
      if (this.sLife[i] <= 0) continue;
      any = true;
      this.sLife[i] -= dt;
      const j = i * 3;
      const gy = this.terrain.height(this.sP[j], this.sP[j + 2]) + 0.02;
      if (this.sP[j + 1] > gy || this.sV[j + 1] > 0) {
        this.sV[j + 1] -= 9.8 * dt;
        this.sP[j] += this.sV[j] * dt;
        this.sP[j + 1] += this.sV[j + 1] * dt;
        this.sP[j + 2] += this.sV[j + 2] * dt;
        this.sR[j] += this.sW[j] * dt;
        this.sR[j + 1] += this.sW[j + 1] * dt;
        this.sR[j + 2] += this.sW[j + 2] * dt;
      }
      if (this.sP[j + 1] < gy) {
        this.sP[j + 1] = gy;
        this.sV[j + 1] = Math.abs(this.sV[j + 1]) > 2 ? -this.sV[j + 1] * 0.3 : 0;
        this.sV[j] *= 0.6;
        this.sV[j + 2] *= 0.6;
        this.sW[j] *= 0.5;
        this.sW[j + 1] *= 0.5;
        this.sW[j + 2] *= 0.5;
      }
      this._q.setFromEuler(this._e.set(this.sR[j], this.sR[j + 1], this.sR[j + 2]));
      const sc = this.sLife[i] > 0 ? 0.14 : 0;
      this._m.compose(this._v.set(this.sP[j], this.sP[j + 1], this.sP[j + 2]), this._q, this._s.set(sc, sc, sc));
      this.shards.setMatrixAt(i, this._m);
    }
    if (any) this.shards.instanceMatrix.needsUpdate = true;
  }
}
