import * as THREE from 'three';
import { buildTower } from './tower';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { Terrain } from './terrain';
import type { FootStep } from './animator';

const INNER = 26;

function snowTexture(): THREE.Texture {
  const s = 512;
  const cv = document.createElement('canvas');
  cv.width = cv.height = s;
  const g = cv.getContext('2d')!;
  g.fillStyle = '#e9eff6';
  g.fillRect(0, 0, s, s);
  // soft drifts
  for (let i = 0; i < 46; i++) {
    const x = Math.random() * s;
    const y = Math.random() * s;
    const r = 30 + Math.random() * 90;
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    const dark = Math.random() < 0.5;
    gr.addColorStop(0, dark ? 'rgba(150,172,205,0.16)' : 'rgba(255,255,255,0.35)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    for (const ox of [-s, 0, s]) for (const oy of [-s, 0, s]) g.fillRect(x - r + ox, y - r + oy, r * 2, r * 2);
  }
  // wind streaks + grain: give the ground readable motion at speed
  for (let i = 0; i < 260; i++) {
    g.strokeStyle = `rgba(120,145,185,${0.05 + Math.random() * 0.1})`;
    g.lineWidth = 1 + Math.random() * 1.5;
    const x = Math.random() * s;
    const y = Math.random() * s;
    const l = 10 + Math.random() * 40;
    g.beginPath();
    g.moveTo(x, y);
    g.lineTo(x + l, y + l * 0.25);
    g.stroke();
  }
  for (let i = 0; i < 5000; i++) {
    g.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,0.7)' : 'rgba(130,155,195,0.22)';
    g.fillRect(Math.random() * s, Math.random() * s, 1.6, 1.6);
  }
  const t = new THREE.CanvasTexture(cv);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

function groundGrid(terrain: Terrain, size: number, segs: number, hole: number): THREE.BufferGeometry {
  const geo = new THREE.PlaneGeometry(size, size, segs, segs);
  geo.rotateX(-Math.PI / 2);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const uv = geo.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    pos.setY(i, terrain.base(x, z));
    uv.setXY(i, x / 7, z / 7);
  }
  if (hole > 0) {
    const idx = geo.index!;
    const out: number[] = [];
    for (let i = 0; i < idx.count; i += 3) {
      const a = idx.getX(i);
      const b = idx.getX(i + 1);
      const c = idx.getX(i + 2);
      const cx = (pos.getX(a) + pos.getX(b) + pos.getX(c)) / 3;
      const cz = (pos.getZ(a) + pos.getZ(b) + pos.getZ(c)) / 3;
      if (Math.abs(cx) < hole && Math.abs(cz) < hole) continue;
      out.push(a, b, c);
    }
    geo.setIndex(out);
  }
  geo.computeVertexNormals();
  return geo;
}

export class Environment {
  sun: THREE.DirectionalLight;
  private snow: THREE.Points;
  private snowPos: Float32Array;
  private prints: THREE.InstancedMesh;
  private printIdx = 0;
  private m = new THREE.Matrix4();
  private q = new THREE.Quaternion();
  private v = new THREE.Vector3();
  private one = new THREE.Vector3(1, 1, 1);

  constructor(scene: THREE.Scene, terrain: Terrain) {
    const horizon = new THREE.Color('#dfe6ee');
    scene.fog = new THREE.Fog(horizon, 38, 300);

    // ---- sky dome
    const sky = new THREE.Mesh(
      new THREE.SphereGeometry(420, 32, 16),
      new THREE.ShaderMaterial({
        side: THREE.BackSide,
        depthWrite: false,
        fog: false,
        uniforms: {
          top: { value: new THREE.Color('#5f86b8') },
          mid: { value: new THREE.Color('#b9cde3') },
          hor: { value: horizon },
          glow: { value: new THREE.Color('#ffe3c2') },
          sunDir: { value: new THREE.Vector3(0.55, 0.42, -0.72).normalize() },
        },
        vertexShader: `varying vec3 vDir; void main(){ vDir = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
        fragmentShader: `varying vec3 vDir; uniform vec3 top; uniform vec3 mid; uniform vec3 hor; uniform vec3 glow; uniform vec3 sunDir;
          void main(){ float h = clamp(vDir.y,0.0,1.0);
            vec3 c = mix(hor, mid, smoothstep(0.0,0.22,h)); c = mix(c, top, smoothstep(0.18,0.8,h));
            float s = max(dot(normalize(vDir), sunDir),0.0);
            c += glow * (pow(s, 24.0)*0.35 + pow(s, 600.0)*1.2);
            gl_FragColor = vec4(c,1.0); }`,
      }),
    );
    sky.frustumCulled = false;
    scene.add(sky);

    // ---- light
    scene.add(new THREE.HemisphereLight('#cfe1ff', '#efe8df', 0.95));
    const sun = new THREE.DirectionalLight('#ffe4c4', 2.5);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const sc = sun.shadow.camera;
    sc.left = sc.bottom = -15;
    sc.right = sc.top = 15;
    sc.near = 1;
    sc.far = 70;
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.03;
    scene.add(sun, sun.target);
    this.sun = sun;

    // ---- ground
    const snowMat = new THREE.MeshStandardMaterial({ map: snowTexture(), color: '#e4ecf5', roughness: 0.95 });
    const inner = new THREE.Mesh(groundGrid(terrain, INNER * 2, 260, 0), snowMat);
    const outer = new THREE.Mesh(groundGrid(terrain, 416, 208, INNER), snowMat);
    inner.receiveShadow = outer.receiveShadow = true;
    scene.add(inner, outer);

    // ---- training props
    const side = new THREE.MeshStandardMaterial({ color: '#465469', roughness: 0.75, metalness: 0.15 });
    const cap = new THREE.MeshStandardMaterial({ color: '#dbe5f0', roughness: 0.95 });
    const trim = new THREE.MeshStandardMaterial({ color: '#f08a2c', roughness: 0.6, emissive: '#7a3a08', emissiveIntensity: 0.5 });
    const mats = [side, side, cap, side, side, side];
    buildTower(scene, terrain);
    for (const b of terrain.boxes) {
      if (b.style) continue;
      const w = b.x1 - b.x0;
      const d = b.z1 - b.z0;
      const hh = b.h + 0.6;
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, hh, d), mats);
      mesh.position.set((b.x0 + b.x1) / 2, b.h - hh / 2, (b.z0 + b.z1) / 2);
      mesh.castShadow = mesh.receiveShadow = true;
      scene.add(mesh);
      if (b.h > 0.4) {
        // hazard trim around the lip of tall props
        const t = new THREE.Mesh(new THREE.BoxGeometry(w + 0.02, 0.035, d + 0.02), trim);
        t.position.set(mesh.position.x, b.h - 0.07, mesh.position.z);
        scene.add(t);
      }
    }
    for (const r of terrain.ramps) {
      const { x0, x1, z0, z1, h0, h1 } = r;
      const lo = -0.6;
      const P = (x: number, y: number, z: number) => [x, y, z];
      const quad = (a: number[], b: number[], c: number[], d: number[]) => [...a, ...b, ...c, ...a, ...c, ...d];
      const top = new THREE.BufferGeometry();
      top.setAttribute(
        'position',
        new THREE.Float32BufferAttribute(quad(P(x0, h0, z0), P(x0, h0, z1), P(x1, h1, z1), P(x1, h1, z0)), 3),
      );
      top.computeVertexNormals();
      const sides = new THREE.BufferGeometry();
      sides.setAttribute(
        'position',
        new THREE.Float32BufferAttribute(
          [
            ...quad(P(x0, lo, z0), P(x0, h0, z0), P(x1, h1, z0), P(x1, lo, z0)),
            ...quad(P(x0, lo, z1), P(x1, lo, z1), P(x1, h1, z1), P(x0, h0, z1)),
            ...quad(P(x1, lo, z0), P(x1, h1, z0), P(x1, h1, z1), P(x1, lo, z1)),
          ],
          3,
        ),
      );
      sides.computeVertexNormals();
      const capD = cap.clone();
      capD.side = THREE.DoubleSide;
      const sideD = side.clone();
      sideD.side = THREE.DoubleSide;
      const tm = new THREE.Mesh(top, capD);
      const sm = new THREE.Mesh(sides, sideD);
      tm.receiveShadow = sm.receiveShadow = true;
      tm.castShadow = sm.castShadow = true;
      scene.add(tm, sm);
    }

    // ---- pines (instanced, vertex coloured)
    const parts: THREE.BufferGeometry[] = [];
    const paint = (geo: THREE.BufferGeometry, fn: (y: number) => THREE.Color) => {
      const p = geo.attributes.position;
      const col = new Float32Array(p.count * 3);
      for (let i = 0; i < p.count; i++) {
        const c = fn(p.getY(i));
        col.set([c.r, c.g, c.b], i * 3);
      }
      geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
      return geo;
    };
    const trunkC = new THREE.Color('#4a3527');
    // tall bare trunks: the canopy starts above the chase camera so it never swallows the view
    const trunk = new THREE.CylinderGeometry(0.2, 0.34, 5, 8);
    trunk.translate(0, 2.5, 0);
    parts.push(paint(trunk, () => trunkC));
    const g1 = new THREE.Color('#1f3d36');
    const g2 = new THREE.Color('#e8f0f6');
    [
      [2.1, 3.0, 4.2],
      [1.6, 2.7, 5.9],
      [1.05, 2.4, 7.5],
    ].forEach(([r, h, y]) => {
      const cone = new THREE.ConeGeometry(r, h, 9);
      cone.translate(0, y + h / 2, 0);
      parts.push(paint(cone, (yy) => g1.clone().lerp(g2, THREE.MathUtils.smoothstep(yy, y + h * 0.35, y + h) * 0.75)));
    });
    const treeGeo = mergeGeometries(parts)!;
    const trees = new THREE.InstancedMesh(
      treeGeo,
      new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.9, flatShading: true }),
      terrain.pillars.length,
    );
    terrain.pillars.forEach((p, i) => {
      const s = (p.r / 0.34) * (0.95 + ((i * 37) % 10) * 0.04);
      this.m.compose(
        this.v.set(p.x, terrain.base(p.x, p.z) - 0.1, p.z),
        this.q.setFromAxisAngle(THREE.Object3D.DEFAULT_UP, i * 1.7),
        new THREE.Vector3(s, s * (0.9 + ((i * 13) % 7) * 0.05), s),
      );
      trees.setMatrixAt(i, this.m);
    });
    trees.castShadow = true;
    trees.receiveShadow = true;
    scene.add(trees);

    // ---- distant ridge line
    const ridgeMat = new THREE.MeshStandardMaterial({ color: '#a9bcd6', roughness: 1, flatShading: true });
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2 + 0.2;
      const h = 55 + ((i * 53) % 60);
      const m = new THREE.Mesh(new THREE.ConeGeometry(60 + ((i * 29) % 40), h, 7), ridgeMat);
      const r = 245 + ((i * 17) % 40);
      m.position.set(Math.sin(a) * r, h / 2 - 6, Math.cos(a) * r);
      m.rotation.y = i;
      scene.add(m);
    }

    // ---- snowfall
    const N = 1400;
    this.snowPos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      this.snowPos[i * 3] = (Math.random() - 0.5) * 44;
      this.snowPos[i * 3 + 1] = Math.random() * 18;
      this.snowPos[i * 3 + 2] = (Math.random() - 0.5) * 44;
    }
    const sg = new THREE.BufferGeometry();
    sg.setAttribute('position', new THREE.BufferAttribute(this.snowPos, 3));
    this.snow = new THREE.Points(
      sg,
      new THREE.PointsMaterial({ color: '#ffffff', size: 0.07, transparent: true, opacity: 0.85, depthWrite: false }),
    );
    this.snow.frustumCulled = false;
    scene.add(this.snow);

    // ---- footprints: every plant leaves a mark, proof the feet don't slide
    const pg = new THREE.PlaneGeometry(0.105, 0.275);
    pg.rotateX(-Math.PI / 2);
    this.prints = new THREE.InstancedMesh(
      pg,
      new THREE.MeshBasicMaterial({
        color: '#8fa5c4',
        transparent: true,
        opacity: 0.6,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -2,
        polygonOffsetUnits: -2,
      }),
      180,
    );
    this.m.makeScale(0, 0, 0);
    for (let i = 0; i < 180; i++) this.prints.setMatrixAt(i, this.m);
    this.prints.frustumCulled = false;
    scene.add(this.prints);
  }

  addFootprint(s: FootStep) {
    this.q.setFromAxisAngle(THREE.Object3D.DEFAULT_UP, s.yaw);
    this.v.set(s.x + Math.sin(s.yaw) * 0.035, s.y + 0.012, s.z + Math.cos(s.yaw) * 0.035);
    this.m.compose(this.v, this.q, this.one);
    this.prints.setMatrixAt(this.printIdx, this.m);
    this.printIdx = (this.printIdx + 1) % 180;
    this.prints.instanceMatrix.needsUpdate = true;
  }

  update(dt: number, focus: THREE.Vector3, time: number) {
    // shadow frustum follows the player in coarse steps (stable shadow texels)
    const sx = Math.round(focus.x * 2) / 2;
    const sz = Math.round(focus.z * 2) / 2;
    const sy = Math.round(focus.y);
    this.sun.target.position.set(sx, sy, sz);
    this.sun.position.set(sx + 13, sy + 22, sz - 17);

    // flakes live in world space and wrap around the player → correct parallax when moving
    const p = this.snowPos;
    const wx = 0.9 + Math.sin(time * 0.3) * 0.5;
    for (let i = 0; i < p.length; i += 3) {
      p[i] += wx * dt;
      p[i + 1] -= (1.1 + (i % 7) * 0.08) * dt;
      p[i + 2] += 0.3 * dt;
      const dx = p[i] - focus.x;
      const dy = p[i + 1] - focus.y;
      const dz = p[i + 2] - focus.z;
      if (dx > 22) p[i] -= 44;
      else if (dx < -22) p[i] += 44;
      if (dy < -2) p[i + 1] += 18;
      else if (dy > 16) p[i + 1] -= 18;
      if (dz > 22) p[i + 2] -= 44;
      else if (dz < -22) p[i + 2] += 44;
    }
    (this.snow.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  }
}
