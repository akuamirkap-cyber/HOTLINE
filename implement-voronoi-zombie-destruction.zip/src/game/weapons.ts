import * as THREE from 'three';
import type { Rig } from './rig';
import type { Terrain } from './terrain';
import type { Range } from './targets';
import type { Foley } from './audio';
import type { CharacterController } from './controller';
import { Spring, clamp01, damp, lerp } from './math';
import type { Horde, ShotSpec } from './zombie/zombies';
import type { Barrels } from './barrels';
import { buildThirdPersonWeapons, adsPose, IDS } from './fpsWeapons';
import { WEAPON_SPECS } from './ref/types';
import { soundEngine } from './ref/audio';

/* Weapons are the PIGEON reference rigs: same models, specs (rpm / mag / reload /
 * spread) and sound engine as the reference project. */
const TP = buildThirdPersonWeapons();
const v3 = (v: THREE.Vector3): V3 => [v.x, v.y, v.z];
/** ADS aim-frame position derived from the reference ADS pose (same sight line as first person). */
const adsFrom = (i: number): V3 => {
  const a = adsPose(i).pos;
  const g = TP[i].grip;
  return [0, a.y + g.y, -(a.z + g.z)];
};

/** Terminal ballistics per weapon slot. */
/*  pistol: a solid shove · rifle: rapid stacking hits that drive the target back and
 *  bowl it over · sniper: anti-materiel — every hit lifts the body off its feet and
 *  throws it metres, blowing a huge Voronoi exit crater out of the far side. */
const SHOT: ShotSpec[] = [
  { dmg: 38, power: 1.15, impulse: 30, pen: 1, explode: 0.1, knock: 3.2, lift: 0.8, spin: 0.75, push: 1.3, frag: 0.05, fragK: 1.0, exit: 0.65 },
  { dmg: 32, power: 1.25, impulse: 36, pen: 1, explode: 0.1, knock: 4.0, lift: 1.0, spin: 0.9, push: 1.55, frag: 0.056, fragK: 1.12, exit: 0.85 },
  { dmg: 180, power: 3, impulse: 95, pen: 3, explode: 0.3, knock: 8.2, lift: 3.6, spin: 2.4, push: 2.2, frag: 0.11, fragK: 2.4, exit: 1.6, heavy: true },
];
const NOISE = [38, 48, 70];

type V3 = [number, number, number];

export interface WeaponDef {
  name: string;
  mode: 'SEMI' | 'AUTO' | 'BOLT';
  mag: number;
  interval: number; // seconds between shots
  reload: number;
  twoHand: boolean; // carried two-handed against the chest (false = follows the right hand)
  /** Grip position in the aim frame (origin = eye, x = left, y = up, z = forward). */
  hip: V3;
  ads: V3;
  /** Support-hand wrist target, weapon local. */
  left: V3;
  muzzle: V3;
  zoom: number; // ADS magnification
  scope: boolean;
  spreadHip: number;
  spreadAds: number;
  bloom: number;
  kickUp: number; // view recoil (rad)
  kickBack: number; // weapon recoil (m/s impulse)
  build: () => THREE.Object3D;
}

/** Everything the animator needs to pose the weapon and hands this frame. */
export interface WeaponPose {
  obj: THREE.Object3D;
  def: WeaponDef;
  aim: boolean;
  ads: boolean;
  lower: number; // 0..1 draw / holster
  reload: number; // 0..1 progress (0 = idle)
  cycle: number; // 0..1 bolt cycle
  kickBack: number;
  kickUp: number;
  aimYaw: number;
  aimPitch: number;
}

// ------------------------------------------------------------------ models
const GUN = new THREE.MeshStandardMaterial({ color: '#434852', roughness: 0.5, metalness: 0.3 });
const POLY = new THREE.MeshStandardMaterial({ color: '#272a31', roughness: 0.8 });
const TAN = new THREE.MeshStandardMaterial({ color: '#8c7a58', roughness: 0.8 });
const OLIVE = new THREE.MeshStandardMaterial({ color: '#4c5842', roughness: 0.85 });
const LENS = new THREE.MeshStandardMaterial({ color: '#3a9cc4', roughness: 0.1, metalness: 0.9, emissive: '#0b3a52' });
const DOT = new THREE.MeshBasicMaterial({ color: '#ff4b3a' });

function box(g: THREE.Object3D, m: THREE.Material, w: number, h: number, d: number, x: number, y: number, z: number, rx = 0) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  mesh.position.set(x, y, z);
  mesh.rotation.x = rx;
  mesh.castShadow = true;
  g.add(mesh);
  return mesh;
}
/** Cylinder along the barrel axis (+Z). */
function tube(g: THREE.Object3D, m: THREE.Material, r: number, len: number, x: number, y: number, z: number) {
  const geo = new THREE.CylinderGeometry(r, r, len, 14);
  geo.rotateX(Math.PI / 2);
  const mesh = new THREE.Mesh(geo, m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  g.add(mesh);
  return mesh;
}

// All weapons: origin at the pistol grip, +Z down the barrel, +Y up.
function buildPistol() {
  const g = new THREE.Group();
  box(g, GUN, 0.03, 0.034, 0.2, 0, 0.062, 0.045); // slide
  box(g, POLY, 0.028, 0.024, 0.17, 0, 0.036, 0.04); // frame
  box(g, POLY, 0.03, 0.11, 0.046, 0, -0.02, -0.012, 0.22); // grip
  box(g, POLY, 0.012, 0.008, 0.055, 0, 0.004, 0.045); // trigger guard
  tube(g, GUN, 0.008, 0.02, 0, 0.064, 0.15);
  box(g, GUN, 0.018, 0.008, 0.008, 0, 0.083, -0.045);
  box(g, GUN, 0.005, 0.008, 0.006, 0, 0.083, 0.135);
  box(g, GUN, 0.022, 0.03, 0.036, 0, -0.078, -0.024, 0.22).name = 'mag';
  return g;
}

function buildRifle() {
  const g = new THREE.Group();
  box(g, GUN, 0.046, 0.075, 0.3, 0, 0.055, 0.07); // receiver
  box(g, POLY, 0.034, 0.04, 0.15, 0, 0.062, -0.15); // buffer tube
  box(g, POLY, 0.04, 0.115, 0.05, 0, 0.038, -0.235); // butt
  box(g, POLY, 0.03, 0.1, 0.042, 0, -0.015, -0.01, 0.3); // grip
  box(g, GUN, 0.028, 0.15, 0.058, 0, -0.05, 0.1, -0.18).name = 'mag';
  box(g, TAN, 0.05, 0.056, 0.27, 0, 0.058, 0.35); // handguard
  tube(g, GUN, 0.011, 0.16, 0, 0.062, 0.56);
  tube(g, GUN, 0.017, 0.05, 0, 0.062, 0.635);
  box(g, GUN, 0.02, 0.01, 0.5, 0, 0.098, 0.2); // rail
  box(g, GUN, 0.03, 0.014, 0.05, 0, 0.108, 0.06); // optic base
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.019, 0.005, 8, 20), GUN);
  ring.position.set(0, 0.134, 0.06);
  ring.castShadow = true;
  g.add(ring);
  const dot = new THREE.Mesh(new THREE.SphereGeometry(0.0028, 8, 6), DOT);
  dot.position.set(0, 0.134, 0.06);
  g.add(dot);
  box(g, GUN, 0.006, 0.03, 0.01, 0, 0.115, 0.47);
  return g;
}

function buildSniper() {
  const g = new THREE.Group();
  box(g, GUN, 0.048, 0.07, 0.34, 0, 0.055, 0.09); // action
  box(g, OLIVE, 0.045, 0.078, 0.21, 0, 0.034, -0.185); // stock
  box(g, POLY, 0.046, 0.13, 0.028, 0, 0.03, -0.3); // butt pad
  box(g, OLIVE, 0.04, 0.03, 0.13, 0, 0.088, -0.17); // cheek riser
  box(g, OLIVE, 0.032, 0.1, 0.045, 0, -0.015, -0.01, 0.3); // grip
  box(g, OLIVE, 0.052, 0.05, 0.3, 0, 0.04, 0.4); // fore-end
  tube(g, GUN, 0.013, 0.62, 0, 0.066, 0.56);
  box(g, GUN, 0.032, 0.03, 0.065, 0, 0.066, 0.885); // muzzle brake
  tube(g, GUN, 0.02, 0.3, 0, 0.136, 0.1); // scope tube
  tube(g, GUN, 0.03, 0.085, 0, 0.136, 0.275);
  tube(g, GUN, 0.026, 0.06, 0, 0.136, -0.07);
  tube(g, LENS, 0.027, 0.004, 0, 0.136, 0.319);
  box(g, GUN, 0.016, 0.035, 0.02, 0, 0.106, 0.02);
  box(g, GUN, 0.016, 0.035, 0.02, 0, 0.106, 0.19);
  box(g, GUN, 0.05, 0.012, 0.012, -0.045, 0.072, -0.02); // bolt handle
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.012, 10, 8), GUN);
  knob.position.set(-0.072, 0.066, -0.02);
  g.add(knob);
  box(g, GUN, 0.03, 0.07, 0.08, 0, -0.012, 0.1).name = 'mag';
  tube(g, GUN, 0.006, 0.22, 0.018, 0.008, 0.45);
  tube(g, GUN, 0.006, 0.22, -0.018, 0.008, 0.45);
  return g;
}

void buildPistol;
void buildRifle;
void buildSniper;
export const WEAPONS: WeaponDef[] = [
  {
    name: WEAPON_SPECS.pistol.name,
    mode: 'SEMI',
    mag: WEAPON_SPECS.pistol.magSize,
    interval: 60 / WEAPON_SPECS.pistol.rpm,
    reload: WEAPON_SPECS.pistol.reloadDuration,
    twoHand: false,
    hip: [-0.115, -0.165, 0.38],
    ads: adsFrom(0),
    left: v3(TP[0].left),
    muzzle: v3(TP[0].muzzle),
    zoom: 1.2,
    scope: false,
    spreadHip: WEAPON_SPECS.pistol.spreadHip,
    spreadAds: WEAPON_SPECS.pistol.spreadAds,
    bloom: 0.008,
    kickUp: 0.022,
    kickBack: 1.5,
    build: () => TP[0].obj,
  },
  {
    name: WEAPON_SPECS.rifle.name,
    mode: 'AUTO',
    mag: WEAPON_SPECS.rifle.magSize,
    interval: 60 / WEAPON_SPECS.rifle.rpm,
    reload: WEAPON_SPECS.rifle.reloadDuration,
    twoHand: true,
    hip: [-0.12, -0.17, 0.2],
    ads: adsFrom(1),
    left: v3(TP[1].left),
    muzzle: v3(TP[1].muzzle),
    zoom: 1.5,
    scope: false,
    spreadHip: WEAPON_SPECS.rifle.spreadHip,
    spreadAds: WEAPON_SPECS.rifle.spreadAds,
    bloom: 0.006,
    kickUp: 0.013,
    kickBack: 1.1,
    build: () => TP[1].obj,
  },
  {
    name: WEAPON_SPECS.sniper.name,
    mode: 'BOLT',
    mag: WEAPON_SPECS.sniper.magSize,
    interval: 60 / WEAPON_SPECS.sniper.rpm,
    reload: WEAPON_SPECS.sniper.reloadDuration,
    twoHand: true,
    hip: [-0.12, -0.17, 0.22],
    ads: adsFrom(2),
    left: v3(TP[2].left),
    muzzle: v3(TP[2].muzzle),
    zoom: 1.6,
    scope: true,
    spreadHip: WEAPON_SPECS.sniper.spreadHip * 2.5,
    spreadAds: WEAPON_SPECS.sniper.spreadAds,
    bloom: 0.02,
    kickUp: 0.06,
    kickBack: 2.6,
    build: () => TP[2].obj,
  },
];

// ------------------------------------------------------------------ effects
class Sparks {
  points: THREE.Points;
  private pos: Float32Array;
  private col: Float32Array;
  private vel: Float32Array;
  private life: Float32Array;
  private i = 0;
  private readonly n = 320;
  constructor() {
    this.pos = new Float32Array(this.n * 3).fill(-999);
    this.col = new Float32Array(this.n * 3);
    this.vel = new Float32Array(this.n * 3);
    this.life = new Float32Array(this.n);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
    this.points = new THREE.Points(
      g,
      new THREE.PointsMaterial({ size: 0.055, vertexColors: true, transparent: true, opacity: 0.95, depthWrite: false }),
    );
    this.points.frustumCulled = false;
  }
  emit(p: THREE.Vector3, n: number, up: number, speed: number, r: number, g: number, b: number) {
    for (let k = 0; k < n; k++) {
      const i = this.i;
      this.i = (this.i + 1) % this.n;
      this.pos.set([p.x, p.y, p.z], i * 3);
      this.vel.set(
        [(Math.random() - 0.5) * speed, Math.random() * speed * up, (Math.random() - 0.5) * speed],
        i * 3,
      );
      this.col.set([r, g, b], i * 3);
      this.life[i] = 0.35 + Math.random() * 0.4;
    }
    this.points.geometry.attributes.color.needsUpdate = true;
  }
  update(dt: number) {
    for (let i = 0; i < this.n; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      const j = i * 3;
      if (this.life[i] <= 0) {
        this.pos[j + 1] = -999;
        continue;
      }
      this.vel[j + 1] -= 7 * dt;
      this.pos[j] += this.vel[j] * dt;
      this.pos[j + 1] += this.vel[j + 1] * dt;
      this.pos[j + 2] += this.vel[j + 2] * dt;
    }
    this.points.geometry.attributes.position.needsUpdate = true;
  }
}

export interface ArsenalInput {
  fire: boolean;
  firePressed: boolean;
  aim: boolean;
  reloadPressed: boolean;
  /** null = no request, -1 = holster, -2 = cycle, 0..2 = slot */
  slot: number | null;
}

/**
 * Weapon logic: inventory, draw/holster, fire control, reload, recoil and
 * hitscan. Posing the weapon in the character's hands is the animator's job —
 * this class only publishes a WeaponPose for it.
 */
export class Arsenal {
  slot = -1;
  ammo = WEAPONS.map((w) => w.mag);
  pose: WeaponPose | null = null;
  facing = false;
  ads = false;
  triggerActive = false;
  scopeW = 0;
  spread = 0;
  hits = 0;
  shots = 0;
  lastDist = 0;
  hitAge = 9;
  reloadK = 0;
  killAge = 9;
  /** power of the round that hit a zombie this shot (0 = none) */
  zPower = 0;
  /** zombies killed / killed by headshot with this arsenal */
  kills = 0;
  heads = 0;
  /** empty magazines reload themselves; low ones top up during a lull */
  autoReload = true;
  /** the running reload was started automatically (HUD) */
  autoReloading = false;
  /** AI-operated (teammate): own gun sound, no dry-fire click */
  readonly npc: boolean;
  headAge = 9;
  zombies: Horde | null = null;
  barrels: Barrels | null = null;
  /** first person: tracers start at the viewmodel muzzle (projected into the world) */
  muzzleOverride: THREE.Vector3 | null = null;
  private flashes: THREE.Object3D[] = [];
  /** reference tracer / smoke system (first-person engine port) */
  onTracer: (start: THREE.Vector3, end: THREE.Vector3, slot: number) => void = () => {};

  private objs: THREE.Object3D[];
  private mags: (THREE.Object3D | undefined)[];
  private pending: number | null = null;
  private lower = 0;
  private reloadT = 0;
  private cooldown = 0;
  private sinceFire = 9;
  private fireBuf = 0;
  private wantShot = false;
  private bloom = 0;
  private kickBack = new Spring(22, 0.55);
  private kickUp = new Spring(20, 0.6);
  private poseObj: WeaponPose;

  private flash: THREE.Mesh;
  private flashLight: THREE.PointLight;
  private flashT = 0;
  private tracers: { mesh: THREE.Mesh; t: number }[] = [];
  private tracerI = 0;
  private sparks = new Sparks();
  private rig: Rig;
  private terrain: Terrain;
  private range: Range;
  private foley: Foley;
  private o = new THREE.Vector3();
  private d = new THREE.Vector3();
  private e = new THREE.Vector3();
  private mz = new THREE.Vector3();
  private rt = new THREE.Vector3();
  private upv = new THREE.Vector3();

  constructor(
    scene: THREE.Scene,
    rig: Rig,
    terrain: Terrain,
    range: Range,
    foley: Foley,
    opts: { tp?: ReturnType<typeof buildThirdPersonWeapons>; light?: boolean; npc?: boolean } = {},
  ) {
    this.rig = rig;
    this.terrain = terrain;
    this.range = range;
    this.foley = foley;
    this.npc = !!opts.npc;
    // each operator carries its own models (the default set is the player's)
    const tp = opts.tp ?? TP;
    this.objs = opts.tp ? tp.map((t) => t.obj) : WEAPONS.map((w) => w.build());
    this.mags = this.objs.map((o) => o.getObjectByName('mag'));
    this.objs.forEach((_, i) => this.stow(i));
    this.poseObj = {
      obj: this.objs[0],
      def: WEAPONS[0],
      aim: false,
      ads: false,
      lower: 0,
      reload: 0,
      cycle: 0,
      kickBack: 0,
      kickUp: 0,
      aimYaw: 0,
      aimPitch: 0,
    };

    // muzzle flash (two crossed additive quads + light)
    const cv = document.createElement('canvas');
    cv.width = cv.height = 64;
    const g = cv.getContext('2d')!;
    const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,235,1)');
    gr.addColorStop(0.3, 'rgba(255,200,90,0.85)');
    gr.addColorStop(1, 'rgba(255,120,20,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 64);
    const fm = new THREE.MeshBasicMaterial({
      map: new THREE.CanvasTexture(cv),
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    });
    const fg = new THREE.PlaneGeometry(0.34, 0.34);
    const fg2 = fg.clone();
    fg2.rotateY(Math.PI / 2);
    const fg3 = new THREE.PlaneGeometry(0.2, 0.2);
    fg3.rotateX(Math.PI / 2);
    this.flash = new THREE.Mesh(fg, fm);
    this.flash.add(new THREE.Mesh(fg2, fm), new THREE.Mesh(fg3, fm));
    this.flash.visible = false;
    this.flashLight = new THREE.PointLight('#ffc070', 0, 9, 2);
    scene.add(this.flash);
    if (opts.light !== false) scene.add(this.flashLight);
    for (let i = 0; i < 3; i++) this.flashes.push(tp[i].flash);

    const tg = new THREE.CylinderGeometry(0.012, 0.012, 1, 6);
    tg.rotateX(Math.PI / 2);
    for (let i = 0; i < 12; i++) {
      const mesh = new THREE.Mesh(
        tg,
        new THREE.MeshBasicMaterial({
          color: '#ffe2a0',
          transparent: true,
          depthWrite: false,
          blending: THREE.AdditiveBlending,
        }),
      );
      mesh.visible = false;
      mesh.frustumCulled = false;
      scene.add(mesh);
      this.tracers.push({ mesh, t: 0 });
    }
    scene.add(this.sparks.points);
  }

  get armed() {
    return this.slot >= 0;
  }
  get def(): WeaponDef | null {
    return this.slot >= 0 ? WEAPONS[this.slot] : null;
  }
  get activeObj(): THREE.Object3D | null {
    return this.slot >= 0 ? this.objs[this.slot] : null;
  }

  /** Park a weapon on the body: long guns on the pack, pistol on the right thigh. */
  private stow(i: number) {
    const o = this.objs[i];
    const m = new THREE.Matrix4();
    const set = (parent: THREE.Object3D, pos: V3, fwd: V3, up: V3) => {
      const z = new THREE.Vector3(...fwd).normalize();
      const y = new THREE.Vector3(...up).normalize();
      const x = new THREE.Vector3().crossVectors(y, z).normalize();
      y.crossVectors(z, x);
      m.makeBasis(x, y, z);
      parent.add(o);
      o.position.set(...pos);
      o.quaternion.setFromRotationMatrix(m);
    };
    if (i === 0) set(this.rig.legs[1].thigh, [-0.1, -0.1, -0.01], [0, -1, 0.08], [0, 0, 1]);
    else if (i === 1) set(this.rig.chest, [-0.115, 0.17, -0.265], [0.28, -0.96, 0], [0, 0, -1]);
    else set(this.rig.chest, [0.12, -0.04, -0.27], [0.22, 0.975, 0], [0, 0, -1]);
  }

  private swap(to: number) {
    if (this.slot >= 0) this.stow(this.slot);
    this.slot = to;
    if (to >= 0) {
      this.rig.root.add(this.objs[to]);
      const mag = this.mags[to];
      if (mag) mag.visible = true;
    }
    this.reloadT = 0;
    this.cooldown = Math.max(this.cooldown, 0.2);
    this.foley.click(0.5);
  }

  private startReload(auto = false) {
    const def = this.def;
    if (!def || this.reloadT > 0 || this.ammo[this.slot] >= def.mag) return;
    this.reloadT = def.reload;
    this.autoReloading = auto;
    this.foley.click(0.8);
  }

  /** Timers, equip, reload and stance flags. Runs before the animator. */
  tick(dt: number, inp: ArsenalInput, c: CharacterController, aimYaw: number, aimPitch: number, firstPerson = false) {
    // ---- weapon selection
    if (inp.slot !== null && this.pending === null) {
      let s = inp.slot;
      if (s === -2) s = (this.slot + 1) % WEAPONS.length;
      else if (s === this.slot) s = -1; // pressing the active slot holsters
      if (s !== this.slot) this.pending = s;
    }
    if (this.pending !== null) {
      if (this.slot >= 0 && this.lower < 1) this.lower = Math.min(1, this.lower + dt / 0.16);
      else {
        this.swap(this.pending);
        this.pending = null;
        this.lower = 1;
      }
    } else if (this.lower > 0) this.lower = Math.max(0, this.lower - dt / 0.28);

    const def = this.def;
    this.cooldown -= dt;
    this.sinceFire += dt;
    this.hitAge += dt;
    this.killAge += dt;
    this.headAge += dt;
    if (inp.firePressed) this.fireBuf = 0.15;
    else this.fireBuf -= dt;
    this.triggerActive = !!def && (inp.fire || this.fireBuf > 0);

    // ---- reload
    this.reloadK = 0;
    if (def) {
      if (inp.reloadPressed && this.lower === 0) this.startReload();
      if (this.reloadT > 0) {
        const before = 1 - this.reloadT / def.reload;
        this.reloadT -= dt;
        const p = clamp01(1 - this.reloadT / def.reload);
        this.reloadK = Math.max(p, 0.001);
        const mag = this.mags[this.slot];
        if (mag) mag.visible = p < 0.25 || p > 0.6;
        if (before < 0.25 && p >= 0.25) this.foley.click(0.6);
        if (before < 0.6 && p >= 0.6) this.foley.click(1);
        if (this.reloadT <= 0) {
          this.ammo[this.slot] = def.mag;
          this.reloadK = 0;
          this.autoReloading = false;
        }
      }
      // ---- automatic reload: a dry magazine reloads at once, a low one tops up when the shooting stops
      if (this.autoReload && this.reloadT <= 0 && this.lower === 0 && this.pending === null) {
        const a = this.ammo[this.slot];
        if (a === 0 && this.cooldown <= 0.05) this.startReload(true);
        else if (a <= Math.max(1, Math.floor(def.mag * 0.3)) && this.sinceFire > 1.5 && !this.triggerActive && !inp.aim) this.startReload(true);
      }
    }

    // ---- fire control
    this.wantShot = false;
    if (def && this.lower < 0.05 && this.reloadT <= 0 && this.cooldown <= 0) {
      const want = def.mode === 'AUTO' ? inp.fire || this.fireBuf > 0 : this.fireBuf > 0;
      if (want) {
        this.fireBuf = 0;
        if (this.ammo[this.slot] > 0) this.wantShot = true;
        else {
          if (!this.npc) soundEngine.playDryFire();
          this.cooldown = 0.25;
          this.startReload(true);
        }
      }
    }

    // ---- stance
    this.facing = !!def && (inp.aim || this.triggerActive || this.sinceFire < 0.9);
    this.ads = !!def && inp.aim && !c.sprinting && this.reloadT <= 0 && this.lower < 0.3;
    this.scopeW = damp(this.scopeW, def && def.scope && this.ads ? 1 : 0, 11, dt);

    this.bloom = Math.max(0, this.bloom - dt * 0.05 - this.bloom * dt * 4);
    if (def) {
      const base = lerp(def.spreadHip, def.spreadAds, this.ads ? 1 : 0);
      const move = c.speed * 0.0035 * (this.ads ? 0.35 : 1) + (c.grounded ? 0 : 0.03);
      this.spread = damp(this.spread, base + move + this.bloom, 14, dt);
    } else this.spread = 0;

    this.kickBack.update(0, dt);
    this.kickUp.update(0, dt);

    if (def) {
      const p = this.poseObj;
      p.obj = this.objs[this.slot];
      p.def = def;
      // first person always presents the weapon (except while sprinting: it drops to the carry)
      p.aim = this.facing || (firstPerson && !c.sprinting);
      p.ads = this.ads;
      p.lower = this.lower;
      p.reload = this.reloadK;
      p.cycle = def.mode === 'BOLT' && this.cooldown > 0 && this.sinceFire < def.interval ? clamp01(this.sinceFire / def.interval) : 0;
      p.kickBack = Math.max(0, -this.kickBack.x);
      p.kickUp = Math.max(-0.05, -this.kickUp.x);
      p.aimYaw = aimYaw;
      p.aimPitch = aimPitch;
      this.pose = p;
    } else this.pose = null;
  }

  /**
   * Resolve a shot. Runs after the camera so the ray goes exactly through the
   * crosshair; the tracer is drawn from the real muzzle to the hit point.
   * Returns the view-kick to apply, or 0.
   */
  shoot(cam: THREE.PerspectiveCamera, tMin: number): number {
    const def = this.def;
    if (!this.wantShot || !def) return 0;
    this.wantShot = false;
    this.ammo[this.slot]--;
    this.shots++;
    this.cooldown = def.interval;
    this.sinceFire = 0;

    cam.getWorldDirection(this.d);
    this.rt.crossVectors(this.d, cam.up).normalize();
    this.upv.crossVectors(this.rt, this.d);
    const a = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random()) * this.spread;
    this.d.addScaledVector(this.rt, Math.cos(a) * r).addScaledVector(this.upv, Math.sin(a) * r).normalize();
    this.o.copy(cam.position);

    const MAX = 240;
    let tT = this.terrain.raycast(this.o.x, this.o.y, this.o.z, this.d.x, this.d.y, this.d.z, tMin, MAX);
    const bh = this.barrels ? this.barrels.raycast(this.o, this.d, tMin, Math.min(tT, MAX)) : null;
    if (bh) tT = bh.t;
    let hit = this.range.raycast(this.o, this.d, tMin, Math.min(tT, MAX));
    let t = hit ? hit.t : Math.min(tT, MAX);
    let zHit = false;
    const Z = this.zombies;
    if (Z) {
      const spec = SHOT[this.slot];
      this.zPower = 0;
      const zh = Z.raycast(this.o, this.d, tMin, t);
      const n = Math.min(zh.length, spec.pen);
      for (let i = 0; i < n; i++) {
        const z = zh[i].z;
        const wasAlive = z.alive;
        const head = zh[i].seg <= 1;
        Z.hit(zh[i], this.d, i === 0 ? spec : { ...spec, dmg: spec.dmg * 0.65, impulse: spec.impulse * 0.7, knock: (spec.knock ?? 0) * 0.75, fragK: (spec.fragK ?? 0.8) * 0.8 });
        this.zPower = Math.max(this.zPower, spec.power);
        if (wasAlive && !z.alive) {
          this.killAge = 0;
          this.kills++;
          if (head) {
            this.headAge = 0;
            this.heads++;
          }
        }
        zHit = true;
      }
      if (n > 0 && (n >= spec.pen || spec.pen === 1)) {
        t = zh[n - 1].t;
        hit = null;
      }
      Z.noise(cam.position.x, cam.position.z, NOISE[this.slot]);
    }
    this.e.copy(this.o).addScaledVector(this.d, t);

    const obj = this.objs[this.slot];
    obj.updateMatrixWorld(true);
    this.mz.set(...def.muzzle).applyMatrix4(obj.matrixWorld);
    if (this.muzzleOverride) this.mz.copy(this.muzzleOverride);
    if (bh && t >= bh.t - 1e-3) this.barrels!.hit(bh.i, this.e);

    // tracer
    this.onTracer(this.mz, this.e, this.slot);
    const tr = this.tracers[this.tracerI];
    this.tracerI = (this.tracerI + 1) % this.tracers.length;
    const len = this.mz.distanceTo(this.e);
    tr.mesh.position.copy(this.mz).lerp(this.e, 0.5);
    tr.mesh.lookAt(this.e);
    tr.mesh.scale.set(1 + len * 0.02, 1 + len * 0.02, len);
    tr.mesh.visible = false;
    tr.t = 0;

    // flash
    const fs = (this.slot === 2 ? 1.5 : this.slot === 1 ? 1.1 : 0.8) * (0.8 + Math.random() * 0.4);
    const sf = this.flashes[this.slot];
    if (!this.muzzleOverride) {
      // the reference rig's own muzzle flash, on the real muzzle (first person shows the viewmodel's)
      sf.rotation.z = Math.random() * Math.PI * 2;
      const k = 0.88 + Math.random() * 0.26;
      sf.scale.set(k, k, k);
      sf.visible = true;
    }
    this.flashLight.position.copy(this.mz);
    this.flashLight.intensity = 6 * fs;
    this.flashT = this.slot === 2 ? 0.095 : this.slot === 1 ? 0.058 : 0.052;

    // impact
    if (zHit) {
      this.hits++;
      this.hitAge = 0;
      this.lastDist = this.mz.distanceTo(this.e);
      this.foley.splat(this.lastDist * 0.3);
    }
    if (hit) {
      this.range.hit(hit.index, this.slot === 2 ? 2 : 1);
      this.hits++;
      this.hitAge = 0;
      this.lastDist = this.mz.distanceTo(this.e);
      this.sparks.emit(this.e, 10, 1.2, 3.2, 1, 0.75, 0.3);
      this.foley.ping();
    } else if (tT < MAX && !zHit) {
      this.sparks.emit(this.e, 9, 1.6, 2.2, 0.95, 0.97, 1);
    }

    // recoil
    this.kickBack.v -= def.kickBack;
    this.kickUp.v -= def.kickUp * 110;
    this.bloom += def.bloom;
    if (this.npc) this.foley.shot(this.slot);
    else soundEngine.playShot(IDS[this.slot], false, 0.15, this.ammo[this.slot] === 0);
    return def.kickUp * (this.ads ? 0.75 : 1);
  }

  updateFx(dt: number) {
    if (this.flashT > 0) {
      this.flashT -= dt;
      if (this.flashT <= 0) {
        this.flash.visible = false;
        for (const f of this.flashes) f.visible = false;
        this.flashLight.intensity = 0;
      }
    }
    for (const tr of this.tracers) {
      if (tr.t <= 0) continue;
      tr.t -= dt;
      (tr.mesh.material as THREE.MeshBasicMaterial).opacity = clamp01(tr.t / 0.075);
      if (tr.t <= 0) tr.mesh.visible = false;
    }
    this.sparks.update(dt);
  }
}
