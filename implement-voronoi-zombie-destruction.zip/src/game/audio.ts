/** Tiny synthesised foley: snow-crunch footsteps and landing thumps. */
export class Foley {
  muted = false;
  private ctx: AudioContext | null = null;
  private noise: AudioBuffer | null = null;
  private master: GainNode | null = null;
  private shotBus: GainNode | null = null;
  private verb: GainNode | null = null;

  /** Must be called from a user gesture. */
  unlock() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume();
      return;
    }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
      const len = this.ctx.sampleRate * 0.4;
      this.noise = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noise.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
      // gun bus: soft-clip waveshaper -> compressor -> master, with a convolution reverb send
      const ctx = this.ctx;
      const shaper = ctx.createWaveShaper();
      const curve = new Float32Array(1024);
      for (let i = 0; i < 1024; i++) {
        const x = (i / 1023) * 2 - 1;
        curve[i] = Math.tanh(x * 2.6) / Math.tanh(2.6);
      }
      shaper.curve = curve;
      const comp = ctx.createDynamicsCompressor();
      comp.threshold.value = -16;
      comp.ratio.value = 5;
      comp.attack.value = 0.002;
      comp.release.value = 0.18;
      this.shotBus = ctx.createGain();
      this.shotBus.gain.value = 0.85;
      this.shotBus.connect(shaper).connect(comp).connect(this.master);
      const conv = ctx.createConvolver();
      const irLen = Math.floor(ctx.sampleRate * 1.8);
      const ir = ctx.createBuffer(2, irLen, ctx.sampleRate);
      for (let c = 0; c < 2; c++) {
        const d = ir.getChannelData(c);
        for (let i = 0; i < irLen; i++) {
          const t = i / ctx.sampleRate;
          // early slap-back from the forest edge + diffuse open-air tail
          const slap = t > 0.07 && t < 0.09 ? 0.6 : 0;
          d[i] = (Math.random() * 2 - 1) * (Math.exp(-t * 3.2) * 0.5 + slap * Math.exp(-(t - 0.07) * 40));
        }
      }
      conv.buffer = ir;
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 2400;
      this.verb = ctx.createGain();
      this.verb.gain.value = 0.35;
      this.verb.connect(lp).connect(conv).connect(comp);
    } catch {
      this.ctx = null;
    }
  }

  step(strength: number, side: number) {
    const ctx = this.ctx;
    if (!ctx || !this.noise || !this.master || this.muted || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = 0.7 + Math.random() * 0.35;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 900 + Math.random() * 700 + strength * 500;
    bp.Q.value = 0.8;
    const g = ctx.createGain();
    const vol = 0.05 + 0.2 * strength;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0008, t + 0.11 + strength * 0.08);
    const pan = ctx.createStereoPanner ? ctx.createStereoPanner() : null;
    src.connect(bp).connect(g);
    if (pan) {
      pan.pan.value = -side * 0.18;
      g.connect(pan).connect(this.master);
    } else g.connect(this.master);
    src.start(t, Math.random() * 0.2, 0.25);

    if (strength > 0.65) {
      // low body thump for landings
      const o = ctx.createOscillator();
      const og = ctx.createGain();
      o.frequency.setValueAtTime(95, t);
      o.frequency.exponentialRampToValueAtTime(42, t + 0.14);
      og.gain.setValueAtTime(0.22 * strength, t);
      og.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      o.connect(og).connect(this.master);
      o.start(t);
      o.stop(t + 0.2);
    }
  }

  private burst(dur: number, freq: number, q: number, vol: number, type: BiquadFilterType = 'bandpass') {
    const ctx = this.ctx;
    if (!ctx || !this.noise || !this.master || this.muted || ctx.state !== 'running') return null;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = 0.8 + Math.random() * 0.4;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.value = freq;
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    src.connect(f).connect(g).connect(this.master);
    src.start(t, Math.random() * 0.1, dur + 0.05);
    return { ctx, t };
  }

  private thump(f0: number, f1: number, dur: number, vol: number) {
    const ctx = this.ctx;
    if (!ctx || !this.master || this.muted || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  /** One noise layer into the gun bus (and the reverb send). */
  private layer(t0: number, dur: number, type: BiquadFilterType, f0: number, f1: number, q: number, vol: number, send = 0.5, rate = 1) {
    const ctx = this.ctx!;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    src.playbackRate.value = rate * (0.95 + Math.random() * 0.1);
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(f0, t0);
    f.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t0 + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0008, t0 + dur);
    src.connect(f).connect(g);
    g.connect(this.shotBus!);
    if (send > 0 && this.verb) {
      const sg = ctx.createGain();
      sg.gain.value = send;
      g.connect(sg).connect(this.verb);
    }
    src.start(t0, Math.random() * 0.15, dur + 0.05);
  }
  private boom(t0: number, f0: number, f1: number, dur: number, vol: number, send = 0.4) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(f0, t0);
    o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
    o.connect(g).connect(this.shotBus!);
    if (this.verb && send > 0) {
      const sg = ctx.createGain();
      sg.gain.value = send;
      g.connect(sg).connect(this.verb);
    }
    o.start(t0);
    o.stop(t0 + dur + 0.02);
  }

  /** Gunshot: 0 pistol (snappy bark + slide), 1 rifle (supersonic crack), 2 sniper (huge blast + bolt). */
  shot(kind: number) {
    const ctx = this.ok();
    if (!ctx || !this.shotBus) return;
    const t = ctx.currentTime;
    const j = 0.95 + Math.random() * 0.1;
    if (kind === 0) {
      this.layer(t, 0.025, 'highpass', 2400, 1800, 0.7, 1.1, 0.2, 1.2); // primer snap
      this.layer(t, 0.15, 'bandpass', 2100 * j, 380, 0.7, 1.15, 0.6); // propellant bark
      this.boom(t, 170 * j, 55, 0.12, 0.9); // chest thump
      this.layer(t + 0.035, 0.03, 'bandpass', 3800, 3000, 4, 0.18, 0.1); // slide back
      this.layer(t + 0.075, 0.025, 'bandpass', 3200, 2600, 5, 0.16, 0.1); // slide home
    } else if (kind === 1) {
      this.layer(t, 0.018, 'highpass', 5200, 4000, 0.8, 1.0, 0.15, 1.3); // supersonic whip
      this.layer(t, 0.12, 'bandpass', 1700 * j, 320, 0.6, 1.2, 0.7);
      this.layer(t, 0.22, 'lowpass', 900, 160, 0.7, 0.6, 0.8);
      this.boom(t, 140 * j, 45, 0.15, 1.0);
      this.layer(t + 0.03, 0.02, 'bandpass', 4200, 3500, 6, 0.12, 0); // bolt carrier
    } else {
      this.layer(t, 0.03, 'highpass', 3500, 2500, 0.7, 1.2, 0.3, 1.1);
      this.layer(t, 0.4, 'bandpass', 1100 * j, 160, 0.5, 1.35, 1.0);
      this.layer(t, 1.1, 'lowpass', 600, 60, 0.5, 0.6, 1.2); // rolling thunder tail
      this.boom(t, 95, 28, 0.38, 1.25, 0.6);
    }
  }

  /** Barrel explosion: crack, deep boom, debris rattle and a long rumble. */
  explosion(dist: number) {
    const ctx = this.ok();
    if (!ctx || !this.shotBus) return;
    const v = Math.min(1.2, 2.2 / (1 + dist * 0.12));
    const t = ctx.currentTime + Math.min(0.25, dist / 340);
    this.layer(t, 0.05, 'highpass', 3000, 1500, 0.6, 1.3 * v, 0.4);
    this.layer(t, 0.6, 'bandpass', 900, 90, 0.4, 1.4 * v, 1.2);
    this.layer(t, 2.4, 'lowpass', 420, 35, 0.4, 0.9 * v, 1.5, 0.6);
    this.boom(t, 75, 22, 0.9, 1.5 * v, 0.8);
    this.boom(t + 0.05, 48, 18, 1.4, 1.0 * v, 0.6);
    for (let i = 0; i < 6; i++) this.layer(t + 0.25 + Math.random() * 0.9, 0.05, 'bandpass', 2500 + Math.random() * 2500, 1800, 3, 0.12 * v, 0.3);
  }

  /** Metallic ping when a barrel is hit. */
  clang() {
    this.burst(0.25, 1800, 8, 0.2);
    this.thump(420, 300, 0.2, 0.15);
  }

  /** Mechanical click (dry fire, magazine, draw). */
  click(strength: number) {
    this.burst(0.03, 3200 + strength * 1200, 2.5, 0.12 + 0.14 * strength);
    this.thump(900, 500, 0.02, 0.05 * strength);
  }

  private ok() {
    const ctx = this.ctx;
    return ctx && this.noise && this.master && !this.muted && ctx.state === 'running' ? ctx : null;
  }
  private atten(dist: number) {
    return 1 / (1 + dist * 0.18);
  }

  /** Throaty undead moan: buzzing source through two vocal formants. */
  groan(dist: number, size = 1) {
    const ctx = this.ok();
    if (!ctx || !this.master) return;
    const t = ctx.currentTime;
    const dur = 0.9 + Math.random() * 1.1;
    const vol = 0.32 * this.atten(dist);
    if (vol < 0.02) return;
    const o = ctx.createOscillator();
    o.type = 'sawtooth';
    const f0 = (70 + Math.random() * 45) / size;
    o.frequency.setValueAtTime(f0 * 1.15, t);
    o.frequency.linearRampToValueAtTime(f0, t + dur * 0.4);
    o.frequency.linearRampToValueAtTime(f0 * 0.82, t + dur);
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 5 + Math.random() * 5;
    const lg = ctx.createGain();
    lg.gain.value = f0 * 0.08;
    lfo.connect(lg).connect(o.frequency);
    const f1 = ctx.createBiquadFilter();
    f1.type = 'bandpass';
    f1.frequency.value = 420 + Math.random() * 200;
    f1.Q.value = 4;
    const f2 = ctx.createBiquadFilter();
    f2.type = 'bandpass';
    f2.frequency.value = 900 + Math.random() * 300;
    f2.Q.value = 6;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.15);
    g.gain.linearRampToValueAtTime(vol * 0.7, t + dur * 0.7);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(f1).connect(g);
    o.connect(f2).connect(g);
    g.connect(this.master);
    o.start(t);
    lfo.start(t);
    o.stop(t + dur + 0.05);
    lfo.stop(t + dur + 0.05);
    // breathy rasp
    const b = this.burst(dur * 0.8, 700, 1.2, vol * 0.35);
    void b;
  }

  /** Runner's shriek when it spots you. */
  scream(dist: number) {
    const ctx = this.ok();
    if (!ctx || !this.master) return;
    const t = ctx.currentTime;
    const dur = 0.7 + Math.random() * 0.4;
    const vol = 0.3 * this.atten(dist);
    const o = ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(260 + Math.random() * 80, t);
    o.frequency.linearRampToValueAtTime(520 + Math.random() * 120, t + 0.12);
    o.frequency.exponentialRampToValueAtTime(220, t + dur);
    const f = ctx.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = 1400;
    f.Q.value = 2;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.05);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(f).connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.05);
    this.burst(dur, 2400, 0.8, vol * 0.4);
  }

  zstep(dist: number, heavy: boolean) {
    const v = (heavy ? 0.12 : 0.07) * this.atten(dist);
    if (v < 0.015) return;
    this.burst(0.09, 700 + Math.random() * 500, 0.9, v);
  }

  /** Body slamming into the snow. */
  thud(dist: number) {
    const v = this.atten(dist);
    this.thump(80, 38, 0.22, 0.5 * v);
    this.burst(0.18, 500, 0.7, 0.25 * v, 'lowpass');
  }

  /** Wet flesh impact; `big` for torn limbs and burst heads. */
  splat(dist: number, big = false) {
    const v = this.atten(Math.min(dist, 30));
    this.burst(big ? 0.35 : 0.14, big ? 450 : 800, 0.8, (big ? 0.55 : 0.3) * v, 'lowpass');
    if (big) {
      this.burst(0.08, 2600, 3, 0.25 * v); // bone crack
      this.thump(140, 50, 0.12, 0.35 * v);
    }
  }

  /** Player takes a hit. */
  hurt() {
    this.thump(120, 45, 0.18, 0.6);
    this.burst(0.2, 900, 0.6, 0.3, 'lowpass');
  }

  /** Steel target ring. */
  ping() {
    const ctx = this.ctx;
    if (!ctx || !this.master || this.muted || ctx.state !== 'running') return;
    const t = ctx.currentTime;
    for (const [f, v, d] of [
      [1480 + Math.random() * 120, 0.16, 0.5],
      [2350 + Math.random() * 150, 0.09, 0.35],
      [3900, 0.04, 0.2],
    ]) {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = f;
      g.gain.setValueAtTime(v, t);
      g.gain.exponentialRampToValueAtTime(0.0008, t + d);
      o.connect(g).connect(this.master);
      o.start(t);
      o.stop(t + d + 0.02);
    }
  }
}
