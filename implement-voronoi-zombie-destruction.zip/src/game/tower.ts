import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { Terrain } from './terrain';

/* ---------------------------------------------------------------------------
 * WATCHTOWER
 * Visual architecture for the tower / stair boxes in the terrain height field:
 * a two-storey concrete block (floor band at 3.24 m, windows on both floors,
 * steel door), an arrival annex, a snow-dusted roof deck with safety railings
 * and a concrete stair whose treads carry snow and yellow anti-slip nosing.
 * Everything matches the walkable surfaces exactly (what you see is what the
 * player, the teammate, the zombies and the ragdolls stand on).
 * ------------------------------------------------------------------------- */
const hash = (x: number, y: number, z: number) => {
  const s = Math.sin(x * 127.1 + y * 311.7 + z * 74.7) * 43758.5453;
  return s - Math.floor(s);
};
const C = (h: string) => new THREE.Color(h);
const CONCRETE = C('#8e949b');
const BAND = C('#a7acb2');
const STAIR = C('#80868d');
const SNOW = C('#dfe6ee');
const NOSING = C('#e0a43a');
const FRAME = C('#b9bdc2');

/** Box with per-face vertex colours (top = `top`), grime noise and darker splash zone near the ground. */
function box(w: number, h: number, d: number, x: number, y: number, z: number, side: THREE.Color, top: THREE.Color, seg = 1, grime = 0.14) {
  const g = new THREE.BoxGeometry(w, h, d, Math.max(1, Math.round(w * seg)), Math.max(1, Math.round(h * seg)), Math.max(1, Math.round(d * seg)));
  g.translate(x, y, z);
  const p = g.attributes.position;
  const n = g.attributes.normal;
  const c = new Float32Array(p.count * 3);
  for (let i = 0; i < p.count; i++) {
    const up = n.getY(i) > 0.7;
    const b = up ? top : side;
    const px = p.getX(i);
    const py = p.getY(i);
    const pz = p.getZ(i);
    let k = 1 - grime * hash(Math.floor(px * 2.3), Math.floor(py * 2.3), Math.floor(pz * 2.3));
    if (!up) k *= 1 - Math.max(0, 0.22 - py * 0.16); // dirt / snow-melt splash at the foot of the walls
    if (!up && py > 0) k *= 1 - 0.06 * Math.max(0, Math.sin(px * 3.1 + pz * 2.7)) * hash(px, 0, pz); // rain streaks
    c[i * 3] = b.r * k;
    c[i * 3 + 1] = b.g * k;
    c[i * 3 + 2] = b.b * k;
  }
  g.setAttribute('color', new THREE.BufferAttribute(c, 3));
  return g;
}

export function buildTower(scene: THREE.Scene, terrain: Terrain) {
  const T = terrain.tower;
  const concrete: THREE.BufferGeometry[] = [];
  const glassDark: THREE.BufferGeometry[] = [];
  const glassLit: THREE.BufferGeometry[] = [];
  const steel: THREE.BufferGeometry[] = [];
  const BASE = -0.5;

  // ---- tower blocks (main + annex), floor bands
  for (const b of terrain.boxes) {
    if (b.style !== 'tower') continue;
    const w = b.x1 - b.x0;
    const d = b.z1 - b.z0;
    const cx = (b.x0 + b.x1) / 2;
    const cz = (b.z0 + b.z1) / 2;
    concrete.push(box(w, b.h - BASE, d, cx, (b.h + BASE) / 2, cz, CONCRETE, SNOW, 1.4));
    concrete.push(box(w + 0.24, 0.26, d + 0.24, cx, T.floor, cz, BAND, BAND, 1, 0.08)); // slab edge between the floors
    concrete.push(box(w + 0.12, 0.12, d + 0.12, cx, b.h - 0.06, cz, BAND, SNOW, 1, 0.08)); // roof lip (flush with the deck)
  }

  // ---- stairs + landings: solid concrete with snowy treads and anti-slip nosing on every riser
  for (const b of terrain.boxes) {
    if (b.style !== 'stair' && b.style !== 'landing') continue;
    const w = b.x1 - b.x0;
    const d = b.z1 - b.z0;
    const cx = (b.x0 + b.x1) / 2;
    const cz = (b.z0 + b.z1) / 2;
    concrete.push(box(w, b.h - BASE, d, cx, (b.h + BASE) / 2, cz, STAIR, SNOW, 1.6, 0.1));
    if (b.style !== 'stair') continue;
    // riser = the short side that faces lower ground
    const alongX = w < d; // run along x (flight 2) → risers face ±x
    const cands: [number, number, number][] = alongX
      ? [[b.x0 - 0.08, cz, -1], [b.x1 + 0.08, cz, 1]]
      : [[cx, b.z0 - 0.08, -1], [cx, b.z1 + 0.08, 1]];
    let best = cands[0];
    let lo = Infinity;
    for (const c of cands) {
      const h = terrain.height(c[0], c[1]);
      if (h < lo) {
        lo = h;
        best = c;
      }
    }
    if (alongX) {
      const x = best[2] < 0 ? b.x0 + 0.035 : b.x1 - 0.035;
      concrete.push(box(0.07, 0.03, d - 0.08, x, b.h - 0.011, cz, NOSING, NOSING, 1, 0.05));
    } else {
      const z = best[2] < 0 ? b.z0 + 0.035 : b.z1 - 0.035;
      concrete.push(box(w - 0.08, 0.03, 0.07, cx, b.h - 0.011, z, NOSING, NOSING, 1, 0.05));
    }
  }

  // ---- windows (both floors, every face; those behind the stair mass are naturally hidden)
  let lit = 0;
  const window = (x: number, y: number, z: number, nx: number, nz: number) => {
    const w = 1.0;
    const h = 1.15;
    const tx = -nz;
    const tz = nx;
    const ox = x + nx * 0.012;
    const oz = z + nz * 0.012;
    const gw = Math.abs(tx) * w + Math.abs(nx) * 0.02;
    const gd = Math.abs(tz) * w + Math.abs(nz) * 0.02;
    const glass = new THREE.BoxGeometry(gw, h, gd);
    glass.translate(ox, y, oz);
    ((lit++ * 7) % 10 < 3 ? glassLit : glassDark).push(glass);
    // frame + sill
    const fw = (len: number, th: number) => [Math.abs(tx) * len + Math.abs(nx) * 0.07, th, Math.abs(tz) * len + Math.abs(nz) * 0.07] as const;
    const [a, bh, c] = fw(w + 0.16, 0.08);
    concrete.push(box(a, bh, c, x + nx * 0.035, y + h / 2 + 0.04, z + nz * 0.035, FRAME, FRAME, 1, 0.05));
    concrete.push(box(a, 0.1, c, x + nx * 0.06, y - h / 2 - 0.05, z + nz * 0.06, FRAME, SNOW, 1, 0.05)); // sill with snow
    const [sa, , sc] = fw(0.08, 0);
    for (const s of [-1, 1]) concrete.push(box(sa, h, sc, x + nx * 0.035 + tx * s * (w / 2 + 0.04), y, z + nz * 0.035 + tz * s * (w / 2 + 0.04), FRAME, FRAME, 1, 0.05));
    // mullion
    concrete.push(box(sa * 0.6 + Math.abs(nx) * 0.02, h, sc * 0.6 + Math.abs(nz) * 0.02, x + nx * 0.03, y, z + nz * 0.03, FRAME, FRAME, 1, 0.05));
  };
  const floors = [1.75, T.floor + 1.75];
  const cxT = (T.x0 + T.x1) / 2;
  const czT = (T.z0 + T.z1) / 2;
  for (const y of floors) {
    for (const o of [-1.5, 1.5]) {
      window(cxT + o, y, T.z0, 0, -1); // south
      window(T.x0, y, czT + o, -1, 0); // west
      window(T.x1, y, czT + o, 1, 0); // east
    }
    window(cxT - 0.6, y + (y < T.floor ? 0.0 : 0), T.z1, 0, 1); // north (left of the annex)
    window(2, y, 3, 0, 1); // annex north
    window(4, y, 3, 0, 1);
    window(5, y, 2, 1, 0); // annex east
  }

  // ---- steel door on the ground floor (north face) with a lamp above it
  const doorG = new THREE.BoxGeometry(1.05, 2.15, 0.06);
  doorG.translate(-2.2, 1.075, T.z1 + 0.03);
  concrete.push(box(1.25, 0.12, 0.14, -2.2, 2.22, T.z1 + 0.07, FRAME, SNOW, 1, 0.05));
  const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.1, 0.12), new THREE.MeshStandardMaterial({ color: '#2b2f35', emissive: '#ffcf8a', emissiveIntensity: 1.6 }));
  lamp.position.set(-2.2, 2.42, T.z1 + 0.1);
  scene.add(lamp);

  // ---- safety railings along every railed deck edge (match the movement barriers exactly)
  for (const r of terrain.rails) {
    const alongX = r.x1 - r.x0 > r.z1 - r.z0;
    const len = alongX ? r.x1 - r.x0 : r.z1 - r.z0;
    const cx = (r.x0 + r.x1) / 2;
    const cz = (r.z0 + r.z1) / 2;
    const posts = Math.max(2, Math.round(len / 1.0) + 1);
    for (let i = 0; i < posts; i++) {
      const t = i / (posts - 1);
      const px = alongX ? r.x0 + t * len : cx;
      const pz = alongX ? cz : r.z0 + t * len;
      const g = new THREE.BoxGeometry(0.055, 1.04, 0.055);
      g.translate(px, r.y + 0.52, pz);
      steel.push(g);
    }
    for (const [hy, th] of [[1.02, 0.06], [0.52, 0.035], [0.08, 0.1]] as const) {
      const g = new THREE.BoxGeometry(alongX ? len : 0.05, th, alongX ? 0.05 : len);
      g.translate(cx, r.y + hy, cz);
      steel.push(g);
    }
  }
  // antenna mast in the annex corner with an aircraft-warning light
  const mast = new THREE.CylinderGeometry(0.028, 0.04, 3.4, 6);
  mast.translate(4.96, T.h + 1.7, 2.96);
  steel.push(mast);
  const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), new THREE.MeshBasicMaterial({ color: '#ff3b30' }));
  beacon.position.set(4.96, T.h + 3.45, 2.96);
  scene.add(beacon);

  // ---- meshes
  const strip = (gs: THREE.BufferGeometry[]) => gs.map((g) => {
    g.deleteAttribute('uv');
    return g.index ? g.toNonIndexed() : g;
  });
  const concreteMesh = new THREE.Mesh(mergeGeometries(strip(concrete))!, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.93, metalness: 0 }));
  concreteMesh.castShadow = concreteMesh.receiveShadow = true;
  scene.add(concreteMesh);
  if (glassDark.length) {
    const m = new THREE.Mesh(mergeGeometries(strip(glassDark))!, new THREE.MeshStandardMaterial({ color: '#1b2430', roughness: 0.12, metalness: 0.65 }));
    m.receiveShadow = true;
    scene.add(m);
  }
  if (glassLit.length) {
    const m = new THREE.Mesh(mergeGeometries(strip(glassLit))!, new THREE.MeshStandardMaterial({ color: '#2e2216', roughness: 0.3, metalness: 0.1, emissive: '#ffae52', emissiveIntensity: 0.85 }));
    scene.add(m);
  }
  const steelMesh = new THREE.Mesh(mergeGeometries(strip(steel))!, new THREE.MeshStandardMaterial({ color: '#d79d32', roughness: 0.45, metalness: 0.55 }));
  steelMesh.castShadow = steelMesh.receiveShadow = true;
  scene.add(steelMesh);
  const door = new THREE.Mesh(doorG, new THREE.MeshStandardMaterial({ color: '#39404a', roughness: 0.45, metalness: 0.6 }));
  door.castShadow = door.receiveShadow = true;
  scene.add(door);
}
