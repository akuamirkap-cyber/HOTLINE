import { WeaponId } from './types';

export type FootstepSurface = 'concrete' | 'asphalt' | 'grass';
export type FootstepStance = 'crouch' | 'walk' | 'sprint';

class SoundEngine {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private masterComp: DynamicsCompressorNode | null = null;
  private gunShaper: WaveShaperNode | null = null;
  private indoorReverb: ConvolverNode | null = null;
  private outdoorReverb: ConvolverNode | null = null;
  private indoorWetGain: GainNode | null = null;
  private outdoorWetGain: GainNode | null = null;
  private muted = false;

  public unlock() {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.setupMasterGraph();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setMuted(m: boolean) {
    this.muted = m;
  }

  public isMuted(): boolean {
    return this.muted;
  }

  private setupMasterGraph() {
    if (!this.ctx) return;
    const ctx = this.ctx;

    // 1. High-resolution 3-second stereo-safe broadband noise source
    const length = ctx.sampleRate * 3;
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    this.noiseBuffer = buffer;

    // 2. Master Bus Compressor (glues punchy gunfire, footsteps & impacts with authentic bodycam dynamics!)
    this.masterComp = ctx.createDynamicsCompressor();
    this.masterComp.threshold.value = -10;
    this.masterComp.knee.value = 12;
    this.masterComp.ratio.value = 5.5;
    this.masterComp.attack.value = 0.002;
    this.masterComp.release.value = 0.14;

    const masterOut = ctx.createGain();
    masterOut.gain.value = 0.94;
    this.masterComp.connect(masterOut);
    masterOut.connect(ctx.destination);

    // 3. Analog Soft-Clipper / Bodycam Mic Saturation Bus for realistic visceral firearm transients!
    this.gunShaper = ctx.createWaveShaper();
    this.gunShaper.curve = this.makeSoftClipCurve(2.4);
    this.gunShaper.oversample = '2x';
    this.gunShaper.connect(this.masterComp);

    // 4. Stereo Algorithmic Concrete Hall Reverb (Abandoned Graffiti Building interior slapback + tail!)
    this.indoorReverb = ctx.createConvolver();
    this.indoorReverb.buffer = this.buildImpulseResponse(1.42, 3.1, true);
    this.indoorWetGain = ctx.createGain();
    this.indoorWetGain.gain.value = 0.44;
    this.indoorReverb.connect(this.indoorWetGain);
    this.indoorWetGain.connect(this.masterComp);

    // 5. Stereo Open Outdoor Courtyard / Mountain Valley Echo Tail
    this.outdoorReverb = ctx.createConvolver();
    this.outdoorReverb.buffer = this.buildImpulseResponse(1.9, 4.2, false);
    this.outdoorWetGain = ctx.createGain();
    this.outdoorWetGain.gain.value = 0.28;
    this.outdoorReverb.connect(this.outdoorWetGain);
    this.outdoorWetGain.connect(this.masterComp);
  }

  private makeSoftClipCurve(drive: number): Float32Array<ArrayBuffer> {
    const samples = 2048;
    const buf = new ArrayBuffer(samples * 4);
    const curve = new Float32Array(buf);
    const norm = Math.tanh(drive);
    for (let i = 0; i < samples; i++) {
      const x = (i * 2) / samples - 1;
      curve[i] = Math.tanh(x * drive) / norm;
    }
    return curve;
  }

  private buildImpulseResponse(durationSec: number, decayPower: number, isConcreteHall: boolean): AudioBuffer {
    const ctx = this.ctx!;
    const sr = ctx.sampleRate;
    const len = Math.floor(sr * durationSec);
    const ir = ctx.createBuffer(2, len, sr);

    // Distinct early concrete wall slap reflections for indoor abandoned warehouse vs wide open valley
    const earlyTapsMs = isConcreteHall
      ? [16, 29, 44, 67, 94, 128, 172]
      : [48, 95, 165, 240, 340];

    for (let ch = 0; ch < 2; ch++) {
      const channel = ir.getChannelData(ch);
      let lpState = 0;
      for (let i = 0; i < len; i++) {
        const t = i / len;
        const env = Math.pow(1 - t, decayPower);
        const white = Math.random() * 2 - 1;
        // Progressive high-frequency air absorption as reverb tail decays
        const cutoff = isConcreteHall ? 0.36 - t * 0.24 : 0.28 - t * 0.2;
        lpState += (white - lpState) * Math.max(0.035, cutoff);
        channel[i] = lpState * env * (isConcreteHall ? 0.85 : 0.72);
      }

      // Inject crisp stereo early wall reflection impulses
      earlyTapsMs.forEach((ms, idx) => {
        const jitter = (ch === 0 ? 1 : -1) * (1.5 + idx * 0.6);
        const sampleIdx = Math.floor(((ms + jitter) / 1000) * sr);
        const amp = (isConcreteHall ? 0.62 : 0.36) * Math.pow(0.78, idx);
        for (let k = 0; k < 24 && sampleIdx + k < len; k++) {
          channel[sampleIdx + k] += (Math.random() * 2 - 1) * amp * (1 - k / 24);
        }
      });
    }
    return ir;
  }

  private ensureReady(): AudioContext | null {
    if (this.muted) return null;
    if (!this.ctx) this.unlock();
    if (!this.ctx || !this.noiseBuffer || !this.masterComp || !this.gunShaper) return null;
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private createNoiseSource(rate = 1.0): { src: AudioBufferSourceNode; offset: number } {
    const src = this.ctx!.createBufferSource();
    src.buffer = this.noiseBuffer!;
    src.loop = true;
    src.playbackRate.value = rate;
    const offset = Math.random() * Math.max(0.5, this.noiseBuffer!.duration - 0.6);
    return { src, offset };
  }

  private routeReverbSend(sourceNode: AudioNode, indoorAmount: number, sendLevel: number) {
    if (!this.ctx || !this.indoorReverb || !this.outdoorReverb) return;
    const ind = Math.max(0, Math.min(1, indoorAmount));
    if (ind > 0.04) {
      const gIn = this.ctx.createGain();
      gIn.gain.value = sendLevel * (0.38 + ind * 0.92);
      sourceNode.connect(gIn);
      gIn.connect(this.indoorReverb);
    }
    if (ind < 0.96) {
      const gOut = this.ctx.createGain();
      gOut.gain.value = sendLevel * (1 - ind * 0.72);
      sourceNode.connect(gOut);
      gOut.connect(this.outdoorReverb);
    }
  }

  /**
   * Multi-Layered Realistic Firearm Acoustics (Bodycam Saturation + Sub Punch + Supersonic Crack + Mechanical Action + Space Reverb!)
   */
  public playShot(
    weapon: WeaponId,
    slowMo = false,
    indoorAmount = 0.5,
    isLastRound = false
  ) {
    const ctx = this.ensureReady();
    if (!ctx || !this.gunShaper || !this.masterComp) return;

    const now = ctx.currentTime;
    const rate = slowMo ? 0.42 : 1.0;
    const pitchJitter = 0.96 + Math.random() * 0.08;

    // Local shot bus so every shot feeds both bodycam waveshaper AND live room reverb seamlessly
    const shotOut = ctx.createGain();
    shotOut.gain.value = 1.0;
    shotOut.connect(this.gunShaper);

    if (weapon === 'pistol') {
      // =====================================================================
      // PISTOL (.45 ACP / 9mm Tactical 1911) — Crisp, Tight, Punchy Bark + Heavy Steel Slide!
      // =====================================================================
      // 1. Razor 10ms primer & muzzle shock transient
      const { src: snapSrc, offset: o1 } = this.createNoiseSource(1.15 * pitchJitter * rate);
      const snapHp = ctx.createBiquadFilter();
      snapHp.type = 'highpass';
      snapHp.frequency.value = 2100 * rate;
      const snapG = ctx.createGain();
      snapG.gain.setValueAtTime(1.15, now);
      snapG.gain.exponentialRampToValueAtTime(0.001, now + 0.022 / rate);
      snapSrc.connect(snapHp);
      snapHp.connect(snapG);
      snapG.connect(shotOut);
      snapSrc.start(now, o1, 0.035 / rate);

      // 2. Main propellant crack (tight punchy mid-high bark)
      const { src: crackSrc, offset: o2 } = this.createNoiseSource(0.95 * pitchJitter * rate);
      const crackBp = ctx.createBiquadFilter();
      crackBp.type = 'bandpass';
      crackBp.frequency.setValueAtTime(2150 * pitchJitter * rate, now);
      crackBp.frequency.exponentialRampToValueAtTime(380 * rate, now + 0.11 / rate);
      crackBp.Q.value = 0.72;
      const crackG = ctx.createGain();
      crackG.gain.setValueAtTime(1.18, now);
      crackG.gain.exponentialRampToValueAtTime(0.001, now + 0.14 / rate);
      crackSrc.connect(crackBp);
      crackBp.connect(crackG);
      crackG.connect(shotOut);
      crackSrc.start(now, o2, 0.16 / rate);

      // 3. Punchy low-mid chest thump (.45 heavy impulse)
      const thump = ctx.createOscillator();
      thump.type = 'triangle';
      thump.frequency.setValueAtTime(225 * pitchJitter * rate, now);
      thump.frequency.exponentialRampToValueAtTime(52 * rate, now + 0.075 / rate);
      const thumpG = ctx.createGain();
      thumpG.gain.setValueAtTime(0.92, now);
      thumpG.gain.exponentialRampToValueAtTime(0.001, now + 0.095 / rate);
      thump.connect(thumpG);
      thumpG.connect(shotOut);
      thump.start(now);
      thump.stop(now + 0.11 / rate);

      // 4. Mechanical steel slide blowback snap (higher ping if locked back on empty!)
      const slideTime = now + 0.036 / rate;
      this.playMetalClick(slideTime, (isLastRound ? 3350 : 2550) * rate, isLastRound ? 0.24 : 0.16);
      if (!isLastRound) {
        this.playMetalClick(slideTime + 0.034 / rate, 1850 * rate, 0.12);
      }

      this.routeReverbSend(shotOut, indoorAmount, 0.56);
    } else if (weapon === 'rifle') {
      // =====================================================================
      // RIFLE (M4A1 5.56×45mm NATO) — Ferocious Supersonic Whip-Crack + AR Buffer Punch!
      // =====================================================================
      // 1. Hyper-sharp 5.56mm supersonic whip-crack transient (signature M4A1 bark!)
      const { src: whipSrc, offset: o1 } = this.createNoiseSource(1.32 * pitchJitter * rate);
      const whipBp = ctx.createBiquadFilter();
      whipBp.type = 'bandpass';
      whipBp.frequency.setValueAtTime(3600 * pitchJitter * rate, now);
      whipBp.frequency.exponentialRampToValueAtTime(980 * rate, now + 0.042 / rate);
      whipBp.Q.value = 0.85;
      const whipG = ctx.createGain();
      whipG.gain.setValueAtTime(1.55, now);
      whipG.gain.exponentialRampToValueAtTime(0.001, now + 0.055 / rate);
      whipSrc.connect(whipBp);
      whipBp.connect(whipG);
      whipG.connect(shotOut);
      whipSrc.start(now, o1, 0.07 / rate);

      // 2. Full-bodied high-pressure muzzle blast roar
      const { src: roarSrc, offset: o2 } = this.createNoiseSource(0.98 * pitchJitter * rate);
      const roarLp = ctx.createBiquadFilter();
      roarLp.type = 'lowpass';
      roarLp.frequency.setValueAtTime(3400 * pitchJitter * rate, now);
      roarLp.frequency.exponentialRampToValueAtTime(290 * rate, now + 0.18 / rate);
      const roarG = ctx.createGain();
      roarG.gain.setValueAtTime(1.22, now);
      roarG.gain.exponentialRampToValueAtTime(0.001, now + 0.21 / rate);
      roarSrc.connect(roarLp);
      roarLp.connect(roarG);
      roarG.connect(shotOut);
      roarSrc.start(now, o2, 0.23 / rate);

      // 3. Heavy chest-slam sub kick + authentic AR-15 buffer tube metallic resonance!
      const sub = ctx.createOscillator();
      sub.type = 'sawtooth';
      sub.frequency.setValueAtTime(182 * pitchJitter * rate, now);
      sub.frequency.exponentialRampToValueAtTime(39 * rate, now + 0.11 / rate);
      const subLp = ctx.createBiquadFilter();
      subLp.type = 'lowpass';
      subLp.frequency.value = 320;
      const subG = ctx.createGain();
      subG.gain.setValueAtTime(1.05, now);
      subG.gain.exponentialRampToValueAtTime(0.001, now + 0.125 / rate);
      sub.connect(subLp);
      subLp.connect(subG);
      subG.connect(shotOut);
      sub.start(now);
      sub.stop(now + 0.14 / rate);

      // Subtle AR-15 stock buffer-spring resonance
      const spring = ctx.createOscillator();
      spring.type = 'sine';
      spring.frequency.setValueAtTime(560 * pitchJitter * rate, now + 0.015 / rate);
      spring.frequency.exponentialRampToValueAtTime(495 * rate, now + 0.11 / rate);
      const springG = ctx.createGain();
      springG.gain.setValueAtTime(0.085, now + 0.015 / rate);
      springG.gain.exponentialRampToValueAtTime(0.0008, now + 0.12 / rate);
      spring.connect(springG);
      springG.connect(this.masterComp);
      spring.start(now + 0.015 / rate);
      spring.stop(now + 0.13 / rate);

      // 4. Crisp rapid bolt carrier steel clack
      this.playMetalClick(now + 0.026 / rate, 3150 * rate, 0.16);
      this.playMetalClick(now + 0.054 / rate, 2100 * rate, 0.11);

      this.routeReverbSend(shotOut, indoorAmount, 0.74);
    } else if (weapon === 'sniper') {
      // =====================================================================
      // SNIPER (.338 LAPUA MAGNUM) — Thunderous Muzzle-Brake Overpressure Cannon!
      // =====================================================================
      // 1. Massive full-spectrum muzzle-brake overpressure shockwave
      const { src: shockSrc, offset: o1 } = this.createNoiseSource(1.18 * pitchJitter * rate);
      const shockHp = ctx.createBiquadFilter();
      shockHp.type = 'highpass';
      shockHp.frequency.value = 950 * rate;
      const shockG = ctx.createGain();
      shockG.gain.setValueAtTime(1.85, now);
      shockG.gain.exponentialRampToValueAtTime(0.001, now + 0.075 / rate);
      shockSrc.connect(shockHp);
      shockHp.connect(shockG);
      shockG.connect(shotOut);
      shockSrc.start(now, o1, 0.095 / rate);

      // 2. Ripping broadband propellant thunder roar (tearing air!)
      const { src: roarSrc, offset: o2 } = this.createNoiseSource(0.82 * pitchJitter * rate);
      const roarLp = ctx.createBiquadFilter();
      roarLp.type = 'lowpass';
      roarLp.frequency.setValueAtTime(4600 * rate, now);
      roarLp.frequency.exponentialRampToValueAtTime(185 * rate, now + 0.48 / rate);
      const roarG = ctx.createGain();
      roarG.gain.setValueAtTime(1.52, now);
      roarG.gain.exponentialRampToValueAtTime(0.001, now + 0.56 / rate);
      roarSrc.connect(roarLp);
      roarLp.connect(roarG);
      roarG.connect(shotOut);
      roarSrc.start(now, o2, 0.6 / rate);

      // 3. Earth-shaking dual sub-bass cannon boom (sine + saw lowpunch)
      const sub1 = ctx.createOscillator();
      sub1.type = 'sine';
      sub1.frequency.setValueAtTime(145 * rate, now);
      sub1.frequency.exponentialRampToValueAtTime(24 * rate, now + 0.36 / rate);
      const sub1G = ctx.createGain();
      sub1G.gain.setValueAtTime(1.42, now);
      sub1G.gain.exponentialRampToValueAtTime(0.001, now + 0.44 / rate);
      sub1.connect(sub1G);
      sub1G.connect(shotOut);
      sub1.start(now);
      sub1.stop(now + 0.46 / rate);

      const sub2 = ctx.createOscillator();
      sub2.type = 'triangle';
      sub2.frequency.setValueAtTime(92 * rate, now);
      sub2.frequency.exponentialRampToValueAtTime(32 * rate, now + 0.24 / rate);
      const sub2G = ctx.createGain();
      sub2G.gain.setValueAtTime(0.95, now);
      sub2G.gain.exponentialRampToValueAtTime(0.001, now + 0.28 / rate);
      sub2.connect(sub2G);
      sub2G.connect(shotOut);
      sub2.start(now);
      sub2.stop(now + 0.3 / rate);

      // 4. Heavy steel muzzle-brake & receiver metallic ring
      this.playMetalClick(now + 0.014 / rate, 1850 * rate, 0.2);

      // 5. Huge echoing thunder tail (reverbs heavily through indoor concrete OR alpine canyon!)
      this.routeReverbSend(shotOut, indoorAmount, 1.05);
    }
  }

  /**
   * Realistic Surface- & Stance-Aware Tactical Boot Footsteps (Heel-to-Toe Articulation + Grit Scuff + Sprint Gear Rustle!)
   */
  public playFootstep(
    stance: FootstepStance,
    foot: 'left' | 'right',
    surface: FootstepSurface = 'concrete',
    indoorAmount = 0.5
  ) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;

    const now = ctx.currentTime;
    const isSprint = stance === 'sprint';
    const isCrouch = stance === 'crouch';

    // Subtle left/right boot pitch & timing asymmetry so running sounds like two real human boots!
    const footPitch = (foot === 'left' ? 0.96 : 1.05) * (0.95 + Math.random() * 0.1);
    const masterVol = isSprint ? 0.56 : isCrouch ? 0.17 : 0.34;

    const stepBus = ctx.createGain();
    stepBus.gain.value = masterVol;
    stepBus.connect(this.masterComp);

    // 1. HEEL IMPACT THUD (low weight transfer onto concrete/asphalt/earth)
    const heelOsc = ctx.createOscillator();
    heelOsc.type = 'sine';
    const baseHeelHz = surface === 'grass' ? 82 : surface === 'asphalt' ? 118 : 104;
    heelOsc.frequency.setValueAtTime(baseHeelHz * footPitch * (isSprint ? 1.18 : 1.0), now);
    heelOsc.frequency.exponentialRampToValueAtTime(34, now + (isSprint ? 0.072 : 0.058));
    const heelG = ctx.createGain();
    heelG.gain.setValueAtTime(isSprint ? 0.92 : isCrouch ? 0.42 : 0.68, now);
    heelG.gain.exponentialRampToValueAtTime(0.001, now + (isSprint ? 0.08 : 0.065));
    heelOsc.connect(heelG);
    heelG.connect(stepBus);
    heelOsc.start(now);
    heelOsc.stop(now + 0.09);

    // 2. BOOT SOLE TAP / HARD SURFACE KNOCK (gives crisp concrete/asphalt boot presence!)
    const { src: tapSrc, offset: o1 } = this.createNoiseSource(footPitch);
    const tapBp = ctx.createBiquadFilter();
    tapBp.type = 'bandpass';
    tapBp.frequency.value =
      (surface === 'grass' ? 580 : surface === 'asphalt' ? 1480 : 1220) * footPitch;
    tapBp.Q.value = surface === 'grass' ? 1.0 : 1.65;
    const tapG = ctx.createGain();
    tapG.gain.setValueAtTime(surface === 'grass' ? 0.48 : 0.78, now);
    tapG.gain.exponentialRampToValueAtTime(0.001, now + (isSprint ? 0.055 : 0.048));
    tapSrc.connect(tapBp);
    tapBp.connect(tapG);
    tapG.connect(stepBus);
    tapSrc.start(now, o1, 0.068);

    // 3. TOE ROLL + SCATTERED RUBBLE / GRIT CRUNCH (+18ms delayed second micro-transient!)
    const toeDelay = isSprint ? 0.016 : 0.024;
    const { src: gritSrc, offset: o2 } = this.createNoiseSource(footPitch * 1.12);
    const gritBp = ctx.createBiquadFilter();
    gritBp.type = 'bandpass';
    gritBp.frequency.value =
      (surface === 'grass' ? 2350 : surface === 'concrete' ? 3200 : 2800) * footPitch;
    gritBp.Q.value = 1.25;
    const gritG = ctx.createGain();
    const gritLevel = surface === 'concrete' ? 0.56 : surface === 'grass' ? 0.64 : 0.42;
    gritG.gain.setValueAtTime(0.001, now + toeDelay);
    gritG.gain.linearRampToValueAtTime(gritLevel, now + toeDelay + 0.008);
    gritG.gain.exponentialRampToValueAtTime(0.001, now + toeDelay + (isSprint ? 0.075 : 0.068));
    gritSrc.connect(gritBp);
    gritBp.connect(gritG);
    gritG.connect(stepBus);
    gritSrc.start(now + toeDelay, o2, 0.095);

    // 4. TACTICAL VEST / CLOTH GEAR RUSTLE (subtle organic movement on sprint & brisk steps!)
    if (!isCrouch) {
      const { src: clothSrc, offset: o3 } = this.createNoiseSource(0.85 + Math.random() * 0.25);
      const clothBp = ctx.createBiquadFilter();
      clothBp.type = 'bandpass';
      clothBp.frequency.value = isSprint ? 1050 : 820;
      clothBp.Q.value = 1.4;
      const clothG = ctx.createGain();
      const rustleVol = isSprint ? 0.26 : 0.09;
      clothG.gain.setValueAtTime(0.001, now);
      clothG.gain.linearRampToValueAtTime(rustleVol, now + 0.025);
      clothG.gain.exponentialRampToValueAtTime(0.001, now + 0.115);
      clothSrc.connect(clothBp);
      clothBp.connect(clothG);
      clothG.connect(stepBus);
      clothSrc.start(now, o3, 0.13);
    }

    // Subtle room echo on concrete warehouse footsteps so indoor steps feel cavernous and real!
    if (indoorAmount > 0.12 && surface === 'concrete') {
      this.routeReverbSend(stepBus, indoorAmount, isSprint ? 0.32 : 0.18);
    }
  }

  /**
   * Jump Push-Off Scuff + Tactical Gear Swish
   */
  public playJump(surface: FootstepSurface = 'concrete') {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    const now = ctx.currentTime;

    const { src, offset } = this.createNoiseSource(1.08);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(surface === 'grass' ? 750 : 1250, now);
    bp.frequency.exponentialRampToValueAtTime(480, now + 0.11);
    bp.Q.value = 1.1;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.24, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    src.connect(bp);
    bp.connect(g);
    g.connect(this.masterComp);
    src.start(now, offset, 0.14);
  }

  /**
   * Heavy Two-Boot Landing Impact Thud + Concrete Gravel Slide + Gear Rattle
   */
  public playLand(impactStrength = 1.0, surface: FootstepSurface = 'concrete', indoorAmount = 0.5) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    const now = ctx.currentTime;
    const mag = Math.max(0.45, Math.min(1.5, impactStrength));

    const landBus = ctx.createGain();
    landBus.gain.value = 0.52 * mag;
    landBus.connect(this.masterComp);

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(98, now);
    osc.frequency.exponentialRampToValueAtTime(28, now + 0.12);
    const og = ctx.createGain();
    og.gain.setValueAtTime(1.0, now);
    og.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    osc.connect(og);
    og.connect(landBus);
    osc.start(now);
    osc.stop(now + 0.15);

    const { src, offset } = this.createNoiseSource(0.92);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = surface === 'grass' ? 920 : 1850;
    bp.Q.value = 1.0;
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.75, now);
    ng.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
    src.connect(bp);
    bp.connect(ng);
    ng.connect(landBus);
    src.start(now, offset, 0.15);

    if (indoorAmount > 0.15) {
      this.routeReverbSend(landBus, indoorAmount, 0.35);
    }
  }

  /**
   * Distant Enemy Bot Concrete Footstep (hear bots sprinting/flanking behind walls!)
   */
  public playBotFootstep(distanceMeters: number, isSprinting: boolean) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    if (distanceMeters > 19) return;

    const now = ctx.currentTime;
    const atten = Math.max(0.02, Math.min(0.28, (isSprinting ? 2.4 : 1.35) / (distanceMeters + 4.5)));

    const { src, offset } = this.createNoiseSource(0.95 + Math.random() * 0.15);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 1350 + Math.random() * 320;
    bp.Q.value = 1.5;
    const g = ctx.createGain();
    g.gain.setValueAtTime(atten, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.065);
    src.connect(bp);
    bp.connect(g);
    g.connect(this.masterComp);
    this.routeReverbSend(g, 0.75, 0.38);
    src.start(now, offset, 0.08);
  }

  public playDryFire() {
    const ctx = this.ensureReady();
    if (!ctx) return;
    this.playMetalClick(ctx.currentTime, 2250, 0.24);
  }

  public playMetalClick(time: number, freq: number, vol: number) {
    const ctx = this.ctx;
    if (!ctx || !this.masterComp || this.muted) return;
    const osc = ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(freq, time);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.42, time + 0.026);

    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = freq;
    bp.Q.value = 4.2;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.032);

    osc.connect(bp);
    bp.connect(gain);
    gain.connect(this.masterComp);
    osc.start(time);
    osc.stop(time + 0.038);
  }

  public playShellBounce(weapon: WeaponId) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    const now = ctx.currentTime;
    const baseFreq = weapon === 'sniper' ? 3200 : weapon === 'rifle' ? 4500 : 5200;
    const jitter = (Math.random() - 0.5) * 450;

    // Dual harmonic brass clink on concrete
    [1.0, 1.62].forEach((mult, i) => {
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime((baseFreq + jitter) * mult, now);
      osc.frequency.exponentialRampToValueAtTime((baseFreq + jitter) * mult * 0.92, now + 0.055);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime((weapon === 'sniper' ? 0.095 : 0.06) / (i + 1), now);
      gain.gain.exponentialRampToValueAtTime(0.0008, now + 0.075);

      osc.connect(gain);
      gain.connect(this.masterComp!);
      osc.start(now);
      osc.stop(now + 0.08);
    });
  }

  public playReloadStep(
    step: 'mag_out' | 'mag_in' | 'rack' | 'bolt_up' | 'bolt_back' | 'bolt_fwd' | 'bolt_down'
  ) {
    const ctx = this.ensureReady();
    if (!ctx || !this.noiseBuffer) return;
    const now = ctx.currentTime;

    if (step === 'mag_out') {
      this.playMetalClick(now, 1450, 0.24);
      this.playSlideFriction(now + 0.02, 0.14, 920, 0.14);
    } else if (step === 'mag_in') {
      this.playSlideFriction(now, 0.09, 1120, 0.16);
      this.playMetalClick(now + 0.075, 1080, 0.36);
      this.playMetalClick(now + 0.095, 2450, 0.24);
    } else if (step === 'rack') {
      this.playSlideFriction(now, 0.085, 1950, 0.2);
      this.playMetalClick(now + 0.07, 2650, 0.3);
      this.playMetalClick(now + 0.17, 1920, 0.36);
    } else if (step === 'bolt_up') {
      this.playMetalClick(now, 2350, 0.24);
    } else if (step === 'bolt_back') {
      this.playSlideFriction(now, 0.12, 1680, 0.21);
      this.playMetalClick(now + 0.11, 2900, 0.24);
    } else if (step === 'bolt_fwd') {
      this.playSlideFriction(now, 0.11, 1520, 0.2);
      this.playMetalClick(now + 0.1, 1780, 0.28);
    } else if (step === 'bolt_down') {
      this.playMetalClick(now, 1320, 0.3);
    }
  }

  private playSlideFriction(time: number, dur: number, freq: number, vol: number) {
    if (!this.ctx || !this.noiseBuffer || !this.masterComp) return;
    const { src, offset } = this.createNoiseSource(1.0);

    const bp = this.ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(freq, time);
    bp.Q.value = 3.2;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(vol, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + dur);

    src.connect(bp);
    bp.connect(gain);
    gain.connect(this.masterComp);
    src.start(time, offset, dur + 0.02);
  }

  public playHit(type: 'steel' | 'headshot' | 'wood' | 'explosion', distanceMeters = 30) {
    const ctx = this.ensureReady();
    if (!ctx || !this.noiseBuffer || !this.masterComp || !this.gunShaper) return;
    const delay = Math.min(0.24, distanceMeters / 580);
    const now = ctx.currentTime + delay;

    if (type === 'headshot') {
      const freqs = [1760, 2637, 3520];
      freqs.forEach((f, idx) => {
        const osc = ctx.createOscillator();
        osc.type = idx === 0 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(f, now);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.24 / (idx + 1), now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.32);
        osc.connect(g);
        g.connect(this.masterComp!);
        osc.start(now);
        osc.stop(now + 0.34);
      });
    } else if (type === 'steel') {
      const freqs = [740 + Math.random() * 90, 1180 + Math.random() * 140];
      freqs.forEach((f, idx) => {
        const osc = ctx.createOscillator();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(f, now);
        osc.frequency.exponentialRampToValueAtTime(f * 0.96, now + 0.25);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0.24 / (idx + 1), now);
        g.gain.exponentialRampToValueAtTime(0.001, now + 0.27);
        osc.connect(g);
        g.connect(this.masterComp!);
        osc.start(now);
        osc.stop(now + 0.29);
      });
    } else if (type === 'wood') {
      const { src, offset } = this.createNoiseSource(0.95);
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.frequency.setValueAtTime(680, now);
      bp.Q.value = 1.6;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.38, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
      src.connect(bp);
      bp.connect(g);
      g.connect(this.masterComp);
      src.start(now, offset, 0.18);
    } else if (type === 'explosion') {
      const boomBus = ctx.createGain();
      boomBus.gain.value = 1.25;
      boomBus.connect(this.gunShaper);
      this.routeReverbSend(boomBus, 0.7, 0.95);

      const { src, offset } = this.createNoiseSource(0.58);
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(1150, now);
      lp.frequency.exponentialRampToValueAtTime(85, now + 0.88);
      const g = ctx.createGain();
      g.gain.setValueAtTime(1.1, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.95);
      src.connect(lp);
      lp.connect(g);
      g.connect(boomBus);
      src.start(now, offset, 0.98);

      const sub = ctx.createOscillator();
      sub.type = 'sine';
      sub.frequency.setValueAtTime(115, now);
      sub.frequency.exponentialRampToValueAtTime(20, now + 0.68);
      const sg = ctx.createGain();
      sg.gain.setValueAtTime(1.05, now);
      sg.gain.exponentialRampToValueAtTime(0.001, now + 0.72);
      sub.connect(sg);
      sg.connect(boomBus);
      sub.start(now);
      sub.stop(now + 0.74);
    }
  }

  public playBotShot(distanceMeters: number, nearMiss = false) {
    const ctx = this.ensureReady();
    if (!ctx || !this.gunShaper || !this.masterComp) return;
    const now = ctx.currentTime;
    const atten = Math.max(0.12, Math.min(0.75, 7.2 / (distanceMeters + 7.0)));

    const botBus = ctx.createGain();
    botBus.gain.value = atten;
    botBus.connect(this.gunShaper);
    this.routeReverbSend(botBus, 0.75, 0.65);

    // Distant tactical rifle bark
    const { src, offset } = this.createNoiseSource(0.9 + Math.random() * 0.18);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(1950, now);
    bp.frequency.exponentialRampToValueAtTime(340, now + 0.15);
    bp.Q.value = 0.8;
    const g = ctx.createGain();
    g.gain.setValueAtTime(1.0, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
    src.connect(bp);
    bp.connect(g);
    g.connect(botBus);
    src.start(now, offset, 0.2);

    // Low distant thump
    const thump = ctx.createOscillator();
    thump.type = 'triangle';
    thump.frequency.setValueAtTime(150, now);
    thump.frequency.exponentialRampToValueAtTime(42, now + 0.08);
    const tg = ctx.createGain();
    tg.gain.setValueAtTime(0.65, now);
    tg.gain.exponentialRampToValueAtTime(0.001, now + 0.095);
    thump.connect(tg);
    tg.connect(botBus);
    thump.start(now);
    thump.stop(now + 0.1);

    // Supersonic bullet snap / whiz right past the bodycam on near misses!
    if (nearMiss && distanceMeters < 32) {
      const whizDelay = Math.min(0.12, distanceMeters / 260);
      const { src: wSrc, offset: wo } = this.createNoiseSource(1.45);
      const wBp = ctx.createBiquadFilter();
      wBp.type = 'bandpass';
      wBp.frequency.setValueAtTime(4200, now + whizDelay);
      wBp.frequency.exponentialRampToValueAtTime(900, now + whizDelay + 0.085);
      wBp.Q.value = 2.4;
      const wG = ctx.createGain();
      wG.gain.setValueAtTime(0.24, now + whizDelay);
      wG.gain.exponentialRampToValueAtTime(0.001, now + whizDelay + 0.095);
      wSrc.connect(wBp);
      wBp.connect(wG);
      wG.connect(this.masterComp);
      wSrc.start(now + whizDelay, wo, 0.11);
    }
  }

  public playPlayerHit() {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(155, now);
    osc.frequency.exponentialRampToValueAtTime(36, now + 0.14);
    const og = ctx.createGain();
    og.gain.setValueAtTime(0.6, now);
    og.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(og);
    og.connect(this.masterComp);
    osc.start(now);
    osc.stop(now + 0.17);

    const { src, offset } = this.createNoiseSource(1.0);
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 1150;
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.32, now);
    ng.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    src.connect(lp);
    lp.connect(ng);
    ng.connect(this.masterComp);
    src.start(now, offset, 0.11);
  }

  /**
   * ZOMBIE HORDE AUDIO — raspy distance-attenuated groan (formant-filtered saw + vibrato + breath noise)
   */
  public playZombieGroan(distanceMeters: number, big = false) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    if (distanceMeters > 70) return;
    const now = ctx.currentTime;
    const atten = Math.max(0.03, Math.min(0.5, 7.5 / (distanceMeters + 7.5))) * (big ? 1.25 : 1.0);
    const base = (big ? 52 : 78) + Math.random() * 34;
    const dur = 0.55 + Math.random() * 0.5;

    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(base * 1.35, now);
    osc.frequency.exponentialRampToValueAtTime(base, now + dur * 0.35);
    osc.frequency.exponentialRampToValueAtTime(base * 0.72, now + dur);

    const vib = ctx.createOscillator();
    vib.frequency.value = 9 + Math.random() * 7;
    const vibG = ctx.createGain();
    vibG.gain.value = base * 0.07;
    vib.connect(vibG);
    vibG.connect(osc.frequency);

    const formant = ctx.createBiquadFilter();
    formant.type = 'bandpass';
    formant.frequency.setValueAtTime(520 + Math.random() * 260, now);
    formant.frequency.exponentialRampToValueAtTime(310, now + dur);
    formant.Q.value = 2.6;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 1500;

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(0.5 * atten, now + 0.07);
    g.gain.exponentialRampToValueAtTime(0.0001, now + dur);

    osc.connect(formant);
    formant.connect(lp);
    lp.connect(g);
    g.connect(this.masterComp);
    osc.start(now);
    vib.start(now);
    osc.stop(now + dur + 0.02);
    vib.stop(now + dur + 0.02);

    const { src, offset } = this.createNoiseSource(0.6);
    const nbp = ctx.createBiquadFilter();
    nbp.type = 'bandpass';
    nbp.frequency.value = 760;
    nbp.Q.value = 1.4;
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.0001, now);
    ng.gain.exponentialRampToValueAtTime(0.22 * atten, now + 0.09);
    ng.gain.exponentialRampToValueAtTime(0.0001, now + dur * 0.9);
    src.connect(nbp);
    nbp.connect(ng);
    ng.connect(this.masterComp);
    src.start(now, offset, dur);
  }

  /** Wet flesh impact / squelch when a bullet tears into a zombie */
  public playZombieHit(distanceMeters: number, headshot: boolean) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    if (distanceMeters > 90) return;
    const now = ctx.currentTime;
    const atten = Math.max(0.1, Math.min(1, 9 / (distanceMeters + 9)));

    const { src, offset } = this.createNoiseSource(headshot ? 0.7 : 1.0);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = headshot ? 900 : 480;
    bp.Q.value = 0.9;
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.55 * atten, now);
    ng.gain.exponentialRampToValueAtTime(0.001, now + (headshot ? 0.2 : 0.13));
    src.connect(bp);
    bp.connect(ng);
    ng.connect(this.masterComp);
    src.start(now, offset, 0.25);

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(headshot ? 190 : 120, now);
    osc.frequency.exponentialRampToValueAtTime(42, now + 0.13);
    const og = ctx.createGain();
    og.gain.setValueAtTime(0.5 * atten, now);
    og.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    osc.connect(og);
    og.connect(this.masterComp);
    osc.start(now);
    osc.stop(now + 0.16);
  }

  /** Wave-incoming air-raid style horde horn (two descending saw blasts) */
  public playHordeHorn(urgent = false) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    const now = ctx.currentTime;
    const blasts = urgent ? 3 : 2;
    for (let i = 0; i < blasts; i++) {
      const t0 = now + i * 0.95;
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(196, t0);
      osc.frequency.linearRampToValueAtTime(urgent ? 150 : 165, t0 + 0.8);
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.value = 780;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(0.28, t0 + 0.08);
      g.gain.setValueAtTime(0.28, t0 + 0.6);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.86);
      osc.connect(lp);
      lp.connect(g);
      g.connect(this.masterComp);
      this.routeReverbSend(g, 0.2, 0.35);
      osc.start(t0);
      osc.stop(t0 + 0.9);
    }
  }

  /**
   * Heavy Abandoned Steel/Wood Door Latch + Creaking Hinge + Frame Thud
   */
  public playDoorToggle(opening: boolean, distanceMeters = 2.0) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    if (distanceMeters > 26) return;

    const now = ctx.currentTime;
    const atten = Math.max(0.12, Math.min(0.85, 4.5 / (distanceMeters + 4.5)));

    const doorBus = ctx.createGain();
    doorBus.gain.value = atten;
    doorBus.connect(this.masterComp);
    this.routeReverbSend(doorBus, 0.72, 0.35);

    // 1. Latch handle metallic clack
    this.playMetalClick(now, opening ? 1680 : 1220, 0.28 * atten);

    // 2. Rusty iron hinge groan / friction sweep
    const creak = ctx.createOscillator();
    creak.type = 'sawtooth';
    creak.frequency.setValueAtTime(opening ? 210 : 285, now + 0.03);
    creak.frequency.exponentialRampToValueAtTime(opening ? 320 : 165, now + 0.24);
    const creakBp = ctx.createBiquadFilter();
    creakBp.type = 'bandpass';
    creakBp.frequency.value = 540;
    creakBp.Q.value = 5.0;
    const creakG = ctx.createGain();
    creakG.gain.setValueAtTime(0.001, now + 0.03);
    creakG.gain.linearRampToValueAtTime(0.14, now + 0.09);
    creakG.gain.exponentialRampToValueAtTime(0.001, now + 0.26);
    creak.connect(creakBp);
    creakBp.connect(creakG);
    creakG.connect(doorBus);
    creak.start(now + 0.03);
    creak.stop(now + 0.28);

    // 3. Heavy frame impact thud (stronger when closing or kicked open!)
    const thudTime = now + (opening ? 0.05 : 0.24);
    const thud = ctx.createOscillator();
    thud.type = 'sine';
    thud.frequency.setValueAtTime(110, thudTime);
    thud.frequency.exponentialRampToValueAtTime(34, thudTime + 0.11);
    const thudG = ctx.createGain();
    thudG.gain.setValueAtTime(opening ? 0.42 : 0.68, thudTime);
    thudG.gain.exponentialRampToValueAtTime(0.001, thudTime + 0.13);
    thud.connect(thudG);
    thudG.connect(doorBus);
    thud.start(thudTime);
    thud.stop(thudTime + 0.14);
  }

  /**
   * Stage 1 Glass Spiderweb Fracture: sharp bullet punch + rapid crystalline stress cracks + micro-splinter tinkles!
   */
  public playGlassCrack(distanceMeters = 10) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    const delay = Math.min(0.16, distanceMeters / 540);
    const now = ctx.currentTime + delay;
    const atten = Math.max(0.22, Math.min(1.0, 10.5 / (distanceMeters + 7.0)));

    const crackBus = ctx.createGain();
    crackBus.gain.value = atten * 0.85;
    crackBus.connect(this.masterComp);
    this.routeReverbSend(crackBus, 0.68, 0.42);

    // 1. Crisp glass punch-through snap
    const { src, offset } = this.createNoiseSource(1.65);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.setValueAtTime(5200, now);
    bp.frequency.exponentialRampToValueAtTime(2200, now + 0.075);
    bp.Q.value = 1.4;
    const g = ctx.createGain();
    g.gain.setValueAtTime(1.05, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    src.connect(bp);
    bp.connect(g);
    g.connect(crackBus);
    src.start(now, offset, 0.11);

    // 2. Rapid crystalline stress-crack ticks radiating through the pane
    for (let i = 0; i < 6; i++) {
      const t = now + 0.006 + i * 0.017 + Math.random() * 0.012;
      const freq = 3400 + Math.random() * 4400;
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.82, t + 0.042);
      const sg = ctx.createGain();
      sg.gain.setValueAtTime(0.24 * (1 - i * 0.1), t);
      sg.gain.exponentialRampToValueAtTime(0.0008, t + 0.055);
      osc.connect(sg);
      sg.connect(crackBus);
      osc.start(t);
      osc.stop(t + 0.065);
    }
  }

  /**
   * Stage 2 Full Explosive Glass Shatter Cascade (Pane Burst + 18 Resonant Crystalline Shards + Concrete Hall Echo!)
   */
  public playGlassShatter(distanceMeters = 12) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    const delay = Math.min(0.18, distanceMeters / 540);
    const now = ctx.currentTime + delay;
    const atten = Math.max(0.24, Math.min(1.0, 11.5 / (distanceMeters + 7.0)));

    const glassBus = ctx.createGain();
    glassBus.gain.value = atten * 0.92;
    glassBus.connect(this.masterComp);
    this.routeReverbSend(glassBus, 0.78, 0.62);

    // 1. Explosive glass-sheet rupture crash (broadband high-sparkle + mid crunch!)
    const { src: s1, offset: o1 } = this.createNoiseSource(1.55);
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.setValueAtTime(3400, now);
    hp.frequency.exponentialRampToValueAtTime(1600, now + 0.24);
    const b1 = ctx.createGain();
    b1.gain.setValueAtTime(1.25, now);
    b1.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
    s1.connect(hp);
    hp.connect(b1);
    b1.connect(glassBus);
    s1.start(now, o1, 0.28);

    // 2. Heavy glass pane impact thump (low-mid physical mass of thick building glass!)
    const { src: s2, offset: o2 } = this.createNoiseSource(0.92);
    const midBp = ctx.createBiquadFilter();
    midBp.type = 'bandpass';
    midBp.frequency.value = 1150;
    midBp.Q.value = 1.1;
    const b2 = ctx.createGain();
    b2.gain.setValueAtTime(0.68, now);
    b2.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
    s2.connect(midBp);
    midBp.connect(b2);
    b2.connect(glassBus);
    s2.start(now, o2, 0.14);

    // 3. 18 Staggered High-Resonance Inharmonic Glass Shards (initial burst + glittering mid-air chime!)
    for (let i = 0; i < 18; i++) {
      const isInitial = i < 10;
      const shardTime = isInitial
        ? now + 0.004 + i * 0.016 + Math.random() * 0.014
        : now + 0.16 + (i - 10) * 0.042 + Math.random() * 0.035;
      const baseF = 2400 + Math.random() * 5800;

      const osc = ctx.createOscillator();
      osc.type = i % 3 === 0 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(baseF, shardTime);
      osc.frequency.exponentialRampToValueAtTime(baseF * (0.93 + Math.random() * 0.05), shardTime + 0.11);

      const sg = ctx.createGain();
      const peak = (isInitial ? 0.28 : 0.15) * (0.55 + Math.random() * 0.65);
      sg.gain.setValueAtTime(peak, shardTime);
      sg.gain.exponentialRampToValueAtTime(0.0007, shardTime + 0.095 + Math.random() * 0.075);

      osc.connect(sg);
      sg.connect(glassBus);
      osc.start(shardTime);
      osc.stop(shardTime + 0.18);
    }
  }

  /**
   * Individual Physical Glass Shard Clinking & Skittering on Concrete Floor!
   */
  public playGlassShardBounce(distanceMeters = 8) {
    const ctx = this.ensureReady();
    if (!ctx || !this.masterComp) return;
    if (distanceMeters > 22) return;

    const now = ctx.currentTime;
    const atten = Math.max(0.04, Math.min(0.24, 2.2 / (distanceMeters + 5.5)));
    const freq = 3600 + Math.random() * 4600;

    const osc = ctx.createOscillator();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.94, now + 0.055);
    const g = ctx.createGain();
    g.gain.setValueAtTime(atten, now);
    g.gain.exponentialRampToValueAtTime(0.0006, now + 0.065);
    osc.connect(g);
    g.connect(this.masterComp);
    osc.start(now);
    osc.stop(now + 0.075);
  }
}

export const soundEngine = new SoundEngine();
