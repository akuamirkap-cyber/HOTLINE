const fakeCtx = new Proxy({}, { get: (_t, k) => (k === 'createRadialGradient' || k === 'createLinearGradient' ? () => ({ addColorStop() {} }) : () => {}), set: () => true });
(globalThis as any).document = { createElement: () => ({ width: 0, height: 0, getContext: () => fakeCtx }) };

import * as THREE from 'three';
import { Terrain } from '../src/game/terrain';
import { Foley } from '../src/game/audio';
import { Horde } from '../src/game/zombie/zombies';
import { Barrels } from '../src/game/barrels';
import { NP, SEGS } from '../src/game/zombie/skeleton';

const terrain = new Terrain();
const scene = new THREE.Scene();
const foley = new Foley();
const horde = new Horde(scene, terrain, foley);
const cam = new THREE.PerspectiveCamera(74, 1.6, 0.08, 500);
const player = { pos: new THREE.Vector3(0, 0, -2), vel: new THREE.Vector3(), sprinting: false, crouching: false, alive: true };
horde.populate(0, -2);
const barrels = new Barrels(scene, terrain, horde.blood, foley);
let explosions = 0;
barrels.onExplode = (p) => {
  explosions++;
  horde.explode(p, 8.5, 1);
};

const pre = horde.zombies.filter((z) => z.active);
console.log('pre-damaged amputees', pre.filter((z) => z.severed.size > 0).length, 'crawlers', pre.filter((z) => z.crawler).length, 'hidden segs', pre.filter((z) => z.hidden).length);

function check(label: string) {
  let nan = 0, below = 0, stretch = 0, fast = 0;
  for (const z of horde.zombies) {
    if (!z.active) continue;
    for (let i = 0; i < NP * 3; i++) if (!isFinite(z.pts[i])) nan++;
    for (let i = 0; i < NP; i++) {
      if (z.ghostTo[i] >= 0 || z.detached[i]) continue;
      if (z.pts[i * 3 + 1] < terrain.height(z.pts[i * 3], z.pts[i * 3 + 2]) - 0.08) below++;
      const v = Math.hypot(z.pts[i * 3] - z.prev[i * 3], z.pts[i * 3 + 1] - z.prev[i * 3 + 1], z.pts[i * 3 + 2] - z.prev[i * 3 + 2]) * 120;
      if (v > 25) fast++;
    }
    for (const s of SEGS) {
      if (z.detached[s.a] !== z.detached[s.b]) continue;
      const d = Math.hypot(z.pts[s.a * 3] - z.pts[s.b * 3], z.pts[s.a * 3 + 1] - z.pts[s.b * 3 + 1], z.pts[s.a * 3 + 2] - z.pts[s.b * 3 + 2]);
      if (d > 0.6 * z.s) stretch++;
    }
  }
  console.log(label, { nan, below, stretch, fast });
}
const dt = 1 / 60;
const run = (sec: number) => {
  for (let f = 0; f < sec * 60; f++) {
    horde.update(dt, player, cam, 900);
    barrels.update(dt, player.pos);
  }
};
run(8);
const near = () => horde.zombies.filter((z) => z.active && z.alive).map((z) => z.dist).sort((a, b) => a - b);
console.log('normal  8s: chasing', horde.stateCounts.CHASING, 'within 10m', near().filter((d) => d < 10).length);
horde.setAggressive(true);
const t0 = performance.now();
run(8);
console.log('aggro   8s: chasing', horde.stateCounts.CHASING + horde.stateCounts.APPROACHING + horde.stateCounts.ATTACKING, 'within 10m', near().filter((d) => d < 10).length, 'ms/frame', ((performance.now() - t0) / 480).toFixed(2));
check('after aggro');

// ---- move a pack of zombies onto a barrel and shoot it
player.alive = false;
const b = barrels.list[0];
let packed = 0;
for (const z of horde.zombies) {
  if (!z.active || !z.alive || packed >= 10) continue;
  const a = (packed / 10) * Math.PI * 2;
  const d = 1.5 + (packed % 3) * 1.6;
  z.pos.set(b.x + Math.cos(a) * d, 0, b.z + Math.sin(a) * d);
  z.pos.y = terrain.height(z.pos.x, z.pos.z);
  z.rootY = z.pos.y;
  packed++;
}
run(0.2);
const o = new THREE.Vector3(b.x + 6, b.y + 0.5, b.z + 0.3);
const dir = new THREE.Vector3(b.x, b.y + 0.5, b.z).sub(o).normalize();
const bh = barrels.raycast(o, dir, 0.1, 50);
console.log('barrel ray hit', !!bh);
if (bh) barrels.hit(bh.i, o);
const killsBefore = horde.kills;
const tb = performance.now();
for (let k = 0; k < 6; k++) {
  run(0.5);
  check(`blast +${((k + 1) * 0.5).toFixed(1)}s`);
}
console.log('explosions', explosions, 'kills from blast', horde.kills - killsBefore, 'limbs', horde.limbs, 'ms/frame during blast', ((performance.now() - tb) / 180).toFixed(2));
const bodies = horde.zombies.filter((z) => z.active && !z.upright).map((z) => z.body);
console.log('down bodies', bodies.length, [...new Set(bodies)].join(','));
run(10);
check('after settle');
console.log('asleep corpses', horde.zombies.filter((z) => z.active && z.asleep).length, 'getting up/standing again', horde.stateCounts.GETTING_UP);

for (const z of horde.zombies) {
  if (!z.active) continue;
  const bad: string[] = [];
  for (let i = 0; i < NP; i++) {
    if (z.ghostTo[i] >= 0 || z.detached[i]) continue;
    const d = z.pts[i * 3 + 1] - terrain.height(z.pts[i * 3], z.pts[i * 3 + 2]);
    if (d < -0.08) bad.push(`${i}:${d.toFixed(2)}`);
  }
  if (bad.length) console.log('BAD', z.slot, z.body, z.crawler, z.upright, z.physics, z.asleep, bad.join(' '));
}
