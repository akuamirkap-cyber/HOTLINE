# Skateclub

Game skateboard side-scrolling, dikembangkan dari [skateclub.zip](https://github.com/akuamirkap-cyber/gunhitv2/blob/main/skateclub.zip).

## Jalankan

```sh
npm install
npm run dev
```

Buka alamat yang ditampilkan Vite, lalu pilih **Mulai main**. Untuk build produksi, jalankan `npm run build`. Seluruh hasil build, termasuk ilustrasi dan font, ada di `dist/`.

## Kontrol

| Tombol | Aksi |
| --- | --- |
| `Space` atau `W` | Lompat |
| `S` | Indy Grab, Melon Grab, dan Airwalk secara bergantian |
| `F` | Putar papan dan lakukan trik freestyle di udara |
| Klik kiri di lintasan | Lompat dan langsung freestyle dari tanah, atau ambil trik berikutnya saat di udara |
| `D` atau panah kanan | Gas (tahan) |
| `A` atau panah kiri | Rem di tanah, salto saat di udara |
| `Z`, `X`, `C` | Keluarga trik Flip, Grab, dan Spin |
| `Esc` atau `P` | Jeda |
| `R` | Ulangi sesi |

Di ponsel tersedia kontrol sentuh. Auto-Land membantu papan kembali sejajar dengan lintasan. Menyenggol cone hanya mengurangi kecepatan dan membuat cone terpental, bahkan saat boost; melompatinya masih memberi poin. Jika WebGL tidak tersedia, renderer Canvas 2D tetap menjalankan fisika, kontrol, dan jejak trik yang sama.