import { useEffect, useRef, useState } from 'react';
import type { PointerEvent as ReactPointerEvent } from 'react';
import { Game } from './game/Game';
import type { Control, CrashReason, GameResult, HudState, Phase, PopupKind } from './game/Game';
import { getBoard, getChar } from './game/skins';
import { getPlace } from './game/themes';
import { ArcadeDialog, ArenaPicker, ART_DIR, ControlGuide, Garage, number, Records, TrickBook } from './ui/ArcadeDialogs';
import type { DialogKind, Session, Skin } from './ui/ArcadeDialogs';
import { Icon, Keycap } from './ui/Icon';
import type { IconName } from './ui/Icon';

const EMPTY_HUD: HudState = { score: 0, distance: 0, coins: 0, cones: 0, combo: 1, best: 0, speed: 0 };
const HISTORY = 'skateclub-sessions-v1';
const SOUND = 'skateclub-mute-v1';
const quickKeys = [['SPACE', 'Lompat'], ['S', 'Grab'], ['F', 'Freestyle'], ['ArrowRight', 'Gas']];

const crashHint: Record<CrashReason, string> = {
  fall: 'Lompat dari bibir lintasan untuk melewati jurang.',
  wall: 'Ambil ancang-ancang sebelum melompati tebing.',
  water: 'Papan masuk air. Yuk, coba lintasannya lagi.',
  head: 'Skater kehilangan keseimbangan. Ayo coba lagi.',
  stuck: 'Papan tersangkut. Coba ambil jarak dan tambah gas.',
};

type Feedback = { id: number; text: string; kind: PopupKind; sub?: string };

function readSessions(): Session[] {
  try {
    const raw: unknown = JSON.parse(localStorage.getItem(HISTORY) || '[]');
    if (Array.isArray(raw)) return raw.filter((run): run is Session => run != null && Number.isFinite(run.at) &&
      Number.isFinite(run.score) && Number.isFinite(run.distance) && Number.isFinite(run.cones) && typeof run.place === 'string').slice(0, 15);
  } catch { /* Storage is optional. */ }
  return [];
}

function SkateHud({ hud, onPause, canPause }: { hud: HudState; onPause(): void; canPause: boolean }) {
  return <div className="ride-hud">
    <div className="hud-score">
      <span className="tiny-label">SKOR</span>
      <strong>{number(hud.score).padStart(4, '0')}</strong>
      {hud.combo > 1 && <span className="hud-combo">x{hud.combo} COMBO</span>}
    </div>
    <div className="hud-right">
      <div className="hud-distance"><span>JARAK</span><strong>{hud.distance} m</strong></div>
      <div className="hud-counts">
        <span title="Koin" aria-label={`${hud.coins} koin`}><Icon name="coin" size={17} /> {hud.coins}</span>
        <span title="Cone terlewati" aria-label={`${hud.cones} cone terlewati`}><Icon name="cone" size={17} /> {hud.cones}</span>
      </div>
      {canPause && <button type="button" className="icon-button ride-pause" aria-label="Jeda permainan" onClick={onPause}><Icon name="pause" size={20} /></button>}
    </div>
  </div>;
}

const touchActions: { control: Control; name: string; icon: IconName }[] = [
  { control: 'right', name: 'Gas', icon: 'bolt' },
  { control: 'grab', name: 'Grab', icon: 'hand' },
  { control: 'freestyle', name: 'Trik', icon: 'spark' },
  { control: 'jump', name: 'Lompat', icon: 'arrowUp' },
];

function TouchControls({ onControl }: { onControl(control: Control, down: boolean): void }) {
  return <div className="touch-controls" aria-label="Kontrol sentuh">
    {touchActions.map(({ control, name, icon }) => <button key={control} className={`touch-${control}`} type="button"
      onPointerDown={(e) => {
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        onControl(control, true);
      }}
      onPointerUp={() => onControl(control, false)} onPointerCancel={() => onControl(control, false)}
      onLostPointerCapture={() => onControl(control, false)}
      onClick={(e) => { if (e.detail === 0) { onControl(control, true); onControl(control, false); } }}>
      <Icon name={icon} size={21} /><span>{name}</span>
    </button>)}
  </div>;
}

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const consoleRef = useRef<HTMLElement>(null);
  const gameRef = useRef<Game | null>(null);
  const popupId = useRef(0);
  const [phase, setPhase] = useState<Phase>('menu');
  const [hud, setHud] = useState(EMPTY_HUD);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<GameResult | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [dialog, setDialog] = useState<DialogKind | null>(null);
  const [placeId, setPlaceId] = useState('hijau');
  const [skin, setSkin] = useState<Skin>({ charId: 'ayam', boardId: 'ayam' });
  const [sessions, setSessions] = useState(readSessions);
  const [muted, setMuted] = useState(() => { try { return localStorage.getItem(SOUND) === '1'; } catch { return false; } });
  const [fullscreen, setFullscreen] = useState(false);
  const [theater, setTheater] = useState(false);
  const [unavailable, setUnavailable] = useState(false);
  const [showError, setShowError] = useState(false);
  const mutedRef = useRef(muted);
  const menu = phase === 'menu';
  const place = getPlace(placeId);
  const focusStage = () => stageRef.current?.focus({ preventScroll: true });

  useEffect(() => {
    if (!mountRef.current) return;
    let game: Game;
    let timer = 0;
    try {
      game = new Game(mountRef.current, {
        onHud: setHud,
        onPause: setPaused,
        onPhase: (next, report) => {
          setPhase(next);
          if (next === 'menu' || next === 'playing') {
            window.clearTimeout(timer);
            setFeedback(null);
            setResult(null);
          }
          if (next === 'playing') focusStage();
          if (report) {
            setResult(report);
            const entry = { at: Date.now(), score: report.score, distance: report.distance, cones: report.cones, place: game.getPlaceId() };
            setSessions((previous) => [entry, ...previous].sort((a, b) => b.score - a.score).slice(0, 15));
          }
        },
        onPopup: (text, kind, sub) => {
          if (kind === 'coin') return;
          window.clearTimeout(timer);
          const id = ++popupId.current;
          setFeedback({ id, text, kind, sub });
          timer = window.setTimeout(() => setFeedback(null), kind === 'air' ? 960 : kind === 'bad' ? 820 : kind === 'crash' ? 1750 : 1350);
        },
      });
    } catch {
      setUnavailable(true);
      return;
    }
    gameRef.current = game;
    game.setMuted(mutedRef.current);
    setPlaceId(game.getPlaceId());
    setSkin(game.getSkin());
    if (import.meta.env.DEV && window.location.hash === '#debug') {
      (window as Window & { __skateclub?: Game }).__skateclub = game;
    }
    return () => {
      window.clearTimeout(timer);
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    gameRef.current?.setMuted(muted);
    mutedRef.current = muted;
    try { localStorage.setItem(SOUND, muted ? '1' : '0'); } catch { /* Storage is optional. */ }
  }, [muted]);

  useEffect(() => {
    try { localStorage.setItem(HISTORY, JSON.stringify(sessions)); } catch { /* Storage is optional. */ }
  }, [sessions]);

  useEffect(() => {
    const check = () => setFullscreen(document.fullscreenElement === consoleRef.current);
    document.addEventListener('fullscreenchange', check);
    return () => document.removeEventListener('fullscreenchange', check);
  }, []);

  useEffect(() => {
    if (!theater) return;
    const exit = (e: KeyboardEvent) => { if (e.code === 'Escape' && !document.querySelector('dialog[open]')) setTheater(false); };
    window.addEventListener('keydown', exit);
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', exit); document.body.style.overflow = overflow; };
  }, [theater]);

  function openDialog(kind: DialogKind) {
    gameRef.current?.setInputBlocked(true);
    setDialog(kind);
  }

  function closeDialog() {
    setDialog(null);
    gameRef.current?.setInputBlocked(false);
  }

  function play() {
    const game = gameRef.current;
    if (!game) { setShowError(true); return; }
    if (phase === 'menu') game.start();
    else if (phase === 'over') game.restart();
    else if (paused) { game.togglePause(); focusStage(); }
  }

  function park() {
    closeDialog();
    if (!menu) gameRef.current?.toMenu();
    setShowError(false);
  }

  function toggleFullscreen() {
    const el = consoleRef.current;
    if (theater) setTheater(false);
    else if (fullscreen) void document.exitFullscreen().catch(() => {});
    else if (el?.requestFullscreen && document.fullscreenEnabled) void el.requestFullscreen().catch(() => setTheater(true));
    else setTheater(true);
    if (phase === 'playing' && !paused) focusStage();
  }

  function stagePress(e: ReactPointerEvent<HTMLDivElement>) {
    if (e.pointerType !== 'mouse' || phase !== 'playing' || paused || (e.target as HTMLElement).closest('button')) return;
    focusStage();
    if (e.button === 0) gameRef.current?.pressFreestyle(true);
    if (e.button === 2) {
      e.currentTarget.setPointerCapture(e.pointerId);
      gameRef.current?.setControl('right', true);
    }
  }

  return <>
    <header className="site-header">
      <div className="site-width header-inner">
        <button className="brand" type="button" onClick={park} aria-label="Skateclub, kembali ke Skatepark">
          <span className="brand-mark"><Icon name="skate" size={24} /></span>
          <span className="brand-word">SKATE<span>CLUB</span></span>
        </button>
        <nav aria-label="Navigasi utama" className="primary-nav">
          <button type="button" className="nav-park" aria-current={!dialog || !['tricks', 'records'].includes(dialog) ? 'page' : undefined} onClick={park}>Skatepark</button>
          <button type="button" aria-current={dialog === 'tricks' ? 'page' : undefined} onClick={() => openDialog('tricks')}>Buku Trik</button>
          <button type="button" aria-current={dialog === 'records' ? 'page' : undefined} onClick={() => openDialog('records')}>Rekor</button>
        </nav>
        <button type="button" className="sound-button" aria-label={muted ? 'Nyalakan suara' : 'Matikan suara'}
          aria-pressed={!muted} onClick={() => { setMuted(!muted); if (phase === 'playing' && !paused) focusStage(); }}>
          <Icon name={muted ? 'mute' : 'volume'} size={18} /><span>Suara</span><small>{muted ? 'OFF' : 'ON'}</small>
        </button>
      </div>
    </header>

    <main className="site-width main-layout">
      <section ref={consoleRef} className={`arcade-console${theater ? ' is-theater' : ''}`} aria-label="Konsol Skateclub">
        <div className="console-bar">
          <button type="button" className="arena-trigger" onClick={() => openDialog('place')} disabled={!menu || unavailable} aria-label={`Pilih arena: ${place.name}`}>
            <Icon name="pin" size={17} /><span className="arena-prefix">Arena</span><span className="arena-divider" />
            <strong>{place.name}</strong>{menu && <Icon name="down" size={13} />}
          </button>
          <div className="console-tools">
            <span className="auto-land"><span className="online-dot" /><span>Auto-Land <strong>Aktif</strong></span></span>
            <button type="button" className="icon-button fullscreen-button" onClick={toggleFullscreen}
              aria-label={fullscreen || theater ? 'Keluar layar penuh' : 'Layar penuh'} title={fullscreen || theater ? 'Keluar layar penuh' : 'Layar penuh'}>
              <Icon name={fullscreen || theater ? 'contract' : 'expand'} size={18} />
            </button>
          </div>
        </div>

        <div className={`stage${menu ? ' stage-intro' : ' stage-active'}`} ref={stageRef} tabIndex={-1} aria-label="Area bermain Skateclub"
          onPointerDown={stagePress} onPointerUp={(e) => { if (e.pointerType === 'mouse' && e.button === 2) gameRef.current?.setControl('right', false); }}
          onLostPointerCapture={(e) => { if (e.pointerType === 'mouse' && e.target === e.currentTarget) gameRef.current?.setControl('right', false); }}
          onContextMenu={(e) => { if (!menu) e.preventDefault(); }}>
          <div ref={mountRef} className="riding-mount" aria-hidden="true" />
          {menu && <div className="intro">
            <img className="cover-art" src={`${ART_DIR}skateclub-cover.jpg`} alt="" fetchPriority="high" draggable={false} />
            <div className="cover-shade" />
            <span className="ambient-sparks" aria-hidden="true"><i /><i /><i /><i /></span>
            <div className="intro-copy">
              <span className="intro-label tiny-label"><i /> ARCADE SKATEBOARD 2D</span>
              <h1><span>SKATE</span><span>CLUB</span></h1>
              <p>Lompati cone, rangkai trik, dan mendarat mulus.</p>
              <div className="intro-actions">
                <button type="button" className="primary-button start-button" onClick={play}><Icon name="play" size={18} /> Mulai main</button>
                <span className="space-hint">atau tekan <Keycap value="SPACE" /></span>
              </div>
              {showError && <p className="intro-error" role="alert">Grafis game tidak bisa dimuat. Coba muat ulang di browser lain.</p>}
            </div>
          </div>}

          {!menu && <SkateHud hud={hud} onPause={() => gameRef.current?.togglePause()} canPause={phase === 'playing' && !paused} />}

          {!menu && feedback && !paused && phase !== 'over' && <div key={feedback.id} className={`ride-feedback feedback-${feedback.kind}`}
            data-freestyle={feedback.kind === 'air' && feedback.sub === 'FREESTYLE' ? 'true' : undefined} role="status">
            {feedback.kind === 'air' && feedback.sub && <span>{feedback.sub}</span>}
            <strong>{feedback.text}</strong>
            {feedback.kind !== 'air' && feedback.sub && <span>{feedback.sub}</span>}
          </div>}

          {phase === 'playing' && !paused && <>
            {hud.distance < 17 && feedback?.kind !== 'bad' && <div className="first-tip"><Icon name="cone" size={16} /><span>Lompati cone pertama!</span></div>}
            <TouchControls onControl={(control, down) => gameRef.current?.setControl(control, down)} />
          </>}

          {paused && phase === 'playing' && <div className="interstitial">
            <div className="interstitial-inner">
              <div className="tiny-label">SESI BEBAS</div><h2>Sesi dijeda</h2><p>Siap lanjut meluncur?</p>
              <div className="interstitial-actions">
                <button type="button" className="primary-button" onClick={play}><Icon name="play" size={16} /> Lanjut main</button>
                <button type="button" className="secondary-button" onClick={() => gameRef.current?.restart()}><Icon name="redo" size={18} /> Ulangi</button>
              </div>
              <button type="button" className="text-link" onClick={park}>Kembali ke Skatepark <Icon name="arrowRight" size={16} /></button>
            </div>
          </div>}

          {phase === 'over' && result && <div className="interstitial">
            <div className="interstitial-inner">
              <div className="tiny-label">{result.newBest ? 'REKOR BARU' : 'SKATECLUB / SESI BEBAS'}</div>
              <h2>Sesi selesai</h2><p>{crashHint[result.reason]}</p>
              <dl className="end-stats">
                <div><dt>SKOR</dt><dd>{number(result.score)}</dd></div>
                <div><dt>JARAK</dt><dd>{result.distance} m</dd></div>
                <div><dt>CONE</dt><dd>{result.cones}</dd></div>
              </dl>
              <div className="interstitial-actions">
                <button type="button" className="primary-button" onClick={play}><Icon name="redo" size={18} /> Main lagi</button>
                <button type="button" className="secondary-button" onClick={park}>Skatepark</button>
              </div>
            </div>
          </div>}
        </div>

        <div className="control-bar">
          <span className="controls-title"><Icon name="keyboard" size={19} /><span>Kontrol</span></span>
          <ul className="quick-controls" aria-label="Kontrol utama">
            {quickKeys.map(([key, name]) => <li key={name} title={key === 'F' ? 'Klik kiri juga bisa: lompat dan freestyle' : undefined}>
              <Keycap value={key} />{key === 'F' && <span className="mouse-cap" role="img" aria-label="Atau klik kiri"><Icon name="mouse" size={14} /></span>}
              <span>{name}</span></li>)}
          </ul>
          <button type="button" className="text-link controls-link" onClick={() => openDialog('controls')}>Semua kontrol <Icon name="diagonal" size={15} /></button>
        </div>
      </section>

      <div className="setup-strip">
        <div className="setup-info"><span className="setup-mark"><Icon name="skate" size={23} /></span>
          <div><div className="tiny-label">SETUP SKATER</div><div className="setup-name"><strong>{getChar(skin.charId).name}</strong><i /> <span>{getBoard(skin.boardId).name}</span></div></div>
        </div>
        <button type="button" className="text-link garage-link" onClick={() => openDialog('garage')} disabled={!menu || unavailable}>
          Buka garasi <Icon name="arrowRight" size={17} />
        </button>
      </div>
    </main>

    {dialog && <ArcadeDialog key={dialog} kind={dialog} onClose={closeDialog}>
      {dialog === 'tricks' && <TrickBook />}
      {dialog === 'controls' && <ControlGuide />}
      {dialog === 'records' && <Records best={hud.best} sessions={sessions} inSession={phase === 'playing' || phase === 'crashed'} onPlay={() => { closeDialog(); play(); }} />}
      {dialog === 'place' && <ArenaPicker placeId={placeId} onPick={(id) => { gameRef.current?.setPlace(id); setPlaceId(id); closeDialog(); }} />}
      {dialog === 'garage' && <Garage skin={skin} onApply={(gear) => { gameRef.current?.setSkin(gear.charId, gear.boardId); setSkin(gear); closeDialog(); }} />}
    </ArcadeDialog>}
  </>;
}