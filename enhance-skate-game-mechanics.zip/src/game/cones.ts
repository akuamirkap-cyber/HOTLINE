import { Euler, Vector3 } from 'three';
import type { Mesh } from 'three';
import { CONE_HALF, CONE_HEIGHT, Z_FRONT } from './constants';

const pivot = 0.27;
const turn = Math.PI * 2;

export class ConeTumble {
  private center: Vector3;
  private velocity: Vector3;
  private up = new Vector3();
  private angles = new Euler(0, 0, 0, 'ZYX');
  private spin: number;
  private direction: number;
  private settleAngle: number | null = null;
  private rebounds = 0;
  private age = 0;
  private settledFor = 0;

  constructor(readonly mesh: Mesh, boardSpeed: number) {
    const force = Math.min(1, Math.abs(boardSpeed) / 24);
    this.direction = Math.sign(boardSpeed) || 1;
    this.center = mesh.position.clone().add(new Vector3(0, pivot, 0));
    this.velocity = new Vector3(this.direction * (2.4 + force * 4.9), 3.4 + force * 3.25, 1.95 + force * 1.6);
    this.spin = -this.direction * (7.8 + force * 3.4);
  }

  advance(dt: number, floorAt: (x: number) => number | null) {
    const steps = Math.max(1, Math.ceil(dt * 90));
    for (let i = 0; i < steps; i++) this.step(dt / steps, floorAt);
    this.mesh.rotation.copy(this.angles);
    this.mesh.position.copy(this.center).addScaledVector(this.up, -pivot);
    if (this.center.y < -18) this.mesh.visible = false;
    return this.settledFor < 0.54 && this.age < 3 && this.mesh.visible;
  }

  private step(dt: number, floorAt: (x: number) => number | null) {
    this.age += dt;
    const v = this.velocity;
    const p = this.center;
    const drag = Math.exp(-dt * (this.settleAngle == null ? 0.95 : 7));
    v.x *= drag;
    v.z *= drag;
    v.y -= 18 * dt;
    p.addScaledVector(v, dt);
    if (p.z > Z_FRONT - 0.31) { p.z = Z_FRONT - 0.31; v.z = 0; }

    if (this.settleAngle == null) {
      this.angles.z += this.spin * dt;
      this.angles.y += dt * 1.4 * this.direction;
      this.angles.x = Math.sin(this.age * 6.2) * 0.24;
    } else {
      const k = 1 - Math.exp(-dt * 13);
      this.angles.z += (this.settleAngle - this.angles.z) * k;
      this.angles.x *= 1 - k;
    }
    this.up.set(0, 1, 0).applyEuler(this.angles);
    const road = floorAt(p.x);
    if (road == null) {
      this.settleAngle = null;
      this.settledFor = 0;
      return;
    }

    // Rest the spinning cone on its base or tip, whichever is closer to the road.
    const side = Math.sqrt(Math.max(0, 1 - this.up.y * this.up.y));
    const low = Math.min(-pivot * this.up.y - CONE_HALF * side, (CONE_HEIGHT - pivot) * this.up.y - 0.044 * side);
    const floor = road - low;
    if (this.settleAngle != null || (p.y <= floor && v.y <= 0)) {
      p.y = floor;
      if (this.settleAngle == null && this.rebounds < 2 && v.y < -2.3) {
        v.y = -v.y * (this.rebounds++ === 0 ? 0.43 : 0.26);
        v.x *= 0.73;
        this.spin *= 0.63;
      } else {
        if (this.settleAngle == null) {
          const sideAngle = -this.direction * 1.51;
          this.settleAngle = sideAngle + Math.round((this.angles.z - sideAngle) / turn) * turn;
        }
        v.y = 0;
        this.settledFor += dt;
      }
    }
  }
}