import * as THREE from 'three';

export interface PSpawn {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  size: number;
  color: number;
  gravity?: number;
  drag?: number;
  flat?: boolean;
  sway?: number;
  spin?: number;
}

interface P {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  size: number;
  color: THREE.Color;
  gravity: number;
  drag: number;
  flat: boolean;
  sway: number;
  rx: number;
  ry: number;
  rz: number;
  spin: number;
  seed: number;
}

export class Particles {
  mesh: THREE.InstancedMesh;
  private max: number;
  private ps: P[] = [];
  private dummy = new THREE.Object3D();
  private time = 0;

  constructor(max = 600) {
    this.max = max;
    const geo = new THREE.BoxGeometry(1, 1, 1);
    const mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    this.mesh = new THREE.InstancedMesh(geo, mat, max);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    const white = new THREE.Color(0xffffff);
    for (let i = 0; i < max; i++) this.mesh.setColorAt(i, white);
    this.mesh.count = 0;
    this.mesh.frustumCulled = false;
  }

  spawn(o: PSpawn) {
    if (this.ps.length >= this.max) this.ps.shift();
    this.ps.push({
      x: o.x,
      y: o.y,
      z: o.z,
      vx: o.vx,
      vy: o.vy,
      vz: o.vz,
      life: o.life,
      maxLife: o.life,
      size: o.size,
      color: new THREE.Color(o.color),
      gravity: o.gravity ?? 15,
      drag: o.drag ?? 0.5,
      flat: !!o.flat,
      sway: o.sway ?? 0,
      rx: Math.random() * 6,
      ry: Math.random() * 6,
      rz: Math.random() * 6,
      spin: o.spin ?? 4,
      seed: Math.random() * 100,
    });
  }

  burst(
    x: number,
    y: number,
    z: number,
    n: number,
    colors: number[],
    speed: number,
    opts: Partial<PSpawn> & { up?: number; spread?: number } = {},
  ) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const s = speed * (0.4 + Math.random() * 0.8);
      this.spawn({
        x: x + (Math.random() - 0.5) * (opts.spread ?? 0.2),
        y: y + (Math.random() - 0.5) * (opts.spread ?? 0.2),
        z: z + (Math.random() - 0.5) * (opts.spread ?? 0.2),
        vx: Math.cos(a) * s + (opts.vx ?? 0),
        vy: Math.abs(Math.sin(a)) * s * 0.8 + (opts.up ?? 0) + (opts.vy ?? 0),
        vz: (Math.random() - 0.5) * s,
        life: (opts.life ?? 0.8) * (0.6 + Math.random() * 0.8),
        size: (opts.size ?? 0.12) * (0.6 + Math.random() * 0.8),
        color: colors[Math.floor(Math.random() * colors.length)],
        gravity: opts.gravity,
        drag: opts.drag,
        flat: opts.flat,
        sway: opts.sway,
        spin: opts.spin,
      });
    }
  }

  update(dt: number) {
    this.time += dt;
    const ps = this.ps;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.life -= dt;
      if (p.life <= 0) {
        ps[i] = ps[ps.length - 1];
        ps.pop();
        continue;
      }
      const dr = Math.max(0, 1 - p.drag * dt);
      p.vx *= dr;
      p.vy *= dr;
      p.vz *= dr;
      p.vy -= p.gravity * dt;
      if (p.sway) p.vx += Math.sin(this.time * 7 + p.seed) * p.sway * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.rx += p.spin * dt;
      p.rz += p.spin * 0.7 * dt;
    }
    const n = ps.length;
    for (let i = 0; i < n; i++) {
      const p = ps[i];
      const k = p.life / p.maxLife;
      const s = p.size * (k < 0.35 ? k / 0.35 : 1);
      this.dummy.position.set(p.x, p.y, p.z);
      this.dummy.rotation.set(p.rx, p.ry, p.rz);
      if (p.flat) this.dummy.scale.set(s, s * 0.22, s * 0.65);
      else this.dummy.scale.set(s, s, s);
      this.dummy.updateMatrix();
      this.mesh.setMatrixAt(i, this.dummy.matrix);
      this.mesh.setColorAt(i, p.color);
    }
    this.mesh.count = n;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  clear() {
    this.ps.length = 0;
    this.mesh.count = 0;
  }
}
