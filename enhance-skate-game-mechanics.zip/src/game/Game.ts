import * as THREE from 'three';
import { Box, Circle, RevoluteJoint, World } from 'planck';
import type { Body, Contact, ContactImpulse, Fixture } from 'planck';
import {
  BOOST_ACC,
  BOOST_SPEED,
  BRAKE_ACC,
  BRAKE_SPEED,
  COLORS,
  CONE_HALF,
  CONE_HEIGHT,
  CRUISE_SPEED,
  DECK_HH,
  DECK_HW,
  GRAVITY,
  JUMP_SPEED,
  PHYS_DT,
  PUSH_ACC,
  RIDE_CLEAR,
  WATER_Y,
  WHEEL_R,
  WHEEL_X,
  WHEEL_Y,
} from './constants';
import { buildCoinGeometry } from './voxel';
import { getPlace } from './themes';
import type { PlaceTheme } from './themes';
import { buildBoardVisual, buildCharRig, getBoard, getChar, SEGS } from './skins';
import type { BoardVisual, CharRig, PivName, SegName } from './skins';
import { FAMILY_ORDER, FREESTYLE_CYCLE, GRAB_CYCLE, TRICK_MAP as TRICK_DEFS, ZERO_POSE, trickPose } from './tricks';
import type { TrickDef, TrickFamily, TrickPose } from './tricks';
import { LevelGen, buildPiece, disposePiece, surfAt } from './terrain';
import type { BuiltPiece, GapInfo, RailInfo } from './terrain';
import { Particles } from './particles';
import { Sfx } from './audio';
import { FlatRenderer } from './FlatRenderer';
import { ConeTumble } from './cones';
import { DeckTrail } from './DeckTrail';

export type Phase = 'menu' | 'playing' | 'crashed' | 'over';
export type PopupKind = 'air' | 'trick' | 'perfect' | 'good' | 'bad' | 'crash' | 'coin';
export type CrashReason = 'head' | 'wall' | 'fall' | 'water' | 'stuck';
export type Control = 'left' | 'right' | 'jump' | 'flip' | 'grab' | 'spin' | 'freestyle';

export interface HudState {
  score: number;
  distance: number;
  coins: number;
  cones: number;
  combo: number;
  best: number;
  speed: number;
}

export interface GameResult {
  score: number;
  distance: number;
  coins: number;
  cones: number;
  best: number;
  newBest: boolean;
  reason: CrashReason;
  flips: number;
}

export interface GameCallbacks {
  onHud(h: HudState): void;
  onPhase(p: Phase, r?: GameResult): void;
  onPopup(text: string, kind: PopupKind, sub?: string): void;
  onPause(p: boolean): void;
}

interface Pose {
  x: number;
  y: number;
  a: number;
}

interface RagPart {
  body: Body;
  mesh: THREE.Mesh;
  z: number;
  kind: 'torso' | 'head' | 'wing' | 'leg';
  qRes: THREE.Quaternion;
  inWater: boolean;
  px: number;
  py: number;
  pa: number;
}

const BEST_KEY = 'ayam-skater-best-v1';
const CHAR_KEY = 'ayam-skater-char-v1';
const BOARD_KEY = 'ayam-skater-board-v1';
const PLACE_KEY = 'ayam-skater-place-v1';
const Z_AXIS = new THREE.Vector3(0, 0, 1);

type GrindStyle = 'fifty' | 'boardslide' | 'lipslide' | 'feeble';

function railAt(rail: RailInfo, x: number): { y: number; ang: number } {
  const pts = rail.pts;
  if (x <= pts[0].x) return { y: pts[0].y, ang: 0 };
  for (let i = 1; i < pts.length; i++) {
    if (x <= pts[i].x) {
      const a = pts[i - 1];
      const b = pts[i];
      const dx = b.x - a.x || 1;
      const t = (x - a.x) / dx;
      return { y: a.y + (b.y - a.y) * t, ang: Math.atan2(b.y - a.y, dx) };
    }
  }
  const a = pts[pts.length - 2];
  const b = pts[pts.length - 1];
  return { y: b.y, ang: Math.atan2(b.y - a.y, b.x - a.x || 1) };
}
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const angleDelta = (a: number) => Math.atan2(Math.sin(a), Math.cos(a));
const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const ART = `${import.meta.env.BASE_URL}art/`;


function makeGrainTexture(): THREE.Texture {
  const cv = document.createElement('canvas');
  cv.width = cv.height = 128;
  const g = cv.getContext('2d')!;
  const img = g.createImageData(cv.width, cv.height);
  for (let i = 0; i < img.data.length; i += 4) {
    const x = (i / 4) % cv.width;
    const y = Math.floor(i / 4 / cv.width);
    const v = 240 + Math.sin(x * Math.PI / 32) * Math.sin(y * Math.PI / 32) * 5 - Math.random() * 26;
    img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  g.fillStyle = 'rgba(51, 49, 34, .12)';
  for (let i = 0; i < 150; i++) g.fillRect(Math.random() * 128, Math.random() * 128, 1 + Math.random() * 3, 1);
  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.magFilter = THREE.LinearFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

export class Game {
  private container: HTMLElement;
  private cb: GameCallbacks;
  private renderer: THREE.WebGLRenderer | FlatRenderer;
  private backdrop: HTMLDivElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private sun: THREE.DirectionalLight;
  private hemi: THREE.HemisphereLight;
  private placeId = 'hijau';
  private theme!: PlaceTheme;
  private voxelMat: THREE.MeshLambertMaterial;
  private terrainMat: THREE.MeshLambertMaterial;
  private coinMat: THREE.MeshLambertMaterial;
  private coinGeo: THREE.BufferGeometry;
  private rig!: CharRig;
  private boardVis!: BoardVisual;
  private charId = 'ayam';
  private boardId = 'ayam';
  private riderRoot = new THREE.Group();
  private spinG = new THREE.Group();
  private facingG = new THREE.Group();
  private bodyYaw = -1.15;
  private headYawW = -1.15;
  private headTarget = -1.15;
  private headTimer = 2;
  private pushing = false;
  private boardTrickG = new THREE.Group();
  private riderTiltG = new THREE.Group();
  private riderOffG = new THREE.Group();
  private hipG = new THREE.Group();
  private pivG = {} as Record<PivName, THREE.Group>;
  private trick: { def: TrickDef; t: number; dur: number; dir: number; freestyle: boolean; caught: boolean } | null = null;
  private releasePose: { from: TrickPose; elapsed: number } | null = null;
  private grinding: { rail: RailInfo; style: GrindStyle; dist: number; pts: number } | null = null;
  private grindStyle: GrindStyle = 'fifty';
  private trickQueue: TrickFamily | null = null;
  private trickQueueT = 0;
  private cycleIdx = 0;
  private grabIdx = 0;
  private grabQueueT = 0;
  private freestyleQueueT = 0;
  private backflipLatch = false;
  private familyIdx: Record<TrickFamily, number> = { flip: 0, grab: 0, spin: 0 };
  private airTricks: TrickDef[] = [];
  private pose: TrickPose = { ...ZERO_POSE };
  private tmpQ = new THREE.Quaternion();
  private handTarget = new THREE.Vector3();
  private trailProjection = new THREE.Vector3();
  private deckTrail: DeckTrail;
  private down = new THREE.Vector3(0, -1, 0);
  private preview = false;
  private particles: Particles;
  private sfx = new Sfx();
  private water: THREE.Mesh;
  private rideShadow: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>;
  private ro: ResizeObserver | null = null;
  private raf = 0;
  private lastT = 0;

  // physics world
  private world!: World;
  private gen!: LevelGen;
  private pieces: BuiltPiece[] = [];
  private tumblingCones: ConeTumble[] = [];
  private board!: Body;
  private headFix: Fixture | null = null;
  private wheelFix: Fixture[] = [];
  private rag: RagPart[] = [];
  private bPrev = { x: 0, y: 0, a: 0 };

  // state
  phase: Phase = 'menu';
  private paused = false;
  private inputBlocked = false;
  private input = { left: false, right: false, jump: false };
  private jumpBuffer = 0;
  private jumpCooldown = 0;
  private coneRecovery = 0;
  private grounded = true;
  private groundN = { x: 0, y: 1 };
  private coyote = 0;
  private airTime = 0;
  private groundTime = 0;
  private takeoffX = 0;
  private prevVel = { x: 0, y: 0 };
  private accS = { x: 0, y: 0 };
  private headHit = false;
  private wallHit = false;
  private stuckTime = 0;
  private accum = 0;
  private slowmo = 0;
  private realTime = 0;
  private crashTimer = 0;
  private overTime = 0;
  private crashReason: CrashReason = 'head';
  private shake = 0;
  private boardInWater = false;
  private splashCooldown = 0;

  // score
  private startX = 0;
  private distance = 0;
  private trickScore = 0;
  private coinCount = 0;
  private coneCount = 0;
  private combo = 0;
  private flipsTotal = 0;
  private best = 0;
  private hudTimer = 0;
  private coinChain = 0;
  private lastCoinT = -10;
  private impactCooldown = 0;

  // rig springs (secondary motion → jelly / ragdoll-ish feel while riding)
  private rig_s = {
    crouch: 0,
    crouchV: 0,
    lean: 0,
    leanV: 0,
    head: 0,
    headV: 0,
    squash: 0,
    squashV: 0,
    flap: 0,
    flapPhase: 0,
    push: -1,
    blinkT: 2,
    blink: 0,
  };
  private wheelSpin = 0;

  // camera
  private camT = new THREE.Vector3(0, 1, 0);
  private camDist = 12;

  constructor(container: HTMLElement, cb: GameCallbacks) {
    this.container = container;
    this.cb = cb;
    try {
      this.best = Number(localStorage.getItem(BEST_KEY) || 0) || 0;
    } catch {
      this.best = 0;
    }

    const w = container.clientWidth || window.innerWidth;
    const h = container.clientHeight || window.innerHeight;
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2', { antialias: true, alpha: true });
    let renderer: THREE.WebGLRenderer | FlatRenderer;
    if (gl) {
      try {
        renderer = new THREE.WebGLRenderer({ canvas, context: gl, antialias: true, alpha: true });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.55));
        renderer.setClearColor(0x000000, 0);
      } catch {
        renderer = new FlatRenderer();
      }
    } else renderer = new FlatRenderer();
    renderer.setSize(w, h);
    renderer.domElement.className = 'riding-canvas';
    const backdrop = document.createElement('div');
    backdrop.className = 'riding-backdrop';
    this.deckTrail = new DeckTrail();
    this.deckTrail.resize(w, h);
    container.append(backdrop, renderer.domElement, this.deckTrail.canvas);
    this.backdrop = backdrop;
    this.renderer = renderer;

    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x5b624a, 24, 52);
    this.scene = scene;

    this.camera = new THREE.PerspectiveCamera(40, w / h, 0.5, 500);

    const hemi = new THREE.HemisphereLight(0xffffff, 0xa39780, 2.05);
    scene.add(hemi);
    this.hemi = hemi;
    const sun = new THREE.DirectionalLight(0xfff0d6, 1.95);
    scene.add(sun);
    scene.add(sun.target);
    this.sun = sun;

    this.voxelMat = new THREE.MeshLambertMaterial({ vertexColors: true });
    this.terrainMat = new THREE.MeshLambertMaterial({ vertexColors: true, map: makeGrainTexture() });
    this.coinMat = new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0x5a3a00 });
    this.coinGeo = buildCoinGeometry();

    try {
      this.charId = localStorage.getItem(CHAR_KEY) || 'ayam';
      this.boardId = localStorage.getItem(BOARD_KEY) || 'ayam';
      this.placeId = localStorage.getItem(PLACE_KEY) || 'hijau';
    } catch {
      /* ignore */
    }
    this.theme = getPlace(this.placeId);
    scene.add(this.riderRoot);
    this.riderRoot.add(this.spinG);
    this.spinG.add(this.boardTrickG, this.facingG);
    this.facingG.add(this.riderTiltG);
    this.riderTiltG.add(this.riderOffG);
    this.riderOffG.add(this.hipG);
    this.hipG.rotation.order = 'ZYX';
    this.riderTiltG.rotation.order = 'ZYX';
    this.buildSkin();

    this.particles = new Particles(800);
    scene.add(this.particles.mesh);

    const water = new THREE.Mesh(
      new THREE.BoxGeometry(150, 14, 9),
      new THREE.MeshLambertMaterial({ color: COLORS.water }),
    );
    water.position.set(0, WATER_Y - 7, -1.5);
    water.receiveShadow = true;
    scene.add(water);
    this.water = water;

    const shadow = document.createElement('canvas');
    shadow.width = shadow.height = 64;
    const ctx = shadow.getContext('2d')!;
    const glow = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    glow.addColorStop(0, 'rgba(15, 17, 12, .82)');
    glow.addColorStop(1, 'rgba(15, 17, 12, 0)');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, 64, 64);
    this.rideShadow = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.35), new THREE.MeshBasicMaterial({
      map: new THREE.CanvasTexture(shadow), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2,
    }));
    this.rideShadow.rotation.order = 'ZYX';
    scene.add(this.rideShadow);
    this.applyTheme();
    this.resetWorld();
    this.snapCamera();

    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);
    window.addEventListener('blur', this.onBlur);
    document.addEventListener('visibilitychange', this.onVisibility);
    if (typeof ResizeObserver !== 'undefined') {
      this.ro = new ResizeObserver(this.onResize);
      this.ro.observe(container);
    }
    this.lastT = performance.now();
    this.raf = requestAnimationFrame(this.loop);
    this.emitHud();
  }

  /* ================================================================ */
  /* Public API                                                       */
  /* ================================================================ */

  start() {
    if (this.phase !== 'menu' || this.inputBlocked) return;
    this.sfx.init();
    this.phase = 'playing';
    this.board.setLinearVelocity({ x: 5.5, y: 0 });
    this.rig_s.push = 0;
    this.snapCamera();
    this.cb.onPhase('playing');
  }

  restart() {
    if (this.inputBlocked) return;
    this.sfx.init();
    this.rememberBest();
    this.phase = 'playing';
    this.resetWorld();
    this.board.setLinearVelocity({ x: 5.5, y: 0 });
    this.rig_s.push = 0;
    this.snapCamera();
    this.paused = false;
    this.cb.onPause(false);
    this.cb.onPhase('playing');
  }

  setControl(name: Control, down: boolean) {
    if (down && (this.inputBlocked || this.paused)) return;
    if (name === 'freestyle') {
      if (down) this.pressFreestyle();
    } else if (name === 'grab') {
      if (down) this.pressGrab();
    } else if (name === 'flip' || name === 'spin') {
      if (down) this.pressTrick(name);
    } else if (name === 'jump') {
      if (down) this.pressJump();
      else this.input.jump = false;
    } else {
      this.input[name] = down;
      if (down) this.sfx.init();
    }
  }

  setMuted(m: boolean) {
    this.sfx.setMuted(m);
  }

  setInputBlocked(blocked: boolean) {
    this.inputBlocked = blocked;
    if (blocked) {
      if (this.phase === 'playing' && !this.paused) this.togglePause();
      this.onBlur();
    }
  }

  getSkin() {
    return { charId: this.charId, boardId: this.boardId };
  }

  /** change character / board (menu only) */
  setSkin(charId: string, boardId: string) {
    if (this.phase !== 'menu') return;
    this.charId = charId;
    this.boardId = boardId;
    try {
      localStorage.setItem(CHAR_KEY, charId);
      localStorage.setItem(BOARD_KEY, boardId);
    } catch {
      /* ignore */
    }
    this.buildSkin();
    this.resetWorld();
    this.snapCamera();
    const p = this.board.getPosition();
    this.particles.burst(p.x, p.y + 0.8, 0.3, 16, [0xffe066, 0xffffff, 0x7fe3ff, 0xff8fd1], 3.5, { up: 2, life: 0.8, size: 0.12, gravity: 3, drag: 2 });
    this.rig_s.squashV -= 3;
    this.sfx.init();
    this.sfx.coin(1.2);
  }

  /** skin picker open: shift the menu camera so the character sits beside the panel */
  setPreview(on: boolean) {
    this.preview = on;
  }

  toMenu() {
    this.rememberBest();
    this.phase = 'menu';
    this.resetWorld();
    this.snapCamera();
    this.sfx.update(0, true, false);
    this.paused = false;
    this.cb.onPause(false);
    this.cb.onPhase('menu');
  }

  private buildSkin() {
    if (this.rig) {
      for (const sg of SEGS) this.rig.meshes[sg].removeFromParent();
      this.rig.dispose();
    }
    if (this.boardVis) {
      this.boardVis.group.removeFromParent();
      this.boardVis.dispose();
    }
    this.charId = getChar(this.charId).id;
    this.boardId = getBoard(this.boardId).id;
    this.rig = buildCharRig(this.charId, this.voxelMat);
    this.boardVis = buildBoardVisual(this.boardId, this.rig.def.deck, this.voxelMat);
    this.boardTrickG.add(this.boardVis.group);
    for (const k of Object.keys(this.pivG) as PivName[]) this.pivG[k].removeFromParent();
    this.pivG = {} as Record<PivName, THREE.Group>;
    for (const k of ['head', 'armN', 'armF', 'legN', 'legF'] as PivName[]) {
      const g = new THREE.Group();
      g.rotation.order = 'ZYX';
      (k === 'legN' || k === 'legF' ? this.riderOffG : this.hipG).add(g);
      this.pivG[k] = g;
    }
    this.attachRig();
  }

  private attachRig() {
    const r = this.rig;
    const put = (m: THREE.Mesh, parent: THREE.Object3D) => {
      parent.add(m);
      m.position.set(0, 0, 0);
      m.quaternion.identity();
      m.scale.set(1, 1, 1);
    };
    put(r.meshes.torso, this.hipG);
    for (const k of ['head', 'armN', 'armF', 'legN', 'legF'] as PivName[]) put(r.meshes[k], this.pivG[k]);
    if (r.eyes) r.eyes.visible = true;
    if (r.deadEyes) r.deadEyes.visible = false;
  }

  pressTrick(fam: TrickFamily) {
    if (this.phase !== 'playing' || this.paused || this.inputBlocked) return;
    this.sfx.init();
    if (this.grounded || this.trick || this.airTime < 0.035 || this.grinding) {
      this.trickQueue = fam;
      this.trickQueueT = 0;
      return;
    }
    this.startTrick(fam);
  }

  pressFreestyle(popFromGround = false) {
    if (this.phase !== 'playing' || this.paused || this.inputBlocked) return;
    this.sfx.init();
    if (!this.grounded && !this.trick && !this.grinding && this.airTime > 0.035) {
      if (this.startNextCycle() || !popFromGround) return;
      this.pressJump();
    } else if (popFromGround && (this.grounded || this.grinding)) {
      this.pressJump();
    }
    this.freestyleQueueT = this.trick ? Math.max(0.34, this.trick.dur - this.trick.t + 0.14) : 0.38;
  }

  private pressGrab() {
    if (this.phase !== 'playing' || this.paused || this.inputBlocked) return;
    this.sfx.init();
    if (!this.grounded && !this.trick && !this.grinding && this.airTime > 0.035) this.startNextGrab();
    else this.grabQueueT = this.trick ? Math.max(0.36, this.trick.dur - this.trick.t + 0.14) : 0.36;
  }

  private startNextGrab() {
    const def = TRICK_DEFS[GRAB_CYCLE[this.grabIdx % GRAB_CYCLE.length]];
    if (this.beginTrick(def)) this.grabIdx++;
  }

  private startNextCycle() {
    const land = this.predictLanding();
    const p = this.board.getPosition();
    const bigAir = (land ? land.t > 0.72 : true) || p.y - this.heightAt(p.x) > 2.4;
    for (let i = 0; i < FREESTYLE_CYCLE.length; i++) {
      const idx = (this.cycleIdx + i) % FREESTYLE_CYCLE.length;
      const d = TRICK_DEFS[FREESTYLE_CYCLE[idx]];
      if (d.bigAirOnly && !bigAir) continue;
      if (!this.beginTrick(d, idx % 2 ? -1 : 1, true)) return false;
      this.cycleIdx = idx + 1;
      return true;
    }
    return false;
  }

  private startTrick(fam: TrickFamily) {
    const land = this.predictLanding();
    const p = this.board.getPosition();
    const bigAir = (land ? land.t > 0.72 : true) || p.y - this.heightAt(p.x) > 2.4;
    const list = FAMILY_ORDER[fam];
    let def: TrickDef | null = null;
    for (let i = 0; i < list.length; i++) {
      const idx = (this.familyIdx[fam] + i) % list.length;
      const d = TRICK_DEFS[list[idx]];
      if (d.bigAirOnly && !bigAir) continue;
      def = d;
      this.familyIdx[fam] = idx + 1;
      break;
    }
    if (!def) return;
    this.beginTrick(def);
  }

  private beginTrick(def: TrickDef, dir = Math.random() < 0.5 ? 1 : -1, freestyle = false) {
    const available = this.predictLanding()?.t ?? def.dur + 0.09;
    if (available < 0.08) return false;
    const dur = Math.min(def.dur, Math.max(def.family === 'grab' ? 0.17 : 0.22, available - 0.07));
    const p = this.board.getPosition();
    this.trick = { def, t: 0, dur, dir, freestyle, caught: false };
    this.deckTrail.begin(this.theme.id, def.family, freestyle);
    this.cb.onPopup(def.name, 'air', def.family === 'grab' ? 'GRAB' : 'FREESTYLE');
    this.sfx.whoosh(def.family === 'grab');
    this.particles.burst(p.x, p.y + 0.1, 0.24, freestyle ? 4 : 3, [0xe7fc86, 0xffdf85, 0xfff1d6], 1.7, {
      up: 0.48, life: 0.27, size: 0.062, gravity: 2, drag: 3, flat: true,
    });
    return true;
  }

  private finishTrick(scored: boolean) {
    if (!this.trick) return;
    const { def, t, dur, dir, freestyle } = this.trick;
    if (scored) this.showFreestyleCatch();
    const from = trickPose(def.kind, t, dur, dir, freestyle);
    for (const axis of ['flip', 'yaw', 'boardYaw', 'trickRoll', 'trickPitch', 'boardPitch', 'salto'] as const) {
      from[axis] = angleDelta(from[axis]);
    }
    this.releasePose = { from, elapsed: 0 };
    this.trick = null;
    this.deckTrail.end();
    if (scored) this.airTricks.push(def);
  }

  private showFreestyleCatch() {
    if (!this.trick?.freestyle || this.trick.caught) return;
    this.trick.caught = true;
    this.deckTrail.catchDeck(this.boardTrickG);
    this.sfx.deckCatch();
  }

  togglePause() {
    if (this.phase !== 'playing') return;
    this.paused = !this.paused;
    this.onBlur();
    if (this.paused) this.sfx.update(0, true, false);
    this.cb.onPause(this.paused);
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('blur', this.onBlur);
    document.removeEventListener('visibilitychange', this.onVisibility);
    this.ro?.disconnect();
    this.sfx.dispose();
    for (const p of this.pieces) disposePiece(p, this.world, this.scene, this.coinGeo);
    this.pieces = [];
    this.rig.dispose();
    this.boardVis.dispose();
    this.coinGeo.dispose();
    this.coinMat.dispose();
    this.terrainMat.map?.dispose();
    this.terrainMat.dispose();
    this.voxelMat.dispose();
    this.rideShadow.material.map?.dispose();
    this.rideShadow.material.dispose();
    this.rideShadow.geometry.dispose();
    this.water.geometry.dispose();
    (this.water.material as THREE.Material).dispose();
    this.particles.mesh.geometry.dispose();
    (this.particles.mesh.material as THREE.Material).dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
    this.backdrop.remove();
    this.deckTrail.canvas.remove();
  }

  /* ================================================================ */
  /* Setup                                                            */
  /* ================================================================ */

  private applyTheme() {
    const t = this.theme;
    this.backdrop.style.backgroundImage = `url("${ART}${t.art}"), ${t.skyCss}`;
    (this.scene.fog as THREE.Fog).color.set(t.fog);
    this.hemi.color.set(t.hemiSky);
    this.hemi.groundColor.set(t.hemiGround);
    this.hemi.intensity = t.hemiIntensity;
    this.sun.color.set(t.sunColor);
    this.sun.intensity = t.sunIntensity;
    (this.water.material as THREE.MeshLambertMaterial).color.set(t.water);
  }

  getPlaceId() {
    return this.placeId;
  }

  /** change place (menu only) */
  setPlace(id: string) {
    if (this.phase !== 'menu') return;
    this.placeId = getPlace(id).id;
    this.theme = getPlace(id);
    try {
      localStorage.setItem(PLACE_KEY, this.placeId);
    } catch {
      /* ignore */
    }
    this.applyTheme();
    this.resetWorld();
    this.snapCamera();
    const p = this.board.getPosition();
    this.particles.burst(p.x, p.y + 0.8, 0.3, 16, [0xffe066, 0xffffff, 0x7fe3ff, 0xff8fd1], 3.5, { up: 2, life: 0.8, size: 0.12, gravity: 3, drag: 2 });
    this.sfx.init();
    this.sfx.coin(1.2);
  }

  private resetWorld() {
    if (this.world) {
      for (const p of this.pieces) disposePiece(p, this.world, this.scene, this.coinGeo);
    }
    this.pieces = [];
    this.rag = [];
    this.tumblingCones = [];
    this.particles.clear();
    this.deckTrail.clear();

    const world = new World({ gravity: { x: 0, y: -GRAVITY } });
    world.on('post-solve', this.onPostSolve);
    this.world = world;
    this.gen = new LevelGen((Math.random() * 1e9) | 0);
    this.gen.propSet = this.theme.props;
    this.camT.set(0, 1, 0);
    this.ensureTerrain(0);

    const b = world.createBody({
      type: 'dynamic',
      position: { x: 0, y: RIDE_CLEAR + 0.01 },
      angle: 0,
      bullet: true,
      allowSleep: false,
      linearDamping: 0,
      angularDamping: 0.05,
    });
    b.createFixture({
      shape: new Box(DECK_HW, DECK_HH),
      density: 6,
      friction: 0,
      restitution: 0,
      filterGroupIndex: -1,
      userData: 'deck',
    });
    this.wheelFix = [
      b.createFixture({
        shape: new Circle({ x: -WHEEL_X, y: WHEEL_Y }, WHEEL_R),
        density: 12,
        friction: 0,
        restitution: 0,
        filterGroupIndex: -1,
        userData: 'wheel',
      }),
      b.createFixture({
        shape: new Circle({ x: WHEEL_X, y: WHEEL_Y }, WHEEL_R),
        density: 12,
        friction: 0,
        restitution: 0,
        filterGroupIndex: -1,
        userData: 'wheel',
      }),
    ];
    this.headFix = b.createFixture({
      shape: (() => {
        const h = this.rig ? this.rig.height : 1.3;
        const lo = DECK_HH + Math.max(0.34, (this.rig ? this.rig.legLen : 0.26) + 0.08);
        const hi = DECK_HH + Math.max(lo + 0.3, h * 0.95);
        return new Box(0.23, (hi - lo) / 2, { x: 0.03, y: (hi + lo) / 2 }, 0);
      })(),
      isSensor: true,
      density: 0,
      filterGroupIndex: -1,
      userData: 'head',
    });
    this.board = b;
    this.bPrev = { x: 0, y: RIDE_CLEAR + 0.01, a: 0 };

    // reset state
    this.input.left = this.input.right = this.input.jump = false;
    this.jumpBuffer = 0;
    this.jumpCooldown = 0;
    this.coneRecovery = 0;
    this.grounded = true;
    this.groundN = { x: 0, y: 1 };
    this.coyote = 0;
    this.airTime = 0;
    this.groundTime = 0;
    this.landCacheAge = 99;
    this.landCache = null;
    this.prevVel = { x: 0, y: 0 };
    this.accS = { x: 0, y: 0 };
    this.headHit = false;
    this.wallHit = false;
    this.stuckTime = 0;
    this.accum = 0;
    this.slowmo = 0;
    this.crashTimer = 0;
    this.shake = 0;
    this.boardInWater = false;
    this.startX = 0;
    this.distance = 0;
    this.trickScore = 0;
    this.coinCount = 0;
    this.coneCount = 0;
    this.combo = 0;
    this.flipsTotal = 0;
    this.coinChain = 0;
    Object.assign(this.rig_s, {
      crouch: 0,
      crouchV: 0,
      lean: 0,
      leanV: 0,
      head: 0,
      headV: 0,
      squash: 0,
      squashV: 0,
      flap: 0,
      push: -1,
    });
    this.trick = null;
    this.releasePose = null;
    this.freestyleQueueT = 0;
    this.grabQueueT = 0;
    this.backflipLatch = false;
    this.cycleIdx = 0;
    this.grabIdx = 0;
    this.familyIdx = { flip: 0, grab: 0, spin: 0 };
    this.grinding = null;
    this.pushing = false;
    this.bodyYaw = -1.15;
    this.headYawW = -1.15;
    this.headTarget = -1.15;
    this.headTimer = 2;
    this.trickQueue = null;
    this.airTricks = [];
    this.pose = { ...ZERO_POSE };
    if (this.rig) this.attachRig();
    this.emitHud();
  }

  private ensureTerrain(x: number) {
    this.gen.generateUntil(x + 160);
    while (this.gen.out.length) {
      const d = this.gen.out.shift()!;
      this.pieces.push(
        buildPiece(
          d,
          this.world,
          { terrain: this.terrainMat, voxel: this.voxelMat, coin: this.coinMat },
          this.coinGeo,
          this.scene,
          this.theme.palette,
        ),
      );
    }
    const cutoff = Math.min(this.camT.x, x) - 90;
    while (this.pieces.length > 1 && this.pieces[0].data.maxX < cutoff) {
      disposePiece(this.pieces.shift()!, this.world, this.scene, this.coinGeo);
    }
    while (this.gen.gaps.length && this.gen.gaps[0].x1 < cutoff) this.gen.gaps.shift();
  }

  private heightAt(x: number): number {
    for (const p of this.pieces) {
      if (x >= p.data.minX && x <= p.data.maxX) return surfAt(p.data.pts, x);
    }
    for (const p of this.pieces) if (p.data.minX > x) return p.data.pts[0].y;
    return 0;
  }

  private gapAt(x: number): GapInfo | null {
    for (const g of this.gen.gaps) if (x > g.x0 && x < g.x1) return g;
    return null;
  }

  /* ================================================================ */
  /* Input                                                            */
  /* ================================================================ */

  private pressJump() {
    if (this.inputBlocked) return;
    this.sfx.init();
    if (this.phase === 'menu') {
      this.start();
      return;
    }
    if (this.phase === 'over') {
      if (this.overTime > 0.6) this.restart();
      return;
    }
    if (this.phase === 'playing') {
      if (this.paused) {
        this.togglePause();
        return;
      }
      this.input.jump = true;
      this.jumpBuffer = 0.18;
    }
  }

  private onKeyDown = (e: KeyboardEvent) => {
    if (this.inputBlocked || e.ctrlKey || e.metaKey || e.altKey || e.defaultPrevented) return;
    const k = e.code;
    const target = e.target instanceof HTMLElement ? e.target : null;
    if (target?.closest('input, textarea, select, [contenteditable]')) return;
    if ((k === 'Space' || k === 'Enter') && target?.closest('button, a, summary')) return;
    if (k === 'ArrowLeft' || k === 'ArrowRight' || k === 'ArrowUp' || k === 'ArrowDown' || k === 'Space') {
      e.preventDefault();
    }
    if (k === 'ArrowLeft' || k === 'KeyA') {
      this.input.left = true;
      this.sfx.init();
    } else if (k === 'ArrowRight' || k === 'KeyD') {
      this.input.right = true;
      this.sfx.init();
    } else if (k === 'Space' || k === 'ArrowUp' || k === 'KeyW') {
      if (!e.repeat) this.pressJump();
    } else if (k === 'KeyZ' || k === 'KeyJ') {
      if (!e.repeat) this.pressTrick('flip');
    } else if (k === 'KeyX' || k === 'KeyK') {
      if (!e.repeat) this.pressTrick('grab');
    } else if (k === 'KeyC' || k === 'KeyL') {
      if (!e.repeat) this.pressTrick('spin');
    } else if (k === 'KeyS') {
      if (!e.repeat) this.pressGrab();
    } else if (k === 'KeyF') {
      if (!e.repeat) this.pressFreestyle();
    } else if (k === 'Enter') {
      if (this.phase === 'menu') this.start();
      else if (this.phase === 'over' && this.overTime > 0.6) this.restart();
    } else if (k === 'KeyR') {
      if (this.phase === 'playing' || this.phase === 'over' || this.phase === 'crashed') this.restart();
    } else if (k === 'Escape' || k === 'KeyP') {
      this.togglePause();
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    const k = e.code;
    if (k === 'ArrowLeft' || k === 'KeyA') this.input.left = false;
    else if (k === 'ArrowRight' || k === 'KeyD') this.input.right = false;
    else if (k === 'Space' || k === 'ArrowUp' || k === 'KeyW') this.input.jump = false;
  };

  private onBlur = () => {
    this.input.left = this.input.right = this.input.jump = false;
    this.jumpBuffer = this.grabQueueT = this.freestyleQueueT = 0;
    this.trickQueue = null;
  };

  private onVisibility = () => {
    if (document.hidden && this.phase === 'playing' && !this.paused) this.togglePause();
  };

  private onResize = () => {
    const w = this.container.clientWidth || window.innerWidth;
    const h = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h);
    this.deckTrail.resize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  /* ================================================================ */
  /* Main loop                                                        */
  /* ================================================================ */

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    let dt = (now - this.lastT) / 1000;
    this.lastT = now;
    if (!(dt > 0)) dt = 0;
    dt = Math.min(dt, 0.075);

    if (this.phase === 'menu' && !this.preview) return;

    if (this.paused) {
      this.renderFrame();
      return;
    }
    this.realTime += dt;

    let timeScale = 1;
    if (this.slowmo > 0) {
      this.slowmo -= dt;
      timeScale = this.slowmo > 0.48 ? 0.34 : 0.34 + clamp(1 - this.slowmo / 0.48, 0, 1) * 0.66;
    }
    const gdt = dt * timeScale;
    this.accum += gdt;
    let steps = 0;
    while (this.accum >= PHYS_DT && steps < 10) {
      this.fixedStep(PHYS_DT);
      this.accum -= PHYS_DT;
      steps++;
    }
    if (steps >= 10) this.accum = 0;
    const alpha = clamp(this.accum / PHYS_DT, 0, 1);

    const bp = this.board.getPosition();
    this.ensureTerrain(bp.x);
    this.updateVisuals(gdt, dt, alpha);
    this.renderFrame();
  };

  private renderFrame() {
    if (this.renderer instanceof FlatRenderer) {
      this.renderer.paint({ camera: this.camera, target: this.camT, pieces: this.pieces, theme: this.theme,
        rider: [this.boardTrickG, ...SEGS.map((key) => this.rig.meshes[key])], particles: this.particles.mesh,
        shadow: { position: this.rideShadow.position, visible: this.rideShadow.visible, opacity: this.rideShadow.material.opacity } });
    } else this.renderer.render(this.scene, this.camera);
    this.deckTrail.paint(this.projectTrail);
  }

  private projectTrail = (world: THREE.Vector3, screen: THREE.Vector2) => {
    if (this.renderer instanceof FlatRenderer) this.renderer.projectToNdc(world, screen);
    else {
      const p = this.trailProjection.copy(world).project(this.camera);
      screen.set(p.x, p.y);
    }
  };

  private fixedStep(dt: number) {
    const b = this.board;
    const bp = b.getPosition();
    this.bPrev.x = bp.x;
    this.bPrev.y = bp.y;
    this.bPrev.a = b.getAngle();
    for (const r of this.rag) {
      const p = r.body.getPosition();
      r.px = p.x;
      r.py = p.y;
      r.pa = r.body.getAngle();
    }

    if (this.phase === 'playing') this.controls(dt);

    const v0 = b.getLinearVelocity();
    this.prevVel.x = v0.x;
    this.prevVel.y = v0.y;

    this.world.step(dt, 8, 3);

    const v1 = b.getLinearVelocity();
    const k = 1 - Math.exp(-dt * 22);
    this.accS.x += ((v1.x - this.prevVel.x) / dt - this.accS.x) * k;
    this.accS.y += ((v1.y - this.prevVel.y) / dt - this.accS.y) * k;
    if (this.impactCooldown > 0) this.impactCooldown -= dt;
    if (this.splashCooldown > 0) this.splashCooldown -= dt;

    if (this.phase === 'playing') this.afterStep(dt);
    else if (this.phase === 'crashed' || this.phase === 'over') this.ragdollPhysics(dt);
  }

  /* ================================================================ */
  /* Skating                                                          */
  /* ================================================================ */

  private controls(dt: number) {
    const b = this.board;
    const v = b.getLinearVelocity();
    const vx = v.x;
    const vy = v.y;
    const ang = b.getAngle();
    const fx = Math.cos(ang);
    const fy = Math.sin(ang);
    const m = b.getMass();

    if (this.jumpBuffer > 0) this.jumpBuffer -= dt;
    if (this.jumpCooldown > 0) this.jumpCooldown -= dt;
    this.coneRecovery = Math.max(0, this.coneRecovery - dt);
    if (this.grinding) {
      if (this.jumpBuffer > 0) {
        this.jumpBuffer = 0;
        this.exitGrind(5.5);
      }
      return;
    }
    if (this.jumpBuffer > 0 && (this.grounded || this.coyote > 0) && this.jumpCooldown <= 0) {
      this.doJump();
      return;
    }

    const L = this.input.left;
    const R = this.input.right;
    if (this.grounded) {
      const s = vx * fx + vy * fy;
      const target = R && !L ? BOOST_SPEED : L && !R ? BRAKE_SPEED : CRUISE_SPEED;
      this.pushing = (R && !L) || s < target - 0.4;
      let a = 0;
      if (s < target) {
        a = R ? BOOST_ACC : PUSH_ACC;
        if (s < 2) a += 4;
      } else if (L && s > target) {
        a = -BRAKE_ACC;
      }
      // push horizontally (not along the board) so the force can't feed a nose-down porpoise
      if (a > 0) a *= 1 - this.coneRecovery * 1.48;
      if (a !== 0) b.applyForceToCenter({ x: a * m, y: 0 }, true);
      // (board angle is locked to the slope in afterStep, after the physics step)
    } else {
      this.pushing = false;
      this.levelAssist(dt);
    }

    const sp = Math.hypot(vx, vy);
    if (sp > 0.1) {
      const k = 0.0032 * sp * m;
      b.applyForceToCenter({ x: -vx * k, y: -vy * k }, true);
    }
    if (sp > 30) b.setLinearVelocity({ x: (vx * 30) / sp, y: (vy * 30) / sp });
  }

  /** Ballistic prediction of where the board will touch down (skips gaps). */
  private predictLanding(): { x: number; slope: number; t: number } | null {
    const b = this.board;
    const p = b.getPosition();
    const v = b.getLinearVelocity();
    let x = p.x;
    let y = p.y;
    let vx = v.x;
    let vy = v.y;
    const st = 0.035;
    for (let t = st; t < 3.2; t += st) {
      vy -= GRAVITY * st;
      x += vx * st;
      y += vy * st;
      if (y < WATER_Y) return null;
      if (this.gapAt(x)) continue;
      const h = this.heightAt(x);
      if (y - RIDE_CLEAR < h + 0.05) {
        const s = (this.heightAt(x + 0.7) - this.heightAt(x - 0.7)) / 1.4;
        return { x, slope: clamp(Math.atan(s), -0.9, 0.9), t };
      }
    }
    return null;
  }

  private landCache: { x: number; slope: number; t: number } | null = null;
  private landCacheAge = 99;

  private slopeAt(x: number) {
    return Math.atan2(this.heightAt(x + WHEEL_X) - this.heightAt(x - WHEEL_X), WHEEL_X * 2);
  }

  private levelAssist(dt: number) {
    const b = this.board;
    this.landCacheAge += dt;
    if (this.landCacheAge > 0.03) {
      this.landCache = this.predictLanding();
      this.landCacheAge = 0;
    }
    const land = this.landCache;
    const near = land ? clamp(1 - land.t / 0.55, 0, 1) : 0;
    const target = (land?.slope ?? 0) * (0.65 + near * 0.35);
    const diff = angleDelta(target - b.getAngle());
    // Only the presentation spins; the physics deck follows the upcoming slope.
    b.setAngularVelocity(clamp(diff * (5 + 13 * near), -8, 8));
  }

  private doJump() {
    const b = this.board;
    const v = b.getLinearVelocity();
    const ang = b.getAngle();
    let dx = -Math.sin(ang) * 0.55;
    let dy = Math.cos(ang) * 0.55 + 0.45;
    const l = Math.hypot(dx, dy) || 1;
    dx /= l;
    dy /= l;
    let vx = v.x;
    let vy = v.y;
    const vn = vx * dx + vy * dy;
    if (vn < 0) {
      vx -= dx * vn;
      vy -= dy * vn;
    }
    vx += dx * JUMP_SPEED;
    vy += dy * JUMP_SPEED;
    b.setLinearVelocity({ x: vx, y: vy });
    b.setAngularVelocity(0.58);
    this.landCacheAge = 99;
    if (this.grounded) {
      this.takeoffX = b.getPosition().x;
      this.airTricks = [];
    }
    this.backflipLatch = false;
    this.jumpBuffer = 0;
    this.coyote = 0;
    this.jumpCooldown = 0.19;
    this.grounded = false;
    this.airTime = 0.001;
    this.rig_s.push = -1;
    this.rig_s.crouchV += 2.4;
    this.rig_s.squashV -= 3.2;
    this.sfx.pop();
    this.dust(3);
  }

  private scanContacts() {
    const b = this.board;
    let wheels = 0;
    let nx = 0;
    let ny = 0;
    let deck = false;
    this.wallHit = false;
    this.headHit = false;
    for (let ce = b.getContactList(); ce; ce = ce.next) {
      const c = ce.contact;
      if (!c.isTouching()) continue;
      const fa = c.getFixtureA();
      const fb = c.getFixtureB();
      const mineIsA = fa.getBody() === b;
      const mine = mineIsA ? fa : fb;
      const other = mineIsA ? fb : fa;
      if (other.getUserData() !== 'terrain' && other.getUserData() !== 'rail') continue;
      const ud = mine.getUserData();
      if (ud === 'head') {
        this.headHit = true;
        continue;
      }
      const wm = c.getWorldManifold(null);
      let cnx = 0;
      let cny = 1;
      if (wm) {
        const s = mineIsA ? -1 : 1;
        cnx = wm.normal.x * s;
        cny = wm.normal.y * s;
      }
      if (cnx < -0.75) this.wallHit = true;
      if (ud === 'wheel') {
        // only surfaces facing upwards count as ground (not cliff walls)
        if (cny > 0.35) {
          wheels++;
          nx += cnx;
          ny += cny;
        }
      } else if (ud === 'deck') {
        deck = true;
      }
    }
    return { wheels, nx, ny, deck };
  }

  private afterStep(dt: number) {
    if (this.grinding) {
      this.grindFollow(dt);
      return;
    }
    if (!this.grounded) this.board.setAngularDamping(0.05);
    const b = this.board;
    const pos = b.getPosition();
    const px = pos.x;
    const py = pos.y;
    const v = b.getLinearVelocity();
    let { wheels, nx, ny, deck } = this.scanContacts();
    const was = this.grounded;
    const slope = this.slopeAt(px);
    const trackY = this.heightAt(px) + RIDE_CLEAR;
    // Bridge a missed wheel contact on a solid landing, never a gap or cliff face.
    if (!wheels && !was && this.airTime > 0.13 && !this.wallHit && !this.gapAt(px - WHEEL_X) && !this.gapAt(px + WHEEL_X) &&
        this.bPrev.y > trackY - 0.13 && py >= trackY - 0.22 && py <= trackY + 0.035 && v.y - v.x * Math.tan(slope) < -0.08) {
      b.setTransform({ x: px, y: trackY + 0.008 }, slope);
      b.setLinearVelocity({ x: v.x, y: v.x * Math.tan(slope) });
      [nx, ny] = [-Math.sin(slope), Math.cos(slope)];
      wheels = 1;
    }
    this.grounded = wheels > 0;
    if (this.grounded) {
      const l = Math.hypot(nx, ny) || 1;
      this.groundN.x = nx / l;
      this.groundN.y = ny / l;
      // keep the board flat on the terrain slope (smooth lerp so landings don't clip)
      const sDiff = angleDelta(slope - b.getAngle());
      b.setAngle(b.getAngle() + sDiff * Math.min(1, dt * 32));
      b.setAngularVelocity(0);
    }

    // grind rail mount: falling onto a rail locks on (Pigeon-style)
    if (!this.grinding) {
      for (const pc of this.pieces) {
        if (pc.data.minX > px + 2 || pc.data.maxX + 2 < px) continue;
        for (const rail of pc.rails) {
          if (px < rail.x0 - 0.4 || px > rail.x1 + 0.4) continue;
          const ra = railAt(rail, px);
          const dy = py - (ra.y + RIDE_CLEAR);
          if (dy > -0.35 && dy < 0.55 && v.y < 4) {
            this.startGrind(rail);
            return;
          }
        }
      }
    }

    if (this.grounded) {
      if (!was && this.airTime > 0.15) {
        this.onLand();
        if (this.phase !== 'playing') return;
      }
      this.coyote = 0.16;
      this.airTime = 0;
      this.groundTime += dt;
    } else {
      if (was) {
        this.takeoffX = px;
        this.landCacheAge = 99;
        this.airTricks = [];
      }
      this.coyote -= dt;
      this.airTime += dt;
      this.groundTime = 0;
    }

    // crash checks
    const upY = Math.cos(b.getAngle());
    if (this.headHit && !this.grounded) return this.crash('head');
    if (deck && upY < 0.25) return this.crash('head');
    if (this.wallHit && this.prevVel.x - v.x > 2.5) return this.crash('wall');
    const gap = this.gapAt(px);
    if (gap && !this.grounded && py < Math.min(gap.y0, gap.y1) - 1.0) return this.crash('fall');
    if (py < WATER_Y + 0.5) return this.crash('water');
    this.checkCones(px, b.getPosition().y);
    const speed = Math.hypot(v.x, v.y);
    if (speed < 0.8) this.stuckTime += dt;
    else this.stuckTime = 0;
    if (this.stuckTime > 2.5) return this.crash('stuck');

    // freestyle trick timing
    if (this.trick) {
      this.trick.t += dt;
      if (this.trick.t >= this.trick.dur) this.finishTrick(true);
    }
    if (this.grabQueueT > 0) this.grabQueueT -= dt;
    if (this.freestyleQueueT > 0) this.freestyleQueueT -= dt;
    const canTrick = !this.grounded && !this.trick && this.airTime > 0.035;
    if (canTrick && this.grabQueueT > 0) {
      this.grabQueueT = 0;
      this.startNextGrab();
    }
    if (this.trickQueue) {
      this.trickQueueT += dt;
      if (!this.grounded && !this.trick && this.airTime > 0.04) {
        const f = this.trickQueue;
        this.trickQueue = null;
        this.startTrick(f);
      } else if (this.trickQueueT > 0.5) {
        this.trickQueue = null;
      }
    }
    // freestyle button queue: fires only after the current trick finishes
    if (canTrick && !this.trick && this.freestyleQueueT > 0) {
      this.freestyleQueueT = 0;
      this.startNextCycle();
    }
    if (!this.input.left) this.backflipLatch = false;
    if (canTrick && !this.trick && this.input.left && !this.input.right && !this.backflipLatch && this.airTime > 0.09) {
      this.backflipLatch = true;
      this.beginTrick(TRICK_DEFS.salto, -1);
    }

    this.distance = Math.max(this.distance, px - this.startX);
    if (this.combo > 0 && this.grounded && this.groundTime > 4.5) this.combo = 0;

    // speed dust trail
    if (this.grounded && speed > 11 && Math.random() < (speed - 11) * 0.025) {
      const wp = b.getWorldPoint({ x: -WHEEL_X, y: WHEEL_Y - WHEEL_R });
      this.particles.spawn({
        x: wp.x,
        y: wp.y + 0.05,
        z: (Math.random() - 0.5) * 0.5,
        vx: -v.x * 0.15 + (Math.random() - 0.5),
        vy: 0.6 + Math.random() * 0.8,
        vz: (Math.random() - 0.5) * 1.2,
        life: 0.5,
        size: 0.12,
        color: 0xe6dcc6,
        gravity: 1,
        drag: 3,
      });
    }

    this.collectCoins(px, py, b.getAngle());
  }

  private mult() {
    return Math.min(8, 1 + this.combo);
  }

  private onLand() {
    const b = this.board;
    const ang = b.getAngle();
    const ux = -Math.sin(ang);
    const uy = Math.cos(ang);
    const n = this.groundN;
    const dot = ux * n.x + uy * n.y;
    const diff = Math.acos(clamp(dot, -1, 1));
    const pv = this.prevVel;
    const impact = Math.max(0, -(pv.x * n.x + pv.y * n.y));
    const interrupted = !!this.trick && this.trick.t / this.trick.dur < 0.7;
    this.finishTrick(!interrupted);
    const imp = Math.min(impact, 15);
    this.rig_s.crouch = Math.min(this.rig_s.crouch, -0.03 - imp * 0.0035);
    this.rig_s.crouchV -= imp * 0.17;
    this.rig_s.squashV += imp * 0.18;
    this.rig_s.leanV -= imp * 0.085;
    const slope = Math.atan2(-n.x, n.y);
    b.setAngle(ang + angleDelta(slope - ang) * 0.65);
    this.sfx.land(impact);
    this.dust(impact);
    if (impact > 7) this.shake = Math.max(this.shake, Math.min(0.23, impact * 0.014));

    const px = b.getPosition().x;
    const gap = this.gen.gaps.find((g) => this.takeoffX < g.x0 + 0.6 && px > g.x1 - 0.3);
    let pts = 0;
    let title = 'MENDARAT MULUS';
    if (gap) {
      pts += 100 + Math.round((gap.x1 - gap.x0) * 12);
      title = 'LOMPAT JURANG';
    }
    const flips = this.airTricks.filter((d) => d.family === 'flip' || d.kind === 'salto').length;
    this.flipsTotal += flips;
    if (this.airTricks.length) {
      pts += this.airTricks.reduce((a, d) => a + d.pts, 0);
      const names = this.airTricks.map((d) => d.name);
      title = names.length === 1 ? names[0] : `${names.length} TRIK COMBO`;
      this.airTricks = [];
    }
    if (this.airTime > 1.17) {
      pts += Math.round(this.airTime * 45);
      if (title === 'MENDARAT MULUS') title = 'BIG AIR';
    }
    const perfect = diff < 0.29 && !interrupted;
    if (pts > 0) {
      if (perfect) pts += 50;
      const mult = this.mult();
      const total = pts * mult;
      this.trickScore += total;
      this.combo++;
      this.cb.onPopup(title, 'trick', `+${total}${mult > 1 ? ` (x${mult})` : ''} / ${perfect ? 'MULUS' : 'AUTO-LAND'}`);
      if (perfect) {
        this.sfx.perfect();
        const p = b.getPosition();
        this.particles.burst(p.x, p.y - 0.12, 0.2, 13, [0xe1f87c, 0xffe4aa, 0xfff1d6], 3.3, {
          up: 0.45, life: 0.43, size: 0.09, gravity: 5, drag: 2, flat: true,
        });
      }
    } else if (this.airTime > 0.36) {
      this.cb.onPopup(perfect ? 'MENDARAT MULUS' : 'AUTO-LAND', 'perfect');
    }
  }

  private checkCones(px: number, py: number) {
    const reach = WHEEL_X + CONE_HALF * 0.72;
    for (const piece of this.pieces) {
      if (piece.data.minX > px + 2 || piece.data.maxX < px - 2) continue;
      for (const cone of piece.cones) {
        if (cone.state !== 'ready' || px + reach < cone.x) continue;
        const height = py - RIDE_CLEAR - cone.y;
        const overlap = px - reach < cone.x && this.bPrev.x - reach <= cone.x;
        if (overlap && height < CONE_HEIGHT - 0.1 && height > -0.55) {
          cone.state = 'hit';
          const v = this.board.getLinearVelocity();
          this.sfx.cone();
          this.tumblingCones.push(new ConeTumble(cone.mesh, v.x));
          const retain = 0.81 - 0.16 * clamp(Math.abs(v.x) / BOOST_SPEED, 0, 1);
          this.board.setLinearVelocity({ x: v.x * retain, y: this.grounded ? v.y * retain : v.y });
          this.coneRecovery = 0.29;
          this.landCacheAge = 99;
          this.rig_s.leanV -= 1.55;
          this.rig_s.crouchV -= 0.6;
          if (!this.trick) this.cb.onPopup('CONE TERSENGGOL', 'bad', 'KECEPATAN TURUN');
          this.particles.burst(cone.x, cone.y + 0.18, 0.25, 7, [0xff8c4a, 0xf1c58a], 2.4, { life: 0.35, vx: 2.2, size: 0.074, flat: true });
        } else if (px >= cone.x + reach) {
          cone.state = 'cleared';
          this.coneCount++;
          this.trickScore += 75;
          this.cb.onPopup('CONE TERLEWATI', 'good', '+75');
          this.sfx.coin(0.84);
          this.particles.burst(cone.x, cone.y + CONE_HEIGHT, 0.2, 8, [0xf3ee9a, 0xcff252], 1.7, { up: 1.1, life: 0.37, size: 0.09, flat: true });
        }
      }
    }
  }

  private collectCoins(px: number, py: number, ang: number) {
    const cx = px - Math.sin(ang) * 0.65;
    const cy = py + Math.cos(ang) * 0.65;
    for (const p of this.pieces) {
      if (p.data.minX > cx + 2 || p.data.maxX + 22 < cx) continue;
      for (const c of p.coins) {
        if (c.taken) continue;
        const dx = c.x - cx;
        if (dx > 1.1 || dx < -1.1) continue;
        const dy = c.y - cy;
        if (dx * dx + dy * dy < 0.95 * 0.95) {
          c.taken = true;
          c.mesh.visible = false;
          this.coinCount++;
          if (this.realTime - this.lastCoinT < 0.7) this.coinChain = Math.min(this.coinChain + 1, 12);
          else this.coinChain = 0;
          this.lastCoinT = this.realTime;
          this.sfx.coin(1 + this.coinChain * 0.06);
          this.particles.burst(c.x, c.y, 0, 7, [0xffe066, 0xffc61a, 0xffffff], 3, {
            up: 1.5,
            life: 0.5,
            size: 0.1,
            gravity: 5,
            drag: 2,
          });
        }
      }
    }
  }

  private dust(impact: number) {
    const b = this.board;
    const n = Math.min(14, 3 + Math.floor(impact * 0.8));
    for (const wx of [-WHEEL_X, WHEEL_X]) {
      const wp = b.getWorldPoint({ x: wx, y: WHEEL_Y - WHEEL_R });
      this.particles.burst(wp.x, wp.y + 0.05, 0, n, [0xe2d3b3, 0xcdb994, 0xf2eadb], 1.5 + impact * 0.18, {
        up: 0.8,
        life: 0.6,
        size: 0.15,
        gravity: 3,
        drag: 3.5,
        spread: 0.3,
      });
    }
  }

  private feathers(x: number, y: number, n: number, power: number) {
    const cols = this.rig ? this.rig.def.fx.map((c) => new THREE.Color(c).getHex()) : [0xffffff];
    this.particles.burst(x, y, 0.2, n, cols, power, {
      up: 2,
      life: 2.4,
      size: 0.17,
      gravity: 2.2,
      drag: 2.4,
      flat: true,
      sway: 7,
      spin: 5,
      spread: 0.5,
    });
  }

  private splash(x: number, n: number) {
    this.particles.burst(x, WATER_Y + 0.1, 0.6, n, [0xffffff, 0xc4ecff, 0x84d6ff], 5, {
      up: 5,
      life: 1.1,
      size: 0.2,
      gravity: 15,
      drag: 0.6,
      spread: 0.7,
    });
  }

  /* ================================================================ */
  /* Crash & ragdoll                                                  */
  /* ================================================================ */

  private crash(reason: CrashReason) {
    if (this.phase !== 'playing') return;
    this.phase = 'crashed';
    this.crashReason = reason;
    this.crashTimer = 0;
    this.cb.onPhase('crashed');

    const b = this.board;
    const v = b.getLinearVelocity();
    const pv = this.prevVel;
    const useV =
      pv.x * pv.x + pv.y * pv.y > v.x * v.x + v.y * v.y ? { x: pv.x, y: pv.y } : { x: v.x, y: v.y };
    const direct = reason === 'wall';
    const w = clamp(b.getAngularVelocity() * 0.48 - (direct ? 3.8 : 1.45), -6.5, 4.2);
    const center = { x: b.getWorldCenter().x, y: b.getWorldCenter().y };
    const launch = direct ? 2.7 : reason === 'fall' ? 0.75 : 1.9;
    const base = { x: clamp(useV.x * (direct ? 0.58 : 0.85), -9, 14.5), y: clamp(useV.y, -15, 4) + launch };
    const R = this.rig;
    // Seed the ragdoll with the visible pose so the rider does not snap upright at impact.
    this.riderRoot.position.set(b.getPosition().x, b.getPosition().y, 0);
    this.riderRoot.rotation.z = b.getAngle();
    this.riderRoot.updateMatrixWorld(true);
    const wpos = new THREE.Vector3();
    const wq = new THREE.Quaternion();
    const wsc = new THREE.Vector3();
    const mk = (seg: SegName, kind: RagPart['kind'], density: number) => {
      const mesh = R.meshes[seg];
      mesh.matrixWorld.decompose(wpos, wq, wsc);
      const e = mesh.matrixWorld.elements;
      let ang = Math.atan2(-e[4], e[5]);
      if (Math.hypot(e[4], e[5]) < 0.25 * Math.max(0.01, wsc.y)) ang = Math.atan2(e[1], e[0]);
      const qRes = new THREE.Quaternion().setFromAxisAngle(Z_AXIS, -ang).multiply(wq);
      this.scene.add(mesh);
      mesh.position.copy(wpos);
      mesh.quaternion.copy(wq);
      mesh.scale.copy(wsc);
      const bx = R.boxes[seg];
      return this.makeRag({ x: wpos.x, y: wpos.y, a: ang }, mesh, wpos.z, kind, bx.hw * wsc.x, bx.hh * wsc.y,
        bx.cx * wsc.x, bx.cy * wsc.y, density, base, w, center, qRes);
    };
    const torso = mk('torso', 'torso', 1.55);
    const head = mk('head', 'head', 1.03);
    const wingN = mk('armN', 'wing', 0.5);
    const wingF = mk('armF', 'wing', 0.5);
    const legN = mk('legN', 'leg', 0.66);
    const legF = mk('legF', 'leg', 0.66);
    this.trick = null;
    this.deckTrail.end();
    this.releasePose = null;
    this.airTricks = [];
    const joint = (a: Body, bb: Body, lo: number, hi: number, drag: number) => {
      this.world.createJoint(
        new RevoluteJoint({ enableLimit: true, lowerAngle: lo, upperAngle: hi, enableMotor: true,
          maxMotorTorque: drag, motorSpeed: 0 }, a, bb, bb.getPosition()),
      );
    };
    joint(torso.body, head.body, -0.58, 0.62, 0.23);
    joint(torso.body, wingN.body, -1.0, 1.8, 0.09);
    joint(torso.body, wingF.body, -1.5, 1.4, 0.09);
    joint(torso.body, legN.body, -1.18, 1.3, 0.16);
    joint(torso.body, legF.body, -1.22, 1.28, 0.16);
    torso.body.setAngularVelocity(w - 1.4);
    head.body.setAngularVelocity(w * 0.58 + 0.7);
    wingN.body.setAngularVelocity(w + 6.3);
    wingF.body.setAngularVelocity(w - 4.5);
    legN.body.setAngularVelocity(w - 3.3);
    legF.body.setAngularVelocity(w + 3.8);

    if (this.headFix) {
      b.destroyFixture(this.headFix);
      this.headFix = null;
    }
    for (const f of this.wheelFix) f.setFriction(0.6);
    b.setLinearDamping(0.58);
    b.setLinearVelocity({ x: useV.x * (direct ? 0.32 : 0.64), y: Math.max(useV.y, -11) + (direct ? 1.05 : 0.3) });
    b.setAngularVelocity(w - 3.2);

    if (R.eyes) R.eyes.visible = false;
    if (R.deadEyes) R.deadEyes.visible = true;
    const tp = torso.body.getPosition();
    this.feathers(tp.x, tp.y + 0.3, 20, 4.8);
    this.sfx.crash();
    if (this.charId === 'ayam' || /chicken|pigeon/.test(this.charId)) this.sfx.squawk();
    if (reason === 'water') {
      this.sfx.splash();
      this.splash(tp.x, 30);
    }
    this.slowmo = 0.82;
    this.shake = 0.43;
    this.combo = 0;
    const msgs: Record<CrashReason, string[]> = {
      head: ['ADUH!'],
      wall: ['TEBING TERTABRAK'],
      fall: ['JATUH KE JURANG'],
      water: ['BYURR!'],
      stuck: ['PAPAN TERSANGKUT'],
    };
    this.cb.onPopup(pick(msgs[reason]), 'crash');
  }

  private makeRag(
    pose: Pose,
    mesh: THREE.Mesh,
    z: number,
    kind: RagPart['kind'],
    hw: number,
    hh: number,
    cx: number,
    cy: number,
    density: number,
    baseV: { x: number; y: number },
    w: number,
    center: { x: number; y: number },
    qRes: THREE.Quaternion,
  ): RagPart {
    const body = this.world.createBody({
      type: 'dynamic',
      position: { x: pose.x, y: pose.y },
      angle: pose.a,
      linearDamping: 0.17,
      angularDamping: 0.72,
      bullet: true,
    });
    body.createFixture({
      shape: new Box(hw, hh, { x: cx, y: cy }, 0),
      density,
      friction: 0.59,
      restitution: kind === 'torso' ? 0.24 : 0.16,
      filterGroupIndex: -1,
      userData: 'rag',
    });
    const rx = pose.x - center.x;
    const ry = pose.y - center.y;
    body.setLinearVelocity({
      x: baseV.x - w * ry + (Math.random() - 0.5) * 0.8,
      y: baseV.y + w * rx + (Math.random() - 0.5) * 0.8,
    });
    body.setAngularVelocity(w);
    const part: RagPart = { body, mesh, z, kind, qRes, inWater: false, px: pose.x, py: pose.y, pa: pose.a };
    this.rag.push(part);
    return part;
  }

  /* ================================================================ */
  /* Grind rails (Pigeon-style: 50-50 / boardslide / lipslide / feeble) */
  /* ================================================================ */

  private startGrind(rail: RailInfo) {
    const roll = Math.random();
    const style: GrindStyle = roll < 0.55 ? 'fifty' : roll < 0.75 ? 'boardslide' : roll < 0.87 ? 'lipslide' : 'feeble';
    this.grinding = { rail, style, dist: 0, pts: 0 };
    this.grindStyle = style;
    this.board.setType('kinematic');
    this.trick = null;
    this.deckTrail.end();
    this.trickQueue = null;
    this.cb.onPopup('GRIND!', 'good', { fifty: '50-50', boardslide: 'BOARDSLIDE', lipslide: 'LIPSLIDE', feeble: 'FEEBLE' }[style]);
    this.sfx.grindStart();
    this.shake = Math.max(this.shake, 0.15);
  }

  private grindFollow(dt: number) {
    const g = this.grinding!;
    const b = this.board;
    const p = b.getPosition();
    const v = b.getLinearVelocity();
    const ra = railAt(g.rail, p.x);
    b.setTransform({ x: p.x, y: ra.y + RIDE_CLEAR }, ra.ang);
    const vx = Math.max(2.5, v.x * (1 - 0.1 * dt));
    b.setLinearVelocity({ x: vx, y: Math.tan(ra.ang) * vx });
    b.setAngularVelocity(0);
    this.grounded = true;
    this.groundN.x = -Math.sin(ra.ang);
    this.groundN.y = Math.cos(ra.ang);
    g.dist += vx * dt;
    g.pts += vx * dt * 3;
    if (Math.random() < 0.7) {
      const wp = b.getWorldPoint({ x: -WHEEL_X, y: WHEEL_Y - WHEEL_R });
      this.particles.spawn({
        x: wp.x,
        y: wp.y + 0.05,
        z: 0.25,
        vx: -vx * 0.25 + (Math.random() - 0.5) * 2,
        vy: 1 + Math.random() * 2,
        vz: (Math.random() - 0.5) * 2,
        life: 0.35,
        size: 0.07,
        color: 0xffd23f,
        gravity: 10,
        drag: 1,
      });
    }
    this.distance = Math.max(this.distance, p.x - this.startX);
    this.collectCoins(p.x, p.y, b.getAngle());
    if (p.x >= g.rail.x1 - 0.15) this.exitGrind(2.4);
  }

  private exitGrind(pop: number) {
    const g = this.grinding;
    if (!g) return;
    this.grinding = null;
    const b = this.board;
    b.setType('dynamic');
    const v = b.getLinearVelocity();
    b.setLinearVelocity({ x: v.x, y: pop });
    b.setAngularVelocity(0);
    this.grounded = false;
    this.airTime = 0.001;
    this.takeoffX = b.getPosition().x;
    this.landCacheAge = 99;
    this.backflipLatch = false;
    this.airTricks = [];
    const pts = Math.round(g.pts);
    if (pts > 0) {
      this.trickScore += pts;
      this.cb.onPopup(`GRIND +${pts}`, 'trick');
    }
    this.sfx.land(2);
  }

  private onPostSolve = (contact: Contact, impulse: ContactImpulse) => {
    if (this.phase !== 'crashed' && this.phase !== 'over') return;
    const fa = contact.getFixtureA();
    const fb = contact.getFixtureB();
    const ua = fa.getUserData();
    const ub = fb.getUserData();
    if (ua !== 'rag' && ub !== 'rag') return;
    if (ua !== 'terrain' && ub !== 'terrain') return;
    const ni = impulse.normalImpulses[0] ?? 0;
    if (ni < 0.35 || this.impactCooldown > 0) return;
    this.impactCooldown = 0.11;
    const body = (ua === 'rag' ? fa : fb).getBody();
    const p = body.getPosition();
    this.sfx.thud(ni);
    if (ni > 0.6) this.feathers(p.x, p.y + 0.2, Math.min(12, 3 + Math.floor(ni * 3)), 2.5 + ni);
    if (ni > 1.3) this.shake = Math.max(this.shake, Math.min(0.4, ni * 0.12));
  };

  private ragdollPhysics(dt: number) {
    for (const r of this.rag) {
      const entered = this.buoy(r.body, r.inWater, dt);
      if (entered) {
        r.inWater = true;
        if ((r.kind === 'torso' || r.kind === 'head') && this.splashCooldown <= 0) {
          this.splashCooldown = 0.25;
          this.splash(r.body.getPosition().x, 24);
          this.sfx.splash();
        }
      }
    }
    if (this.buoy(this.board, this.boardInWater, dt)) {
      this.boardInWater = true;
      this.splash(this.board.getPosition().x, 12);
    }
  }

  /** returns true when the body just entered the water */
  private buoy(body: Body, wasIn: boolean, dt: number): boolean {
    const p = body.getPosition();
    const depth = WATER_Y - p.y + 0.15;
    if (depth <= 0) return false;
    const m = body.getMass();
    body.applyForceToCenter({ x: 0, y: m * GRAVITY * (1 + Math.min(depth, 0.8) * 2.4) }, true);
    const v = body.getLinearVelocity();
    const k = Math.max(0, 1 - dt * 3.5);
    body.setLinearVelocity({ x: v.x * k, y: v.y * k });
    body.setAngularVelocity(body.getAngularVelocity() * Math.max(0, 1 - dt * 2));
    return !wasIn;
  }

  private toOver() {
    this.phase = 'over';
    this.overTime = 0;
    const score = this.score();
    const newBest = this.rememberBest();
    this.emitHud();
    this.cb.onPhase('over', {
      score,
      distance: Math.floor(this.distance),
      coins: this.coinCount,
      cones: this.coneCount,
      best: this.best,
      newBest,
      reason: this.crashReason,
      flips: this.flipsTotal,
    });
  }

  private rememberBest() {
    const score = this.score();
    if (score <= this.best) return false;
    this.best = score;
    try {
      localStorage.setItem(BEST_KEY, String(score));
    } catch {
      /* Storage may be disabled by the browser. */
    }
    return true;
  }

  private score() {
    return Math.floor(this.distance) + this.trickScore + this.coinCount * 25;
  }

  private emitHud() {
    const v = this.board ? this.board.getLinearVelocity() : { x: 0, y: 0 };
    this.cb.onHud({
      score: this.score(),
      distance: Math.floor(this.distance),
      coins: this.coinCount,
      cones: this.coneCount,
      combo: this.combo > 0 ? this.mult() : 1,
      best: this.best,
      speed: Math.hypot(v.x, v.y),
    });
  }

  /* ================================================================ */
  /* Visuals                                                          */
  /* ================================================================ */

  private updateRig(dt: number, speed: number) {
    if (dt <= 0) return;
    const r = this.rig_s;
    const b = this.board;
    const ang = b.getAngle();
    const c = Math.cos(ang);
    const s = Math.sin(ang);
    const fxw = this.accS.x;
    const fyw = this.accS.y + GRAVITY;
    const flx = c * fxw + s * fyw;
    const fly = -s * fxw + c * fyw;
    const menu = this.phase === 'menu';
    const t = this.realTime;

    let crouchT = clamp(-(fly - GRAVITY) * 0.006, -0.13, 0.06);
    if (r.push >= 0 && this.grounded) crouchT -= 0.03;
    if (!this.grounded && !menu) {
      // in the air: tuck up while rising, extend while falling
      crouchT += clamp(b.getLinearVelocity().y * 0.008, -0.04, 0.05);
    }
    if (menu) crouchT = Math.sin(t * 2.6) * 0.018;
    r.crouchV += ((crouchT - r.crouch) * 170 - r.crouchV * 13) * dt;
    r.crouch = clamp(r.crouch + r.crouchV * dt, -0.16, 0.09);

    let leanT = clamp(flx * 0.018, -0.45, 0.45);
    if (!this.grounded && !menu) {
      if (this.input.left) leanT += 0.25;
      if (this.input.right) leanT -= 0.25;
      // lean back on the way up, forward to prepare the landing on the way down
      leanT += clamp(-b.getLinearVelocity().y * 0.01, -0.18, 0.18);
    }
    if (menu) leanT = Math.sin(t * 1.3) * 0.05;
    r.leanV += ((leanT - r.lean) * 80 - r.leanV * 8) * dt;
    r.lean = clamp(r.lean + r.leanV * dt, -0.7, 0.7);

    const headT = -r.leanV * 0.07 + (menu ? Math.sin(t * 1.7) * 0.14 : 0) + (!this.grounded && !menu ? 0.12 : 0);
    r.headV += ((headT - r.head) * 140 - r.headV * 9) * dt;
    r.head = clamp(r.head + r.headV * dt, -0.55, 0.55);

    r.squashV += (-r.squash * 280 - r.squashV * 9) * dt;
    r.squash = clamp(r.squash + r.squashV * dt, -0.22, 0.32);

    const air = !this.grounded && !menu;
    const spinning = air && (this.input.left || this.input.right);
    r.flapPhase += dt * (air ? 26 : 10);
    let flapT: number;
    if (spinning) flapT = 1.25 + Math.sin(r.flapPhase) * 0.15;
    else if (air) flapT = 0.65 + Math.sin(r.flapPhase) * 0.55;
    else if (menu) flapT = Math.sin(t * 0.9) > 0.92 ? 0.7 + Math.sin(r.flapPhase * 2.4) * 0.5 : 0.08;
    else flapT = 0.08 + Math.abs(Math.sin(r.flapPhase)) * Math.min(0.14, speed * 0.009);
    r.flap += (flapT - r.flap) * Math.min(1, dt * 18);

    if (!this.grounded && !menu) r.push = -1;
    else if (r.push >= 0) {
      r.push += dt / 0.42;
      if (r.push >= 1) r.push = this.pushing && speed > 1.5 ? 0 : -1;
    } else if (this.grounded && this.phase === 'playing' && this.pushing && speed > 1.5 && !this.grinding) {
      r.push = 0;
    }

    // body faces right while skating (push cycle active) / airborne / grinding, camera when idle
    const wantYaw = menu ? -1.15 : -0.12;
    this.bodyYaw += (wantYaw - this.bodyYaw) * Math.min(1, dt * 6);
    // head mostly faces right (direction of travel), rarely glances at the camera
    this.headTimer -= dt;
    if (this.headTimer <= 0) {
      this.headTimer = 1.5 + Math.random() * 3.5;
      this.headTarget = Math.random() < 0.15 ? -1.15 : 0;
    }
    // while pushing / airborne / grinding the head stays facing right
    if (this.pushing || !this.grounded || this.grinding) this.headTarget = 0;
    this.headYawW += (this.headTarget - this.headYawW) * Math.min(1, dt * 2.5);

    r.blinkT -= dt;
    if (r.blinkT <= 0) {
      r.blink = 0.12;
      r.blinkT = 2 + Math.random() * 3;
    }
    if (r.blink > 0) r.blink -= dt;
  }

  /** Pose the rider scene graph: springs (jelly feel) + freestyle trick formulas */
  private applyRig() {
    const r = this.rig_s;
    const R = this.rig;
    const P = this.pose;
    const t = this.realTime;
    const g = P.grab;
    const grabAmount = Math.abs(g);
    const tr = this.trick;
    const tk = tr ? tr.def.kind : null;
    const hu = tr ? Math.sin(Math.PI * Math.min(1, tr.t / tr.dur)) : 0;
    const airwalk = clamp(P.lift / 0.24, 0, 1);

    this.spinG.rotation.set(0, P.yaw, 0);
    this.facingG.rotation.y = this.bodyYaw;
    const grabLift = g > 0 ? g * 0.33 : 0;
    const grabTuck = g < 0 ? -g * 0.24 : 0;
    const bob = this.boardVis.float ? Math.sin(t * 4.5) * 0.035 : 0;
    this.boardTrickG.position.set(P.deckShift + (g > 0 ? -g * 0.2 : 0), P.deckLift + grabLift + grabTuck + bob, 0);
    this.boardTrickG.rotation.set(P.flip + (g > 0 ? g * 0.9 : 0), P.boardYaw, P.boardPitch + (g < 0 ? g * 0.35 : 0));
    if (this.grinding) {
      // Pigeon-style grind poses: board across the rail / angled / flat
      const st = this.grindStyle;
      if (st === 'boardslide') this.boardTrickG.rotation.y = Math.PI / 2;
      else if (st === 'lipslide') {
        this.boardTrickG.rotation.y = -Math.PI / 2;
        this.boardTrickG.rotation.z += 0.22;
      } else if (st === 'feeble') {
        this.boardTrickG.rotation.y = -0.7;
        this.boardTrickG.rotation.z += 0.18;
      }
    }

    // rider pivots around its body centre (salto / barrel roll spin in place)
    const lift = this.boardVis.float ? 0.12 : 0;
    const cy = R.legLen + Math.min(0.45, R.height * 0.32);
    const crouchG = grabAmount * 0.23;
    this.riderTiltG.position.set(-g * 0.11, DECK_HH + lift + bob + P.hop + grabLift + grabTuck - crouchG + cy + P.lift, 0);
    this.riderTiltG.rotation.set(P.trickRoll, 0, P.trickPitch + (g > 0 ? g * 0.35 : 0) + (g < 0 ? g * 0.25 : 0) + P.salto);
    this.riderOffG.position.set(0, -cy, 0);

    const pushDip = r.push >= 0 ? 0.07 : 0;
    const hipY = R.legLen + r.crouch - pushDip - grabAmount * 0.04;
    this.hipG.position.set(0, hipY, 0);
    this.hipG.rotation.set(0, 0, r.lean);
    const sq = r.squash;
    this.hipG.scale.set(1 + sq * 0.4, 1 - sq * 0.8, 1 + sq * 0.4);
    if (this.grinding) {
      this.hipG.position.y -= 0.05;
      this.hipG.scale.y *= 0.92;
    }

    this.pivG.head.position.copy(R.piv.head);
    this.pivG.head.rotation.set(0, this.headYawW - this.bodyYaw, r.head - grabAmount * 0.13);

    // arms / wings: balance flaps, grabs reach the board, Christ Air T-pose, Wing Flap frenzy
    let sN = r.flap;
    let sF = r.flap;
    let wN = 0;
    let wF = 0;
    let stN = 1;
    if (this.grinding) {
      const st = this.grindStyle;
      if (st === 'boardslide') sN = sF = 0.85;
      else if (st === 'lipslide') sN = sF = 0.7;
      else if (st === 'feeble') {
        sN = 0.2;
        sF = 0.9;
      } else sN = sF = 0.35; // 50-50: balanced
    } else if (tk === 'christ') {
      sN = sF = 1.45;
    } else if (airwalk > 0.02) {
      sN = 0.5;
      sF = 0.55 + 0.87 * airwalk;
    } else if (tk === 'wingflap') {
      sN = sF = 0.85 + Math.sin(t * 40) * 0.55;
    } else if (tk === 'gazelle') {
      // windmill arms through the barrel roll
      const wm = Math.sin(t * 18);
      sN = 0.9 + wm * 0.5;
      sF = 0.9 - wm * 0.5;
    } else if (tk === 'salto') {
      // tucked tight, hugging the knees
      sN = sF = 0.12;
    } else if (tk === 'rocket') {
      // swept back like a rocket
      sN = sF = -0.35;
    } else if (Math.abs(g) > 0.05) {
      const k = Math.min(1, Math.abs(g) * 1.6);
      sN = r.flap * (1 - k) + 0.12 * k;
      wN = (g > 0 ? 0.9 : -0.7) * k;
      stN = 1 + 0.35 * k;
      sF = r.flap * (1 - k) + 1.1 * k;
    } else if (tr && tk && TRICK_DEFS[tk].family === 'flip') {
      // flip tricks: arms wide for balance
      sN = sF = 0.55 + 0.67 * hu;
      if (tr.freestyle) {
        sN += P.tuck * 0.16;
        sF -= P.tuck * 0.3;
        wN = P.tuck * 0.83;
        wF = -P.tuck * 0.65;
      }
    } else if (tr && tk && TRICK_DEFS[tk].family === 'spin') {
      // spin tricks: arms tucked in
      sN = sF = tr.freestyle ? 0.81 - P.tuck * 0.54 : 0.25;
      wN = P.tuck * 0.66;
      wF = P.tuck * 0.39;
    } else if (!this.grounded && this.phase !== 'menu') {
      // jumping: arms reach up on the way up, spread on the way down
      sN = sF = 0.55 + clamp(this.board.getLinearVelocity().y * 0.08, -0.3, 0.5);
    } else if (r.push >= 0) {
      // pushing: arms out for balance, swinging with the stride
      const sw = Math.sin(r.push * Math.PI);
      sN = 0.4 + sw * 0.2;
      sF = 0.4 - sw * 0.2;
    }
    this.pivG.armN.position.copy(R.piv.armN);
    this.pivG.armF.position.copy(R.piv.armF);
    this.pivG.armN.rotation.set(-sN, 0, wN);
    this.pivG.armF.rotation.set(sF, 0, wF);
    this.pivG.armN.scale.set(1, stN, 1);
    this.pivG.armF.scale.set(1, 1, 1);

    if (Math.abs(g) > 0.04 || airwalk > 0.04) {
      const far = tk === 'melon';
      const arm = this.pivG[far ? 'armF' : 'armN'];
      const box = R.boxes[far ? 'armF' : 'armN'];
      const contact = this.handTarget.set(airwalk > 0.03 ? DECK_HW * 0.71 : far ? -0.13 : 0.1, DECK_HH, far ? -0.18 : 0.2);
      this.boardTrickG.localToWorld(contact);
      arm.parent!.worldToLocal(contact).sub(arm.position);
      const extend = clamp(contact.length() / Math.max(0.21, Math.abs(box.cy) + box.hh), 1, 1.83);
      const weight = clamp(Math.max(Math.abs(g), airwalk) * 1.22, 0, 1);
      this.tmpQ.setFromUnitVectors(this.down, contact.normalize());
      arm.quaternion.slerp(this.tmpQ, weight);
      arm.scale.y += (extend - arm.scale.y) * weight;
    }

    for (const k of ['legN', 'legF'] as PivName[]) {
      const base = Math.max(0.05, R.legLen + R.piv[k].y);
      const h = Math.max(0.03, base + r.crouch - pushDip);
      let ang = -r.lean * 0.2;
      let sc = h / base;
      let dz = 0;
      if (k === 'legN' && r.push >= 0) {
        const u = r.push;
        if (u < 0.2) {
          // recovery: foot lifts off the ground and swings forward
          const q = u / 0.2;
          ang = -0.6 + q * 1.1;
          sc = (h / base) * (1 - Math.sin(q * Math.PI) * 0.32);
          dz = 0.1 * Math.sin(q * Math.PI);
        } else {
          // push: foot reaches DOWN to the ground beside the board and kicks back
          const q = (u - 0.2) / 0.8;
          ang = 0.5 - q * 1.2;
          sc = Math.min(1.7, (h + RIDE_CLEAR) / (base * Math.max(0.45, Math.cos(ang))));
          dz = 0.16;
        }
      }
      if (k === 'legN' && tk === 'benihana') ang -= hu * 1.25;
      if (tk === 'christ') ang *= 0.3;
      if (airwalk > 0.02) {
        ang += (k === 'legN' ? 1.05 : -0.88) * airwalk;
        sc *= 1 + airwalk * 0.09;
        dz += (k === 'legN' ? 0.1 : -0.1) * airwalk;
      }
      if (this.grinding) sc *= 0.88; // knees bent on the rail
      // airborne: knees tuck while rising, extend while falling
      if (!this.grounded && this.phase !== 'menu') {
        const tuck = clamp(this.board.getLinearVelocity().y * 0.05, -0.15, 0.25);
        sc *= 1 - tuck;
        ang += tuck * 0.5;
      }
      // tricks tuck the legs: salto hugs tight, grabs pull in, flips stay compact
      if (tk === 'salto') {
        sc *= 0.72;
        ang += 0.5;
      } else if (Math.abs(g) > 0.05) {
        const near = k === 'legN' ? 1 : -1;
        sc *= 1 - grabAmount * 0.23;
        ang += grabAmount * (0.27 + 0.49 * near);
        dz += grabAmount * 0.069 * near;
      } else if (tr && tk && TRICK_DEFS[tk].family === 'flip') {
        sc *= 0.92;
        ang += 0.15;
      }
      const stance = k === 'legN' ? 1 : -1;
      sc *= 1 - P.tuck * (stance > 0 ? 0.22 : 0.13);
      ang += P.tuck * (stance > 0 ? 0.8 : -0.61);
      this.pivG[k].position.set(R.piv[k].x + stance * P.tuck * 0.068, h + P.tuck * 0.062, R.piv[k].z + dz);
      this.pivG[k].rotation.set(0, 0, ang);
      this.pivG[k].scale.set(1, sc, 1);
    }
    if (R.eyes) R.eyes.scale.y = r.blink > 0 ? 0.15 : 1;
  }

  private updateVisuals(gdt: number, rdt: number, alpha: number) {
    const b = this.board;
    const p = b.getPosition();
    const a = b.getAngle();
    const bx = this.bPrev.x + (p.x - this.bPrev.x) * alpha;
    const by = this.bPrev.y + (p.y - this.bPrev.y) * alpha;
    const ba = this.bPrev.a + (a - this.bPrev.a) * alpha;
    this.riderRoot.position.set(bx, by, 0);
    this.riderRoot.rotation.set(0, 0, ba);
    const v = b.getLinearVelocity();
    const speed = Math.hypot(v.x, v.y);
    const fwd = v.x * Math.cos(a) + v.y * Math.sin(a);
    this.wheelSpin -= (fwd * gdt) / WHEEL_R;
    for (const w of this.boardVis.wheels) w.rotation.z = this.wheelSpin;

    if (this.phase === 'menu' || this.phase === 'playing') {
      const tr = this.trick;
      const trickTime = tr ? tr.t + alpha * PHYS_DT : 0;
      this.pose = tr ? trickPose(tr.def.kind, trickTime, tr.dur, tr.dir, tr.freestyle) : { ...ZERO_POSE };
      if (this.releasePose) {
        this.releasePose.elapsed += gdt;
        const { from, elapsed } = this.releasePose;
        const u = clamp(1 - elapsed / (tr ? 0.11 : 0.17), 0, 1);
        const k = u * u * (3 - 2 * u);
        for (const axis of Object.keys(from) as (keyof TrickPose)[]) this.pose[axis] += from[axis] * k;
        if (u === 0) this.releasePose = null;
      }
      this.updateRig(gdt, speed);
      this.applyRig();
      if (tr) {
        const progress = trickTime / tr.dur;
        const power = clamp(Math.min(progress / 0.29, (1.048 - progress) / 0.23), 0, 1);
        this.deckTrail.tick(gdt, this.boardTrickG, power);
        if (progress >= 0.85) this.showFreestyleCatch();
      } else this.deckTrail.tick(gdt);
    } else {
      this.deckTrail.tick(gdt);
      this.spinG.rotation.set(0, 0, 0);
      this.boardTrickG.position.set(0, this.boardVis.float ? Math.sin(this.realTime * 4.5) * 0.035 : 0, 0);
      this.boardTrickG.rotation.set(0, 0, 0);
      for (const r of this.rag) {
        const rp = r.body.getPosition();
        const ra = r.body.getAngle();
        const x = r.px + (rp.x - r.px) * alpha;
        const y = r.py + (rp.y - r.py) * alpha;
        const ang = r.pa + (ra - r.pa) * alpha;
        r.mesh.position.set(x, y, r.z);
        this.tmpQ.setFromAxisAngle(Z_AXIS, ang).multiply(r.qRes);
        r.mesh.quaternion.copy(this.tmpQ);
      }
    }

    const roadY = this.heightAt(bx);
    const above = Math.max(0, by - roadY - RIDE_CLEAR);
    this.rideShadow.visible = !this.gapAt(bx) && above < 6.5 && by >= roadY;
    this.rideShadow.position.set(bx + above * 0.21, roadY + 0.019, -above * 0.08);
    this.rideShadow.rotation.set(-Math.PI / 2, 0, this.slopeAt(bx));
    this.rideShadow.scale.setScalar(1 + above * 0.16);
    this.rideShadow.material.opacity = clamp(0.76 - above * 0.12, 0, 1);

    const t = this.realTime;
    for (const pc of this.pieces) {
      for (const c of pc.coins) {
        if (c.taken) continue;
        c.mesh.rotation.y = t * 3 + c.phase;
        c.mesh.position.y = c.y + Math.sin(t * 3 + c.phase) * 0.08;
      }
      if (pc.waterMesh) pc.waterMesh.position.y = Math.sin(t * 1.6 + pc.data.id) * 0.07;
    }
    if (this.tumblingCones.length && gdt > 0) {
      this.tumblingCones = this.tumblingCones.filter((cone) => cone.advance(gdt, this.coneFloor));
    }

    this.particles.update(gdt);
    this.updateCamera(rdt, bx, by);
    this.updateBackground();
    this.sfx.update(speed, this.grounded, this.phase === 'playing');

    this.hudTimer -= rdt;
    if (this.hudTimer <= 0) {
      this.hudTimer = 0.1;
      this.emitHud();
    }
    if (this.phase === 'crashed') {
      this.crashTimer += rdt;
      if (this.crashTimer > 2.35) this.toOver();
    } else if (this.phase === 'over') {
      this.overTime += rdt;
      this.crashTimer += rdt;
    }
    this.shake = Math.max(0, this.shake - rdt * 1.6);
  }

  private coneFloor = (x: number) => (this.gapAt(x) ? null : this.heightAt(x));

  private focusPoint(bx: number, by: number) {
    if ((this.phase === 'crashed' || this.phase === 'over') && this.rag.length) {
      const tp = this.rag[0].body.getPosition();
      const tv = this.rag[0].body.getLinearVelocity();
      return { x: tp.x, y: tp.y, vx: tv.x * 0.4 };
    }
    return { x: bx, y: by, vx: this.board.getLinearVelocity().x };
  }

  private snapCamera() {
    const f = this.focusPoint(this.board.getPosition().x, this.board.getPosition().y);
    this.camT.set(f.x, f.y + 0.75, 0);
    this.camDist = 10;
    this.updateCamera(0, f.x, f.y);
  }

  private updateCamera(dt: number, bx: number, by: number) {
    const w = this.container.clientWidth || 1;
    const h = this.container.clientHeight || 1;
    const aspect = w / h;
    if (Math.abs(this.camera.aspect - aspect) > 1e-3) {
      this.camera.aspect = aspect;
      this.camera.updateProjectionMatrix();
    }
    const f = this.focusPoint(bx, by);
    const v = this.board.getLinearVelocity();
    const speed = Math.hypot(v.x, v.y);
    const tanH = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
    const ground = this.heightAt(f.x + 6);
    const above = Math.max(0, f.y - this.heightAt(f.x) - 1.2);
    let halfW = (aspect < 1 ? 5.4 : 11.2) + Math.min(Math.max(speed - 9, 0), 16) * (aspect < 1 ? 0.19 : 0.28);
    let halfH = 5.1 + above * 0.39;
    let look = clamp((aspect < 1 ? 1.5 : 3.2) + f.vx * 0.22, -2, halfW * 0.49);
    let ty = f.y * 0.56 + ground * 0.44 + 1.6;
    if (this.phase === 'menu') {
      halfW = aspect < 1 ? 4.2 : 6;
      halfH = 3.4;
      look = this.preview ? halfW * (aspect < 1 ? 0 : 0.5) : 0;
      ty = f.y + (this.preview && aspect < 1 ? -0.9 : 0.75);
    } else if (this.phase === 'crashed' || this.phase === 'over') {
      halfW *= 0.76;
      halfH *= 0.76;
      look = clamp(f.vx * 0.22, -1.4, 1.8);
      ty = f.y + 0.8;
    }
    const dist = Math.max(halfW / (tanH * aspect), halfH / tanH);
    const kz = dt > 0 ? 1 - Math.exp(-dt * 2.2) : 1;
    const kx = dt > 0 ? 1 - Math.exp(-dt * 6) : 1;
    const ky = dt > 0 ? 1 - Math.exp(-dt * 3.4) : 1;
    this.camDist += (dist - this.camDist) * kz;
    this.camT.x += (f.x + look - this.camT.x) * kx;
    this.camT.y += (ty - this.camT.y) * ky;
    const d = this.camDist;
    const sh = this.shake;
    const sx = Math.sin(this.realTime * 57) * sh * 0.32;
    const sy = Math.sin(this.realTime * 71) * sh * 0.35;
    this.camera.position.set(this.camT.x - d * 0.03 + sx, this.camT.y + d * 0.105 + sy, d);
    this.camera.lookAt(this.camT.x + sx * 0.5, this.camT.y + sy * 0.5, 0);

    this.sun.position.set(this.camT.x - 14, this.camT.y + 26, 22);
    this.sun.target.position.set(this.camT.x + 2, this.camT.y - 2, -2);
    this.water.position.x = this.camT.x;
  }

  private updateBackground() {
    const x = -Math.sin(this.camT.x * 0.013) * 3.75;
    const y = clamp(this.camT.y * 0.44, -3.4, 3.4);
    this.backdrop.style.transform = `translate3d(${x.toFixed(2)}%, ${y.toFixed(2)}%, 0) scale(1.1)`;
  }
}
