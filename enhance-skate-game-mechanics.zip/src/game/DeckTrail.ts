import { Vector2, Vector3 } from 'three';
import type { Object3D } from 'three';
import { DECK_HW } from './constants';
import type { PlaceId } from './themes';
import type { TrickFamily } from './tricks';

type Ink = { glow: string; mid: string; light: string };
type Sample = { world: Vector3; time: number; power: number };
type Ribbon = { samples: Sample[]; ink: Ink; side: number; life: number; width: number };
type Glint = { world: Vector3; time: number; ink: Ink; scale: number };
type Project = (world: Vector3, screen: Vector2) => void;

const honey = { glow: '#f09546', mid: '#ffbf64', light: '#fff3d3' };
const lime = { glow: '#b5d653', mid: '#ddf680', light: '#f5ffd2' };
const ember = { glow: '#f6865b', mid: '#ffc098', light: '#fff0d3' };
const orchid = { glow: '#ab85e8', mid: '#dabaff', light: '#fbecff' };
const INV_SQRT2 = Math.SQRT1_2;

export class DeckTrail {
  readonly canvas = document.createElement('canvas');
  private ctx: CanvasRenderingContext2D;
  private ribbons: Ribbon[] = [];
  private live: Ribbon[] = [];
  private glints: Glint[] = [];
  private clock = 0;
  private width = 1;
  private height = 1;
  private pixelRatio = 1;
  private drawn = false;
  private screen = new Vector2();
  private reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  constructor() {
    this.ctx = this.canvas.getContext('2d')!;
    this.canvas.className = 'deck-trail';
    this.canvas.setAttribute('aria-hidden', 'true');
  }

  resize(w: number, h: number) {
    this.width = w;
    this.height = h;
    this.pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);
    this.canvas.width = Math.round(w * this.pixelRatio);
    this.canvas.height = Math.round(h * this.pixelRatio);
    this.ctx.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);
  }

  begin(place: PlaceId, family: TrickFamily, freestyle: boolean) {
    const accent = place === 'shibuya' ? orchid : place === 'tokyo' ? ember : lime;
    const lead = family === 'spin' ? accent : honey;
    const inks = [lead, family === 'spin' ? honey : accent];
    this.live = inks.slice(0, this.reduced ? 1 : 2).map((ink, i) => ({
      samples: [], ink, side: i ? 1 : -1,
      life: this.reduced ? 0.16 : (freestyle ? 0.34 - i * 0.08 : 0.21 - i * 0.05),
      width: (freestyle ? 4.5 : 2.45) * (i ? 0.6 : 1),
    }));
    this.ribbons.push(...this.live);
  }

  end() { this.live = []; }

  tick(dt: number, deck: Object3D | null = null, power = 0) {
    this.clock += dt;
    if (deck && power > 0.02) {
      deck.updateWorldMatrix(true, false);
      for (const ribbon of this.live) {
        const last = ribbon.samples[ribbon.samples.length - 1];
        if (last && this.clock - last.time < 0.0105) continue;
        // Store the deck tips in world space so the curves stay in place as the camera scrolls.
        const s = ribbon.side;
        const tip = new Vector3(s * DECK_HW * 0.94, -0.025, -s * 0.205).applyMatrix4(deck.matrixWorld);
        ribbon.samples.push({ world: tip, time: this.clock, power });
      }
    }
    for (const ribbon of this.ribbons) {
      while (ribbon.samples.length && this.clock - ribbon.samples[0].time > ribbon.life) ribbon.samples.shift();
    }
    this.ribbons = this.ribbons.filter((r) => r.samples.length || this.live.includes(r));
    this.glints = this.glints.filter((g) => this.clock - g.time < 0.21);
  }

  catchDeck(deck: Object3D) {
    if (this.reduced || !this.live.length) return;
    const { ink } = this.live[0];
    deck.updateWorldMatrix(true, false);
    for (const [x, y, size] of [[0.63, 0.045, 1], [-0.46, -0.08, 0.46]]) {
      const world = new Vector3(x, y, 0.15).applyMatrix4(deck.matrixWorld);
      this.glints.push({ world, time: this.clock, ink, scale: size });
    }
  }

  paint(project: Project) {
    const visible = this.ribbons.some((r) => r.samples.length > 1) || this.glints.length > 0;
    if (!visible && !this.drawn) return;
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.width, this.height);
    this.drawn = visible;
    const unit = Math.min(1.45, Math.max(0.65, this.height / 485));
    for (const ribbon of this.ribbons) this.paintRibbon(ribbon, unit, project);
    for (const glint of this.glints) this.paintGlint(glint, unit, project);
    ctx.globalAlpha = 1;
  }

  private point(world: Vector3, project: Project) {
    project(world, this.screen);
    return { x: (this.screen.x + 1) * 0.5 * this.width, y: (1 - this.screen.y) * 0.5 * this.height };
  }

  private paintRibbon(ribbon: Ribbon, unit: number, project: Project) {
    const { samples, life, ink } = ribbon;
    if (samples.length < 2) return;
    const ctx = this.ctx;
    const pts = samples.map(({ world, time, power }) => ({ ...this.point(world, project), age: this.clock - time, power }));
    const first = pts[0];
    const last = pts[pts.length - 1];
    if (Math.hypot(last.x - first.x, last.y - first.y) < 1.5 && pts.length < 4) return;
    const fade = Math.max(0, 1 - last.age / life) ** 1.15;
    const shape = (scale: number, alpha: number, colors: string[]) => {
      const edge = (side: number) => pts.map((p, i) => {
        const prev = pts[Math.max(0, i - 1)];
        const next = pts[Math.min(pts.length - 1, i + 1)];
        const dx = next.x - prev.x;
        const dy = next.y - prev.y;
        const rise = Math.min(1, i / Math.max(2, (pts.length - 1) * 0.74));
        const wide = (0.045 + rise ** 0.72 * Math.sqrt(Math.max(0, 1 - p.age / life)) * (0.28 + p.power * 0.72));
        const width = side * scale * unit * ribbon.width * wide / Math.max(0.01, Math.hypot(dx, dy));
        return { x: p.x - dy * width, y: p.y + dx * width };
      });
      const outline = (line: ReturnType<typeof edge>, start: boolean) => {
        if (start) ctx.moveTo(line[0].x, line[0].y); else ctx.lineTo(line[0].x, line[0].y);
        for (let i = 1; i < line.length - 1; i++) {
          ctx.quadraticCurveTo(line[i].x, line[i].y, (line[i].x + line[i + 1].x) * 0.5, (line[i].y + line[i + 1].y) * 0.5);
        }
        const end = line[line.length - 1];
        ctx.lineTo(end.x, end.y);
      };
      ctx.beginPath();
      outline(edge(1), true);
      outline(edge(-1).reverse(), false);
      ctx.closePath();
      const gradient = ctx.createLinearGradient(first.x, first.y, last.x + 0.001, last.y);
      gradient.addColorStop(0, `${colors[0]}00`);
      gradient.addColorStop(0.43, `${colors[0]}aa`);
      gradient.addColorStop(0.82, colors[1]);
      gradient.addColorStop(1, colors[2]);
      ctx.globalAlpha = fade * alpha * (ribbon.side < 0 ? 1 : 0.73);
      ctx.fillStyle = gradient;
      ctx.fill();
    };
    if (!this.reduced) shape(2.2, 0.25, [ink.glow, ink.glow, ink.mid]);
    shape(1, 0.94, [ink.glow, ink.mid, ink.light]);
    if (!this.reduced) shape(0.3, 0.66, [ink.mid, ink.light, '#fffbe4']);
  }

  private paintGlint(glint: Glint, unit: number, project: Project) {
    const ctx = this.ctx;
    const progress = (this.clock - glint.time) / 0.21;
    const p = this.point(glint.world, project);
    const size = (4.5 + 5.5 * Math.sin(Math.PI * progress * 0.8)) * unit * glint.scale;
    ctx.save();
    ctx.translate(p.x - progress * 11, p.y + progress * 3);
    ctx.rotate(-0.48);
    ctx.globalAlpha = (1 - progress) ** 1.25 * Math.min(1, 0.43 + progress * 8);
    ctx.fillStyle = glint.ink.light;
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const angle = i * Math.PI / 4;
      const r = i % 2 ? size * INV_SQRT2 * 0.26 : size;
      ctx.lineTo(Math.cos(angle) * r, Math.sin(angle) * r * 0.74);
    }
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  clear() {
    this.ribbons = [];
    this.live = [];
    this.glints = [];
    this.clock = 0;
    this.ctx.clearRect(0, 0, this.width, this.height);
    this.drawn = false;
  }
}