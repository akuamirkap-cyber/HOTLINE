import { Color, Matrix4, Vector3 } from 'three';
import type { InstancedMesh, Mesh, Object3D, PerspectiveCamera, Vector2 } from 'three';
import { BOTTOM_Y, CONE_HEIGHT, CONE_HALF, ROAD_HALF, WATER_Y, Z_BACK, Z_FRONT } from './constants';
import type { BuiltPiece, TPoint } from './terrain';
import { baseAt, surfAt } from './terrain';
import type { PlaceTheme } from './themes';

interface FlatFrame {
  camera: PerspectiveCamera;
  target: Vector3;
  pieces: BuiltPiece[];
  theme: PlaceTheme;
  rider: Object3D[];
  particles: InstancedMesh;
  shadow: { position: Vector3; visible: boolean; opacity: number };
}

type Triangle = { z: number; color: string; a: Vector3; b: Vector3; c: Vector3 };
const ink = (hex: number) => `#${hex.toString(16).padStart(6, '0')}`;
const tilt = 0.137;

/** Canvas fallback: it projects the same rig and obstacles, without running another simulation. */
export class FlatRenderer {
  readonly domElement = document.createElement('canvas');
  private ctx: CanvasRenderingContext2D;
  private w = 1;
  private h = 1;
  private dpr = 1;
  private tx = 0;
  private ty = 0;
  private scale = 1;
  private triangles: Triangle[] = [];
  private normal = new Vector3();
  private color = new Color();
  private instance = new Matrix4();

  constructor() {
    const ctx = this.domElement.getContext('2d');
    if (!ctx) throw new Error('Canvas rendering is unavailable');
    this.ctx = ctx;
  }

  setSize(w: number, h: number) {
    this.w = w;
    this.h = h;
    this.dpr = Math.min(1.4, window.devicePixelRatio || 1);
    this.domElement.width = Math.round(w * this.dpr);
    this.domElement.height = Math.round(h * this.dpr);
  }

  private x(x: number) { return this.w * 0.5 + (x - this.tx) * this.scale; }
  private y(y: number, z = 0) { return this.h * 0.5 + (this.ty - y + z * tilt) * this.scale; }

  projectToNdc(world: Vector3, screen: Vector2) {
    screen.set(this.x(world.x) * 2 / this.w - 1, 1 - this.y(world.y, world.z) * 2 / this.h);
  }

  paint(frame: FlatFrame) {
    const g = this.ctx;
    const { camera, target, pieces, theme, rider, shadow } = frame;
    this.tx = target.x;
    this.ty = target.y;
    this.scale = this.h / (2 * camera.position.z * Math.tan(camera.fov * Math.PI / 360));
    g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    g.clearRect(0, 0, this.w, this.h);
    const water = this.y(WATER_Y, Z_BACK);
    if (water < this.h) {
      g.fillStyle = ink(theme.water);
      g.fillRect(0, water, this.w, this.h - water);
    }

    for (const piece of pieces) {
      if (this.x(piece.data.minX) > this.w + 20 || this.x(piece.data.maxX) < -20) continue;
      this.paintTrack(piece, theme);
    }
    if (shadow.visible && shadow.opacity > 0) {
      g.fillStyle = `rgba(15, 21, 16, ${shadow.opacity * 0.68})`;
      g.beginPath();
      g.ellipse(this.x(shadow.position.x), this.y(shadow.position.y), this.scale * 0.88, this.scale * 0.075, 0, 0, Math.PI * 2);
      g.fill();
    }
    this.paintParticles(frame.particles);
    this.triangles.length = 0;
    for (const part of rider) {
      part.updateWorldMatrix(true, true);
      part.traverseVisible((node) => { if ((node as Mesh).isMesh) this.projectMesh(node as Mesh); });
    }
    this.triangles.sort((a, b) => a.z - b.z);
    g.lineWidth = 0.55;
    for (const { a, b, c, color } of this.triangles) {
      g.fillStyle = g.strokeStyle = color;
      g.beginPath();
      g.moveTo(this.x(a.x), this.y(a.y, a.z));
      g.lineTo(this.x(b.x), this.y(b.y, b.z));
      g.lineTo(this.x(c.x), this.y(c.y, c.z));
      g.closePath();
      g.fill();
      g.stroke();
    }
  }

  private paintTrack(piece: BuiltPiece, theme: PlaceTheme) {
    const g = this.ctx;
    const { data, rails, coins, cones } = piece;
    const { pts } = data;
    const pal = theme.palette;
    const from = Math.max(0, pts.findIndex((p) => this.x(p.x) >= -85) - 1);
    const tail = pts.findIndex((p) => this.x(p.x) > this.w + 85);
    const path = pts.slice(from, tail < 0 ? undefined : tail + 1);
    const band = (up: (p: TPoint) => number, down: (p: TPoint) => number, fill: string) => {
      g.beginPath();
      path.forEach((p, i) => i ? g.lineTo(this.x(p.x), up(p)) : g.moveTo(this.x(p.x), up(p)));
      for (let i = path.length - 1; i >= 0; i--) g.lineTo(this.x(path[i].x), down(path[i]));
      g.closePath();
      g.fillStyle = fill;
      g.fill();
    };
    band((p) => this.y(p.y - 3.9, Z_FRONT), () => this.y(BOTTOM_Y, Z_FRONT), ink(pal.rock));
    band((p) => this.y(p.y - 1.55, Z_FRONT), (p) => this.y(p.y - 3.91, Z_FRONT), ink(pal.dirt));
    band((p) => this.y(p.y - 0.28, Z_FRONT), (p) => this.y(p.y - 1.56, Z_FRONT), ink(pal.topsoil));
    band((p) => this.y(p.y, Z_FRONT), (p) => this.y(p.y - 0.3, Z_FRONT), ink(pal.asphaltEdge));
    band((p) => this.y(p.base, Z_BACK), (p) => this.y(p.y, -ROAD_HALF + 0.06), ink(pal.grassA));
    band((p) => this.y(p.y, -ROAD_HALF), (p) => this.y(p.y, Z_FRONT + 0.04), ink(pal.asphalt));
    band((p) => this.y(p.y, ROAD_HALF), (p) => this.y(p.y - 0.1, Z_FRONT), ink(pal.curbR));
    this.trackLine(path, 0.06, 0.032, '#e0d4b0a6', [0.8, 1.13]);
    this.trackLine(path, Z_FRONT - 0.08, 0.086, ink(pal.curbW), [0.86, 0.87]);

    for (const prop of data.decor) {
      const x = this.x(prop.x);
      if (x < -80 || x > this.w + 80) continue;
      const y = this.y(baseAt(pts, prop.x), prop.z);
      const s = (prop.s ?? 1) * this.scale;
      if (prop.kind === 'pine' || prop.kind === 'tree') {
        g.fillStyle = '#514535';
        g.fillRect(x - s * 0.074, y - s * 1.1, s * 0.15, s * 1.1);
        g.fillStyle = '#334a35';
        for (let i = 0; i < 3; i++) {
          const base = y - s * (0.24 + i * 0.47);
          const r = s * (0.61 - i * 0.125);
          g.beginPath(); g.moveTo(x - r, base); g.lineTo(x, base - s * 1.05); g.lineTo(x + r, base); g.fill();
        }
      } else if (prop.kind === 'lamp') {
        g.strokeStyle = '#555748'; g.lineWidth = s * 0.092;
        g.beginPath(); g.moveTo(x, y); g.lineTo(x, y - s * 2.4); g.lineTo(x + s * 0.64, y - s * 2.4); g.stroke();
      } else if (prop.kind === 'rock' || prop.kind === 'bush') {
        g.fillStyle = prop.kind === 'rock' ? '#827f6d' : '#465c3a';
        g.beginPath(); g.moveTo(x - s * 0.44, y); g.lineTo(x - s * 0.37, y - s * 0.25);
        g.lineTo(x + s * 0.22, y - s * 0.32); g.lineTo(x + s * 0.48, y); g.fill();
      }
    }

    for (const rail of rails) {
      if (this.x(rail.x1) < -20 || this.x(rail.x0) > this.w + 20) continue;
      g.strokeStyle = '#c9c9b3'; g.lineWidth = Math.max(1.2, this.scale * 0.095);
      g.beginPath();
      rail.pts.forEach(({ x, y }, i) => i ? g.lineTo(this.x(x), this.y(y)) : g.moveTo(this.x(x), this.y(y)));
      g.stroke();
      for (const { x, y } of rail.pts.filter((_, i) => i % 3 === 0)) {
        g.strokeStyle = '#9b9b8c';
        g.beginPath(); g.moveTo(this.x(x), this.y(y)); g.lineTo(this.x(x), this.y(surfAt(pts, x))); g.stroke();
      }
    }
    for (const coin of coins) {
      const x = this.x(coin.x);
      if (coin.taken || x < -20 || x > this.w + 20) continue;
      g.fillStyle = '#ecbd49'; g.strokeStyle = '#ffdf88'; g.lineWidth = 1.4;
      const r = this.scale * 0.21;
      g.beginPath(); g.ellipse(x, this.y(coin.mesh.position.y), r * (0.27 + 0.73 * Math.abs(Math.cos(coin.mesh.rotation.y))), r, 0, 0, Math.PI * 2);
      g.fill(); g.stroke();
    }

    for (const cone of cones) {
      if (!cone.mesh.visible) continue;
      const p = cone.mesh.position;
      const x = this.x(p.x);
      if (x < -25 || x > this.w + 25) continue;
      const s = this.scale;
      g.save();
      g.translate(x, this.y(p.y, p.z));
      g.rotate(-cone.mesh.rotation.z);
      g.fillStyle = '#ad462d';
      g.fillRect(-CONE_HALF * s, -0.09 * s, 2 * CONE_HALF * s, 0.1 * s);
      g.beginPath(); g.moveTo(-0.236 * s, -0.09 * s); g.lineTo(-0.044 * s, -CONE_HEIGHT * s);
      g.lineTo(0.044 * s, -CONE_HEIGHT * s); g.lineTo(0.236 * s, -0.09 * s); g.closePath();
      g.fillStyle = '#f57037'; g.fill(); g.clip();
      g.fillStyle = '#ffe5b1';
      for (const y of [-0.64, -0.4]) g.fillRect(-0.3 * s, y * s, 0.6 * s, 0.105 * s);
      g.restore();
    }
  }

  private trackLine(pts: TPoint[], z: number, width: number, color: string, dash: number[]) {
    if (!pts.length) return;
    const g = this.ctx;
    g.setLineDash(dash.map((v) => v * this.scale));
    g.lineDashOffset = pts[0].x * this.scale;
    g.lineWidth = Math.max(1, width * this.scale);
    g.strokeStyle = color;
    g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(this.x(p.x), this.y(p.y, z)) : g.moveTo(this.x(p.x), this.y(p.y, z)));
    g.stroke(); g.setLineDash([]);
  }

  private projectMesh(mesh: Mesh) {
    const { attributes: { position, color, normal }, index } = mesh.geometry;
    if (!position || !normal) return;
    const matrix = mesh.matrixWorld;
    const points: Vector3[] = [];
    const len = index?.count ?? position.count;
    for (let i = 0; i < len; i += 3) {
      const ia = index?.getX(i) ?? i;
      this.normal.set(normal.getX(ia), normal.getY(ia), normal.getZ(ia)).transformDirection(matrix);
      if (this.normal.z + this.normal.y * tilt <= 0.001) continue;
      const at = (id: number) => points[id] ??= new Vector3(position.getX(id), position.getY(id), position.getZ(id)).applyMatrix4(matrix);
      const a = at(ia);
      const b = at(index?.getX(i + 1) ?? i + 1);
      const c = at(index?.getX(i + 2) ?? i + 2);
      if (color) this.color.setRGB(color.getX(ia), color.getY(ia), color.getZ(ia)); else this.color.set(0xf3e4be);
      const lit = Math.max(0.68, 0.86 + 0.23 * this.normal.y - 0.16 * this.normal.x);
      this.color.multiplyScalar(lit);
      this.triangles.push({ a, b, c, color: this.color.getStyle(), z: (a.z + b.z + c.z) + tilt * (a.y + b.y + c.y) });
    }
  }

  private paintParticles(particles: InstancedMesh) {
    const g = this.ctx;
    for (let i = 0; i < particles.count; i++) {
      particles.getMatrixAt(i, this.instance);
      particles.getColorAt(i, this.color);
      const m = this.instance.elements;
      const size = Math.hypot(m[0], m[1], m[2]) * this.scale;
      g.fillStyle = this.color.getStyle();
      g.fillRect(this.x(m[12]) - size * 0.5, this.y(m[13], m[14]) - size * 0.25, size, size * 0.52);
    }
  }

  dispose() { this.triangles.length = 0; }
}