import type { ReactNode } from 'react';

const shapes = {
  skate: <g transform="rotate(-42 12 12)"><rect x="2.35" y="8.55" width="19.3" height="6.9" rx="3.45"/><path d="M7.5 8.5v-2m0 9v2m9-9v-2m0 9v2m-6-5.5h3"/></g>,
  volume: <><path d="M11 5 6 9H3v6h3l5 4V5Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7m3-10a9 9 0 0 1 0 13"/></>,
  mute: <><path d="M11 5 6 9H3v6h3l5 4V5Z"/><path d="m16 9 5 6m0-6-5 6"/></>,
  pin: <><path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="2.6"/></>,
  expand: <path d="M8 4H4v4m12-4h4v4M4 16v4h4m12-4v4h-4"/>,
  contract: <path d="M4 8h4V4m12 4h-4V4M8 20v-4H4m12 4v-4h4"/>,
  play: <path d="M8 4.5 20 12 8 19.5Z" fill="currentColor" strokeLinejoin="round"/>,
  pause: <><path d="M9 5.5v13m6-13v13" strokeWidth="2.6"/></>,
  down: <path d="m6 9 6 6 6-6"/>,
  right: <path d="m9 6 6 6-6 6"/>,
  arrowRight: <path d="M4 12h15m-6-6 6 6-6 6"/>,
  arrowLeft: <path d="M20 12H5m6-6-6 6 6 6"/>,
  arrowUp: <path d="M12 20V5m-6 6 6-6 6 6"/>,
  diagonal: <path d="M6 18 18 6M7 6h11v11"/>,
  keyboard: <><rect x="2.5" y="5.5" width="19" height="13" rx="2"/><path d="M6.5 10h.1m3.5 0h.1m3.6 0h.1m3.5 0h.1m-11 4h.1m3.2 0h7.8"/></>,
  mouse: <><rect x="6" y="3" width="12" height="18" rx="6"/><path d="M12 3v7H6"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  checkCircle: <><circle cx="12" cy="12" r="9"/><path d="m8 12 2.6 2.6L16 9"/></>,
  cone: <><path d="M3 19h18M6 18 10.6 5h2.8L18 18m-9.8-6h7.6m-9.1 4h10.6"/></>,
  coin: <><circle cx="12" cy="12" r="8.5"/><path d="M12 8v8m-2-7 2-1"/></>,
  trophy: <><path d="M8 21h8m-4-5v5M7 4h10v7a5 5 0 0 1-10 0V4Zm0 2H3v2a4 4 0 0 0 4 4m10-6h4v2a4 4 0 0 1-4 4"/></>,
  close: <path d="m6 6 12 12M18 6 6 18"/>,
  redo: <><path d="M5 10a7 7 0 1 1 .4 5M5 5v5h5"/></>,
  bolt: <path d="m13 2-8 12h6l-1 8 9-13h-6l1-7Z"/>,
  spark: <><path d="M12 2v6m0 8v6M2 12h6m8 0h6m-15-5 2 2m6 6 2 2m0-10-2 2m-6 6-2 2"/></>,
  hand: <path d="M7 12V6.5a1.5 1.5 0 0 1 3 0V10 4.5a1.5 1.5 0 0 1 3 0V10 6a1.5 1.5 0 0 1 3 0v5-2.5a1.5 1.5 0 0 1 3 0V14c0 4.4-2.1 7-6 7a6 6 0 0 1-5-2.5L4.1 14a1.6 1.6 0 0 1 2.4-2Z"/>,
} satisfies Record<string, ReactNode>;

export type IconName = keyof typeof shapes;

export function Icon({ name, size = 20, className }: { name: IconName; size?: number; className?: string }) {
  return <svg className={className} width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{shapes[name]}</svg>;
}

export function Keycap({ value }: { value: string }) {
  return <kbd>{value === 'ArrowRight' ? <><Icon name="arrowRight" size={13} /><span className="sr-only">Panah kanan</span></>
    : value === 'ArrowLeft' ? <><Icon name="arrowLeft" size={13} /><span className="sr-only">Panah kiri</span></> : value}</kbd>;
}