import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { BOARDS, CHARS, getBoard, getChar } from '../game/skins';
import { PLACES, getPlace } from '../game/themes';
import { GRAB_CYCLE, TRICK_MAP, TRICKS } from '../game/tricks';
import type { TrickFamily } from '../game/tricks';
import { Icon, Keycap } from './Icon';

export type DialogKind = 'tricks' | 'records' | 'garage' | 'place' | 'controls';
export type Skin = { charId: string; boardId: string };
export type Session = { at: number; score: number; distance: number; cones: number; place: string };
export const ART_DIR = `${import.meta.env.BASE_URL}art/`;
export const number = (n: number) => n.toLocaleString('id-ID');

const dialogNames: Record<DialogKind, [string, string]> = {
  tricks: ['PANDUAN SESI', 'Buku Trik'],
  records: ['SKATECLUB / LOKAL', 'Rekor Sesi'],
  garage: ['PILIH PERLENGKAPAN', 'Garasi'],
  place: ['PILIH LINTASAN', 'Arena'],
  controls: ['SIAP MELUNCUR', 'Kontrol'],
};

export function ArcadeDialog({ kind, onClose, children }: { kind: DialogKind; onClose(): void; children: ReactNode }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [label, title] = dialogNames[kind];
  useEffect(() => {
    const node = dialog.current;
    if (!node) return;
    node.showModal();
    return () => { if (node.open) node.close(); };
  }, []);

  return (
    <dialog ref={dialog} className="arcade-dialog" aria-labelledby="dialog-title"
      onCancel={(e) => { e.preventDefault(); onClose(); }} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="dialog-body">
        <header className="dialog-header">
          <div><div className="tiny-label">{label}</div><h2 id="dialog-title">{title}</h2></div>
          <button type="button" className="icon-button close-dialog" aria-label="Tutup" onClick={onClose}><Icon name="close" /></button>
        </header>
        {children}
      </div>
    </dialog>
  );
}

export function TrickBook() {
  const [filter, setFilter] = useState<TrickFamily | 'all'>('all');
  const filters = [{ id: 'all', title: 'Semua' }, { id: 'flip', title: 'Flip' }, { id: 'grab', title: 'Grab' }, { id: 'spin', title: 'Spin' }] as const;
  const visible = filter === 'grab' ? [...GRAB_CYCLE.map((kind) => TRICK_MAP[kind]), ...TRICKS.filter((def) => def.family === 'grab' && !GRAB_CYCLE.includes(def.kind))]
    : TRICKS.filter((def) => filter === 'all' || def.family === filter);
  return <>
    <div className="dialog-note"><Keycap value="S" /><p>Tekan saat di udara untuk bergantian melakukan <strong>Indy Grab, Melon Grab,</strong> dan <strong>Airwalk</strong>.</p></div>
    <div className="filter-tabs" aria-label="Kategori trik">
      {filters.map(({ id, title }) => <button key={id} type="button" aria-pressed={filter === id} onClick={() => setFilter(id)}>{title}</button>)}
    </div>
    <ul className="trick-list">
      {visible.map((trick) => (
        <li key={trick.kind}>
          <div><strong>{trick.name}</strong><p>{trick.desc}{trick.bigAirOnly ? ' (butuh lompatan tinggi)' : ''}</p></div>
          <span className="trick-points">+{trick.pts}</span>
        </li>
      ))}
    </ul>
  </>;
}

const controlRows = [
  { keys: ['SPACE', 'W'], action: 'Lompat', detail: 'Tekan sebelum cone atau di ujung lintasan untuk melewati jurang.' },
  { keys: ['S'], action: 'Grab', detail: 'Indy, Melon, dan Airwalk bergantian saat di udara.' },
  { keys: ['F'], action: 'Freestyle', detail: 'Tekan F saat di udara, atau klik kiri di lintasan untuk lompat sekaligus melakukan trik.' },
  { keys: ['ArrowRight', 'D'], action: 'Gas', detail: 'Tahan untuk boost. Klik kanan juga bisa.' },
  { keys: ['ArrowLeft', 'A'], action: 'Rem / Salto', detail: 'Tahan untuk mengerem di tanah atau salto saat melayang.' },
  { keys: ['Z', 'X', 'C'], action: 'Flip / Grab / Spin', detail: 'Pilih keluarga trik saat kamu di udara.' },
  { keys: ['ESC', 'R'], action: 'Jeda / Ulangi', detail: 'Jeda dengan Esc atau mulai sesi baru dengan R.' },
];

export function ControlGuide() {
  return <>
    <div className="dialog-note"><Icon name="checkCircle" /><p><strong>Auto-Land aktif.</strong> Papan mengikuti kemiringan lintasan. Cone yang tersenggol akan terpental dan hanya mengurangi kecepatan, termasuk saat boost.</p></div>
    <dl className="control-list">
      {controlRows.map(({ keys, action, detail }) => <div key={action}>
        <dt><strong>{action}</strong><span>{keys.map((key) => <Keycap key={key} value={key} />)}</span></dt>
        <dd>{detail}</dd>
      </div>)}
    </dl>
  </>;
}

export function ArenaPicker({ placeId, onPick }: { placeId: string; onPick(id: string): void }) {
  return <div className="arena-list">
    {PLACES.map((place, i) => <button type="button" key={place.id} aria-pressed={place.id === placeId} onClick={() => onPick(place.id)}>
      <img src={`${ART_DIR}${place.art}`} alt="" />
      <span className="arena-text"><small>ARENA 0{i + 1}</small><strong>{place.name}</strong><span>{place.desc}</span></span>
      {place.id === placeId ? <Icon name="checkCircle" /> : <Icon name="right" />}
    </button>)}
  </div>;
}

export function Garage({ skin, onApply }: { skin: Skin; onApply(skin: Skin): void }) {
  const [draft, setDraft] = useState(skin);
  const [preview, setPreview] = useState({ animal: '', board: '' });
  const char = getChar(draft.charId);
  const board = getBoard(draft.boardId);

  useEffect(() => {
    let current = true;
    void import('../game/thumbs').then(({ charThumb, boardThumb }) => {
      if (current) setPreview({ animal: charThumb(char.id), board: boardThumb(board.id, char.deck) });
    }).catch(() => { /* The selector remains usable without thumbnails. */ });
    return () => { current = false; };
  }, [char, board]);

  return <form onSubmit={(e) => { e.preventDefault(); onApply(draft); }}>
    <div className="garage-grid">
      <label>
        <span className="gear-portrait" style={{ '--deck-color': char.deck } as React.CSSProperties}>
          {preview.animal ? <img alt="" src={preview.animal} /> : <Icon name="spark" size={34} />}
        </span>
        <span className="tiny-label">SKATER</span>
        <select value={draft.charId} onChange={(e) => setDraft({ ...draft, charId: e.target.value })}>
          {CHARS.map((animal) => <option key={animal.id} value={animal.id}>{animal.name}</option>)}
        </select>
        <span className="gear-description">{char.desc}</span>
      </label>
      <label>
        <span className="gear-portrait" style={{ '--deck-color': char.deck } as React.CSSProperties}>
          {preview.board ? <img alt="" src={preview.board} /> : <Icon name="skate" size={36} />}
        </span>
        <span className="tiny-label">PAPAN</span>
        <select value={draft.boardId} onChange={(e) => setDraft({ ...draft, boardId: e.target.value })}>
          {BOARDS.map((deck) => <option key={deck.id} value={deck.id}>{deck.name}</option>)}
        </select>
        <span className="gear-description">{board.desc}</span>
      </label>
    </div>
    <button type="submit" className="primary-button dialog-action"><Icon name="check" size={18} /> Pakai pilihan ini</button>
  </form>;
}

export function Records({ best, sessions, onPlay, inSession }: { best: number; sessions: Session[]; onPlay(): void; inSession: boolean }) {
  return <>
    <div className="record-headline"><Icon name="trophy" size={29} /><div><div className="tiny-label">SKOR TERBAIK</div><strong>{number(best)}</strong></div></div>
    {sessions.length ? <ol className="session-list" aria-label="Lima sesi terbaik">
      {[...sessions].sort((a, b) => b.score - a.score).slice(0, 5).map((run, i) => <li key={run.at}>
        <span className="rank">0{i + 1}</span><div><strong>{getPlace(run.place).name}</strong><small>{run.distance} m / {run.cones} cone</small></div>
        <span className="trick-points">{number(run.score)}</span>
      </li>)}
    </ol> : <p className="record-empty">Belum ada sesi selesai. Skormu akan tersimpan di perangkat ini setelah bermain.</p>}
    <button type="button" className="primary-button dialog-action" onClick={onPlay}><Icon name="play" size={16} />{inSession ? 'Kembali ke sesi' : 'Mulai main'}</button>
  </>;
}